from dataclasses import dataclass
from evolution_decision_controller_bridge import EvolutionDecisionControllerBridge
from evolution_cycle_audit import EvolutionCycleAudit


@dataclass(frozen=True)
class RuntimeResult:
    proposal_id: str
    decision: str
    score: float
    gate: str
    event_id: str


class EvolutionRuntime:
    """Coordinates signal assessment, decision gating and durable audit.

    The runtime coordinates existing components; it never activates a strategy
    by itself and never bypasses the Evolution Controller.
    """

    def __init__(self, bridge, audit):
        self.bridge = bridge
        self.audit = audit

    def evaluate(self, proposal_id, assessment, event_id):
        gate = self.bridge.assess(proposal_id, assessment)
        self.audit.record_assessment(gate, event_id)
        return RuntimeResult(
            proposal_id=gate.proposal_id,
            decision=gate.decision,
            score=gate.score,
            gate=gate.gate.value,
            event_id=event_id,
        )

    def request_activation(self, proposal_id, assessment, approval=False):
        return self.bridge.request_activation(
            proposal_id, assessment, approval=approval
        )
