"""Desktop process helpers for Rabidanti v5.2.

This module has no third-party dependencies. It provides a small single-instance
lease for the desktop/Sala launcher and user-visible startup error reporting for
frozen windowed builds.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import json
import os
import secrets
import signal
import sys
import time


class AlreadyRunningError(RuntimeError):
    pass


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


@dataclass
class DesktopInstanceLease:
    state_dir: Path
    filename: str = "desktop-instance.lock"
    _token: Optional[str] = None

    @property
    def path(self) -> Path:
        return self.state_dir / self.filename

    def _read_existing(self) -> dict:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, TypeError):
            return {}

    def acquire(self) -> dict:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        token = secrets.token_hex(16)
        payload = {
            "pid": os.getpid(),
            "token": token,
            "created_at": time.time(),
            "program": "Rabidanti",
        }
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        mode = 0o600
        try:
            fd = os.open(self.path, flags, mode)
        except FileExistsError:
            existing = self._read_existing()
            pid = int(existing.get("pid") or 0)
            if _pid_alive(pid):
                raise AlreadyRunningError(f"Rabidanti is already running (pid={pid})")
            # stale/corrupt lease: remove once, then retry atomically
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
            fd = os.open(self.path, flags, mode)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            if os.name != "nt":
                os.chmod(self.path, 0o600)
        except Exception:
            try:
                self.path.unlink()
            except OSError:
                pass
            raise
        self._token = token
        return payload

    def release(self) -> None:
        if not self._token:
            return
        existing = self._read_existing()
        if existing.get("token") == self._token and int(existing.get("pid") or 0) == os.getpid():
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
        self._token = None

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release()
        return False


def show_startup_error(message: str, title: str = "Rabidanti") -> None:
    """Show a startup error in desktop builds, with stderr as safe fallback."""
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(title, message)
        root.destroy()
        return
    except Exception:
        pass
    try:
        print(f"{title}: {message}", file=sys.stderr)
    except Exception:
        pass
