"""Rabidanti v3.62 — controlled evaluation of adaptive prioritization proposals.

Evaluates proposed weights in a historical shadow experiment. It never applies
weights, executes work, bypasses approvals, or treats retrospective association
as causal proof.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict

from adaptive_prioritization import AdaptationProposal
from priority_learning import PriorityLearningStore


@dataclass(frozen=True)
class AdaptationEvaluation:
    factor: str
    evidence_count: int
    completed_count: int
    failed_count: int
    baseline_gap: float
    proposed_gap: float
    improvement: float
    recommendation: str
    rationale: str

    def to_dict(self) -> dict:
        return asdict(self)


class AdaptiveExperimentEngine:
    """Shadow-test a single bounded adaptation against recorded outcomes."""

    MIN_GROUP = 3

    def __init__(self, store: PriorityLearningStore, current_weights: dict[str, float]):
        self.store = store
        self.weights = dict(current_weights)
        if not self.weights:
            raise ValueError("current_weights are required")
        if any(not isinstance(k, str) or not k for k in self.weights):
            raise ValueError("weight names must be non-empty strings")
        if any(not -1.0 <= float(v) <= 1.0 for v in self.weights.values()):
            raise ValueError("weights must be between -1 and 1")

    @staticmethod
    def _score(components: dict[str, float], weights: dict[str, float]) -> float:
        return sum(float(components.get(k, 0.0)) * float(v) for k, v in weights.items())

    def evaluate(self, proposal: AdaptationProposal) -> AdaptationEvaluation:
        if proposal.factor not in self.weights:
            raise ValueError("proposal factor is not in current weights")
        proposed_weights = dict(self.weights)
        proposed_weights[proposal.factor] = float(proposal.proposed_weight)
        outcomes = [o for o in self.store.list() if o.outcome in {"COMPLETED", "FAILED"}]
        usable = [o for o in outcomes if hasattr(o, "components") and all(k in o.components for k in self.weights)]
        completed = [o for o in usable if o.outcome == "COMPLETED"]
        failed = [o for o in usable if o.outcome == "FAILED"]
        if len(completed) < self.MIN_GROUP or len(failed) < self.MIN_GROUP:
            raise ValueError("insufficient completed/failed evidence")
        baseline_gap = self._gap(completed, failed, self.weights)
        proposed_gap = self._gap(completed, failed, proposed_weights)
        improvement = round(proposed_gap - baseline_gap, 6)
        recommendation = "PROMISING_SHADOW_RESULT" if improvement > 0 else "DO_NOT_ADOPT"
        rationale = (
            f"Historical score-gap change for {proposal.factor}: {improvement:+.6f}. "
            "This is retrospective evidence, not causal proof; approval and forward testing remain required."
        )
        return AdaptationEvaluation(
            proposal.factor, len(completed) + len(failed), len(completed), len(failed),
            round(baseline_gap, 6), round(proposed_gap, 6), improvement,
            recommendation, rationale,
        )

    def _gap(self, completed, failed, weights) -> float:
        cm = sum(self._score(o.components, weights) for o in completed) / len(completed)
        fm = sum(self._score(o.components, weights) for o in failed) / len(failed)
        return round(cm - fm, 6)
