# Rabidanti v3.99 — Controlled Change Authorization & Executor

## Objetivo
Converter uma proposta de integração v3.98 num change set imutável que só pode ser executado após autorização humana explícita ligada ao digest exato da alteração.

## Fluxo
Proposta v3.98 → Change set → Autorização explícita → Preflight → Backup → Aplicação em workspace → Verificação allowlisted → APPLIED ou ROLLED_BACK.

## Limites de autoridade
- O executor não se autoautoriza.
- Não autoriza ações externas.
- Não executa shell arbitrário.
- Só aceita caminhos relativos POSIX sem traversal.
- Só altera os ficheiros declarados exatamente na proposta.
- A autorização fica vinculada ao SHA-256 lógico do change set.
- O proposal digest é revalidado imediatamente antes da execução.

## Integridade e rollback
Para ficheiros existentes, o change set pode exigir o SHA-256 prévio. Para ficheiros novos, a existência inesperada bloqueia a execução. Antes da escrita é criado backup com manifesto. Qualquer falha de escrita ou teste restaura os bytes anteriores e remove ficheiros que não existiam antes.

## Verificação
Nesta versão, comandos de verificação aceites estão limitados a invocações diretas de pytest (`python -m pytest`, `python3 -m pytest`, `pytest`) sem shell. O output e return code são persistidos no ledger.

## Limitação
v3.99 é um mecanismo de alteração local controlada, não um sistema completo de deploy, sandbox de SO, assinatura criptográfica de identidade, CI remoto ou autorização para publicar/gastar/transferir.
