from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class SignalType(str, Enum):
    HEALTH = "health"
    PERFORMANCE = "performance"
    LEARNING = "learning"
    LABORATORY = "laboratory"
    WORLD_AWARENESS = "world_awareness"
    KNOWLEDGE = "knowledge"


@dataclass(frozen=True)
class EvolutionSignal:
    signal_id: str
    signal_type: SignalType
    metric: str
    value: float
    baseline: float
    confidence: float
    evidence_refs: tuple[str, ...] = ()

    @property
    def delta(self) -> float:
        return self.value - self.baseline


@dataclass(frozen=True)
class EvolutionProposal:
    proposal_id: str
    strategy_key: str
    rationale: str
    signal_ids: tuple[str, ...]
    confidence: float
    requires_approval: bool = True


class CoreEvolutionSignalBridge:
    """Converts observed signals into bounded, approval-gated evolution proposals.

    This layer proposes evolution only. It never activates, deploys, rolls back,
    or changes Core configuration by itself.
    """

    def __init__(self, controller):
        self.controller = controller
        self._signals: Dict[str, EvolutionSignal] = {}
        self._proposals: Dict[str, EvolutionProposal] = {}

    def record_signal(self, signal: EvolutionSignal) -> EvolutionSignal:
        if not signal.signal_id.strip():
            raise ValueError("signal_id is required")
        if not signal.metric.strip():
            raise ValueError("metric is required")
        if not 0.0 <= signal.confidence <= 1.0:
            raise ValueError("confidence must be between 0 and 1")
        if signal.signal_id in self._signals:
            raise ValueError("duplicate signal_id")
        self._signals[signal.signal_id] = signal
        return signal

    def get_signal(self, signal_id: str) -> EvolutionSignal:
        try:
            return self._signals[signal_id]
        except KeyError:
            raise KeyError("unknown signal_id")

    def propose(
        self,
        proposal_id: str,
        strategy_key: str,
        rationale: str,
        signal_ids: List[str],
        min_confidence: float = 0.70,
    ) -> EvolutionProposal:
        if not proposal_id.strip():
            raise ValueError("proposal_id is required")
        if proposal_id in self._proposals:
            raise ValueError("duplicate proposal_id")
        if not strategy_key.strip():
            raise ValueError("strategy_key is required")
        if not rationale.strip():
            raise ValueError("rationale is required")
        if not signal_ids:
            raise ValueError("at least one signal is required")
        if not 0.0 <= min_confidence <= 1.0:
            raise ValueError("min_confidence must be between 0 and 1")

        signals = [self.get_signal(sid) for sid in signal_ids]
        confidence = sum(s.confidence for s in signals) / len(signals)
        if confidence < min_confidence:
            raise ValueError("insufficient evidence confidence")

        proposal = EvolutionProposal(
            proposal_id=proposal_id,
            strategy_key=strategy_key,
            rationale=rationale,
            signal_ids=tuple(signal_ids),
            confidence=confidence,
            requires_approval=True,
        )
        self._proposals[proposal_id] = proposal
        return proposal

    def get_proposal(self, proposal_id: str) -> EvolutionProposal:
        try:
            return self._proposals[proposal_id]
        except KeyError:
            raise KeyError("unknown proposal_id")

    def list_signals(self) -> List[EvolutionSignal]:
        return list(self._signals.values())

    def list_proposals(self) -> List[EvolutionProposal]:
        return list(self._proposals.values())
