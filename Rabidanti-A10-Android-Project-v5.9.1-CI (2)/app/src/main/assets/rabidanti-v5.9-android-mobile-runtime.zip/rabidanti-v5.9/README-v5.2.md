# Rabidanti v5.2 — Desktop Build & Installer Hardening

Versão: **5.2.0**

A v5.2 endurece a experiência desktop sem alterar as fronteiras de segurança do Core.

## Arranque do utilizador

Windows (fonte):

```text
START-RABIDANTI.bat
```

Build nativo, quando construído:

```text
Rabidanti.exe
```

O launcher sem argumentos abre a Sala e usa o diretório de dados por utilizador. Uma segunda instância desktop é bloqueada por uma lease local. Locks de processos já terminados são recuperados automaticamente.

## Build Windows

```text
build_windows.bat
```

O build executa a suite, `compileall`, PyInstaller, confirma a existência de `dist\\Rabidanti.exe` e executa um smoke test `product build-info` no binário produzido.

O `Rabidanti.spec` usa `console=False`, metadata de versão e `assets/rabidanti.ico`.

## Instalador

Com Inno Setup 6 disponível:

```text
build_installer_windows.bat
```

O instalador é per-user (`PrivilegesRequired=lowest`) e instala em `%LOCALAPPDATA%\\Programs\\Rabidanti`.

## Segurança e dados

A v5.2 não altera as regras de autorização: o modelo não ganha execução automática; conectores e mutações continuam a passar pelas camadas existentes. Dados pessoais e bases SQLite continuam fora da pasta do programa.

## Limitação de validação

Neste ambiente de desenvolvimento não há PyInstaller nem Inno Setup. Portanto o spec, os scripts, a lease desktop e o launcher foram testados, mas **um Rabidanti.exe/Setup.exe Windows real ainda precisa ser construído e executado num Windows compatível**.
