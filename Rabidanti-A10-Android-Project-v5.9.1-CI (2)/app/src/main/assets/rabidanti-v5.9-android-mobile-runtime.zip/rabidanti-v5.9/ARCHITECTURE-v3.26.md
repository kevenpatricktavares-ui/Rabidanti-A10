# Rabidanti v3.26 — DAG Parallel Execution

Adds deterministic parallel DAG batch planning on top of v3.25. Independent
workflow branches are grouped into executable layers. Planning is read-only;
DurableWorkerQueue remains responsible for claims, leases and execution.

This is an in-process/local foundation and does not claim cloud execution,
autoscaling or external brokers.
