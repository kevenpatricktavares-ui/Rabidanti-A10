"""Rabidanti v3.41 — distribution-to-ads campaign preparation."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class AdsBrief:
    project_id: str
    product_name: str
    channels: tuple[str, ...]
    objective: str
    audience: Mapping[str, Any]
    creatives: tuple[str, ...]
    variants: tuple[str, ...]
    landing_target: str
    tracking_events: tuple[str, ...]
    experiment_id: str
    budget: Mapping[str, Any]
    status: str = "READY_FOR_APPROVAL"
    limitations: tuple[str, ...] = ()
    def to_dict(self) -> dict[str, Any]: return asdict(self)

class AdsEngine:
    def build(self, project_id: str, product: Mapping[str, Any], distribution: Mapping[str, Any], sales: Mapping[str, Any], brand: Mapping[str, Any] | None = None, persona: Mapping[str, Any] | None = None) -> AdsBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not product: raise ValueError("product must not be empty")
        if not distribution: raise ValueError("distribution must not be empty")
        if not sales: raise ValueError("sales must not be empty")
        channels = tuple(distribution.get("channels") or ())
        if not channels: raise ValueError("distribution channels are required")
        name = str(product.get("name") or product.get("title") or "Digital Product").strip()
        landing = str(sales.get("landing_title") or name).strip()
        audience = dict(persona or {})
        creative_base = str((brand or {}).get("creative_direction") or (brand or {}).get("tone") or "product-led creative").strip()
        creatives = tuple(f"{c}:primary-{creative_base}" for c in channels)
        variants = ("control", "value_angle", "problem_solution")
        events = tuple(sales.get("events") or ("landing_view", "cta_click", "checkout_start", "purchase"))
        experiment_id = f"exp-{project_id}-ads-001"
        limits = (
            "No ad is published or spent by this brief.",
            "Budget is a placeholder until an authorized spend limit is supplied.",
            "External ad accounts and publication require approved connectors and permissions.",
        )
        return AdsBrief(str(project_id), name, channels, "product_conversion", audience, creatives, variants, landing, events, experiment_id, {"currency": None, "amount": None, "approved": False}, "READY_FOR_APPROVAL", limits)
