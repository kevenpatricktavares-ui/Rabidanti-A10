# Rabidanti v4.2 — Sala / Local Interface

## Objetivo
Transformar a API local da v4.1 numa superfície visual utilizável, mantendo a política de segurança local-first e sem adicionar dependências externas obrigatórias.

## Componentes novos
- `ui/index.html` — estrutura da Sala.
- `ui/style.css` — apresentação responsiva local.
- `ui/app.js` — cliente da API v1, sem frameworks externos.
- comando CLI `room` em `rabidanti.py`.

## Fluxo
Browser local → `/ui/` → API local v1 → `RabidantiRuntime` → stores SQLite existentes.

## Capacidades visíveis
- estado do runtime;
- diagnóstico;
- tarefas persistentes;
- criação de tarefas autenticada;
- evidências;
- decisões registadas na Evidence Memory;
- workflows;
- eventos de auditoria.

## Fronteiras de segurança
- bind continua restrito a loopback;
- nenhuma dependência CDN;
- CSP restritiva e `X-Frame-Options: DENY`;
- token de mutação não é embutido na UI;
- token introduzido pelo utilizador não é persistido em `localStorage`, `sessionStorage` ou cookies;
- endpoints de leitura continuam separados das mutações;
- Sala não concede `self_authorization`, autorização de ações externas ou integração automática do Core.

## Limitações
A v4.2 é uma interface local. Não fornece autenticação multiutilizador, TLS remoto, publicação na Internet, conectores externos, execução 24/7 nem empacotamento autónomo `.exe`.
