# Rabidanti v5.0 — Executable Product Foundation

## Objetivo

Separar o ciclo de produto do runtime interno: bootstrap de ambiente, launcher de utilizador, localização de dados, build reprodutível e empacotamento, sem alterar as políticas de autorização.

## Novos componentes

### `rabidanti_product.py`
Diagnóstico de produto, deteção de dependências, deteção opcional de Ollama, informação de build e inicialização explícita do diretório de dados.

### `rabidanti_bootstrap.py`
CLI de bootstrap baseado apenas na biblioteca padrão. Não importa o Core nem cria bases de dados do runtime durante `doctor`/`setup`.

### `rabidanti_launcher.py`
Ponto de entrada do produto. Sem argumentos abre a Sala usando um diretório persistente apropriado ao sistema operativo.

### Build
`Rabidanti.spec`, `build_windows.bat` e `build_linux.sh` descrevem o build PyInstaller. Os scripts correm testes antes do empacotamento.

## Estado persistente

O launcher deixa de assumir que dados devem viver ao lado dos ficheiros do programa:

- Windows: `%LOCALAPPDATA%\\Rabidanti`
- macOS: `~/Library/Application Support/Rabidanti`
- Linux: `$XDG_DATA_HOME/rabidanti` ou `~/.local/share/rabidanti`
- override: `RABIDANTI_STATE_DIR`

## Fronteiras

O bootstrap não instala automaticamente dependências, não descarrega Ollama/modelos e não autoriza ações externas. Build de executável nativo é uma etapa de distribuição e não altera privilégios do Rabidanti.
