"""Rabidanti v3.33 — evidence-bounded Opportunity Engine."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class OpportunityBrief:
    project_id: str
    objective: str
    score: float
    demand_score: float
    pain_score: float
    gap_score: float
    objection_score: float
    opportunity: str
    rationale: tuple[str, ...]
    hypotheses: tuple[str, ...]
    evidence: tuple[dict[str, Any], ...]
    limitations: tuple[str, ...]
    source_stage: str = "research"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

class OpportunityEngine:
    """Convert a ResearchBrief-shaped mapping into a traceable opportunity score.

    Scores are deterministic heuristics, not claims of market probability. Missing
    evidence is explicitly reflected in limitations.
    """
    def score(self, project_id: str, objective: str, research: Mapping[str, Any]) -> OpportunityBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not str(objective).strip(): raise ValueError("objective must not be empty")
        r = dict(research or {})
        demand = self._items(r.get("demand_signals"))
        pains = self._items(r.get("pain_points"))
        gaps = self._items(r.get("market_gaps"))
        objections = self._items(r.get("objections"))
        evidence = tuple(x for x in (r.get("evidence") or ()) if isinstance(x, dict))
        demand_score = min(100.0, len(demand) * 20.0)
        pain_score = min(100.0, len(pains) * 20.0)
        gap_score = min(100.0, len(gaps) * 25.0)
        objection_score = min(100.0, max(0.0, 100.0 - len(objections) * 15.0))
        score = round(demand_score*.30 + pain_score*.25 + gap_score*.30 + objection_score*.15, 2)
        rationale=[]
        if demand: rationale.append(f"{len(demand)} demand signal(s) supplied")
        if pains: rationale.append(f"{len(pains)} pain point(s) supplied")
        if gaps: rationale.append(f"{len(gaps)} market gap(s) supplied")
        if objections: rationale.append(f"{len(objections)} objection(s) require validation")
        limitations=list(r.get("limitations") or [])
        if not evidence: limitations.append("Opportunity score has no external evidence attached.")
        if not any((demand,pains,gaps)): limitations.append("Research contains no demand, pain, or gap signals; score is weakly grounded.")
        opportunity = f"Test a product addressing '{str(objective).strip()}' against the supplied research signals."
        hypotheses = tuple(r.get("hypotheses") or ())
        return OpportunityBrief(str(project_id), str(objective).strip(), score, demand_score, pain_score, gap_score,
                                objection_score, opportunity, tuple(rationale), hypotheses, evidence,
                                tuple(dict.fromkeys(str(x) for x in limitations)), "research")
    @staticmethod
    def _items(v: Any) -> list[str]:
        if isinstance(v, str): return [v] if v.strip() else []
        if isinstance(v, (list,tuple)): return [str(x).strip() for x in v if str(x).strip()]
        return []
