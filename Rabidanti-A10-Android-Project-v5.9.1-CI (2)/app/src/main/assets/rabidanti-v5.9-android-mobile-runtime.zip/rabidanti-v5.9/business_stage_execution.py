"""Rabidanti v3.31 — business stage execution contracts.

This module wires canonical business-pipeline stages to the durable worker runner
without pretending that a domain engine exists when it has not been connected yet.
Each stage has a stable handler name and an explicit registration point.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Mapping
from research_engine import ResearchEngine
from opportunity_engine import OpportunityEngine
from product_engine import ProductEngine
from content_engine import ContentEngine
from review_engine import ReviewEngine
from render_engine import RenderEngine
from brand_engine import BrandEngine
from landing_engine import LandingEngine
from sales_engine import SalesEngine
from distribution_engine import DistributionEngine
from ads_engine import AdsEngine
from analytics_engine import AnalyticsEngine
from learning_engine import LearningEngine
from stage_artifact_store import StageArtifactStore

STAGE_HANDLER_PREFIX = "business.stage."

@dataclass(frozen=True)
class StageExecutionContext:
    project_id: str
    stage: str
    objective: str
    context: dict[str, Any]
    pipeline_version: str

@dataclass(frozen=True)
class StageExecutionResult:
    stage: str
    status: str
    output: Any

Handler = Callable[[StageExecutionContext], Any]

class BusinessStageRegistry:
    """Explicit registry for domain handlers used by the business workflow."""
    def __init__(self, artifact_store: StageArtifactStore | None = None) -> None:
        self._handlers: dict[str, Handler] = {}
        self.artifact_store = artifact_store

    @staticmethod
    def handler_name(stage: str) -> str:
        if not stage or not stage.strip():
            raise ValueError("stage must not be empty")
        return f"{STAGE_HANDLER_PREFIX}{stage.strip()}"

    def register(self, stage: str, handler: Handler) -> str:
        name = self.handler_name(stage)
        if not callable(handler):
            raise TypeError("handler must be callable")
        if name in self._handlers:
            raise ValueError(f"handler already registered: {name}")
        self._handlers[name] = handler
        return name

    def replace(self, stage: str, handler: Handler) -> str:
        name = self.handler_name(stage)
        if not callable(handler):
            raise TypeError("handler must be callable")
        self._handlers[name] = handler
        return name

    def get(self, stage: str) -> Handler:
        name = self.handler_name(stage)
        try:
            return self._handlers[name]
        except KeyError:
            raise KeyError(f"No domain handler registered for stage: {stage}") from None

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._handlers))

    def attach_to_runner(self, runner: Any) -> None:
        """Register every stage handler with a ContinuousWorkerRunner."""
        for name, handler in self._handlers.items():
            # Runner handlers receive payload data, so adapt the context contract.
            def invoke(data: Any, _handler=handler):
                if not isinstance(data, Mapping):
                    raise TypeError("business stage payload must be a mapping")
                ctx = StageExecutionContext(
                    project_id=str(data.get("project_id", "")),
                    stage=str(data.get("stage", "")),
                    objective=str(data.get("objective", "")),
                    context=dict(data.get("context") or {}),
                    pipeline_version=str(data.get("pipeline_version", "")),
                )
                output = _handler(ctx)
                if self.artifact_store is not None:
                    self.artifact_store.put(ctx.project_id, ctx.stage, output)
                return StageExecutionResult(ctx.stage, "COMPLETED", output)
            runner.register_handler(name, invoke)


def register_builtin_research(registry: BusinessStageRegistry) -> str:
    """Register the real Research Engine as the business research stage."""
    engine = ResearchEngine()
    return registry.replace(
        "research",
        lambda ctx: engine.research(ctx.project_id, ctx.objective, ctx.context).to_dict(),
    )


def register_builtin_opportunity(registry: BusinessStageRegistry) -> str:
    """Register Opportunity Engine; it consumes the durable Research artifact."""
    engine = OpportunityEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for opportunity integration")
    store = registry.artifact_store
    return registry.replace(
        "opportunity",
        lambda ctx: _run_opportunity(engine, store, ctx),
    )

def _run_opportunity(engine: OpportunityEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    research = store.get(ctx.project_id, "research")
    if research is None:
        raise RuntimeError(f"research artifact missing for project: {ctx.project_id}")
    return engine.score(ctx.project_id, ctx.objective, research).to_dict()


def register_builtin_product(registry: BusinessStageRegistry) -> str:
    """Register Product Engine; it consumes the durable Opportunity artifact."""
    engine = ProductEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for product integration")
    store = registry.artifact_store
    return registry.replace("product", lambda ctx: _run_product(engine, store, ctx))

def _run_product(engine: ProductEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    opportunity = store.get(ctx.project_id, "opportunity")
    if opportunity is None:
        raise RuntimeError(f"opportunity artifact missing for project: {ctx.project_id}")
    return engine.build(ctx.project_id, ctx.objective, opportunity).to_dict()


def register_builtin_content(registry: BusinessStageRegistry) -> str:
    """Register Content Engine; it consumes the durable Product artifact."""
    engine = ContentEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for content integration")
    store = registry.artifact_store
    return registry.replace("content", lambda ctx: _run_content(engine, store, ctx))

def _run_content(engine: ContentEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    product = store.get(ctx.project_id, "product")
    if product is None:
        raise RuntimeError(f"product artifact missing for project: {ctx.project_id}")
    return engine.build(ctx.project_id, ctx.objective, product).to_dict()


def register_builtin_review(registry: BusinessStageRegistry) -> str:
    """Register Review Engine; it consumes the durable Content artifact."""
    engine = ReviewEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for review integration")
    store = registry.artifact_store
    return registry.replace("review", lambda ctx: _run_review(engine, store, ctx))

def _run_review(engine: ReviewEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    content = store.get(ctx.project_id, "content")
    if content is None:
        raise RuntimeError(f"content artifact missing for project: {ctx.project_id}")
    return engine.review(ctx.project_id, content).to_dict()


def register_builtin_render(registry: BusinessStageRegistry, output_dir: str = "rendered_products") -> str:
    """Register the real PDF renderer behind the review gate."""
    engine = RenderEngine(output_dir)
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for render integration")
    store = registry.artifact_store
    return registry.replace("render", lambda ctx: _run_render(engine, store, ctx))

def _run_render(engine: RenderEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    content = store.get(ctx.project_id, "content")
    if content is None:
        raise RuntimeError(f"content artifact missing for project: {ctx.project_id}")
    review = store.get(ctx.project_id, "review")
    if review is None:
        raise RuntimeError(f"review artifact missing for project: {ctx.project_id}")
    return engine.render_pdf(ctx.project_id, content, review).to_dict()


def register_builtin_brand(registry: BusinessStageRegistry) -> str:
    """Register Brand Engine; it consumes Product and the real Render artifact."""
    engine = BrandEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for brand integration")
    store = registry.artifact_store
    return registry.replace("brand", lambda ctx: _run_brand(engine, store, ctx))

def _run_brand(engine: BrandEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    product = store.get(ctx.project_id, "product")
    if product is None: raise RuntimeError(f"product artifact missing for project: {ctx.project_id}")
    render = store.get(ctx.project_id, "render")
    if render is None: raise RuntimeError(f"render artifact missing for project: {ctx.project_id}")
    return engine.build(ctx.project_id, product, render).to_dict()

def register_builtin_landing(registry: BusinessStageRegistry) -> str:
    """Register Landing Engine; it consumes Product, Brand and Render artifacts."""
    engine = LandingEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for landing integration")
    store = registry.artifact_store
    return registry.replace("landing", lambda ctx: _run_landing(engine, store, ctx))

def _run_landing(engine: LandingEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    product = store.get(ctx.project_id, "product")
    brand = store.get(ctx.project_id, "brand")
    render = store.get(ctx.project_id, "render")
    if product is None: raise RuntimeError(f"product artifact missing for project: {ctx.project_id}")
    if brand is None: raise RuntimeError(f"brand artifact missing for project: {ctx.project_id}")
    if render is None: raise RuntimeError(f"render artifact missing for project: {ctx.project_id}")
    return engine.build(ctx.project_id, product, brand, render).to_dict()


def register_builtin_sales(registry: BusinessStageRegistry) -> str:
    """Register Sales Engine; it consumes the durable Product and Landing artifacts."""
    engine = SalesEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for sales integration")
    store = registry.artifact_store
    return registry.replace("sales", lambda ctx: _run_sales(engine, store, ctx))

def _run_sales(engine: SalesEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    product = store.get(ctx.project_id, "product")
    landing = store.get(ctx.project_id, "landing")
    if product is None: raise RuntimeError(f"product artifact missing for project: {ctx.project_id}")
    if landing is None: raise RuntimeError(f"landing artifact missing for project: {ctx.project_id}")
    return engine.build(ctx.project_id, product, landing).to_dict()


def register_builtin_distribution(registry: BusinessStageRegistry) -> str:
    """Register Distribution Engine; it consumes Product and Sales artifacts."""
    engine = DistributionEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for distribution integration")
    store = registry.artifact_store
    return registry.replace("distribution", lambda ctx: _run_distribution(engine, store, ctx))

def _run_distribution(engine: DistributionEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    product = store.get(ctx.project_id, "product")
    sales = store.get(ctx.project_id, "sales")
    if product is None: raise RuntimeError(f"product artifact missing for project: {ctx.project_id}")
    if sales is None: raise RuntimeError(f"sales artifact missing for project: {ctx.project_id}")
    channels = tuple(ctx.context.get("distribution_channels") or ())
    return engine.prepare(ctx.project_id, product, sales, channels or None).to_dict()

def register_builtin_analytics(registry: BusinessStageRegistry) -> str:
    """Register Analytics Engine; it consumes Ads + Sales and supplied observations."""
    engine = AnalyticsEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for analytics integration")
    store = registry.artifact_store
    return registry.replace("analytics", lambda ctx: _run_analytics(engine, store, ctx))

def _run_analytics(engine: AnalyticsEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    ads = store.get(ctx.project_id, "ads")
    sales = store.get(ctx.project_id, "sales")
    if ads is None: raise RuntimeError(f"ads artifact missing for project: {ctx.project_id}")
    if sales is None: raise RuntimeError(f"sales artifact missing for project: {ctx.project_id}")
    observations = ctx.context.get("observations") or ctx.context.get("analytics_observations") or {}
    return engine.summarize(ctx.project_id, ads, sales, observations).to_dict()


def register_builtin_learning(registry: BusinessStageRegistry) -> str:
    """Register Learning Engine; it consumes the durable Analytics artifact."""
    engine = LearningEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for learning integration")
    store = registry.artifact_store
    return registry.replace("learning", lambda ctx: _run_learning(engine, store, ctx))

def _run_learning(engine: LearningEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    analytics = store.get(ctx.project_id, "analytics")
    ads = store.get(ctx.project_id, "ads")
    if analytics is None: raise RuntimeError(f"analytics artifact missing for project: {ctx.project_id}")
    return engine.analyze(ctx.project_id, analytics, ads).to_dict()


def register_builtin_ads(registry: BusinessStageRegistry) -> str:
    """Register Ads Engine; it consumes Distribution, Sales, Product and optional Brand/Persona."""
    engine = AdsEngine()
    if registry.artifact_store is None:
        raise ValueError("artifact_store is required for ads integration")
    store = registry.artifact_store
    return registry.replace("ads", lambda ctx: _run_ads(engine, store, ctx))

def _run_ads(engine: AdsEngine, store: StageArtifactStore, ctx: StageExecutionContext) -> dict[str, Any]:
    product = store.get(ctx.project_id, "product")
    distribution = store.get(ctx.project_id, "distribution")
    sales = store.get(ctx.project_id, "sales")
    brand = store.get(ctx.project_id, "brand")
    persona = store.get(ctx.project_id, "persona")
    if product is None: raise RuntimeError(f"product artifact missing for project: {ctx.project_id}")
    if distribution is None: raise RuntimeError(f"distribution artifact missing for project: {ctx.project_id}")
    if sales is None: raise RuntimeError(f"sales artifact missing for project: {ctx.project_id}")
    return engine.build(ctx.project_id, product, distribution, sales, brand, persona).to_dict()
