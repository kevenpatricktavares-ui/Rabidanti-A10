# Rabidanti v3.9 — Persistent Autonomous Runtime

## What changed
v3.9 turns the v3.8 Autonomous Task Runtime into a SQLite-backed persistent
task runtime.

### Capabilities
- Autonomous tasks survive process restart.
- Persistent states: QUEUED, RUNNING, WAITING, COMPLETED, FAILED, CANCELLED.
- Persistent dependencies and priority ordering.
- Persistent worker ownership and retry counters.
- Persistent results/errors.
- Restart recovery for RUNNING tasks.
- Persistent task event history for audit/debugging.
- Dependency resolution works after restart.
- Cancellation and retry state survive restart.

## Recovery rule
On startup/recovery, stale RUNNING tasks are returned to QUEUED so a new worker
can claim them. If a task has exhausted its maximum attempts, recovery marks it
FAILED instead.

## Deliberate scope
This release is a persistent single-process foundation. It does not claim:
- distributed locking
- external/cloud queues
- autoscaling
- multi-region failover
- production 24/7 deployment
- cloud monitoring

Those remain later infrastructure work.

## Evolution path
v3.8 Autonomous Runtime
→ v3.9 Persistent Autonomous Runtime
→ distributed coordination / external queue
→ always-on cloud workers
→ production observability and cost/resource controls
