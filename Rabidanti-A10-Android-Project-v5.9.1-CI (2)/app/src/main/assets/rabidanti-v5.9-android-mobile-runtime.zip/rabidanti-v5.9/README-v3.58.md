# Rabidanti v3.58

Intelligence Prioritization Engine. Deterministic ranking for Laboratory and Opportunity candidates using explicitly supplied signals. No automatic execution or unsupported inference.
