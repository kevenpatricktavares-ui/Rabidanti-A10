from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Dict, Optional

@dataclass
class DurableJob:
    job_id: str
    state: str = "QUEUED"
    worker_id: Optional[str] = None
    lease_until: Optional[datetime] = None
    attempts: int = 0
    max_attempts: int = 3
    requires_approval: bool = False
    approval_granted: bool = False
    error: Optional[str] = None

class DurableExecutionCoordinator:
    """
    In-memory coordinator primitive mirroring the persistence contract:
    atomic claim, lease expiry recovery, approval gating, and retry limits.
    The production SQLite repository remains the source of durable truth.
    """
    def __init__(self, lease_seconds: int = 60):
        if lease_seconds < 1:
            raise ValueError("lease_seconds must be >= 1")
        self.lease_seconds = lease_seconds
        self.jobs: Dict[str, DurableJob] = {}
        self.lock = Lock()

    def add(self, job: DurableJob):
        with self.lock:
            if job.job_id in self.jobs:
                raise ValueError("job already exists")
            self.jobs[job.job_id] = job

    def approve(self, job_id: str):
        with self.lock:
            job=self.jobs[job_id]
            job.approval_granted=True
            if job.state=="WAITING_APPROVAL":
                job.state="QUEUED"

    def recover_expired(self, now=None):
        now=now or datetime.now(timezone.utc)
        recovered=[]
        with self.lock:
            for job in self.jobs.values():
                if job.state=="RUNNING" and job.lease_until and job.lease_until <= now:
                    job.state="RETRY" if job.attempts < job.max_attempts else "FAILED"
                    job.worker_id=None
                    job.lease_until=None
                    recovered.append(job.job_id)
        return recovered

    def claim(self, worker_id: str, now=None):
        now=now or datetime.now(timezone.utc)
        with self.lock:
            for job in self.jobs.values():
                if job.state not in ("QUEUED","RETRY"):
                    continue
                if job.requires_approval and not job.approval_granted:
                    job.state="WAITING_APPROVAL"
                    continue
                job.state="RUNNING"
                job.worker_id=worker_id
                job.attempts += 1
                job.lease_until=now+timedelta(seconds=self.lease_seconds)
                job.error=None
                return job
        return None

    def complete(self, job_id: str, worker_id: str):
        with self.lock:
            job=self.jobs[job_id]
            if job.worker_id != worker_id or job.state != "RUNNING":
                raise PermissionError("worker does not own running job")
            job.state="COMPLETED"
            job.worker_id=None
            job.lease_until=None

    def fail(self, job_id: str, worker_id: str, error: str):
        with self.lock:
            job=self.jobs[job_id]
            if job.worker_id != worker_id or job.state != "RUNNING":
                raise PermissionError("worker does not own running job")
            job.error=error
            job.worker_id=None
            job.lease_until=None
            job.state="RETRY" if job.attempts < job.max_attempts else "FAILED"
