from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import time
import zipfile

import pytest

from rabidanti_recovery import (
    OfflineUpdateManager,
    RecoveryError,
    RecoverySession,
    StateBackupManager,
    UpdateValidationError,
    sha256_file,
)


def make_update(path: Path, version: str = "5.4.0", *, unsafe: bool = False) -> str:
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("rabidanti-v5.4/VERSION", version + "\n")
        zf.writestr("../escape.txt" if unsafe else "rabidanti-v5.4/README.md", "update")
    return sha256_file(path)


def test_version_is_at_least_5_3():
    version = tuple(map(int, Path("VERSION").read_text().strip().split(".")))
    assert version >= (5, 3, 0)


def test_backup_create_validate_and_excludes_transients(tmp_path):
    state = tmp_path / "state"
    state.mkdir()
    (state / "tasks.sqlite3").write_bytes(b"task-data")
    (state / "config.json").write_text('{"x":1}')
    (state / "desktop-instance.lock").write_text("transient")
    (state / "updates").mkdir()
    (state / "updates" / "x").write_text("not-state")
    mgr = StateBackupManager(state)
    result = mgr.create(reason="manual test", version="5.3.0")
    assert Path(result["path"]).exists()
    validated = mgr.validate(result["path"])
    paths = {x["path"] for x in validated["files"]}
    assert "tasks.sqlite3" in paths and "config.json" in paths
    assert "desktop-instance.lock" not in paths
    assert all(not x.startswith("updates/") for x in paths)


def test_backup_restore_requires_confirmation_and_creates_safety_backup(tmp_path):
    state = tmp_path / "state"
    state.mkdir()
    target = state / "config.json"
    target.write_text("old")
    mgr = StateBackupManager(state)
    backup = mgr.create(reason="snapshot", version="5.3.0")
    target.write_text("new")
    with pytest.raises(RecoveryError):
        mgr.restore(backup["path"], confirm=False, current_version="5.3.0")
    result = mgr.restore(backup["path"], confirm=True, current_version="5.3.0")
    assert target.read_text() == "old"
    assert Path(result["safety_backup"]).exists()
    assert result["overlay_restore"] is True


def test_recovery_session_detects_stale_marker_and_cleans_on_exit(tmp_path):
    marker = tmp_path / "recovery-session.json"
    marker.write_text(json.dumps({"session_id": "old", "pid": 99999999, "version": "5.2.0"}))
    session = RecoverySession(tmp_path, "5.3.0", heartbeat_interval=0.02)
    with session:
        assert session.recovered_previous_crash is True
        assert marker.exists()
        time.sleep(0.04)
        status = RecoverySession.status(tmp_path, stale_after=1.0)
        assert status["heartbeat_stale"] is False
        assert status["automatic_restart"] is False
    assert not marker.exists()
    assert not (tmp_path / "liveness.json").exists()
    history = (tmp_path / "recovery-history.jsonl").read_text()
    assert "UNCLEAN_SHUTDOWN_DETECTED" in history
    assert "CLEAN_SHUTDOWN" in history


def test_recovery_status_marks_old_heartbeat_stale(tmp_path):
    (tmp_path / "liveness.json").write_text(json.dumps({"updated_at": time.time() - 100, "session_id": "x"}))
    status = RecoverySession.status(tmp_path, stale_after=5)
    assert status["heartbeat_stale"] is True
    assert status["external_action_authorized"] is False


def test_update_inspect_requires_exact_sha_and_newer_version(tmp_path):
    pkg = tmp_path / "update.zip"
    digest = make_update(pkg, "5.4.0")
    mgr = OfflineUpdateManager(tmp_path / "state", current_version="5.3.0")
    result = mgr.inspect(pkg, expected_sha256=digest)
    assert result["target_version"] == "5.4.0"
    assert result["installation_authorized"] is False
    with pytest.raises(UpdateValidationError):
        mgr.inspect(pkg, expected_sha256="0" * 64)
    old = tmp_path / "old.zip"
    old_digest = make_update(old, "5.3.0")
    with pytest.raises(UpdateValidationError):
        mgr.inspect(old, expected_sha256=old_digest)


def test_update_rejects_zip_traversal(tmp_path):
    pkg = tmp_path / "unsafe.zip"
    digest = make_update(pkg, "5.4.0", unsafe=True)
    mgr = OfflineUpdateManager(tmp_path / "state", current_version="5.3.0")
    with pytest.raises(UpdateValidationError):
        mgr.inspect(pkg, expected_sha256=digest)


def test_update_stage_creates_backup_and_non_authorized_plan(tmp_path):
    state = tmp_path / "state"
    state.mkdir()
    (state / "tasks.sqlite3").write_text("state")
    pkg = tmp_path / "update.zip"
    digest = make_update(pkg, "5.4.0")
    mgr = OfflineUpdateManager(state, current_version="5.3.0")
    plan = mgr.stage(pkg, expected_sha256=digest, actor="Esequiel", reason="approved staging test")
    assert Path(plan["package"]).exists()
    assert Path(plan["backup"]).exists()
    assert plan["installation_authorized"] is False
    assert plan["automatic_apply"] is False
    stored = json.loads((state / "updates" / "staged" / "5.4.0" / "update-plan.json").read_text())
    assert stored["package_sha256"] == digest


def test_update_manager_refuses_in_process_apply(tmp_path):
    mgr = OfflineUpdateManager(tmp_path / "state", current_version="5.3.0")
    with pytest.raises(RecoveryError, match="external installer"):
        mgr.apply()


def test_cli_exposes_product_recovery_and_update_commands():
    text = Path("rabidanti.py").read_text()
    for command in ["recovery-status", "backup-create", "backup-restore", "update-inspect", "update-stage", "update-list"]:
        assert command in text


def test_launcher_uses_recovery_session():
    text = Path("rabidanti_launcher.py").read_text()
    assert "RecoverySession" in text
    assert "with lease, RecoverySession" in text


def test_installer_metadata_matches_current_version():
    info = Path("rabidanti_version_info.txt").read_text()
    iss = Path("installer_windows.iss").read_text()
    current = Path("VERSION").read_text().strip()
    assert f"ProductVersion', '{current}'" in info
    assert f'MyAppVersion "{current}"' in iss

def test_state_schema_migration_requires_confirmation_and_creates_backup(tmp_path):
    from rabidanti_recovery import StateSchemaManager
    state = tmp_path / "state"
    state.mkdir()
    (state / "tasks.sqlite3").write_text("data")
    mgr = StateSchemaManager(state, app_version="5.3.0")
    assert mgr.status()["migration_required"] is True
    with pytest.raises(RecoveryError):
        mgr.migrate(confirm=False)
    result = mgr.migrate(confirm=True)
    assert result["schema_version"] == 1
    assert Path(result["backup"]).exists()
    assert mgr.status()["migration_required"] is False


def test_state_schema_rejects_future_schema(tmp_path):
    from rabidanti_recovery import StateSchemaManager
    state = tmp_path / "state"
    state.mkdir()
    (state / "state-schema.json").write_text(json.dumps({"schema_version": 999}))
    mgr = StateSchemaManager(state, app_version="5.3.0")
    assert mgr.status()["future_schema"] is True
    with pytest.raises(RecoveryError, match="newer"):
        mgr.migrate(confirm=True)
