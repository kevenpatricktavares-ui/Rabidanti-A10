from __future__ import annotations

import json
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from rabidanti import room_browser_url
from rabidanti_api import RabidantiApiService
from rabidanti_config import redact_sensitive
from rabidanti_onboarding import FirstRunOnboarding, OnboardingError
from rabidanti_runtime import RabidantiRuntime

TOKEN = "z" * 32
ROOT = Path(__file__).resolve().parent


def _get(base: str, path: str):
    with urlopen(base + path, timeout=3) as r:
        return r.status, json.loads(r.read().decode())


def _post(base: str, path: str, body: dict, token: str | None = TOKEN):
    headers = {"Content-Type": "application/json"}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    req = Request(base + path, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urlopen(req, timeout=3) as r:
        return r.status, json.loads(r.read().decode())


def _service(tmp_path: Path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    service = RabidantiApiService(runtime, port=0, token=TOKEN)
    addr = service.start()
    return runtime, service, f"http://{addr.host}:{addr.port}"


def test_version_is_5_1_0():
    parts = tuple(int(x) for x in (ROOT / "VERSION").read_text().strip().split("."))
    assert parts >= (5, 1, 0)


def test_onboarding_defaults_incomplete_and_contains_no_secret(tmp_path):
    manager = FirstRunOnboarding(tmp_path / "onboarding.json")
    status = manager.status()
    assert status["completed"] is False
    assert status["external_action_authorized"] is False
    assert not (tmp_path / "onboarding.json").exists()


def test_onboarding_completion_persists_only_non_secret_metadata(tmp_path):
    path = tmp_path / "onboarding.json"
    manager = FirstRunOnboarding(path)
    result = manager.complete(
        config_changes={"ai.model": "llama3.2", "ai.fallback_model": "", "ui.auto_open_browser": True},
        selected_model="llama3.2",
        vault_was_unlocked=True,
    )
    assert result["completed"] is True
    text = path.read_text().lower()
    assert "master_key" not in text
    assert "password" not in text
    assert "token" not in text
    assert "llama3.2" in text


def test_onboarding_rejects_unsupported_config_keys(tmp_path):
    manager = FirstRunOnboarding(tmp_path / "onboarding.json")
    with pytest.raises(OnboardingError, match="unsupported"):
        manager.complete(
            config_changes={"api.token": "nope"},
            selected_model="llama3.2",
        )


def test_master_key_is_redacted_by_audit_boundary():
    assert redact_sensitive({"vault_master_key": "super-secret", "nested": {"master_key": "another"}}) == {
        "vault_master_key": "[REDACTED]",
        "nested": {"master_key": "[REDACTED]"},
    }


def test_runtime_completes_onboarding_updates_config_and_does_not_authorize_actions(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    try:
        result = runtime.complete_onboarding(
            model="qwen3:4b",
            fallback_model="llama3.2",
            auto_open_browser=False,
            logging_level="WARNING",
            vault_master_key="m" * 32,
        )
        assert result["completed"] is True
        assert result["external_action_authorized"] is False
        assert result["vault"]["unlocked"] is True
        cfg = runtime.get_config()
        assert cfg["ai"]["model"] == "qwen3:4b"
        assert cfg["ai"]["fallback_model"] == "llama3.2"
        assert cfg["ui"]["auto_open_browser"] is False
        assert cfg["logging"]["level"] == "WARNING"
        disk = (tmp_path / "state" / "onboarding.json").read_text()
        assert ("m" * 32) not in disk
        events = json.dumps(runtime.runtime_events())
        assert ("m" * 32) not in events
    finally:
        runtime.stop()


def test_setup_api_requires_token_and_never_returns_master_key(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        with pytest.raises(HTTPError) as exc:
            _post(base, "/v1/setup/complete", {"model": "llama3.2"}, token=None)
        assert exc.value.code == 401
        status, out = _post(base, "/v1/setup/complete", {"model": "llama3.2", "vault_master_key": "k" * 32})
        assert status == 200
        assert out["completed"] is True
        dumped = json.dumps(out)
        assert ("k" * 32) not in dumped
        assert "vault_master_key" not in dumped.lower()
    finally:
        service.stop(); runtime.stop()


def test_vault_unlock_api_requires_auth_and_keeps_key_out_of_state(tmp_path):
    runtime, service, base = _service(tmp_path)
    key = "v" * 32
    try:
        with pytest.raises(HTTPError) as exc:
            _post(base, "/v1/vault/unlock", {"master_key": key}, token=None)
        assert exc.value.code == 401
        status, out = _post(base, "/v1/vault/unlock", {"master_key": key})
        assert status == 200 and out["unlocked"] is True
    finally:
        service.stop(); runtime.stop()
    for file in (tmp_path / "state").glob("*"):
        if file.is_file():
            assert key.encode() not in file.read_bytes(), file.name


def test_get_connector_control_cannot_mutate_state(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        before = {x["connector_id"]: x["enabled"] for x in runtime.list_connectors()}
        with pytest.raises(HTTPError) as exc:
            _get(base, "/v1/connectors/control")
        assert exc.value.code == 404
        after = {x["connector_id"]: x["enabled"] for x in runtime.list_connectors()}
        assert before == after
    finally:
        service.stop(); runtime.stop()


def test_room_browser_url_uses_fragment_for_ephemeral_token_and_setup_flag():
    url = room_browser_url("http://127.0.0.1:8765", TOKEN, True)
    assert url.startswith("http://127.0.0.1:8765/ui/#")
    assert "token=" in url and TOKEN in url
    assert "setup=1" in url
    assert "?token=" not in url


def test_ui_consumes_fragment_without_browser_storage():
    js = (ROOT / "ui" / "app.js").read_text()
    html = (ROOT / "ui" / "index.html").read_text()
    assert "location.hash" in js
    assert "history.replaceState" in js
    assert "localStorage" not in js
    assert "sessionStorage" not in js
    assert 'id="setup-form"' in html
    assert 'id="vault-unlock-form"' in html


def test_setup_does_not_claim_automatic_install_or_model_download():
    html = (ROOT / "ui" / "index.html").read_text().lower()
    assert "não instala software" in html
    assert "não descarrega modelos" in html
