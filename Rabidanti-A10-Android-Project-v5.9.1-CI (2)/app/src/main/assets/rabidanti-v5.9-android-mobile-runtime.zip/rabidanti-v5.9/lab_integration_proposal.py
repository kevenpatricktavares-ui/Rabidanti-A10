"""Rabidanti v3.98 — Laboratory Integration Proposal Workflow.

Turns an APPROVED v3.97 human laboratory review into an immutable, auditable
proposal for a future controlled change. A proposal is descriptive only: it
cannot modify files, authorize Core integration, or authorize external actions.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import json
import sqlite3


class LabIntegrationProposalWorkflow:
    """Create persistent integration proposals bound to approved evidence.

    Each proposal is bound to one immutable v3.97 human-review decision and its
    evidence snapshot. Identical proposal content is idempotent. Any material
    change produces a new proposal, preserving the previous record.
    """

    PROPOSED = "PROPOSED_FOR_INTEGRATION_REVIEW"

    def __init__(self, human_review_workflow, evidence_memory, database="rabidanti_lab_integration_proposals.sqlite3"):
        if human_review_workflow is None or evidence_memory is None:
            raise ValueError("human_review_workflow and evidence_memory are required")
        self.reviews = human_review_workflow
        self.memory = evidence_memory
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS lab_integration_proposals(
                proposal_id TEXT PRIMARY KEY,
                proposal_digest TEXT NOT NULL UNIQUE,
                review_id TEXT NOT NULL,
                experiment_id TEXT NOT NULL,
                readiness_id TEXT NOT NULL,
                evidence_snapshot_digest TEXT NOT NULL,
                title TEXT NOT NULL,
                summary TEXT NOT NULL,
                target_component TEXT NOT NULL,
                affected_files TEXT NOT NULL,
                change_plan TEXT NOT NULL,
                test_plan TEXT NOT NULL,
                rollback_plan TEXT NOT NULL,
                risks TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL,
                integration_authorized INTEGER NOT NULL DEFAULT 0,
                external_action_authorized INTEGER NOT NULL DEFAULT 0,
                scientifically_validated INTEGER NOT NULL DEFAULT 0
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS lab_integration_proposal_events(
                event_id TEXT PRIMARY KEY,
                proposal_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                actor_id TEXT NOT NULL,
                note TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(proposal_id) REFERENCES lab_integration_proposals(proposal_id)
            )""")

    def _db(self):
        c = sqlite3.connect(self.database)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _text(value, name):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be non-empty text")
        return value.strip()

    @classmethod
    def _text_list(cls, value, name):
        if not isinstance(value, (list, tuple)) or not value:
            raise ValueError(f"{name} must be a non-empty list of text")
        out = []
        for i, item in enumerate(value):
            out.append(cls._text(item, f"{name}[{i}]"))
        return out

    @staticmethod
    def _canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    @classmethod
    def _safe_files(cls, value):
        files = cls._text_list(value, "affected_files")
        normalized = []
        for raw in files:
            if "\\" in raw:
                raise ValueError("affected_files must use repository-relative POSIX paths")
            p = PurePosixPath(raw)
            if p.is_absolute() or ".." in p.parts or raw in {".", ".."}:
                raise ValueError("affected_files must be repository-relative paths without traversal")
            if not p.parts or any(part in {"", ".", ".."} for part in p.parts):
                raise ValueError("affected_files contains an invalid path")
            if p.parts[0].endswith(":"):
                raise ValueError("affected_files must not contain drive-qualified paths")
            normalized.append(p.as_posix())
        # Stable canonical ordering also prevents accidental duplicate path entries.
        return sorted(set(normalized))

    @staticmethod
    def _proposal_id(digest):
        return f"integration-proposal:{digest[:24]}"

    @staticmethod
    def _decision_node_id(review_id):
        return f"human-review-decision:{review_id}"

    @staticmethod
    def _json_load(value):
        return json.loads(value)

    def _row(self, row):
        if row is None:
            return None
        d = dict(row)
        for key in ("affected_files", "change_plan", "test_plan", "rollback_plan", "risks"):
            d[key] = self._json_load(d[key])
        for key in ("integration_authorized", "external_action_authorized", "scientifically_validated"):
            d[key] = bool(d[key])
        return d

    def _ensure_link(self, from_id, relation, to_id, note=""):
        trace = self.memory.trace(from_id)
        for link in trace["links"]:
            if link["from_id"] == from_id and link["relation"] == relation and link["to_id"] == to_id:
                return link
        return self.memory.link(from_id, relation, to_id, note=note)

    def get(self, proposal_id):
        with self._db() as c:
            row = c.execute(
                "SELECT * FROM lab_integration_proposals WHERE proposal_id=?", (proposal_id,)
            ).fetchone()
        if row is None:
            raise KeyError(proposal_id)
        return self._row(row)

    def events(self, proposal_id):
        self.get(proposal_id)
        with self._db() as c:
            rows = c.execute(
                "SELECT * FROM lab_integration_proposal_events WHERE proposal_id=? ORDER BY created_at,event_id",
                (proposal_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    def create(
        self,
        review_id,
        *,
        title,
        summary,
        target_component,
        affected_files,
        change_plan,
        test_plan,
        rollback_plan,
        risks,
        created_by="creator",
    ):
        title = self._text(title, "title")
        summary = self._text(summary, "summary")
        target_component = self._text(target_component, "target_component")
        created_by = self._text(created_by, "created_by")
        affected_files = self._safe_files(affected_files)
        change_plan = self._text_list(change_plan, "change_plan")
        test_plan = self._text_list(test_plan, "test_plan")
        rollback_plan = self._text_list(rollback_plan, "rollback_plan")
        risks = self._text_list(risks, "risks")

        review = self.reviews.get(review_id)
        if review["status"] != self.reviews.APPROVED:
            raise ValueError("integration proposal requires an APPROVED human review")

        decision_node_id = self._decision_node_id(review_id)
        decision_node = self.memory.get_node(decision_node_id)
        if decision_node["kind"] != "DECISION":
            raise ValueError("human review evidence node has incompatible kind")
        decision_meta = decision_node["metadata"]
        if decision_meta.get("decision") != self.reviews.APPROVED:
            raise ValueError("human review evidence is not APPROVED")
        if decision_meta.get("evidence_snapshot_digest") != review["evidence_snapshot_digest"]:
            raise ValueError("human review evidence snapshot does not match review ledger")
        if decision_meta.get("review_id") != review_id:
            raise ValueError("human review evidence does not match requested review")

        body = {
            "record_type": "integration_proposal",
            "review_id": review_id,
            "experiment_id": review["experiment_id"],
            "readiness_id": review["readiness_id"],
            "evidence_snapshot_digest": review["evidence_snapshot_digest"],
            "title": title,
            "summary": summary,
            "target_component": target_component,
            "affected_files": affected_files,
            "change_plan": change_plan,
            "test_plan": test_plan,
            "rollback_plan": rollback_plan,
            "risks": risks,
            "created_by": created_by,
            "status": self.PROPOSED,
            "scientifically_validated": False,
            "integration_authorized": False,
            "external_action_authorized": False,
            "requires_separate_integration_approval": True,
        }
        canonical = self._canonical(body)
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        proposal_id = self._proposal_id(digest)

        with self._db() as c:
            existing = c.execute(
                "SELECT * FROM lab_integration_proposals WHERE proposal_digest=?", (digest,)
            ).fetchone()
            if existing is not None:
                return self._row(existing)

        now = self._now()
        node_metadata = {**body, "proposal_id": proposal_id, "proposal_digest": digest, "created_at": now}
        try:
            self.memory.add_node(
                "ARTIFACT",
                title,
                "Proposed Core integration change; proposal only, not execution authority",
                node_id=proposal_id,
                content=canonical,
                metadata=node_metadata,
            )
        except ValueError as e:
            # Fail closed if the deterministic identifier already exists in the
            # evidence store but the proposal ledger has no matching record.
            raise ValueError("integration proposal evidence already exists without matching ledger record") from e

        with self._db() as c:
            try:
                c.execute(
                    """INSERT INTO lab_integration_proposals(
                        proposal_id,proposal_digest,review_id,experiment_id,readiness_id,
                        evidence_snapshot_digest,title,summary,target_component,affected_files,
                        change_plan,test_plan,rollback_plan,risks,created_by,created_at,status,
                        integration_authorized,external_action_authorized,scientifically_validated
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,0)""",
                    (
                        proposal_id, digest, review_id, review["experiment_id"], review["readiness_id"],
                        review["evidence_snapshot_digest"], title, summary, target_component,
                        self._canonical(affected_files), self._canonical(change_plan), self._canonical(test_plan),
                        self._canonical(rollback_plan), self._canonical(risks), created_by, now, self.PROPOSED,
                    ),
                )
                c.execute(
                    "INSERT INTO lab_integration_proposal_events VALUES(?,?,?,?,?,?)",
                    (
                        f"proposal-created:{proposal_id}", proposal_id, "PROPOSAL_CREATED", created_by,
                        "Approved laboratory evidence converted into a reviewable integration proposal; no authority granted.",
                        now,
                    ),
                )
            except sqlite3.IntegrityError as e:
                raise ValueError("integration proposal ledger conflict") from e

        self._ensure_link(
            decision_node_id,
            "HAS_INTEGRATION_PROPOSAL",
            proposal_id,
            "Human-approved evidence produced a proposal; separate integration authorization remains required",
        )
        self._ensure_link(
            proposal_id,
            "BASED_ON_READINESS",
            review["readiness_id"],
            "Proposal is bound to the immutable evidence snapshot reviewed by the creator",
        )
        self._ensure_link(
            f"experiment:{review['experiment_id']}",
            "HAS_INTEGRATION_PROPOSAL",
            proposal_id,
            "Proposal derived from approved human review",
        )
        return self.get(proposal_id)

    def history(self, experiment_id):
        # Ensure callers cannot use this as an oracle for unknown experiments.
        self.reviews.manager.get(experiment_id)
        with self._db() as c:
            rows = c.execute(
                "SELECT * FROM lab_integration_proposals WHERE experiment_id=? ORDER BY created_at,proposal_id",
                (experiment_id,),
            ).fetchall()
        return {
            "experiment_id": experiment_id,
            "proposals": [self._row(r) for r in rows],
            "integration_authorized": False,
            "external_action_authorized": False,
            "scientifically_validated": False,
            "limitation": (
                "Integration proposals are planning artifacts only. They do not modify the repository, "
                "authorize integration, or independently establish scientific validity."
            ),
        }

    def authorize_integration(self, *args, **kwargs):
        raise PermissionError("integration proposal cannot authorize or apply Core integration")

    def apply(self, *args, **kwargs):
        raise PermissionError("v3.98 proposals are non-executable; use a separately authorized controlled executor")

    def authorize_external_action(self, *args, **kwargs):
        raise PermissionError("integration proposal cannot authorize external actions")
