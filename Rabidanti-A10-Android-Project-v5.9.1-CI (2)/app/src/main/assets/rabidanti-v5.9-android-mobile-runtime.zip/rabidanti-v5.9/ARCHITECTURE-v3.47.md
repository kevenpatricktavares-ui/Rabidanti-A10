# Rabidanti v3.47 — World Awareness → Laboratory Integration

World signals can now create traceable Lab investigations while preserving source provenance, verification, confidence and freshness. The bridge does not fetch external data and does not declare discoveries automatically. External exploitation and core changes remain subject to review/approval.
