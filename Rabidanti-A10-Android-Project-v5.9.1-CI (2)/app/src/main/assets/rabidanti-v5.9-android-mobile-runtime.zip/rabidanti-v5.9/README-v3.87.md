# Rabidanti v3.87 — Isolated Laboratory Runner

Adds a controlled subprocess runner for explicitly allowlisted commands. Each run receives a fresh temporary workspace, optional text artifacts, a timeout, output cap, a result status and a SHA-256 digest for the result record. It does not use a shell and rejects unsafe relative paths.

**Security boundary:** this is a bounded runner, not a hardened sandbox. Process timeouts and temporary directories do not prevent every filesystem/network/resource attack. Do not execute untrusted code on a sensitive host. Before production use, run workloads inside OS-level containers or a dedicated VM with network disabled, memory/CPU/process limits, non-root identity, and disposable storage. No integration or deployment occurs automatically.

Run tests from the project root with `pytest -q`.
