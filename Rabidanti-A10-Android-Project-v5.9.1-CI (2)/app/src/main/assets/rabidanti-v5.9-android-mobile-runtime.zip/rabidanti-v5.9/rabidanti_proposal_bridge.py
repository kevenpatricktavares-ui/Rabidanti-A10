"""Rabidanti v4.9 — proposal review and controlled execution bridge.

Reasoning proposals remain inert until a human review is recorded. Connector
mutations still require the connector registry's independent one-time approval
bound to the exact connector/capability/payload digest.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional
import hashlib, json, sqlite3, uuid

from rabidanti_connectors import ConnectorRegistry, ConnectorPermissionError
from rabidanti_reasoning import AgentReasoningRuntime, ReasoningError


class ProposalBridgeError(RuntimeError): pass
class ProposalReviewRequired(ProposalBridgeError): pass
class ProposalRejected(ProposalBridgeError): pass
class ProposalIntegrityError(ProposalBridgeError): pass


class ProposalExecutionBridge:
    SCHEMA_VERSION = 1
    def __init__(
        self,
        db_path: str|Path,
        reasoning: AgentReasoningRuntime,
        connectors: ConnectorRegistry,
        task_creator: Callable[..., dict[str, Any]],
        audit_callback: Optional[Callable[[str, dict[str, Any]], None]] = None,
    ) -> None:
        self.db_path=Path(db_path); self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self.reasoning=reasoning; self.connectors=connectors; self.task_creator=task_creator
        self._audit=audit_callback or (lambda event, details: None)
        self._init()

    @staticmethod
    def _now()->str: return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def _required(value: str, name: str)->str:
        if not isinstance(value,str) or not value.strip(): raise ValueError(f"{name} is required")
        text=value.strip()
        if len(text)>1000: raise ValueError(f"{name} is too long")
        return text
    @staticmethod
    def _digest(value: Any)->str:
        raw=json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False,default=str).encode()
        return hashlib.sha256(raw).hexdigest()
    def _conn(self):
        c=sqlite3.connect(self.db_path); c.row_factory=sqlite3.Row; return c
    def _init(self):
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS proposal_reviews(
                proposal_id TEXT PRIMARY KEY, proposal_digest TEXT NOT NULL,
                decision TEXT NOT NULL, actor TEXT NOT NULL, reason TEXT NOT NULL,
                reviewed_at TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS proposal_authorizations(
                authorization_id TEXT PRIMARY KEY, proposal_id TEXT NOT NULL,
                proposal_digest TEXT NOT NULL, connector_approval_id TEXT,
                actor TEXT NOT NULL, reason TEXT NOT NULL, consumed INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL, consumed_at TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS proposal_executions(
                execution_id TEXT PRIMARY KEY, proposal_id TEXT NOT NULL,
                proposal_digest TEXT NOT NULL, kind TEXT NOT NULL, actor TEXT NOT NULL,
                status TEXT NOT NULL, result_json TEXT, result_digest TEXT,
                error TEXT, connector_approval_id TEXT, created_at TEXT NOT NULL,
                finished_at TEXT)""")
            c.execute("""CREATE TABLE IF NOT EXISTS proposal_bridge_metadata(
                key TEXT PRIMARY KEY,value TEXT NOT NULL)""")
            c.execute("INSERT OR REPLACE INTO proposal_bridge_metadata VALUES(?,?)",("schema_version",str(self.SCHEMA_VERSION)))

    def _proposal(self, proposal_id: str)->dict[str,Any]:
        try: p=self.reasoning.get_proposal(proposal_id)
        except (KeyError, ReasoningError) as exc: raise ProposalBridgeError("proposal not found") from exc
        return p

    def review(self, proposal_id: str, *, decision: str, actor: str, reason: str)->dict[str,Any]:
        decision=str(decision).upper()
        if decision not in {"APPROVED","REJECTED"}: raise ValueError("decision must be APPROVED or REJECTED")
        actor=self._required(actor,"actor"); reason=self._required(reason,"reason"); p=self._proposal(proposal_id)
        with self._conn() as c:
            old=c.execute("SELECT * FROM proposal_reviews WHERE proposal_id=?",(proposal_id,)).fetchone()
            if old is not None: raise ProposalBridgeError("proposal already has a final human review")
            c.execute("INSERT INTO proposal_reviews VALUES(?,?,?,?,?,?)",(proposal_id,p["proposal_digest"],decision,actor,reason,self._now()))
        self._audit("REASONING_PROPOSAL_REVIEWED",{"proposal_id":proposal_id,"decision":decision,"actor":actor})
        return self.get_review(proposal_id)

    def get_review(self, proposal_id: str)->dict[str,Any]:
        with self._conn() as c: row=c.execute("SELECT * FROM proposal_reviews WHERE proposal_id=?",(proposal_id,)).fetchone()
        if row is None: raise ProposalReviewRequired("proposal has not been reviewed")
        return dict(row)

    def reviews(self, limit:int=100)->list[dict[str,Any]]:
        limit=max(1,min(int(limit),500))
        with self._conn() as c: return [dict(r) for r in c.execute("SELECT * FROM proposal_reviews ORDER BY reviewed_at DESC LIMIT ?",(limit,)).fetchall()]

    def _approved(self, p: dict[str,Any])->dict[str,Any]:
        review=self.get_review(p["proposal_id"])
        if review["proposal_digest"] != p["proposal_digest"]: raise ProposalIntegrityError("proposal changed after human review")
        if review["decision"] != "APPROVED": raise ProposalRejected("proposal was rejected")
        return review

    def authorize(self, proposal_id: str, *, actor: str, reason: str)->dict[str,Any]:
        actor=self._required(actor,"actor"); reason=self._required(reason,"reason"); p=self._proposal(proposal_id); self._approved(p)
        approval_id=None
        if p["kind"] == "connector":
            state=self.connectors.get(p["connector_id"])
            cap=next((x for x in state["capabilities"] if x["name"]==p["capability"]),None)
            if cap is None: raise ProposalBridgeError("connector capability no longer exists")
            if cap["approval_required"]:
                approval=self.connectors.approve(p["connector_id"],p["capability"],p["payload"],actor=actor,reason=reason)
                approval_id=approval["approval_id"]
        elif p["kind"] != "internal_task":
            raise ProposalBridgeError("unsupported proposal kind")
        with self._conn() as c:
            success=c.execute("SELECT 1 FROM proposal_executions WHERE proposal_id=? AND status='SUCCEEDED'",(proposal_id,)).fetchone()
            if success is not None: raise ProposalBridgeError("proposal has already been executed successfully")
            aid=f"proposal-auth-{uuid.uuid4().hex}"
            c.execute("INSERT INTO proposal_authorizations VALUES(?,?,?,?,?,?,0,?,NULL)",(aid,proposal_id,p["proposal_digest"],approval_id,actor,reason,self._now()))
        self._audit("REASONING_PROPOSAL_AUTHORIZED",{"proposal_id":proposal_id,"authorization_id":aid,"actor":actor,"connector_approval_required":bool(approval_id)})
        return self.get_authorization(proposal_id)

    def get_authorization(self, proposal_id:str)->dict[str,Any]:
        with self._conn() as c: row=c.execute("SELECT * FROM proposal_authorizations WHERE proposal_id=? AND consumed=0 ORDER BY created_at DESC LIMIT 1",(proposal_id,)).fetchone()
        if row is None: raise ProposalBridgeError("proposal has no unconsumed execution authorization")
        d=dict(row); d["consumed"]=bool(d["consumed"]); return d

    def _consume_authorization(self, authorization_id: str)->None:
        with self._conn() as c:
            row=c.execute("SELECT consumed FROM proposal_authorizations WHERE authorization_id=?",(authorization_id,)).fetchone()
            if row is None or row["consumed"]:
                raise ProposalBridgeError("execution authorization is missing or already consumed")
            c.execute("UPDATE proposal_authorizations SET consumed=1,consumed_at=? WHERE authorization_id=?",(self._now(),authorization_id))

    def execute(self, proposal_id: str, *, actor: str)->dict[str,Any]:
        actor=self._required(actor,"actor"); p=self._proposal(proposal_id); self._approved(p)
        with self._conn() as c:
            prev=c.execute("SELECT 1 FROM proposal_executions WHERE proposal_id=? AND status='SUCCEEDED'",(proposal_id,)).fetchone()
            if prev is not None: raise ProposalBridgeError("proposal has already been executed successfully")
        # All execution requires a separate explicit authorization step, even read-only connector calls and internal tasks.
        auth=self.get_authorization(proposal_id)
        if auth["proposal_digest"] != p["proposal_digest"]: raise ProposalIntegrityError("proposal changed after execution authorization")
        self._consume_authorization(auth["authorization_id"])
        eid=f"proposal-exec-{uuid.uuid4().hex}"; now=self._now(); status="FAILED"; result=None; err=None
        try:
            if p["kind"]=="connector":
                result=self.connectors.invoke(p["connector_id"],p["capability"],p["payload"],actor=actor,approval_id=auth["connector_approval_id"])
            elif p["kind"]=="internal_task":
                result=self.task_creator(p["name"])
            else:
                raise ProposalBridgeError("unsupported proposal kind")
            status="SUCCEEDED"; return_result=result
            return {"execution_id":eid,"proposal_id":proposal_id,"status":status,"result":return_result,"execution_authorized":True,"external_action_authorized":p["kind"]=="connector"}
        except Exception as exc:
            err=f"{type(exc).__name__}: {exc}"
            raise
        finally:
            finished=self._now(); result_json=None if result is None else json.dumps(result,sort_keys=True,ensure_ascii=False,default=str); result_digest=None if result is None else self._digest(result)
            with self._conn() as c:
                c.execute("INSERT INTO proposal_executions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(eid,proposal_id,p["proposal_digest"],p["kind"],actor,status,result_json,result_digest,err,auth["connector_approval_id"],now,finished))
            self._audit("REASONING_PROPOSAL_EXECUTED",{"proposal_id":proposal_id,"execution_id":eid,"actor":actor,"status":status,"kind":p["kind"]})

    def executions(self, limit:int=100)->list[dict[str,Any]]:
        limit=max(1,min(int(limit),500))
        with self._conn() as c: rows=c.execute("SELECT * FROM proposal_executions ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()
        out=[]
        for r in rows:
            d=dict(r); d["result"]=None if not d.pop("result_json") else json.loads(r["result_json"]); out.append(d)
        return out
