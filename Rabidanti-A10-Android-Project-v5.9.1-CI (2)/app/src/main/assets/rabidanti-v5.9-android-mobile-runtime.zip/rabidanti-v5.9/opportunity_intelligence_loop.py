"""Rabidanti v3.50 — Opportunity Intelligence Loop.

Closes the evidence-bounded loop from world opportunity themes into research,
controlled experiment planning, observed results, and explicit learning.
No stage may invent market performance or promote a hypothesis to a fact.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping
import json, sqlite3, threading, time, uuid

from opportunity_discovery import OpportunityTheme
from research_engine import ResearchEngine
from learning_engine import LearningEngine

STAGES = ("DISCOVERED", "RESEARCHED", "EXPERIMENT_READY", "RESULT_RECORDED", "LEARNED")

@dataclass(frozen=True)
class OpportunityLoop:
    loop_id: str
    project_id: str
    topic: str
    objective: str
    theme_id: str
    stage: str
    hypothesis: str
    research: Mapping[str, Any]
    experiment: Mapping[str, Any]
    result: Mapping[str, Any]
    learning: Mapping[str, Any]
    limitations: tuple[str, ...]
    created_at: float
    updated_at: float
    def to_dict(self) -> dict[str, Any]: return asdict(self)

class OpportunityLoopStore:
    def __init__(self, db_path: str):
        self.db_path=db_path; self._lock=threading.RLock()
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory=sqlite3.Row
        if db_path != ':memory:': self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS opportunity_loops (
            loop_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, topic TEXT NOT NULL,
            objective TEXT NOT NULL, theme_id TEXT NOT NULL, stage TEXT NOT NULL,
            hypothesis TEXT NOT NULL, research_json TEXT NOT NULL,
            experiment_json TEXT NOT NULL, result_json TEXT NOT NULL,
            learning_json TEXT NOT NULL, limitations_json TEXT NOT NULL,
            created_at REAL NOT NULL, updated_at REAL NOT NULL)''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_opportunity_loops_stage ON opportunity_loops(stage)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_opportunity_loops_project ON opportunity_loops(project_id)')

    def save(self, loop: OpportunityLoop) -> None:
        with self._lock:
            self._conn.execute('''INSERT INTO opportunity_loops VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(loop_id) DO UPDATE SET stage=excluded.stage,
                hypothesis=excluded.hypothesis,research_json=excluded.research_json,
                experiment_json=excluded.experiment_json,result_json=excluded.result_json,
                learning_json=excluded.learning_json,limitations_json=excluded.limitations_json,
                updated_at=excluded.updated_at''',
                (loop.loop_id,loop.project_id,loop.topic,loop.objective,loop.theme_id,loop.stage,
                 loop.hypothesis,json.dumps(dict(loop.research),ensure_ascii=False),
                 json.dumps(dict(loop.experiment),ensure_ascii=False),json.dumps(dict(loop.result),ensure_ascii=False),
                 json.dumps(dict(loop.learning),ensure_ascii=False),json.dumps(list(loop.limitations),ensure_ascii=False),
                 loop.created_at,loop.updated_at))

    def get(self, loop_id: str) -> OpportunityLoop | None:
        with self._lock: row=self._conn.execute('SELECT * FROM opportunity_loops WHERE loop_id=?',(loop_id,)).fetchone()
        return None if not row else self._row(row)

    def list(self, project_id: str | None = None) -> list[OpportunityLoop]:
        with self._lock:
            if project_id:
                rows=self._conn.execute('SELECT * FROM opportunity_loops WHERE project_id=? ORDER BY updated_at DESC',(project_id,)).fetchall()
            else:
                rows=self._conn.execute('SELECT * FROM opportunity_loops ORDER BY updated_at DESC').fetchall()
        return [self._row(r) for r in rows]

    @staticmethod
    def _row(r: sqlite3.Row) -> OpportunityLoop:
        return OpportunityLoop(r['loop_id'],r['project_id'],r['topic'],r['objective'],r['theme_id'],r['stage'],r['hypothesis'],
            json.loads(r['research_json']),json.loads(r['experiment_json']),json.loads(r['result_json']),
            json.loads(r['learning_json']),tuple(json.loads(r['limitations_json'])),r['created_at'],r['updated_at'])

class OpportunityIntelligenceLoop:
    """Advance an opportunity theme only through evidence-supported stages."""
    def __init__(self, store: OpportunityLoopStore):
        self.store=store; self.research_engine=ResearchEngine(); self.learning_engine=LearningEngine()

    def start(self, project_id: str, objective: str, theme: OpportunityTheme) -> OpportunityLoop:
        if not str(project_id).strip(): raise ValueError('project_id must not be empty')
        if not str(objective).strip(): raise ValueError('objective must not be empty')
        now=time.time()
        loop=OpportunityLoop('oloop-'+uuid.uuid4().hex,str(project_id).strip(),theme.topic,str(objective).strip(),theme.theme_id,
            'DISCOVERED',theme.hypothesis,{}, {}, {}, {},
            tuple(theme.limitations)+('World signals are not proof of commercial demand or profitability.',),now,now)
        self.store.save(loop); return loop

    def research(self, loop_id: str) -> OpportunityLoop:
        loop=self._require(loop_id)
        brief=self.research_engine.research(loop.project_id,loop.objective,{
            'market_gaps':[loop.hypothesis], 'hypotheses':[loop.hypothesis],
            'evidence': list(self._theme_evidence(loop)),
        })
        now=time.time()
        updated=self._replace(loop,stage='RESEARCHED',research=brief.to_dict(),updated_at=now)
        self.store.save(updated); return updated

    def plan_experiment(self, loop_id: str, *, metric: str = 'validation_signal') -> OpportunityLoop:
        loop=self._require(loop_id)
        if loop.stage not in ('RESEARCHED','EXPERIMENT_READY'):
            raise ValueError('research must be completed before experiment planning')
        if not str(metric).strip(): raise ValueError('metric must not be empty')
        experiment={'experiment_id':'opp-exp-'+uuid.uuid4().hex,'type':'opportunity_validation_test',
                    'metric':str(metric).strip(),'hypothesis':loop.hypothesis,
                    'controls':('Define a baseline before testing.', 'Change one major variable at a time.',
                                'Record observed results from an approved/verified source.'),
                    'status':'PLANNED'}
        now=time.time(); updated=self._replace(loop,stage='EXPERIMENT_READY',experiment=experiment,updated_at=now)
        self.store.save(updated); return updated

    def record_result(self, loop_id: str, result: Mapping[str, Any]) -> OpportunityLoop:
        loop=self._require(loop_id)
        if loop.stage != 'EXPERIMENT_READY': raise ValueError('experiment must be planned before recording a result')
        if not isinstance(result, Mapping) or not result: raise ValueError('result must not be empty')
        clean={str(k):v for k,v in result.items()}
        clean['observed']=True
        now=time.time(); updated=self._replace(loop,stage='RESULT_RECORDED',result=clean,updated_at=now)
        self.store.save(updated); return updated

    def learn(self, loop_id: str) -> OpportunityLoop:
        loop=self._require(loop_id)
        if loop.stage != 'RESULT_RECORDED': raise ValueError('an observed result is required before learning')
        analytics={'status':'MEASURED','experiment_id':loop.experiment.get('experiment_id'),'metrics':loop.result}
        brief=self.learning_engine.analyze(loop.project_id,analytics)
        now=time.time(); updated=self._replace(loop,stage='LEARNED',learning=brief.to_dict(),updated_at=now)
        self.store.save(updated); return updated

    def _theme_evidence(self, loop: OpportunityLoop) -> list[dict[str,Any]]:
        # Evidence is already embedded in the discovery theme only at start time;
        # keep this method intentionally conservative for persisted loops.
        return []

    def _require(self, loop_id: str) -> OpportunityLoop:
        loop=self.store.get(loop_id)
        if loop is None: raise KeyError('opportunity loop not found')
        return loop

    @staticmethod
    def _replace(loop: OpportunityLoop, **changes: Any) -> OpportunityLoop:
        data=loop.to_dict(); data.update(changes); data['limitations']=tuple(data.get('limitations') or ())
        return OpportunityLoop(**data)
