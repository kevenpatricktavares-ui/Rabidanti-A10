"""Rabidanti v5.8 read-only operational observability.

Aggregates health signals for humans. It never mutates runtime state, grants
permissions, executes remediation, or calls external services.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from rabidanti_recovery import RecoverySession


SEVERITY_ORDER = {"OK": 0, "WARNING": 1, "CRITICAL": 2}


class OperationalObservability:
    def __init__(self, runtime: Any) -> None:
        self.runtime = runtime

    @staticmethod
    def _alert(alerts: list[dict[str, Any]], severity: str, code: str, title: str, detail: str) -> None:
        alerts.append({"severity": severity, "code": code, "title": title, "detail": detail})

    def snapshot(self) -> dict[str, Any]:
        status = self.runtime.status()
        doctor = self.runtime.doctor()
        recovery = RecoverySession.status(self.runtime.paths.root)
        providers = self.runtime.provider_status()
        connectors = self.runtime.list_connectors()
        model = self.runtime.model_status()
        events = self.runtime.runtime_events(limit=25)
        alerts: list[dict[str, Any]] = []

        for check in doctor.get("checks", []):
            if not check.get("ok") and check.get("name") != "container_runtime":
                self._alert(alerts, "CRITICAL", f"DOCTOR_{str(check.get('name')).upper()}",
                            f"Falha no diagnóstico: {check.get('name')}", str(check.get("detail", "")))
        container_check = next((c for c in doctor.get("checks", []) if c.get("name") == "container_runtime"), None)
        if container_check and not container_check.get("ok"):
            self._alert(alerts, "WARNING", "CONTAINER_RUNTIME_UNAVAILABLE", "Isolamento por container indisponível",
                        str(container_check.get("detail", "")))

        workers = status.get("workers", {})
        stale_ids = workers.get("stale_worker_ids") or []
        if stale_ids:
            self._alert(alerts, "CRITICAL", "STALE_WORKERS", "Workers sem heartbeat", ", ".join(map(str, stale_ids)))

        task_failed = int(status.get("tasks", {}).get("counts", {}).get("FAILED", 0) or 0)
        if task_failed:
            self._alert(alerts, "WARNING", "FAILED_TASKS", "Tarefas falhadas", f"{task_failed} tarefa(s) em FAILED")
        queue_failed = int(status.get("queue", {}).get("counts", {}).get("FAILED", 0) or 0)
        if queue_failed:
            self._alert(alerts, "WARNING", "FAILED_QUEUE_ITEMS", "Itens falhados na fila", f"{queue_failed} item(ns) em FAILED")

        if recovery.get("heartbeat_stale"):
            self._alert(alerts, "CRITICAL", "HEARTBEAT_STALE", "Heartbeat desktop stale",
                        f"idade={recovery.get('heartbeat_age_seconds')}s")

        for provider in providers:
            provider_state = str(provider.get("status", "")).upper()
            if provider_state in {"ERROR", "REVOKED", "EXPIRED"}:
                self._alert(alerts, "WARNING", "PROVIDER_" + provider_state,
                            f"Provider {provider.get('display_name') or provider.get('provider_id')} requer atenção",
                            provider_state)

        for connector in connectors:
            if connector.get("enabled") and not connector.get("secrets_ready"):
                self._alert(alerts, "WARNING", "CONNECTOR_SECRETS_MISSING",
                            f"Conector ativo sem credenciais prontas: {connector.get('connector_id')}",
                            "Desative o conector ou configure os segredos necessários.")
            if connector.get("enabled") and not connector.get("runtime_handler_loaded"):
                self._alert(alerts, "CRITICAL", "CONNECTOR_HANDLER_MISSING",
                            f"Conector ativo sem handler: {connector.get('connector_id')}",
                            "O conector não deve ser considerado operacional.")

        if not model.get("reachable", False):
            self._alert(alerts, "WARNING", "MODEL_UNREACHABLE", "Modelo local indisponível",
                        str(model.get("error") or model.get("base_url") or "Ollama não alcançável"))

        overall = "OK"
        if alerts:
            overall = max((a["severity"] for a in alerts), key=lambda s: SEVERITY_ORDER[s])

        return {
            "program": "Rabidanti",
            "schema": 1,
            "version": self.runtime.version,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "overall": overall,
            "healthy": overall != "CRITICAL",
            "alerts": alerts,
            "summary": {
                "alerts_total": len(alerts),
                "critical": sum(1 for a in alerts if a["severity"] == "CRITICAL"),
                "warning": sum(1 for a in alerts if a["severity"] == "WARNING"),
                "tasks": status.get("tasks"),
                "queue": status.get("queue"),
                "workers": {k: workers.get(k) for k in ("healthy", "total", "counts", "stale_worker_ids")},
                "connectors": status.get("connectors"),
            },
            "doctor": doctor,
            "recovery": recovery,
            "model": model,
            "providers": providers,
            "connectors": connectors,
            "product_self_test": {"available": True, "automatic_run": False, "persistent_user_state_modified": False},
            "recent_events": events,
            "safety": {
                "read_only": True,
                "automatic_remediation": False,
                "external_action_authorized": False,
                "self_authorization": False,
            },
        }
