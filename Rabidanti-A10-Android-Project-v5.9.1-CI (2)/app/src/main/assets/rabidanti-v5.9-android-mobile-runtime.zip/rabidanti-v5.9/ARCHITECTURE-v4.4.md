# Rabidanti v4.4 — Connector Framework & Permission Gate Architecture

## Goal

Provide one controlled contract for all future external integrations without coupling third-party APIs directly into the Core.

## Components

### `rabidanti_connectors.py`

Defines:

- `ConnectorAccess`
- `ConnectorCapability`
- `ConnectorDefinition`
- `ConnectorContext`
- `ConnectorRegistry`
- connector-specific permission/rate-limit exceptions
- canonical request digest generation

### Persistent connector ledger

`<state-dir>/connectors.sqlite3` stores:

- connector definitions and enabled state;
- one-time action approvals;
- invocation metadata/outcomes;
- schema version.

It does **not** store secret values or raw invocation payloads.

### Permission model

`READ` capability:

- connector must be registered in the current process;
- connector must be explicitly enabled;
- required secrets must be configured;
- rate limit must permit execution.

`WRITE` capability additionally requires:

- explicit human approval;
- approval bound to connector + capability + canonical payload SHA-256;
- approval unused at invocation time.

The approval is consumed once before connector code receives the action.

### Runtime integration

`RabidantiRuntime` owns a `ConnectorRegistry` and exposes connector registration, activation, approvals, invocation and audit queries. Connector audit events flow through the existing redacted runtime event store.

### API integration

The local API exposes discovery, activation and approval surfaces. It deliberately omits a generic invocation endpoint in v4.4.

### Sala integration

The Sala provides visibility into connector state and allows authenticated activation/deactivation. It does not bypass connector permissions.

## Trust boundary

A connector handler is executable code and therefore must be reviewed before inclusion. The framework constrains activation, secrets, write authorization, rate and audit, but cannot make malicious connector code safe by itself.

## Future extension

v4.5+ can implement real provider adapters as separate modules/packages using this contract, beginning with read-only connectors and provider-native OAuth/scopes where possible.
