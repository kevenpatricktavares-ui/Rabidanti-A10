# Rabidanti v3.32 — Research Engine Integration

The business `research` stage is now connected to a real deterministic domain engine.

Flow:
Core → Business Workflow → `business.stage.research` → ResearchEngine → structured ResearchBrief → durable job result.

The engine is evidence-bounded. It does not claim live market research unless external evidence is supplied in the stage context. Missing evidence is recorded as a limitation rather than fabricated.

Future work can replace/extend the evidence-ingestion layer with approved web, scientific, market and repository connectors without changing the workflow contract.
