"""Rabidanti v3.57 — Knowledge Graph to Lab & Opportunity Intelligence.

Turns sufficiently supported graph relationships into bounded research and
opportunity hypotheses. It never treats a graph edge as commercial proof or
as a scientific discovery. Every generated item preserves graph provenance.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional
import json, sqlite3, threading, time, uuid

from knowledge_graph import WorldKnowledgeGraph, RelationStatus, KnowledgeRelation
from laboratory import LaboratoryEngine

_ALLOWED_STATUSES = {RelationStatus.VERIFIED, RelationStatus.SUPPORTED}

@dataclass(frozen=True)
class IntelligenceCandidate:
    candidate_id: str
    kind: str  # LAB_INVESTIGATION | OPPORTUNITY_HYPOTHESIS
    relation_id: str
    subject_id: str
    object_id: str
    predicate: str
    confidence: float
    title: str
    hypothesis: str
    evidence: tuple[dict, ...]
    limitations: tuple[str, ...]
    created_at: float
    def to_dict(self): return asdict(self)

class KnowledgeIntelligenceStore:
    def __init__(self, db_path: str):
        self.db_path=db_path; self._lock=threading.RLock()
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory=sqlite3.Row
        if db_path != ':memory:': self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS knowledge_intelligence_candidates (
            candidate_id TEXT PRIMARY KEY, kind TEXT NOT NULL, relation_id TEXT NOT NULL,
            subject_id TEXT NOT NULL, object_id TEXT NOT NULL, predicate TEXT NOT NULL,
            confidence REAL NOT NULL, title TEXT NOT NULL, hypothesis TEXT NOT NULL,
            evidence_json TEXT NOT NULL, limitations_json TEXT NOT NULL, created_at REAL NOT NULL,
            UNIQUE(kind, relation_id))''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_ki_kind ON knowledge_intelligence_candidates(kind)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_ki_relation ON knowledge_intelligence_candidates(relation_id)')

    def save(self, c: IntelligenceCandidate) -> IntelligenceCandidate:
        with self._lock:
            self._conn.execute('''INSERT OR REPLACE INTO knowledge_intelligence_candidates
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                (c.candidate_id,c.kind,c.relation_id,c.subject_id,c.object_id,c.predicate,
                 c.confidence,c.title,c.hypothesis,json.dumps(list(c.evidence),ensure_ascii=False),
                 json.dumps(list(c.limitations),ensure_ascii=False),c.created_at))
        return c

    def get(self, candidate_id: str) -> Optional[IntelligenceCandidate]:
        with self._lock: row=self._conn.execute('SELECT * FROM knowledge_intelligence_candidates WHERE candidate_id=?',(candidate_id,)).fetchone()
        return None if not row else self._row(row)

    def get_for_relation(self, kind: str, relation_id: str) -> Optional[IntelligenceCandidate]:
        with self._lock: row=self._conn.execute('SELECT * FROM knowledge_intelligence_candidates WHERE kind=? AND relation_id=?',(kind,relation_id)).fetchone()
        return None if not row else self._row(row)

    def list(self, kind: Optional[str]=None, limit: int=500) -> list[IntelligenceCandidate]:
        with self._lock:
            if kind: rows=self._conn.execute('SELECT * FROM knowledge_intelligence_candidates WHERE kind=? ORDER BY created_at DESC LIMIT ?',(kind,int(limit))).fetchall()
            else: rows=self._conn.execute('SELECT * FROM knowledge_intelligence_candidates ORDER BY created_at DESC LIMIT ?',(int(limit),)).fetchall()
        return [self._row(r) for r in rows]

    @staticmethod
    def _row(r):
        return IntelligenceCandidate(r['candidate_id'],r['kind'],r['relation_id'],r['subject_id'],r['object_id'],r['predicate'],r['confidence'],r['title'],r['hypothesis'],tuple(json.loads(r['evidence_json'])),tuple(json.loads(r['limitations_json'])),r['created_at'])

class KnowledgeIntelligenceEngine:
    def __init__(self, graph: WorldKnowledgeGraph, store: KnowledgeIntelligenceStore):
        self.graph=graph; self.store=store

    def _eligible(self, *, min_confidence: float, statuses=_ALLOWED_STATUSES) -> list[KnowledgeRelation]:
        if not 0 <= float(min_confidence) <= 1: raise ValueError('min_confidence must be between 0 and 1')
        relations=self.graph.store.relations(limit=5000)
        return [r for r in relations if r.status in statuses and r.confidence >= float(min_confidence)]

    def _candidate(self, kind: str, relation: KnowledgeRelation) -> IntelligenceCandidate:
        subject=self.graph.store.entity(relation.subject_id); obj=self.graph.store.entity(relation.object_id)
        if subject is None or obj is None: raise KeyError('graph relation references missing entity')
        statement=f"{subject.name} {relation.predicate.replace('_',' ')} {obj.name}."
        if kind == 'LAB_INVESTIGATION':
            title=f"Investigate: {subject.name} / {relation.predicate} / {obj.name}"
            hypothesis=f"The relationship '{statement}' may reveal a research question, mechanism, application, or limitation worth testing."
        else:
            title=f"Opportunity hypothesis: {subject.name} / {relation.predicate} / {obj.name}"
            hypothesis=f"The relationship '{statement}' may indicate an opportunity to investigate a useful product, service, or application."
        evidence=({
            'relation_id':relation.relation_id,'status':relation.status.value,'confidence':relation.confidence,
            'source_id':relation.source_id,'claim_id':relation.claim_id,'note':relation.note,
        },)
        limitations=(
            'This item is a hypothesis generated from supported knowledge, not a validated discovery.',
            'Additional primary evidence and domain-specific research are required.',
            'For opportunity hypotheses, demand, willingness-to-pay, competition, feasibility and profitability are not inferred.',
        )
        return IntelligenceCandidate('ki-'+uuid.uuid4().hex,kind,relation.relation_id,relation.subject_id,relation.object_id,relation.predicate,relation.confidence,title,hypothesis,evidence,limitations,time.time())

    def generate_lab_investigations(self, *, min_confidence: float=.75, limit: int=50) -> list[IntelligenceCandidate]:
        if not 1 <= int(limit) <= 500: raise ValueError('limit must be between 1 and 500')
        out=[]
        for r in self._eligible(min_confidence=min_confidence):
            existing=self.store.get_for_relation('LAB_INVESTIGATION',r.relation_id)
            out.append(existing or self.store.save(self._candidate('LAB_INVESTIGATION',r)))
            if len(out)>=int(limit): break
        return out

    def generate_opportunity_hypotheses(self, *, min_confidence: float=.75, limit: int=50) -> list[IntelligenceCandidate]:
        if not 1 <= int(limit) <= 500: raise ValueError('limit must be between 1 and 500')
        out=[]
        for r in self._eligible(min_confidence=min_confidence):
            existing=self.store.get_for_relation('OPPORTUNITY_HYPOTHESIS',r.relation_id)
            out.append(existing or self.store.save(self._candidate('OPPORTUNITY_HYPOTHESIS',r)))
            if len(out)>=int(limit): break
        return out

    def create_lab_projects(self, laboratory: LaboratoryEngine, *, min_confidence: float=.75, limit: int=20) -> list:
        candidates=self.generate_lab_investigations(min_confidence=min_confidence,limit=limit)
        projects=[]
        for c in candidates:
            lab_id='lab-kg-'+c.relation_id
            existing=laboratory.store.get(lab_id)
            if existing is not None: projects.append(existing); continue
            p=laboratory.create(title=c.title,question=c.hypothesis,domain='knowledge-graph',hypothesis=c.hypothesis,lab_id=lab_id)
            laboratory.investigate(p.lab_id,evidence=list(c.evidence),findings=['Generated from a supported/verified knowledge-graph relationship; validation remains required.'])
            projects.append(laboratory.store.get(p.lab_id))
        return projects
