# Rabidanti v3.90 — Laboratory Container Executor

Adds a fail-closed execution gate on top of the v3.89 container plan. Every run requires explicit per-run approval, a reachable Docker/Podman runtime, a digest-pinned image, a valid existing workspace, mandatory isolation flags, bounded timeout, and networking disabled. Output is capped and a SHA-256 audit digest is returned.

**Environment status:** this build environment does not provide Docker or Podman, so no real container execution is claimed or verified. Tests cover policy gates and simulated runtime-unavailable behavior. Runtime availability is not itself proof of effective isolation; harden and independently review the host before enabling untrusted experiments.

Run: `pytest -q`
