# Rabidanti v3.61 — Controlled Adaptive Prioritization

Adds bounded, evidence-based proposals for revising prioritization weights.
Execution outcomes preserve the original decision components. The adaptive
engine compares completion rates for high vs low observed factor values and
creates a capped proposal only when evidence is sufficient.

Important: association is not causation. Proposals are advisory and are never
automatically applied. Any strategy change must follow test → explicit approval
→ integration → monitoring → rollback if needed.
