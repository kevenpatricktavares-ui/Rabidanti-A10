"""Rabidanti v3.25 — durable workflow/DAG orchestration foundation."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Optional
from durable_worker_queue import DurableWorkerQueue, QueueItemState

@dataclass(frozen=True)
class WorkflowNode:
    task_id: str
    dependencies: tuple[str, ...] = ()
    priority: int = 0

@dataclass(frozen=True)
class WorkflowPlan:
    task_ids: tuple[str, ...]
    ready_task_ids: tuple[str, ...]
    blocked_task_ids: tuple[str, ...]
    completed_task_ids: tuple[str, ...]

class WorkflowCycleError(ValueError):
    pass

class WorkflowEngine:
    """Validate DAGs and project durable queue state into workflow plans."""
    def __init__(self, queue: DurableWorkerQueue):
        self.queue = queue

    @staticmethod
    def validate(nodes: Iterable[WorkflowNode]) -> tuple[WorkflowNode, ...]:
        items = tuple(nodes)
        ids = [n.task_id for n in items]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate workflow task_id")
        known = set(ids)
        graph = {n.task_id: tuple(n.dependencies) for n in items}
        for n in items:
            if n.task_id in n.dependencies:
                raise WorkflowCycleError("workflow contains self-cycle")
            missing = [d for d in n.dependencies if d not in known]
            if missing:
                raise ValueError(f"missing workflow dependency: {missing[0]}")
        visiting, visited = set(), set()
        def visit(t: str):
            if t in visiting:
                raise WorkflowCycleError("workflow contains a cycle")
            if t in visited:
                return
            visiting.add(t)
            for dep in graph[t]:
                visit(dep)
            visiting.remove(t); visited.add(t)
        for t in graph: visit(t)
        return items

    def register(self, nodes: Iterable[WorkflowNode], payloads: Optional[dict[str, object]] = None,
                 max_attempts: int = 3) -> tuple[str, ...]:
        items = self.validate(nodes)
        payloads = payloads or {}
        for n in items:
            if self.queue.get_by_task_id(n.task_id) is not None:
                raise ValueError(f"task already exists: {n.task_id}")
        for n in items:
            self.queue.enqueue(payloads.get(n.task_id, {}), priority=n.priority,
                               max_attempts=max_attempts, task_id=n.task_id,
                               dependencies=n.dependencies)
        return tuple(n.task_id for n in items)


    def parallel_batches(self, task_ids: Optional[Iterable[str]] = None) -> tuple[tuple[str, ...], ...]:
        """Return executable DAG layers; independent tasks share a batch.

        Completed tasks are treated as already satisfied. A batch contains tasks
        whose dependencies are satisfied by completed tasks or an earlier batch.
        The method is planning-only and never claims or mutates queue state.
        """
        selected = tuple(task_ids) if task_ids is not None else tuple(x.task_id for x in self.queue.list())
        selected_set = set(selected)
        items = {x.task_id: x for x in self.queue.list() if x.task_id in selected_set}
        completed = {x.task_id for x in items.values() if x.state == QueueItemState.COMPLETED}
        remaining = {tid for tid, x in items.items() if x.state != QueueItemState.COMPLETED}
        batches: list[tuple[str, ...]] = []
        while remaining:
            ready = sorted(
                tid for tid in remaining
                if all(dep in completed or dep not in selected_set for dep in items[tid].dependencies)
            )
            if not ready:
                break
            batch = tuple(ready)
            batches.append(batch)
            completed.update(batch)
            remaining.difference_update(batch)
        return tuple(batches)

    def plan(self, task_ids: Optional[Iterable[str]] = None) -> WorkflowPlan:
        selected = tuple(task_ids) if task_ids is not None else tuple(x.task_id for x in self.queue.list())
        ready = {x.task_id for x in self.queue.ready()}
        completed = {x.task_id for x in self.queue.list() if x.state == QueueItemState.COMPLETED}
        blocked = tuple(t for t in selected if t not in ready and t not in completed)
        return WorkflowPlan(selected, tuple(t for t in selected if t in ready), blocked,
                            tuple(t for t in selected if t in completed))
