from __future__ import annotations

import json
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from rabidanti_api import RabidantiApiService
from rabidanti_runtime import RabidantiRuntime
from rabidanti import build_parser

TOKEN = "s" * 32


def _service(tmp_path: Path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    service = RabidantiApiService(runtime, port=0, token=TOKEN)
    addr = service.start()
    return runtime, service, f"http://{addr.host}:{addr.port}"


def _raw(base: str, path: str):
    req = Request(base + path, method="GET")
    with urlopen(req, timeout=3) as r:
        return r.status, dict(r.headers), r.read()


def test_ui_assets_exist_and_are_local_files():
    root = Path(__file__).with_name("ui")
    assert (root / "index.html").is_file()
    assert (root / "app.js").is_file()
    assert (root / "style.css").is_file()
    html = (root / "index.html").read_text(encoding="utf-8")
    assert "https://" not in html
    assert "http://" not in html
    assert "/ui/app.js" in html
    assert "/ui/style.css" in html


def test_root_redirects_to_sala_and_ui_is_served(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        # urllib follows the root redirect; the final document is the Sala.
        status, headers, body = _raw(base, "/")
        text = body.decode("utf-8")
        assert status == 200
        assert "Rabidanti" in text and "Sala" in text
        assert headers["Content-Type"].startswith("text/html")
    finally:
        service.stop(); runtime.stop()


def test_ui_assets_have_strict_security_headers(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        for path in ("/ui/", "/ui/app.js", "/ui/style.css"):
            status, headers, _ = _raw(base, path)
            assert status == 200
            assert headers["X-Frame-Options"] == "DENY"
            assert headers["X-Content-Type-Options"] == "nosniff"
            assert headers["Referrer-Policy"] == "no-referrer"
            csp = headers["Content-Security-Policy"]
            assert "default-src 'self'" in csp
            assert "object-src 'none'" in csp
            assert "frame-ancestors 'none'" in csp
    finally:
        service.stop(); runtime.stop()


def test_sala_does_not_embed_mutation_token(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        _, _, body = _raw(base, "/ui/")
        assert TOKEN.encode() not in body
        _, _, js = _raw(base, "/ui/app.js")
        assert TOKEN.encode() not in js
    finally:
        service.stop(); runtime.stop()


def test_sala_uses_bearer_token_only_for_mutation():
    js = Path("ui/app.js").read_text(encoding="utf-8")
    assert "Authorization" in js and "Bearer ${token}" in js
    assert "localStorage" not in js
    assert "sessionStorage" not in js
    assert "document.cookie" not in js


def test_sala_exposes_governance_without_claiming_authority():
    html = Path("ui/index.html").read_text(encoding="utf-8")
    assert "Decisões registadas" in html
    assert "Não equivalem a validação científica" in html
    assert "nenhuma ação externa é autorizada" in html


def test_ui_unknown_asset_returns_404(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        with pytest.raises(HTTPError) as exc:
            urlopen(base + "/ui/nope.js", timeout=3)
        assert exc.value.code == 404
    finally:
        service.stop(); runtime.stop()


def test_room_cli_is_explicitly_loopback_configured():
    parser = build_parser()
    args = parser.parse_args(["room", "--no-browser"])
    assert args.command == "room"
    assert args.host == "127.0.0.1"
    assert args.port == 8765
    assert args.no_browser is True


def test_version_is_semver_and_not_older_than_4_2():
    raw = Path("VERSION").read_text(encoding="utf-8").strip()
    parts = raw.split(".")
    assert len(parts) == 3 and all(x.isdigit() for x in parts)
    assert tuple(map(int, parts)) >= (4, 2, 0)
