from dataclasses import dataclass
from collections import defaultdict


@dataclass(frozen=True)
class SignalCorrelation:
    correlation_id: str
    signal_ids: tuple
    domains: tuple
    strength: float
    rationale: str


class EvolutionSignalCorrelator:
    """Deterministic, bounded correlation layer; it proposes patterns, not actions."""

    def __init__(self, min_strength=0.60, max_signals=12):
        if not 0 <= min_strength <= 1:
            raise ValueError("min_strength must be between 0 and 1")
        if max_signals < 2:
            raise ValueError("max_signals must be at least 2")
        self.min_strength = min_strength
        self.max_signals = max_signals
        self._signals = {}
        self._correlations = {}

    def add_signal(self, signal_id, domain, confidence, delta):
        if not signal_id or not domain:
            raise ValueError("signal_id and domain are required")
        if signal_id in self._signals:
            raise ValueError("duplicate signal_id")
        if not 0 <= confidence <= 1:
            raise ValueError("confidence must be between 0 and 1")
        if not -1 <= delta <= 1:
            raise ValueError("delta must be between -1 and 1")
        self._signals[signal_id] = (domain, confidence, delta)

    def correlate(self, correlation_id, signal_ids):
        if not correlation_id or correlation_id in self._correlations:
            raise ValueError("invalid or duplicate correlation_id")
        ids = tuple(signal_ids)
        if len(ids) < 2 or len(ids) > self.max_signals:
            raise ValueError("invalid signal count")
        if len(set(ids)) != len(ids):
            raise ValueError("duplicate signal in correlation")
        if any(i not in self._signals for i in ids):
            raise ValueError("unknown signal")
        rows = [self._signals[i] for i in ids]
        confidence = sum(r[1] for r in rows) / len(rows)
        magnitude = sum(abs(r[2]) for r in rows) / len(rows)
        domain_count = len(set(r[0] for r in rows))
        diversity = min(1.0, domain_count / 3.0)
        strength = round((confidence * 0.5) + (magnitude * 0.3) + (diversity * 0.2), 6)
        if strength < self.min_strength:
            raise ValueError("correlation strength below threshold")
        domains = tuple(sorted(set(r[0] for r in rows)))
        c = SignalCorrelation(
            correlation_id, ids, domains, strength,
            "combined confidence, signal magnitude and domain diversity"
        )
        self._correlations[correlation_id] = c
        return c

    def get(self, correlation_id):
        return self._correlations.get(correlation_id)

    def list_correlations(self):
        return tuple(self._correlations.values())

    def domain_summary(self):
        out = defaultdict(int)
        for domain, _, _ in self._signals.values():
            out[domain] += 1
        return dict(out)
