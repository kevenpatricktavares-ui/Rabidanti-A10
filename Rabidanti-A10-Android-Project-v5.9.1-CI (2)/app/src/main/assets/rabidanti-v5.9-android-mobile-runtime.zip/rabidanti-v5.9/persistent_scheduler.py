
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import sqlite3
from threading import Lock
from typing import Optional

@dataclass
class PersistentSchedule:
    task_id: str
    run_at: datetime
    interval_seconds: Optional[int]
    enabled: bool
    runs: int = 0

class PersistentScheduler:
    def __init__(self, db_path="rabidanti_scheduler.sqlite3", clock=None):
        self.db_path = db_path
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.lock = Lock()
        self._init()

    def _conn(self):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        return c

    def _init(self):
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS schedules(
                task_id TEXT PRIMARY KEY,
                run_at TEXT NOT NULL,
                interval_seconds INTEGER,
                enabled INTEGER NOT NULL,
                runs INTEGER NOT NULL DEFAULT 0
            )""")
            c.commit()

    @staticmethod
    def _dt(v):
        return datetime.fromisoformat(v)

    def add(self, task_id, run_at, interval_seconds=None):
        if interval_seconds is not None and interval_seconds < 1:
            raise ValueError("interval_seconds must be >= 1")
        with self.lock, self._conn() as c:
            try:
                c.execute(
                    "INSERT INTO schedules(task_id,run_at,interval_seconds,enabled,runs) VALUES(?,?,?,?,0)",
                    (task_id, run_at.isoformat(), interval_seconds, 1)
                )
                c.commit()
            except sqlite3.IntegrityError:
                raise ValueError("task already exists")

    def cancel(self, task_id):
        with self.lock, self._conn() as c:
            cur = c.execute("UPDATE schedules SET enabled=0 WHERE task_id=?", (task_id,))
            if cur.rowcount == 0:
                raise KeyError(task_id)
            c.commit()

    def due(self, now=None):
        now = now or self.clock()
        with self.lock, self._conn() as c:
            rows = c.execute(
                "SELECT * FROM schedules WHERE enabled=1 AND run_at<=? ORDER BY run_at,task_id",
                (now.isoformat(),)
            ).fetchall()
        return [
            PersistentSchedule(
                r["task_id"], self._dt(r["run_at"]),
                r["interval_seconds"], bool(r["enabled"]), r["runs"]
            ) for r in rows
        ]

    def acknowledge(self, task_id, now=None):
        now = now or self.clock()
        with self.lock, self._conn() as c:
            row = c.execute(
                "SELECT interval_seconds FROM schedules WHERE task_id=?", (task_id,)
            ).fetchone()
            if row is None:
                raise KeyError(task_id)
            if row["interval_seconds"] is None:
                c.execute(
                    "UPDATE schedules SET enabled=0,runs=runs+1 WHERE task_id=?",
                    (task_id,)
                )
            else:
                nxt = now + timedelta(seconds=row["interval_seconds"])
                c.execute(
                    "UPDATE schedules SET run_at=?,runs=runs+1 WHERE task_id=?",
                    (nxt.isoformat(), task_id)
                )
            c.commit()

    def list(self):
        with self._conn() as c:
            rows = c.execute(
                "SELECT * FROM schedules ORDER BY run_at,task_id"
            ).fetchall()
        return [
            PersistentSchedule(
                r["task_id"], self._dt(r["run_at"]),
                r["interval_seconds"], bool(r["enabled"]), r["runs"]
            ) for r in rows
        ]

class PersistentSchedulerLoop:
    def __init__(self, scheduler, enqueue):
        self.scheduler = scheduler
        self.enqueue = enqueue

    def tick(self, now=None):
        due = list(self.scheduler.due(now))
        queued = []
        for task in due:
            result = self.enqueue(task.task_id)
            queued.append(result)
            self.scheduler.acknowledge(task.task_id, now)
        return queued
