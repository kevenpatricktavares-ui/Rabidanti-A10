# Rabidanti v3.92 — Evidence-aware Laboratory Result Analysis

Adds `lab_result_analyzer.py`, which reviews a recorded run against every predeclared success criterion. The reviewer must classify each criterion as `PASS`, `FAIL`, or `INCONCLUSIVE` and supply an evidence note. Missing or extra criteria, missing evidence, an unknown run, or a missing reviewer are rejected.

- Verified executed run + all criteria PASS -> experiment `PASSED`.
- Any criterion FAIL -> experiment `FAILED`.
- Any INCONCLUSIVE and no FAIL -> remains in `ANALYSIS` for further work.
- Unverified/blocked execution -> report `BLOCKED`; never claims criteria passed.
- Each analysis report is persisted as a recommendation entry and includes an evidence digest where applicable.
- Integration is never authorized by this analyzer. Reproducibility and independent scientific validation remain separate steps.

Run tests: `pytest -q`.
