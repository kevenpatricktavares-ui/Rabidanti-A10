"""
Rabidanti v3.10 — Distributed Coordination Foundation.

SQLite-backed coordination primitives for multiple worker processes sharing
the same durable database. This provides atomic task claims, leases, heartbeats,
ownership checks and lease expiry recovery.

It is a coordination foundation, not a claim of cloud deployment, autoscaling,
multi-region operation, or production-grade distributed infrastructure.
"""

from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import dataclass
from typing import Optional


@dataclass
class CoordinationLease:
    task_id: str
    worker_id: str
    lease_until: float
    attempts: int


class DistributedCoordinator:
    """Coordinate workers through a shared SQLite database."""

    def __init__(self, db_path: str, lease_seconds: int = 60):
        if lease_seconds < 1:
            raise ValueError("lease_seconds must be >= 1")
        self.db_path = db_path
        self.lease_seconds = lease_seconds
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            db_path, check_same_thread=False, isolation_level=None
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        if db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")
            self._conn.execute("PRAGMA synchronous = NORMAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS worker_leases (
                task_id TEXT PRIMARY KEY,
                worker_id TEXT NOT NULL,
                lease_until REAL NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                updated_at REAL NOT NULL
            )
            """
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_worker_leases_expiry "
            "ON worker_leases(lease_until)"
        )

    def try_claim(self, task_id: str, worker_id: str) -> Optional[CoordinationLease]:
        """Atomically claim a task if no active lease exists."""
        if not task_id or not worker_id:
            raise ValueError("task_id and worker_id are required")
        now = time.time()
        until = now + self.lease_seconds
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute(
                    "SELECT * FROM worker_leases WHERE task_id=?",
                    (task_id,),
                ).fetchone()
                if row is not None and float(row["lease_until"]) > now:
                    self._conn.execute("COMMIT")
                    return None

                attempts = int(row["attempts"]) + 1 if row is not None else 1
                self._conn.execute(
                    """
                    INSERT INTO worker_leases(task_id,worker_id,lease_until,attempts,updated_at)
                    VALUES(?,?,?,?,?)
                    ON CONFLICT(task_id) DO UPDATE SET
                        worker_id=excluded.worker_id,
                        lease_until=excluded.lease_until,
                        attempts=excluded.attempts,
                        updated_at=excluded.updated_at
                    """,
                    (task_id, worker_id, until, attempts, now),
                )
                self._conn.execute("COMMIT")
                return CoordinationLease(task_id, worker_id, until, attempts)
            except Exception:
                self._conn.execute("ROLLBACK")
                raise

    def heartbeat(self, task_id: str, worker_id: str) -> CoordinationLease:
        now = time.time()
        until = now + self.lease_seconds
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM worker_leases WHERE task_id=?",
                (task_id,),
            ).fetchone()
            if row is None:
                raise KeyError(task_id)
            if row["worker_id"] != worker_id:
                raise PermissionError("worker does not own lease")
            self._conn.execute(
                """
                UPDATE worker_leases
                SET lease_until=?, updated_at=?
                WHERE task_id=? AND worker_id=?
                """,
                (until, now, task_id, worker_id),
            )
            return CoordinationLease(task_id, worker_id, until, int(row["attempts"]))

    def release(self, task_id: str, worker_id: str) -> None:
        with self._lock:
            row = self._conn.execute(
                "SELECT worker_id FROM worker_leases WHERE task_id=?",
                (task_id,),
            ).fetchone()
            if row is None:
                return
            if row["worker_id"] != worker_id:
                raise PermissionError("worker does not own lease")
            self._conn.execute(
                "DELETE FROM worker_leases WHERE task_id=? AND worker_id=?",
                (task_id, worker_id),
            )

    def recover_expired(self) -> list[str]:
        now = time.time()
        with self._lock:
            rows = self._conn.execute(
                "SELECT task_id FROM worker_leases WHERE lease_until<=?",
                (now,),
            ).fetchall()
            ids = [r["task_id"] for r in rows]
            if ids:
                # Preserve the attempt counter so the next claimant inherits
                # the number of attempts already consumed.
                self._conn.execute(
                    """
                    UPDATE worker_leases
                    SET worker_id='', lease_until=0, updated_at=?
                    WHERE lease_until<=?
                    """,
                    (now, now),
                )
            return ids

    def get(self, task_id: str) -> Optional[CoordinationLease]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM worker_leases WHERE task_id=?",
                (task_id,),
            ).fetchone()
        if row is None:
            return None
        return CoordinationLease(
            task_id=row["task_id"],
            worker_id=row["worker_id"],
            lease_until=float(row["lease_until"]),
            attempts=int(row["attempts"]),
        )

    def active(self) -> list[CoordinationLease]:
        now = time.time()
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM worker_leases WHERE lease_until>?",
                (now,),
            ).fetchall()
        return [
            CoordinationLease(
                task_id=r["task_id"],
                worker_id=r["worker_id"],
                lease_until=float(r["lease_until"]),
                attempts=int(r["attempts"]),
            )
            for r in rows
        ]

    def close(self) -> None:
        with self._lock:
            self._conn.close()
