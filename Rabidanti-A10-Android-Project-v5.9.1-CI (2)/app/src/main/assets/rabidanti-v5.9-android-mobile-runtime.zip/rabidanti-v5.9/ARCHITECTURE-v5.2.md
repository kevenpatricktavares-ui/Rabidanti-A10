# Architecture v5.2 — Desktop Build & Installer Hardening

## Objetivo

Transformar a fundação executável v5.0/v5.1 numa distribuição desktop mais robusta sem deslocar autoridade para o launcher ou instalador.

## Componentes novos/alterados

### `rabidanti_desktop.py`
- `DesktopInstanceLease`: lock exclusivo em `<state-dir>/desktop-instance.lock`.
- Bloqueia uma segunda instância se o PID proprietário estiver vivo.
- Recupera locks stale/corrompidos.
- Só remove um lock que ainda pertença ao próprio processo/token.
- `show_startup_error`: diálogo gráfico com fallback para stderr.

### `rabidanti_launcher.py`
- O arranque desktop sem argumentos adquire a lease.
- `SIGTERM` é convertido em encerramento controlado, permitindo libertar a lease e parar o serviço local.
- Erros de startup tornam-se visíveis em builds sem consola.
- Com argumentos explícitos, preserva o comportamento CLI anterior.

### Empacotamento Windows
- `Rabidanti.spec`: `console=False`, ícone e version resource.
- `rabidanti_version_info.txt`: metadata 5.2.0.
- `build_windows.bat`: testes + compilação + build + smoke test do binário.
- `installer_windows.iss`: instalador Inno Setup per-user.
- `build_installer_windows.bat`: build do binário seguido do instalador.

## Segurança

A camada desktop não recebe Permission Gate alternativo, credenciais novas nem caminhos de execução externos. O instalador não pede privilégios administrativos por defeito.

## Limites

A presença de scripts/spec não prova que o binário Windows é válido. A validação nativa exige PyInstaller/Inno Setup e execução num host Windows.
