from __future__ import annotations

from pathlib import Path
from urllib.parse import parse_qs, urlparse
import json

import httpx
import pytest

from rabidanti_vault import EncryptedCredentialVault, VaultIntegrityError, VaultLocked
from rabidanti_oauth import OAuthPKCEManager, OAuthProvider, OAuthError
from gmail_connector import GmailReadOnlyHandler, gmail_definition
from rabidanti_runtime import RabidantiRuntime

MASTER = "correct horse battery staple rabidanti master key"


def test_vault_encrypts_value_and_never_persists_master(tmp_path):
    path = tmp_path / "credentials.vault.json"
    vault = EncryptedCredentialVault(path, MASTER)
    vault.set("API_TOKEN", "super-secret-value")
    raw = path.read_text()
    assert "super-secret-value" not in raw
    assert MASTER not in raw
    assert vault.get("API_TOKEN") == "super-secret-value"
    if __import__('os').name != 'nt':
        assert (path.stat().st_mode & 0o777) == 0o600


def test_vault_locked_cannot_decrypt(tmp_path):
    path = tmp_path / "vault.json"
    EncryptedCredentialVault(path, MASTER).set("GMAIL_ACCESS_TOKEN", "token-123")
    locked = EncryptedCredentialVault(path)
    assert locked.status()["unlocked"] is False
    with pytest.raises(VaultLocked):
        locked.get("GMAIL_ACCESS_TOKEN")


def test_vault_wrong_master_key_detected(tmp_path):
    path = tmp_path / "vault.json"
    EncryptedCredentialVault(path, MASTER).set("GMAIL_ACCESS_TOKEN", "token-123")
    with pytest.raises(VaultIntegrityError):
        EncryptedCredentialVault(path, "this is definitely a wrong master key 123").unlock(
            "this is definitely a wrong master key 123"
        )


def test_vault_delete_and_names(tmp_path):
    v = EncryptedCredentialVault(tmp_path / "v.json", MASTER)
    v.set("B_TOKEN", "b")
    v.set("A_TOKEN", "a")
    assert v.names() == ["A_TOKEN", "B_TOKEN"]
    assert v.delete("A_TOKEN") is True
    assert v.delete("A_TOKEN") is False
    assert v.names() == ["B_TOKEN"]


def provider(base):
    return OAuthProvider("test", base + "/authorize", base + "/token", ("scope.read",))


def test_oauth_start_uses_pkce_and_vault_for_verifier(tmp_path):
    vault = EncryptedCredentialVault(tmp_path / "v.json", MASTER)
    mgr = OAuthPKCEManager(vault)
    result = mgr.start(provider("https://id.example"), client_id="client", redirect_uri="http://127.0.0.1/cb")
    parsed = parse_qs(urlparse(result["authorization_url"]).query)
    assert parsed["code_challenge_method"] == ["S256"]
    assert "code_challenge" in parsed
    assert parsed["state"] == [result["state"]]
    flow_names = [n for n in vault.names() if n.startswith("OAUTH_FLOW_")]
    assert len(flow_names) == 1
    assert "code_verifier" not in result


def test_oauth_exchange_stores_tokens_and_consumes_flow(tmp_path):
    vault = EncryptedCredentialVault(tmp_path / "v.json", MASTER)
    calls = []
    class Response:
        status_code = 200
        def json(self):
            return {"access_token": "access-abc", "refresh_token": "refresh-xyz", "expires_in": 3600, "token_type": "Bearer"}
    def post(url, **kwargs):
        calls.append((url, kwargs))
        return Response()
    p = provider("https://id.example")
    mgr = OAuthPKCEManager(vault, post=post)
    start = mgr.start(p, client_id="client", redirect_uri="http://127.0.0.1/cb")
    result = mgr.exchange(p, flow_id=start["flow_id"], state=start["state"], code="abc", client_id="client")
    assert result["access_token_stored"] is True
    assert vault.get("GMAIL_ACCESS_TOKEN") == "access-abc"
    assert vault.get("GMAIL_REFRESH_TOKEN") == "refresh-xyz"
    assert not any(n.startswith("OAUTH_FLOW_") for n in vault.names())
    assert calls[0][0].endswith("/token")
    assert "code_verifier" in calls[0][1]["data"]


def test_oauth_rejects_state_mismatch_without_token_request(tmp_path):
    vault = EncryptedCredentialVault(tmp_path / "v.json", MASTER)
    called = []
    mgr = OAuthPKCEManager(vault, post=lambda *a, **k: called.append(1))
    p = provider("https://id.example")
    start = mgr.start(p, client_id="client", redirect_uri="http://127.0.0.1/cb")
    with pytest.raises(OAuthError):
        mgr.exchange(p, flow_id=start["flow_id"], state="wrong", code="abc", client_id="client")
    assert called == []


def make_mock_client(seen):
    def handler(request: httpx.Request):
        seen.append(request)
        assert request.headers["authorization"] == "Bearer test-token"
        if request.url.path.endswith("/profile"):
            return httpx.Response(200, json={"emailAddress": "user@example.com", "messagesTotal": 42})
        if request.url.path.endswith("/messages"):
            return httpx.Response(200, json={"messages": [{"id": "m1"}]})
        return httpx.Response(200, json={"id": "m1", "snippet": "hello"})
    return httpx.Client(transport=httpx.MockTransport(handler))


def test_gmail_definition_is_strictly_read_only():
    d = gmail_definition()
    assert d.connector_id == "gmail.readonly"
    assert d.required_secrets == ("GMAIL_ACCESS_TOKEN",)
    assert {c.access.value for c in d.capabilities} == {"READ"}
    assert all(not c.approval_required for c in d.capabilities)


def test_gmail_profile_calls_fixed_profile_endpoint():
    seen=[]
    h = GmailReadOnlyHandler(lambda n: "test-token", api_base="https://gmail.test/v1", client=make_mock_client(seen))
    out = h("gmail.profile", {}, None)
    assert out["emailAddress"] == "user@example.com"
    assert seen[0].url.path == "/v1/users/me/profile"


def test_gmail_list_validates_and_maps_query():
    seen=[]
    h = GmailReadOnlyHandler(lambda n: "test-token", api_base="https://gmail.test/v1", client=make_mock_client(seen))
    out = h("gmail.messages.list", {"query":"is:unread", "max_results":10, "label_ids":["INBOX"]}, None)
    assert out["messages"][0]["id"] == "m1"
    params = dict(seen[0].url.params.multi_items())
    assert params["q"] == "is:unread"
    assert params["maxResults"] == "10"


def test_gmail_get_escapes_message_id_and_restricts_format():
    seen=[]
    h = GmailReadOnlyHandler(lambda n: "test-token", api_base="https://gmail.test/v1", client=make_mock_client(seen))
    out = h("gmail.messages.get", {"message_id":"m/1", "format":"metadata"}, None)
    assert out["id"] == "m1"
    assert seen[0].url.path.endswith("/messages/m/1")  # URL parser presents decoded path, transport still fixed-origin
    with pytest.raises(ValueError):
        h("gmail.messages.get", {"message_id":"m1", "format":"raw"}, None)


def test_gmail_rejects_unknown_fields_and_oversized_list():
    h = GmailReadOnlyHandler(lambda n: "test-token", client=httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200,json={}))))
    with pytest.raises(ValueError):
        h("gmail.messages.list", {"url":"https://evil.example"}, None)
    with pytest.raises(ValueError):
        h("gmail.messages.list", {"max_results":101}, None)


def test_runtime_registers_gmail_but_keeps_it_disabled(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        row = next(x for x in rt.list_connectors() if x["connector_id"] == "gmail.readonly")
        assert row["enabled"] is False
        assert row["runtime_handler_loaded"] is True
        assert row["secrets_ready"] is False
        assert rt.vault_status()["master_key_persisted"] is False
    finally:
        rt.stop()


def test_runtime_secret_resolution_prefers_session_over_vault(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        rt.vault_set("GMAIL_ACCESS_TOKEN", "vault-token")
        assert rt.get_secret("GMAIL_ACCESS_TOKEN") == "vault-token"
        rt.set_session_secret("GMAIL_ACCESS_TOKEN", "session-token")
        assert rt.get_secret("GMAIL_ACCESS_TOKEN") == "session-token"
        assert "vault-token" not in (rt.paths.vault_file.read_text())
    finally:
        rt.stop()


def test_runtime_does_not_expose_master_key_in_status_or_events(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        rt.start()
        blob = json.dumps({"status": rt.status(), "events": rt.runtime_events()})
        assert MASTER not in blob
        assert rt.status()["safety"]["external_action_authorized"] is False
    finally:
        rt.stop()
