# Rabidanti v3.3 — Concurrent Workers

Bounded concurrent execution foundation on top of v3.2 persistent workers.
Concurrency is explicitly limited by worker_count. Existing persistence and
approval semantics remain authoritative. Distributed queues, autoscaling and
production deployment are not claimed by this version.
