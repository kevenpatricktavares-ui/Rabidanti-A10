# Rabidanti v4.8 — Model Manager & Agent Reasoning Runtime

## Objective
Add local model discovery/selection, versioned prompts, and a persistent planning layer that may propose actions but cannot execute or authorize them.

## Components
- `rabidanti_model_manager.py`: reads Ollama `/api/tags`, reports installed models, selects primary/fallback.
- `rabidanti_prompts.py`: versioned conversation and reasoning system prompts.
- `rabidanti_reasoning.py`: strict JSON planning layer + persistent `reasoning.sqlite3` proposal ledger.
- `rabidanti_conversation.py`: uses the versioned conversation prompt and reports prompt version.
- Runtime/API/CLI/Sala expose model status, reasoning proposals, and planning requests.

## Safety boundary
Reasoning output is untrusted model output. It is parsed through a strict schema and can only create `connector` or `internal_task` proposals. No proposal is executed. Connector mutations still require the independent ConnectorRegistry permission gate and one-time human approval. The reasoning layer never sets external or tool authorization to true.

## Model selection
The configured primary model is preferred. If it is not installed and `ai.fallback_model` is installed, chat/reasoning actually switch to that fallback. Both primary and fallback remain restricted to the local Ollama endpoint configured by the existing loopback-only policy.

## Not implemented / not validated
- No automatic model download/deletion.
- No arbitrary remote model provider.
- No automatic conversion of a proposal into connector execution.
- Ollama/model execution was not validated against a live Ollama daemon in this build environment; protocol behavior is covered by mocks.
