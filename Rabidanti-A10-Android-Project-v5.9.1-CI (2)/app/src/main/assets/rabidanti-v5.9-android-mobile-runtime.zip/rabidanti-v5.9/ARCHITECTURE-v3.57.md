# Rabidanti v3.57 — Knowledge Graph → Laboratory & Opportunity Intelligence

## Objective
Turn sufficiently supported knowledge-graph relationships into bounded research and opportunity hypotheses while preserving provenance.

## Flow
Knowledge Graph → eligibility (SUPPORTED/VERIFIED + confidence threshold) → hypothesis candidates → Laboratory / Opportunity work.

## Safety of inference
- CONTESTED, REJECTED, PROPOSED and low-confidence relations are not promoted by default.
- Laboratory outputs remain investigations/hypotheses, not discoveries.
- Opportunity outputs remain hypotheses; no demand, willingness-to-pay, competition, feasibility or profitability is inferred.
- Every candidate preserves relation, claim, source, confidence and limitations.

## Persistence
Candidate generation is SQLite-backed and idempotent per `(kind, relation_id)`. Lab projects use deterministic IDs derived from the originating relation.

## Deliberate scope
This version does not automatically run experiments, publish products, spend money, or declare discoveries. Those actions remain separate stages with their existing approval/validation gates.
