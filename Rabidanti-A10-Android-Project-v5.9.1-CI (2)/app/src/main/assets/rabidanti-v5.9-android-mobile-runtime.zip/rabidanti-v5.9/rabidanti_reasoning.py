"""Rabidanti v4.8 reasoning runtime.

Model output is parsed into *proposals only*. No proposal is executed here. Any
future connector execution must still go through ConnectorRegistry and, for
mutations, its one-time human approval gate.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import hashlib, json, re, sqlite3, uuid

from rabidanti_model_gateway import LocalOllamaGateway, ModelGatewayError
from rabidanti_prompts import REASONING_PROMPT_VERSION, REASONING_SYSTEM_PROMPT

_SAFE_ID=re.compile(r"^[a-z][a-z0-9_.-]{1,63}$")

class ReasoningError(RuntimeError): pass

class AgentReasoningRuntime:
    SCHEMA_VERSION=1
    def __init__(self, db_path: str|Path, gateway: LocalOllamaGateway):
        self.db_path=Path(db_path); self.gateway=gateway
        self.db_path.parent.mkdir(parents=True,exist_ok=True); self._init()
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    def _conn(self):
        c=sqlite3.connect(self.db_path); c.row_factory=sqlite3.Row; return c
    def _init(self):
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS reasoning_runs(
                reasoning_id TEXT PRIMARY KEY, prompt_version TEXT NOT NULL,
                input_digest TEXT NOT NULL, response_text TEXT NOT NULL,
                model TEXT NOT NULL, created_at TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS action_proposals(
                proposal_id TEXT PRIMARY KEY, reasoning_id TEXT NOT NULL,
                kind TEXT NOT NULL, proposal_json TEXT NOT NULL,
                proposal_digest TEXT NOT NULL, created_at TEXT NOT NULL,
                FOREIGN KEY(reasoning_id) REFERENCES reasoning_runs(reasoning_id))""")
    @staticmethod
    def _digest(value: Any)->str:
        raw=json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
        return hashlib.sha256(raw).hexdigest()
    @staticmethod
    def _clean_action(action: Any)->dict[str,Any]:
        if not isinstance(action,dict): raise ReasoningError("proposed action must be an object")
        kind=action.get("kind")
        if kind=="connector":
            allowed={"kind","connector_id","capability","payload","reason"}
            if set(action)-allowed: raise ReasoningError("connector proposal contains unknown fields")
            cid=action.get("connector_id"); cap=action.get("capability"); payload=action.get("payload"); reason=action.get("reason")
            if not isinstance(cid,str) or not _SAFE_ID.fullmatch(cid): raise ReasoningError("invalid connector_id")
            if not isinstance(cap,str) or not _SAFE_ID.fullmatch(cap): raise ReasoningError("invalid capability")
            if not isinstance(payload,dict): raise ReasoningError("connector payload must be an object")
            if not isinstance(reason,str) or not reason.strip() or len(reason)>1000: raise ReasoningError("invalid proposal reason")
            raw=json.dumps(payload,ensure_ascii=False).lower()
            if any(marker in raw for marker in ('"password"','"token"','"secret"','"api_key"','"private_key"')):
                raise ReasoningError("proposal payload appears to contain secret material")
            return {"kind":"connector","connector_id":cid,"capability":cap,"payload":payload,"reason":reason.strip()}
        if kind=="internal_task":
            allowed={"kind","name","reason"}
            if set(action)-allowed: raise ReasoningError("internal task proposal contains unknown fields")
            name=action.get("name"); reason=action.get("reason")
            if not isinstance(name,str) or not name.strip() or len(name)>500: raise ReasoningError("invalid task name")
            if not isinstance(reason,str) or not reason.strip() or len(reason)>1000: raise ReasoningError("invalid proposal reason")
            return {"kind":"internal_task","name":name.strip(),"reason":reason.strip()}
        raise ReasoningError("unsupported proposed action kind")
    def reason(self, request: str, context: str|None=None)->dict[str,Any]:
        if not isinstance(request,str) or not request.strip() or len(request)>20000: raise ValueError("request must be 1..20000 characters")
        if context is not None and (not isinstance(context,str) or len(context)>20000): raise ValueError("invalid context")
        user=request.strip() if not context else f"Request:\n{request.strip()}\n\nContext:\n{context.strip()}"
        reply=self.gateway.chat([{"role":"system","content":REASONING_SYSTEM_PROMPT},{"role":"user","content":user}])
        try: data=json.loads(reply.content)
        except json.JSONDecodeError as exc: raise ReasoningError("reasoning model did not return valid JSON") from exc
        if not isinstance(data,dict) or set(data)!={"response","proposed_actions"}: raise ReasoningError("reasoning response has invalid shape")
        if not isinstance(data["response"],str) or not data["response"].strip(): raise ReasoningError("reasoning response text is required")
        if not isinstance(data["proposed_actions"],list) or len(data["proposed_actions"])>20: raise ReasoningError("proposed_actions must be a list of at most 20")
        actions=[self._clean_action(a) for a in data["proposed_actions"]]
        rid=f"reason-{uuid.uuid4().hex}"; now=self._now(); input_digest=self._digest({"request":request,"context":context})
        with self._conn() as c:
            c.execute("INSERT INTO reasoning_runs VALUES(?,?,?,?,?,?)",(rid,REASONING_PROMPT_VERSION,input_digest,data["response"].strip(),reply.model,now))
            proposals=[]
            for action in actions:
                pid=f"proposal-{uuid.uuid4().hex}"; dg=self._digest(action)
                c.execute("INSERT INTO action_proposals VALUES(?,?,?,?,?,?)",(pid,rid,action["kind"],json.dumps(action,sort_keys=True,ensure_ascii=False),dg,now))
                proposals.append({"proposal_id":pid,"reasoning_id":rid,**action,"proposal_digest":dg,"execution_authorized":False})
        return {"reasoning_id":rid,"response":data["response"].strip(),"model":reply.model,"prompt_version":REASONING_PROMPT_VERSION,"proposed_actions":proposals,"external_action_authorized":False,"tool_execution_authorized":False}

    def get_proposal(self, proposal_id: str)->dict[str,Any]:
        if not isinstance(proposal_id,str) or not proposal_id.startswith("proposal-"):
            raise KeyError(proposal_id)
        with self._conn() as c:
            r=c.execute("SELECT * FROM action_proposals WHERE proposal_id=?",(proposal_id,)).fetchone()
        if r is None:
            raise KeyError(proposal_id)
        p=json.loads(r["proposal_json"])
        return {"proposal_id":r["proposal_id"],"reasoning_id":r["reasoning_id"],**p,"proposal_digest":r["proposal_digest"],"created_at":r["created_at"],"execution_authorized":False}

    def proposals(self, limit:int=100)->list[dict[str,Any]]:
        limit=max(1,min(int(limit),500))
        with self._conn() as c:
            rows=c.execute("SELECT * FROM action_proposals ORDER BY created_at DESC LIMIT ?",(limit,)).fetchall()
        out=[]
        for r in rows:
            p=json.loads(r["proposal_json"]); out.append({"proposal_id":r["proposal_id"],"reasoning_id":r["reasoning_id"],**p,"proposal_digest":r["proposal_digest"],"created_at":r["created_at"],"execution_authorized":False})
        return out
