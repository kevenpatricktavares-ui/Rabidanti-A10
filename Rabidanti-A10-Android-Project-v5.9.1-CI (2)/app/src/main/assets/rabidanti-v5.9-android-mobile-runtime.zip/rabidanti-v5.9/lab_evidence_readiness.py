"""Rabidanti v3.96 — Laboratory Evidence Readiness Gate.

Evaluates whether a laboratory experiment has enough internally recorded and
linked evidence to be presented for human review. It is intentionally fail-
closed: readiness is not scientific validation, deployment approval, or Core
integration authority.
"""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib, json

from lab_evidence_integration import LabEvidenceIntegration


class LabEvidenceReadinessGate:
    READY = "READY_FOR_HUMAN_REVIEW"
    NOT_READY = "NOT_READY"
    INSUFFICIENT = "INSUFFICIENT_EVIDENCE"

    def __init__(self, experiment_manager, evidence_memory):
        if experiment_manager is None or evidence_memory is None:
            raise ValueError("experiment_manager and evidence_memory are required")
        self.manager = experiment_manager
        self.memory = evidence_memory
        self.bridge = LabEvidenceIntegration(experiment_manager, evidence_memory)

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)

    def _ensure_link(self, from_id, relation, to_id, note=""):
        trace = self.memory.trace(from_id)
        for link in trace["links"]:
            if link["from_id"] == from_id and link["relation"] == relation and link["to_id"] == to_id:
                return link
        return self.memory.link(from_id, relation, to_id, note=note)

    def _snapshot(self, experiment_id):
        exp_node_id = f"experiment:{experiment_id}"
        trace = self.memory.trace(exp_node_id)
        runs, analyses, repros = {}, {}, {}
        for link in trace["links"]:
            if link["from_id"] != exp_node_id:
                continue
            meta = link["other_metadata"]
            if link["relation"] == "EXECUTED_AS":
                runs[link["to_id"]] = meta
            elif link["relation"] == "HAS_ANALYSIS":
                analyses[link["to_id"]] = meta
            elif link["relation"] == "HAS_REPRODUCIBILITY":
                repros[link["to_id"]] = meta
        body = {
            "experiment": self.manager.get(experiment_id).__dict__,
            "runs": runs,
            "analyses": analyses,
            "reproducibility": repros,
        }
        digest = hashlib.sha256(self._canonical(body).encode()).hexdigest()
        return body, digest

    def assess(self, experiment_id, *, minimum_runs=2, persist=True):
        if not isinstance(minimum_runs, int) or isinstance(minimum_runs, bool) or minimum_runs < 2:
            raise ValueError("minimum_runs must be an integer >= 2")

        # Synchronize authoritative laboratory records before evaluating them.
        self.bridge.sync_experiment(experiment_id)
        snapshot, digest = self._snapshot(experiment_id)
        exp = snapshot["experiment"]
        runs = snapshot["runs"]
        analyses = snapshot["analyses"]
        repros = snapshot["reproducibility"]

        reasons = []
        executed = {nid: r for nid, r in runs.items() if r.get("executed") is True}
        if len(executed) < minimum_runs:
            reasons.append(f"requires at least {minimum_runs} verified executed runs; found {len(executed)}")

        analyses_by_run = {}
        for nid, report in analyses.items():
            rid = report.get("run_id")
            if isinstance(rid, str) and rid:
                analyses_by_run.setdefault(rid, []).append((nid, report))

        passed_analysis_nodes = []
        for run_node, run in executed.items():
            rid = run.get("run_id")
            candidates = analyses_by_run.get(rid, [])
            passed = [(nid, r) for nid, r in candidates if r.get("classification") == "PASSED"]
            if not candidates:
                reasons.append(f"executed run {rid} has no reviewed analysis")
            elif not passed:
                states = sorted({str(r.get('classification', 'UNKNOWN')) for _, r in candidates})
                reasons.append(f"executed run {rid} has no PASSED analysis ({', '.join(states)})")
            else:
                passed_analysis_nodes.extend(nid for nid, _ in passed)

        consistent_repros = []
        for nid, report in repros.items():
            run_ids = report.get("run_ids") or []
            if report.get("classification") == "CONSISTENT" and len(set(run_ids)) >= minimum_runs:
                if all(f"run:{rid}" in executed for rid in run_ids):
                    consistent_repros.append(nid)
        if not consistent_repros:
            reasons.append("no CONSISTENT reproducibility assessment covers the required executed runs")

        if exp.get("status") != "PASSED":
            reasons.append(f"experiment status is {exp.get('status')}, not PASSED")

        if len(executed) < minimum_runs or any("no reviewed analysis" in r for r in reasons):
            classification = self.INSUFFICIENT
        elif reasons:
            classification = self.NOT_READY
        else:
            classification = self.READY

        report = {
            "readiness_id": f"readiness:{experiment_id}:{digest[:24]}",
            "experiment_id": experiment_id,
            "classification": classification,
            "minimum_runs": minimum_runs,
            "executed_runs": len(executed),
            "passed_analysis_count": len(set(passed_analysis_nodes)),
            "consistent_reproducibility_count": len(consistent_repros),
            "reasons": reasons,
            "evidence_snapshot_digest": digest,
            "scientifically_validated": False,
            "integration_authorized": False,
            "human_review_required": classification == self.READY,
            "created_at": self._now(),
            "limitations": [
                "Readiness only evaluates recorded internal evidence and link consistency.",
                "It does not independently verify source truth, scientific validity, runtime isolation, or external reproducibility.",
            ],
        }
        if persist:
            self._persist(report, passed_analysis_nodes, consistent_repros)
        return report

    def _persist(self, report, analysis_nodes, repro_nodes):
        node_id = report["readiness_id"]
        try:
            existing = self.memory.get_node(node_id)
            if existing["kind"] != "DECISION":
                raise ValueError(f"evidence node {node_id} exists with incompatible kind")
        except KeyError:
            self.memory.add_node(
                "DECISION",
                f"Readiness {report['experiment_id']}",
                f"Laboratory evidence readiness: {report['classification']}",
                node_id=node_id,
                content=self._canonical({k: v for k, v in report.items() if k != "created_at"}),
                metadata=report,
            )
        exp_node = f"experiment:{report['experiment_id']}"
        self._ensure_link(exp_node, "HAS_READINESS_ASSESSMENT", node_id, "Evidence readiness assessment; no integration authority")
        for support in sorted(set(analysis_nodes + repro_nodes)):
            self._ensure_link(node_id, "SUPPORTED_BY", support, "Recorded evidence supporting readiness assessment")
        return self.memory.get_node(node_id)

    def authorize_integration(self, *args, **kwargs):
        raise PermissionError("readiness assessment cannot authorize Core integration")
