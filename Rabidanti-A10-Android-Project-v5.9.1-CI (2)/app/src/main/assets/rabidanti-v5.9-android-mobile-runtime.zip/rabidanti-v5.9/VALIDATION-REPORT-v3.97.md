# Rabidanti v3.97 — Validation Report

## Release
- Version: `3.97.0`
- Name: **Laboratory Human Review & Decision Workflow**
- Base release: v3.96

## Baseline verification
Before changing the v3.96 source tree, the complete existing test suite was executed.

- Baseline tests: **464 passed**
- Baseline failures: **0**

## Implemented in v3.97
`lab_human_review.py` adds a persistent human-governance stage after the v3.96 evidence-readiness gate.

A review can only be opened when the current evidence snapshot is classified `READY_FOR_HUMAN_REVIEW`.

Supported immutable final decisions:
- `APPROVED`
- `REJECTED`
- `MORE_EVIDENCE_REQUIRED`

The workflow records:
- experiment ID;
- readiness assessment ID;
- exact evidence snapshot digest;
- asserted reviewer/requester identity;
- decision rationale;
- timestamps;
- immutable review events;
- linked `DECISION` evidence node in the Evidence Memory.

Repeated submission of the same readiness snapshot is idempotent. A decided review cannot be overwritten. New evidence produces a new readiness snapshot and can therefore enter a new review without deleting prior decisions.

## Safety boundaries verified
A human-review approval in v3.97 does **not** grant:
- scientific validation;
- Core integration authority;
- deployment authority;
- external-action authority;
- publication authority;
- spending/payment authority.

Reviewer identity is recorded as `ASSERTED_ONLY`; this module does not authenticate the human identity cryptographically.

## New tests
`test_v3_97_lab_human_review.py` adds 8 tests covering:
1. persistent review creation for ready experiments;
2. refusal of non-ready experiments;
3. approval provenance and non-authority guarantees;
4. rejection and more-evidence decisions;
5. immutable final decisions;
6. restart persistence and history;
7. duplicate-review prevention for the same evidence snapshot;
8. input validation and fail-closed permission boundaries.

New-version tests: **8 passed / 0 failed**.

## Full regression
Full source-tree suite after implementation:

- **472 passed**
- **0 failed**

`python -m compileall -q .` also completed without syntax/bytecode compilation errors.

## Known limitations
- Human identity is asserted text, not authenticated identity.
- Evidence readiness and human approval do not independently establish scientific truth.
- Docker/Podman runtime isolation was not newly validated by this version.
- v3.97 does not integrate approved laboratory decisions into the Core; that remains a separate explicit-control boundary.
- External platform connectors, complete production audiovisual generation, payments, and final 24/7 deployment remain outside the verified scope of this release.

## Conclusion
v3.97 is validated as a backward-compatible governance extension to the Laboratory evidence flow. It formalizes human review while preserving the project's principle: freedom to investigate and propose does not imply authority to integrate or act externally.

## Distribution-package verification
The generated ZIP was extracted into a clean verification directory and the complete test suite was executed from the extracted package itself.

- Package test result: **472 passed / 0 failed**
- Package VERSION: `3.97.0`
