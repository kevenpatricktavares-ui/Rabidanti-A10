# Rabidanti v3.68 — Evolution Controller

Controlled lifecycle coordinator:
PROPOSED → EXPERIMENTING → PROMOTION_PENDING → ACTIVATION_PENDING → ACTIVE → HEALTH_REVIEW → ROLLBACK_RECOMMENDED → ROLLED_BACK.

Activation and rollback require explicit approval. Invalid transitions are rejected and history is preserved. This layer does not bypass experiments, promotions, queue ownership, capacity, versioning, security or approvals.
