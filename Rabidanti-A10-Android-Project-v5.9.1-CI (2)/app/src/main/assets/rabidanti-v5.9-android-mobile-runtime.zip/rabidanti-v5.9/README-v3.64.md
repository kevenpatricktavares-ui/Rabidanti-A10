# Rabidanti v3.64

Forward controlled experiments are now connected to real execution planning.

### Added
- `experiment_execution_planner.py`
- experiment-aware priority ordering
- stable persistent CONTROL/TREATMENT assignments
- actual worker outcome recording
- runner integration with the v3.63 experiment engine

### Safety boundaries
Experiments remain advisory. Dependencies, capacity, approvals, durable queue claims, leases and worker ownership remain authoritative. No experiment automatically changes production weights.

### Validation
- Full pytest suite: 283 passed
- Python compileall: passed
