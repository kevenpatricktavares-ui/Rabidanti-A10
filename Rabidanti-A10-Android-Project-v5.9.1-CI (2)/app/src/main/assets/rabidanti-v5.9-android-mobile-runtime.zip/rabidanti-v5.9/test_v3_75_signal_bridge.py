from evolution_signal_runtime_bridge import (
    EvolutionSignalRuntimeBridge, SignalRuntimeInput
)
from evolution_runtime import EvolutionRuntime
from evolution_cycle_store import EvolutionCycleStore
from evolution_cycle_audit import EvolutionCycleAudit
from evolution_decision_controller_bridge import EvolutionDecisionControllerBridge
from evolution_evidence_decision import EvolutionEvidenceDecisionEngine, EvidenceAssessment


class Controller:
    def request_activation(self,pid): return "requested"


def assessment(**kw):
    d=dict(evidence_confidence=.9, expected_impact=.8, risk=.2,
           estimated_cost=.2, reversibility=.9)
    d.update(kw)
    return EvidenceAssessment(**d)


def bridge():
    c=Controller()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    s=EvolutionCycleStore()
    r=EvolutionRuntime(b, EvolutionCycleAudit(s))
    return EvolutionSignalRuntimeBridge(r),s


def test_signal_reaches_runtime_and_audit():
    br,s=bridge()
    out=br.process(SignalRuntimeInput("sig1","p1",assessment(),"evt1"))
    assert out.proposal_id=="p1"
    assert s.latest("p1").event_id=="evt1"


def test_blocked_signal_is_audited():
    br,s=bridge()
    out=br.process(SignalRuntimeInput(
        "sig2","p2",assessment(evidence_confidence=.4),"evt2"))
    assert out.gate=="blocked"
    assert s.latest("p2").gate=="blocked"


def test_duplicate_signal_is_rejected():
    br,_=bridge()
    x=SignalRuntimeInput("sig3","p3",assessment(),"evt3")
    br.process(x)
    try:
        br.process(x)
        assert False
    except ValueError:
        assert True


def test_missing_identifiers_rejected():
    br,_=bridge()
    try:
        br.process(SignalRuntimeInput("","p4",assessment(),"evt4"))
        assert False
    except ValueError:
        assert True


def test_bridge_does_not_activate():
    br,s=bridge()
    br.process(SignalRuntimeInput("sig5","p5",assessment(),"evt5"))
    assert s.latest("p5").decision=="approval_required"
