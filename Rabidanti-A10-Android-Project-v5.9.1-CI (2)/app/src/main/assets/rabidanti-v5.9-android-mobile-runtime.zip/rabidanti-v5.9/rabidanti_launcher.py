#!/usr/bin/env python3
"""User-facing Rabidanti launcher used by source and frozen builds."""
from __future__ import annotations

from pathlib import Path
import os
import signal
import sys

from rabidanti_product import default_state_dir
from rabidanti_desktop import DesktopInstanceLease, AlreadyRunningError, show_startup_error
from rabidanti_recovery import RecoverySession


def launcher_args(argv: list[str]) -> list[str]:
    if argv:
        return argv
    return ["--state-dir", str(default_state_dir()), "room"]


def _desktop_default(argv: list[str]) -> bool:
    return len(argv) == 0


def main(argv: list[str] | None = None) -> int:
    raw = list(sys.argv[1:] if argv is None else argv)
    from rabidanti import main as cli_main
    if not _desktop_default(raw):
        return cli_main(launcher_args(raw))

    state_dir = default_state_dir()
    lease = DesktopInstanceLease(Path(state_dir))
    previous_term = None
    if hasattr(signal, "SIGTERM"):
        previous_term = signal.getsignal(signal.SIGTERM)
        signal.signal(signal.SIGTERM, lambda _signum, _frame: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        version = Path(__file__).with_name("VERSION").read_text(encoding="utf-8").strip()
        with lease, RecoverySession(Path(state_dir), version):
            return cli_main(["--state-dir", str(state_dir), "room"])
    except AlreadyRunningError as exc:
        show_startup_error(str(exc))
        return 2
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        show_startup_error(f"Rabidanti could not start.\n\n{type(exc).__name__}: {exc}")
        return 1
    finally:
        if previous_term is not None:
            signal.signal(signal.SIGTERM, previous_term)


if __name__ == "__main__":
    raise SystemExit(main())
