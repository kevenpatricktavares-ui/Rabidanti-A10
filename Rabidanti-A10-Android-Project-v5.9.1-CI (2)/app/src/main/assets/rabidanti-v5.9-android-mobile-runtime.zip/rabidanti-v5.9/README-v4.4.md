# Rabidanti v4.4 — Connector Framework & Permission Gate

Rabidanti v4.4 introduces a common security boundary for future external integrations. This release does **not** connect to Gmail, Google, Meta, YouTube, Shopify or any other third-party account by itself.

## Connector contract

Each connector must declare:

- stable `connector_id` and version;
- human-readable display name;
- capabilities;
- whether each capability is `READ` or `WRITE`;
- required secret names;
- a per-minute rate limit.

Write capabilities are always forced to require explicit per-action human approval.

## Lifecycle

A connector is registered in code but remains disabled by default.

Typical flow:

1. register connector implementation;
2. configure required secret(s) through the v4.3 secrets layer;
3. explicitly enable the connector with actor + reason;
4. execute read capabilities within the declared permission surface;
5. for write capabilities, create a one-time approval bound to the exact request digest;
6. invoke the approved action;
7. record audit-safe metadata and outcome.

Approvals cannot be reused and cannot be applied to a modified payload.

## Secret and payload handling

Connector secrets are retrieved through the non-persistent `RabidantiSecrets` boundary. The connector database stores secret **names**, never secret values.

Raw invocation payloads are also not stored in the connector ledger. Only a SHA-256 digest of the canonical request is persisted with audit metadata.

This reduces accidental credential/data retention but does not make arbitrary connector code trustworthy. Each real connector still requires review and tests.

## Runtime / CLI

```bash
python rabidanti.py connector list
python rabidanti.py connector set <connector_id> on --actor "creator" --reason "approved integration"
python rabidanti.py connector set <connector_id> off --actor "creator" --reason "maintenance"
```

The v4.4 package ships with **no third-party connector enabled or connected**.

## Local API

Read-only:

- `GET /v1/connectors`
- `GET /v1/connectors/approvals`
- `GET /v1/connectors/invocations`

Authenticated mutations:

- `POST /v1/connectors/control`
- `POST /v1/connectors/approve`

There is intentionally **no generic HTTP connector invocation endpoint** in v4.4. This prevents the local API from becoming an arbitrary external-action surface before real connector-specific policies exist.

## Sala

The Sala now contains a **Conectores** tab showing registered connectors, capability types, secret readiness, activation state, approvals and invocation history. Connector enable/disable remains bearer-token protected and requires actor + justification.

## Safety boundaries

v4.4 does not change the project's core principles:

- registration is not activation;
- secret presence is not authorization;
- activation is not write authorization;
- write authorization is one-time and bound to exact payload digest;
- no connector can self-authorize its own write action;
- no account is connected merely by starting Rabidanti;
- no external action is authorized by runtime startup.

## Known limitations

- No real third-party connector is bundled in this release.
- No OS credential vault integration exists yet.
- Read permissions are connector-level once explicitly enabled; future real connectors should add provider scopes and resource-level policy where available.
- Rate limiting is local to the Rabidanti process/database and does not replace provider-side quotas.
