# Rabidanti v4.3 — Validation Report

## Baseline

Input package: `rabidanti-v4.2-sala-local-interface.zip`

- SHA-256: `f4ee9ea8bf0c319814a787f594a61f73f51449c0d0cee0f353b228f4f114817a`
- VERSION before changes: `4.2.0`
- Baseline regression: **525 passed / 0 failed**

## Implemented in v4.3

- `rabidanti_config.py`
  - schema-limited persistent configuration;
  - atomic writes;
  - POSIX `0600` mode where supported;
  - rejection of unsupported and secret-shaped keys;
  - recursive audit redaction;
  - non-persistent environment/session secret resolver.
- Runtime integration
  - `config.json` under the selected state directory;
  - configuration and secret-status methods;
  - secret-count-only runtime status;
  - audit redaction before SQLite writes.
- Local API integration
  - `GET /v1/config`;
  - `GET /v1/secrets` metadata only;
  - authenticated `POST /v1/config`;
  - authenticated `POST /v1/secrets/session`;
  - API mutation token can resolve from `RABIDANTI_SECRET_API_TOKEN`.
- CLI integration
  - `config show` / `config set`;
  - `secret status` / `secret set` / `secret clear`;
  - secret values are prompted rather than accepted as command-line arguments.
- Sala integration
  - local configuration/secret controls;
  - no localStorage/sessionStorage/cookie persistence of credentials.

## Test results

New v4.3 tests: **11 passed / 0 failed**.

Full regression after version-test maintenance: **536 passed / 0 failed**.

One historical v4.2 test initially failed because it required the literal string `4.2.0`. It was changed to validate SemVer and require a version not older than 4.2, preserving the actual invariant while allowing subsequent releases.

Python bytecode compilation (`python -m compileall -q .`): **PASS**.

CLI smoke tests:
- `config show`: PASS
- `config set api.port 9009`: PASS
- persisted config reload: PASS
- `secret status`: PASS

## Security findings / boundaries

Verified:
- secret-like keys cannot be stored in persistent configuration;
- session secret values are not returned by status APIs;
- session secret values are absent from state files in tests;
- secret-looking audit fields are redacted before persistence;
- mutations still require the loopback API bearer token;
- no external connector or action is authorized by secret presence.

Not claimed:
- OS credential vault/keychain persistence is **not implemented**;
- environment variables are not equivalent to a hardware-backed or OS-vault secret;
- secrets embedded inside arbitrary free-form text cannot be guaranteed detectable by key-based redaction;
- remote operation remains disabled by the local API binding policy;
- Docker/Podman isolation remains environment-dependent.
