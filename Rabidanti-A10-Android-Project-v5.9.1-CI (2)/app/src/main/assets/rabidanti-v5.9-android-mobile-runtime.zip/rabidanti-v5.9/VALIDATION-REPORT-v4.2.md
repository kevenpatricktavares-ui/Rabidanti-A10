# Rabidanti v4.2 — Relatório de Validação

## Baseline
- Pacote de entrada: v4.1
- SHA-256 de entrada: `279e92ee99c832977faf8e3e8eb06785093e942b5d59e97206d50bfaa52862c2`
- Baseline executada antes das alterações: **516 passed**

## Alterações verificadas
- Sala local servida pelo mesmo serviço HTTP loopback-only.
- Interface sem CDN ou framework externo.
- Dashboard de status, tarefas, evidências, decisões, workflows, eventos e diagnóstico.
- Criação de tarefas via endpoint existente autenticado.
- Token não embutido na UI e não persistido no armazenamento do browser.
- Security headers: CSP, no-store, nosniff, DENY framing e no-referrer.
- Novo comando `rabidanti.py room`.

## Testes
- Testes novos v4.2: **9 passed**.
- Testes v4.1 + v4.2 em conjunto: **19 passed**.
- Regressão completa: **525 passed**.
- `python -m compileall -q .`: **PASS**.

## Limitações verificadas
- Docker/Podman não é requisito da Sala e permanece indisponível neste ambiente.
- A interface não é um serviço remoto e não deve ser exposta à Internet.
- Decisões exibidas na Sala continuam a ser evidência de governação, não validação científica.
- Nenhuma ação externa ou integração automática do Core é concedida.
