# Rabidanti v3.13 — Worker Supervisor & Health

## Objetivo
Adicionar uma camada persistente de supervisão dos workers, permitindo ao Rabidanti saber quais workers existem, sua capacidade, carga, estado e último heartbeat.

## Capacidades
- registro persistente de workers;
- capacidade configurável;
- contagem de trabalho ativo;
- estados STARTING/RUNNING/DRAINING/STOPPED/STALE;
- heartbeat persistente;
- detecção de workers stale;
- listagem e inspeção de saúde;
- remoção de registros;
- compatível com múltiplos processos usando SQLite/WAL.

## Limites
Esta versão não afirma cloud deployment, autoscaling, leader election, broker externo, multi-region ou monitorização de produção. É uma fundação para essas etapas.

## Próxima evolução
Integrar o supervisor ao ContinuousWorkerRunner e, depois, adicionar health checks do processo, recuperação coordenada e telemetria operacional.
