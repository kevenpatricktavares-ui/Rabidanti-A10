# Validation Report — Rabidanti v5.8

## Release

- Version: `5.8.0`
- Feature: Observability & Diagnostics Dashboard

## New validation coverage

11 new tests validate:

1. healthy/read-only operational snapshot;
2. required doctor failure => CRITICAL;
3. unavailable container runtime => WARNING;
4. stale worker => CRITICAL;
5. failed task/queue signals => WARNING;
6. revoked provider and unavailable model alerts;
7. enabled connector without secrets/handler;
8. read-only API endpoint;
9. CLI `observe` command;
10. Sala operations dashboard wiring;
11. release version invariant.

## Development-tree regression

- v5.x: 109 passed
- v4.x: 121 passed
- v3.x: 157 passed
- historical `tests/`: 337 passed
- Total: **724 passed / 0 failed**

Additional checks:

- `compileall`: PASS
- `node --check ui/app.js`: PASS
- release preflight: 25/25 PASS
- CLI `observe` smoke test: PASS
- snapshot declares `read_only=true`: PASS
- `external_action_authorized=false`: PASS

## Environment-specific observation

In the Linux validation environment the operational snapshot reported `WARNING`, not because of a v5.8 regression, but because optional Docker/Podman isolation and the configured local Ollama model were unavailable. The dashboard correctly surfaced these conditions instead of claiming they were healthy.

## Native Windows limitation

This report does not claim a validated Windows executable or installer. Native Windows release validation still requires the v5.6+ Windows handoff pipeline and real Windows artifacts.
