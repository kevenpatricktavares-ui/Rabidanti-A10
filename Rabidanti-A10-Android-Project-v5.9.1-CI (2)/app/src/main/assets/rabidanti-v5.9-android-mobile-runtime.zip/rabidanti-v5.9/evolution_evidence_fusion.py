from dataclasses import dataclass

@dataclass(frozen=True)
class EvidenceItem:
    evidence_id: str
    confidence: float
    relevance: float
    independence: float

@dataclass(frozen=True)
class EvidenceFusion:
    fusion_id: str
    evidence_count: int
    independent_weight: float
    average_confidence: float
    average_relevance: float
    pattern_score: float
    fused_score: float
    status: str

class EvolutionEvidenceFusion:
    def __init__(self, min_items=2, min_independence=0.30):
        if min_items < 1: raise ValueError("min_items must be positive")
        if not 0 <= min_independence <= 1: raise ValueError("min_independence must be between 0 and 1")
        self.min_items=min_items
        self.min_independence=min_independence
        self._items={}

    def add(self,item):
        if not item.evidence_id: raise ValueError("evidence_id is required")
        if item.evidence_id in self._items: raise ValueError("duplicate evidence_id")
        if any(not 0 <= v <= 1 for v in (item.confidence,item.relevance,item.independence)):
            raise ValueError("evidence factors must be between 0 and 1")
        self._items[item.evidence_id]=item

    def fuse(self,fusion_id,evidence_ids,pattern_score=0.0):
        if not fusion_id: raise ValueError("fusion_id is required")
        ids=tuple(evidence_ids)
        if len(ids)<self.min_items: raise ValueError("insufficient evidence items")
        if len(set(ids))!=len(ids): raise ValueError("duplicate evidence item")
        if any(i not in self._items for i in ids): raise ValueError("unknown evidence")
        if not 0 <= pattern_score <= 1: raise ValueError("pattern_score must be between 0 and 1")
        rows=[self._items[i] for i in ids]
        independence=sum(r.independence for r in rows)/len(rows)
        confidence=sum(r.confidence for r in rows)/len(rows)
        relevance=sum(r.relevance for r in rows)/len(rows)
        weight=max(0.0,min(1.0,independence))
        base=confidence*.35+relevance*.25+pattern_score*.40
        fused=round(base*(.75+.25*weight),6)
        if weight < self.min_independence: status="LOW_INDEPENDENCE"
        elif fused >= .75: status="STRONG_FUSED_EVIDENCE"
        elif fused >= .55: status="MODERATE_FUSED_EVIDENCE"
        else: status="WEAK_FUSED_EVIDENCE"
        return EvidenceFusion(fusion_id,len(rows),round(weight,6),round(confidence,6),
                              round(relevance,6),pattern_score,fused,status)
