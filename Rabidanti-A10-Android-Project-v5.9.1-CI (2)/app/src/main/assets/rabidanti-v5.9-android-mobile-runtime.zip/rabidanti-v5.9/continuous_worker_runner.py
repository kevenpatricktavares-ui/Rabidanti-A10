"""Rabidanti v3.12 — Continuous Worker Runner.

Runs durable queue work continuously with bounded concurrency, heartbeats,
lease recovery, handler dispatch, graceful shutdown and execution statistics.
This remains an in-process runner; it does not claim cloud/autoscaling.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable, Optional

from durable_worker_queue import DurableWorkerQueue, QueueItem, QueueItemState
from worker_supervisor import WorkerSupervisor, WorkerStatus
from observability import ObservabilityStore
from health_monitor import HealthMonitor
from recovery_controller import RecoveryController
from resource_capacity import ResourceCapacityMonitor
from capacity_intelligence import CapacityIntelligence
from execution_planner import ExecutionPlanner, PlannedItem
from priority_execution_planner import PriorityAwareExecutionPlanner
from experiment_execution_planner import ExperimentAwarePriorityExecutionPlanner
from forward_experiment import ForwardExperimentEngine
from intelligence_prioritization import PriorityDecision


@dataclass
class RunnerStats:
    ticks: int = 0
    claimed: int = 0
    completed: int = 0
    failed: int = 0
    recovered: int = 0
    rejected: int = 0


class ContinuousWorkerRunner:
    def __init__(self, queue: DurableWorkerQueue, max_workers: int = 2,
                 poll_interval: float = 0.05, worker_prefix: str = "runner",
                 supervisor: Optional[WorkerSupervisor] = None,
                 observability: Optional[ObservabilityStore] = None,
                 health_monitor: Optional[HealthMonitor] = None,
                 recovery_controller: Optional[RecoveryController] = None,
                 capacity_monitor: Optional[ResourceCapacityMonitor] = None,
                 capacity_intelligence: Optional[CapacityIntelligence] = None,
                 execution_planner: Optional[ExecutionPlanner] = None,
                 priority_decisions_provider: Optional[Callable[[list[QueueItem]], Any]] = None,
                 experiment_engine: Optional[ForwardExperimentEngine] = None,
                 experiment_id: Optional[str] = None):
        if max_workers < 1:
            raise ValueError("max_workers must be >= 1")
        if poll_interval < 0:
            raise ValueError("poll_interval must be >= 0")
        self.queue = queue
        self.max_workers = int(max_workers)
        self.poll_interval = float(poll_interval)
        self.worker_prefix = worker_prefix or "runner"
        self.supervisor = supervisor
        self.observability = observability
        self.health_monitor = health_monitor
        self.recovery_controller = recovery_controller
        self.capacity_monitor = capacity_monitor
        self.capacity_intelligence = capacity_intelligence
        self.execution_planner = execution_planner
        self.priority_decisions_provider = priority_decisions_provider
        self.experiment_engine = experiment_engine
        self.experiment_id = experiment_id
        if self.experiment_id and self.experiment_engine is None:
            raise ValueError("experiment_engine is required when experiment_id is set")
        if self.experiment_id and not isinstance(self.execution_planner, ExperimentAwarePriorityExecutionPlanner):
            raise ValueError("execution_planner must be ExperimentAwarePriorityExecutionPlanner when experiment_id is set")
        if self.execution_planner is None and self.capacity_intelligence is not None:
            self.execution_planner = ExecutionPlanner(self.capacity_intelligence)
        self.recovery_cycles = 0
        self.handlers: dict[str, Callable[[Any], Any]] = {}
        self.stats = RunnerStats()
        self.recovered_workers = 0
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._executor = ThreadPoolExecutor(max_workers=self.max_workers)
        self._futures: dict[Future, tuple[str, str]] = {}
        self._worker_ids = [f"{self.worker_prefix}-{i+1}" for i in range(self.max_workers)]
        self._free_workers = list(self._worker_ids)
        if self.supervisor is not None:
            for wid in self._worker_ids:
                self.supervisor.register(wid, 1, metadata="continuous-worker-runner")
                self.supervisor.set_status(wid, WorkerStatus.RUNNING)

    def register_handler(self, name: str, handler: Callable[[Any], Any]) -> None:
        if not name or not callable(handler):
            raise ValueError("name and callable handler are required")
        self.handlers[name] = handler
        if self.observability:
            self.observability.event("handler_registered", detail=name)

    def stop(self) -> None:
        self._stop.set()

    @property
    def stopped(self) -> bool:
        return self._stop.is_set()

    def _worker_id(self) -> str:
        with self._lock:
            if not self._free_workers:
                raise RuntimeError("no free worker slot")
            return self._free_workers.pop(0)

    def _release_worker(self, worker_id: str) -> None:
        with self._lock:
            if worker_id not in self._free_workers:
                self._free_workers.append(worker_id)

    def _execute(self, item: QueueItem, worker_id: str) -> None:
        heartbeat_stop = threading.Event()
        interval = max(0.05, self.queue.coordinator.lease_seconds / 3.0)

        def beat() -> None:
            while not heartbeat_stop.wait(interval):
                try:
                    self.queue.heartbeat(item.item_id, worker_id)
                    if self.supervisor is not None:
                        self.supervisor.heartbeat(worker_id, active=1)
                except Exception:
                    return

        hb = threading.Thread(target=beat, daemon=True)
        hb.start()
        try:
            if self.supervisor is not None:
                self.supervisor.heartbeat(worker_id, active=1)
            if self.observability:
                self.observability.event("job_started", worker_id=worker_id, item_id=item.item_id)
            payload = item.payload if isinstance(item.payload, dict) else {"payload": item.payload}
            handler_name = payload.get("handler")
            if not handler_name or handler_name not in self.handlers:
                raise KeyError(f"No handler registered: {handler_name}")
            result = self.handlers[handler_name](payload.get("data"))
            self.queue.complete(item.item_id, worker_id, result)
            if self.experiment_id and self.experiment_engine is not None:
                self.experiment_engine.record(self.experiment_id, item.item_id, "COMPLETED")
            with self._lock:
                self.stats.completed += 1
            if self.observability:
                self.observability.event("job_completed", worker_id=worker_id, item_id=item.item_id)
        except Exception as exc:
            try:
                self.queue.fail(item.item_id, worker_id, str(exc))
            except Exception:
                pass
            if self.experiment_id and self.experiment_engine is not None:
                try:
                    self.experiment_engine.record(self.experiment_id, item.item_id, "FAILED")
                except Exception:
                    pass
            with self._lock:
                self.stats.failed += 1
            if self.observability:
                self.observability.event("job_failed", worker_id=worker_id, item_id=item.item_id, detail=str(exc))
        finally:
            heartbeat_stop.set()
            if self.supervisor is not None:
                try:
                    self.supervisor.heartbeat(worker_id, active=0)
                except Exception:
                    pass
            self._release_worker(worker_id)

    def tick(self) -> int:
        with self._lock:
            self.stats.ticks += 1
            if self.recovery_controller is not None:
                report = self.recovery_controller.run_if_due()
                if report is not None:
                    applied = sum(a.status == "APPLIED" for a in report.actions)
                    self.stats.recovered += applied
                    self.recovery_cycles += 1
                    self.recovered_workers += sum(
                        a.kind == "IDLE_WORKER_RECOVERY" and a.status == "APPLIED"
                        for a in report.actions
                    )
            else:
                self.stats.recovered += len(self.queue.recover_expired())
                if self.supervisor is not None:
                    stale_workers = self.supervisor.stale()
                    # Conservative recovery: only revive stale slots that have no
                    # active work. Abandoned queue work is recovered by queue leases.
                    for record in stale_workers:
                        if record.active == 0:
                            try:
                                self.supervisor.recover_idle_stale(record.worker_id)
                                with self._lock:
                                    self.recovered_workers += 1
                            except (KeyError, RuntimeError):
                                pass
            active = len(self._futures)
            capacity = self.max_workers - active
        if capacity <= 0:
            self._collect_done()
            return 0
        self._collect_done()
        capacity = self.max_workers - len(self._futures)
        ready_items = self.queue.ready()
        if self.execution_planner is not None:
            planned_items = [PlannedItem(item.item_id, item.priority) for item in ready_items]
            if self.experiment_id:
                if self.priority_decisions_provider is None:
                    raise ValueError("priority_decisions_provider is required for experiment execution")
                decisions = self.priority_decisions_provider(ready_items)
                planned = self.execution_planner.plan_with_experiment(
                    planned_items, capacity, decisions, self.experiment_id
                )
            elif isinstance(self.execution_planner, PriorityAwareExecutionPlanner) and self.priority_decisions_provider is not None:
                decisions = self.priority_decisions_provider(ready_items)
                planned = self.execution_planner.plan_with_decisions(planned_items, capacity, decisions)
            else:
                planned = self.execution_planner.plan(planned_items, capacity)
            selected = set(planned.selected)
            items_to_claim = [item for item in ready_items if item.item_id in selected]
            if self.observability:
                self.observability.event(
                    "execution_plan_created",
                    detail=planned.reason,
                    selected=len(planned.selected),
                    deferred=len(planned.deferred),
                )
        else:
            items_to_claim = ready_items[:capacity]
        claimed = 0
        for item in items_to_claim:
            worker_id = self._worker_id()
            claimed_item = self.queue.claim(item.item_id, worker_id)
            if claimed_item is None:
                continue
            future = self._executor.submit(self._execute, claimed_item, worker_id)
            self._futures[future] = (claimed_item.item_id, worker_id)
            claimed += 1
            with self._lock:
                self.stats.claimed += 1
            if self.observability:
                self.observability.metric("runner.claimed", 1)
        if self.observability:
            self.observability.metric("runner.active_futures", len(self._futures))
            self.observability.metric("runner.queue_claimed_total", self.stats.claimed)
            self.observability.metric("runner.completed_total", self.stats.completed)
            self.observability.metric("runner.failed_total", self.stats.failed)
        return claimed

    def _collect_done(self) -> None:
        done = [f for f in self._futures if f.done()]
        for f in done:
            self._futures.pop(f, None)
            try:
                f.result()
            except Exception:
                pass

    def run(self, max_ticks: Optional[int] = None) -> RunnerStats:
        if max_ticks is not None and max_ticks < 1:
            raise ValueError("max_ticks must be >= 1")
        ticks = 0
        while not self.stopped and (max_ticks is None or ticks < max_ticks):
            self.tick()
            ticks += 1
            if self.poll_interval:
                time.sleep(self.poll_interval)
        # Always let claimed work finish before returning.
        while self._futures:
            self._collect_done()
            if self._futures:
                time.sleep(min(0.05, max(self.poll_interval, 0.01)))
        return self.stats

    def health(self):
        if self.supervisor is None:
            return {"supervisor": False, "stopped": self.stopped, "active_futures": len(self._futures)}
        snapshot = self.supervisor.health_snapshot()
        if self.observability:
            snapshot["observability"] = self.observability.summary()
        snapshot.update({
            "supervisor": True,
            "stopped": self.stopped,
            "active_futures": len(self._futures),
            "recovered_workers": self.recovered_workers,
            "recovery_cycles": self.recovery_cycles,
        })
        if self.capacity_monitor is not None:
            if self.capacity_intelligence is not None:
                cap = self.capacity_intelligence.observe(self.max_workers, len(self._futures))
            else:
                cap = self.capacity_monitor.analyze(self.max_workers, len(self._futures))
            snapshot["capacity"] = cap.__dict__.copy()
            if self.capacity_intelligence is not None:
                try:
                    snapshot["capacity_forecast"] = self.capacity_intelligence.forecast().__dict__.copy()
                except RuntimeError:
                    pass
        if self.health_monitor is not None:
            report = self.health_monitor.analyze()
            snapshot["health_monitor"] = {"healthy": report.healthy, "score": report.score,
                                          "alerts": [a.__dict__.copy() for a in report.alerts],
                                          "metrics": report.metrics}
        return snapshot

    def close(self) -> None:
        self.stop()
        self.run(max_ticks=1)
        if self.supervisor is not None:
            for wid in self._worker_ids:
                try:
                    self.supervisor.stop(wid)
                except Exception:
                    pass
        self._executor.shutdown(wait=True)
