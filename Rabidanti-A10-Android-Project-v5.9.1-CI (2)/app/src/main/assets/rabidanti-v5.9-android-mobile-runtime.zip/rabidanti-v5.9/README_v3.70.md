# Rabidanti v3.70 — Evolution Signal Bridge

v3.70 connects observable Rabidanti signals to the controlled evolution layer.

## New capability
- Records typed evidence signals from Health, Performance, Learning, Laboratory,
  World Awareness and Knowledge subsystems.
- Computes bounded evidence confidence.
- Creates evolution proposals only when evidence meets a configurable confidence threshold.
- Preserves explicit approval as a mandatory requirement.
- Does not activate, deploy, rollback, or modify Core configuration automatically.

## Safety invariant
Observation -> Evidence -> Proposal -> Approval -> Evolution Controller.

A proposal is not an activation.

## Validation
The package includes focused tests for evidence recording, confidence gating,
approval requirements, duplicates, and missing evidence.
