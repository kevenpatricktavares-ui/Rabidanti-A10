# Rabidanti v3.82 — Evidence Decision Runtime

## Objetivo
Tornar o caminho **evidência fundida → decisão evolutiva → persistência** durável e auditável.

## Novos componentes
- `evolution_evidence_runtime.py`: orquestra EvidenceFusion + v3.81 EvidenceToDecisionIntegration.
- `evolution_evidence_store.py`: persiste decisões com fusion_id, independência, score, decisão e requisitos de aprovação.
- `tests/test_v382_evidence_runtime.py`: testes do novo ciclo e dos limites de autoridade.

## Fluxo
`EvidenceFusion → EvidenceDecisionIntegration → EvidenceRuntime → SQLite Evidence Store`

A v3.82 não ativa, publica, implanta ou altera o Core. Essas ações continuam subordinadas ao Evolution Controller e aos fluxos de aprovação existentes.
