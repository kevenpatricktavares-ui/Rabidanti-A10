"""Rabidanti v5.7 integrated product self-test.

Runs a non-destructive readiness check in an isolated temporary state directory.
It intentionally does not call external providers, local AI models, connectors,
or execute reasoning proposals.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import tempfile
import uuid

from rabidanti_product import ProductFoundation
from rabidanti_runtime import RabidantiRuntime


@dataclass(frozen=True)
class SelfTestCheck:
    name: str
    ok: bool
    detail: Any
    optional: bool = False


class ProductSelfTest:
    """Run operational checks without mutating the user's persistent state."""

    def __init__(self, state_parent: str | Path | None = None) -> None:
        self.state_parent = Path(state_parent).expanduser().resolve() if state_parent else None

    def _add(self, checks: list[SelfTestCheck], name: str, ok: bool, detail: Any, *, optional: bool = False) -> None:
        checks.append(SelfTestCheck(name=name, ok=bool(ok), detail=detail, optional=optional))

    def run(self) -> dict[str, Any]:
        checks: list[SelfTestCheck] = []
        parent = self.state_parent
        if parent is not None:
            parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="rabidanti-selftest-", dir=str(parent) if parent else None) as temp:
            state_dir = Path(temp) / "state"
            product = ProductFoundation(state_dir)
            product_doctor = product.doctor(probe_ollama=False)
            self._add(checks, "runtime_dependencies", product_doctor["ready_for_runtime"], product_doctor["checks"])

            task_id = f"selftest-{uuid.uuid4().hex}"
            runtime: RabidantiRuntime | None = None
            try:
                runtime = RabidantiRuntime(state_dir)
                started = runtime.start(recover=True)
                self._add(checks, "runtime_start", started.get("runtime_state") == "RUNNING", started.get("runtime_state"))
                safety = started.get("safety", {})
                safe = (
                    safety.get("self_authorization") is False
                    and safety.get("external_action_authorized") is False
                    and safety.get("automatic_core_integration") is False
                )
                self._add(checks, "safety_boundaries", safe, safety)

                doctor = runtime.doctor()
                required = [x for x in doctor["checks"] if x["name"] != "container_runtime"]
                self._add(checks, "runtime_doctor", all(x["ok"] for x in required), required)
                container = next(x for x in doctor["checks"] if x["name"] == "container_runtime")
                self._add(checks, "container_runtime", container["ok"], container["detail"], optional=True)

                created = runtime.add_task("Rabidanti integrated self-test", task_id=task_id)
                self._add(checks, "task_write", created.get("task_id") == task_id and created.get("state") == "QUEUED", created)
                present = any(item.get("task_id") == task_id for item in runtime.list_tasks())
                self._add(checks, "task_read", present, {"task_id": task_id})
                events = runtime.runtime_events(limit=100)
                audited = any(e.get("event_type") == "TASK_ADDED" and e.get("details", {}).get("task_id") == task_id for e in events)
                self._add(checks, "audit_event", audited, {"event_type": "TASK_ADDED", "task_id": task_id})
            except Exception as exc:  # self-test must report failures, not hide them
                self._add(checks, "runtime_exception", False, f"{type(exc).__name__}: {exc}")
            finally:
                if runtime is not None:
                    runtime.stop()

            # Re-open the same isolated state to verify durable persistence.
            reopened: RabidantiRuntime | None = None
            try:
                reopened = RabidantiRuntime(state_dir)
                reopened.start(recover=False)
                persisted = any(item.get("task_id") == task_id for item in reopened.list_tasks())
                self._add(checks, "restart_persistence", persisted, {"task_id": task_id})
                connector_state = reopened.connectors.list()
                builtin_disabled = all(not item.get("enabled", False) for item in connector_state)
                self._add(checks, "connectors_disabled_by_default", builtin_disabled, connector_state)
            except Exception as exc:
                self._add(checks, "restart_exception", False, f"{type(exc).__name__}: {exc}")
            finally:
                if reopened is not None:
                    reopened.stop()

        required_ok = all(item.ok for item in checks if not item.optional)
        return {
            "program": "Rabidanti",
            "self_test_schema": 1,
            "healthy": required_ok,
            "checks": [asdict(item) for item in checks],
            "isolated": True,
            "persistent_user_state_modified": False,
            "external_network_required": False,
            "external_action_authorized": False,
            "scientific_validation_claimed": False,
        }
