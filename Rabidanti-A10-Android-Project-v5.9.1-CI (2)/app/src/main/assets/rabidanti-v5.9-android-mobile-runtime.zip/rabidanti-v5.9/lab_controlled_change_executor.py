"""Rabidanti v3.99 — Controlled Change Authorization & Executor.

Applies an explicitly authorized change set to a caller-supplied workspace only.
The executor is intentionally narrow: repository-relative file replacement or
creation, immutable authorization bound to exact proposal/change digests,
pre-change backup, command allowlisting, automatic verification, and rollback
on failure. It never grants external-action authority and never authorizes
itself.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import uuid


class ControlledChangeExecutor:
    PENDING = "PENDING_AUTHORIZATION"
    AUTHORIZED = "AUTHORIZED"
    APPLIED = "APPLIED"
    ROLLED_BACK = "ROLLED_BACK"
    FAILED = "FAILED"

    def __init__(self, proposal_workflow, database="rabidanti_controlled_changes.sqlite3"):
        if proposal_workflow is None:
            raise ValueError("proposal_workflow is required")
        self.proposals = proposal_workflow
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS controlled_change_sets(
                change_id TEXT PRIMARY KEY,
                change_digest TEXT NOT NULL UNIQUE,
                proposal_id TEXT NOT NULL,
                proposal_digest TEXT NOT NULL,
                files_json TEXT NOT NULL,
                verification_commands TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL,
                authorized_by TEXT,
                authorization_reason TEXT,
                authorized_at TEXT,
                authorization_digest TEXT,
                executed_at TEXT,
                workspace TEXT,
                backup_path TEXT,
                verification_json TEXT,
                error TEXT,
                external_action_authorized INTEGER NOT NULL DEFAULT 0
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS controlled_change_events(
                event_id TEXT PRIMARY KEY,
                change_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                actor_id TEXT NOT NULL,
                note TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(change_id) REFERENCES controlled_change_sets(change_id)
            )""")

    def _db(self):
        c = sqlite3.connect(self.database)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    @staticmethod
    def _text(value, name):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be non-empty text")
        return value.strip()

    @classmethod
    def _safe_relpath(cls, value):
        raw = cls._text(value, "path")
        if "\\" in raw:
            raise ValueError("path must use repository-relative POSIX syntax")
        p = PurePosixPath(raw)
        if p.is_absolute() or ".." in p.parts or raw in {".", ".."}:
            raise ValueError("path must be repository-relative without traversal")
        if not p.parts or any(part in {"", ".", ".."} for part in p.parts):
            raise ValueError("invalid repository-relative path")
        if p.parts[0].endswith(":"):
            raise ValueError("drive-qualified paths are forbidden")
        return p.as_posix()

    @staticmethod
    def _sha256_bytes(data):
        return hashlib.sha256(data).hexdigest()

    @classmethod
    def _normalize_files(cls, files):
        if not isinstance(files, (list, tuple)) or not files:
            raise ValueError("files must be a non-empty list")
        out = []
        seen = set()
        for i, item in enumerate(files):
            if not isinstance(item, dict):
                raise ValueError(f"files[{i}] must be a dictionary")
            path = cls._safe_relpath(item.get("path"))
            if path in seen:
                raise ValueError("duplicate file path in change set")
            seen.add(path)
            content = item.get("content")
            if not isinstance(content, str):
                raise ValueError(f"files[{i}].content must be text")
            expected = item.get("expected_sha256")
            if expected is not None:
                if not isinstance(expected, str) or len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected.lower()):
                    raise ValueError("expected_sha256 must be a 64-character hexadecimal digest")
                expected = expected.lower()
            encoded = content.encode("utf-8")
            out.append({
                "path": path,
                "content": content,
                "content_sha256": cls._sha256_bytes(encoded),
                "expected_sha256": expected,
            })
        return sorted(out, key=lambda x: x["path"])

    @classmethod
    def _normalize_commands(cls, commands):
        if not isinstance(commands, (list, tuple)) or not commands:
            raise ValueError("verification_commands must be a non-empty list")
        allowed = {
            ("python", "-m", "pytest"),
            ("python3", "-m", "pytest"),
            ("pytest",),
        }
        out = []
        for i, cmd in enumerate(commands):
            if not isinstance(cmd, (list, tuple)) or not cmd or not all(isinstance(x, str) and x for x in cmd):
                raise ValueError(f"verification_commands[{i}] must be a non-empty argv list")
            argv = list(cmd)
            prefix_ok = any(tuple(argv[:len(prefix)]) == prefix for prefix in allowed)
            if not prefix_ok:
                raise ValueError("verification command is not allowlisted")
            forbidden = {";", "&&", "||", "|", ">", "<", "`", "$()"}
            if any(any(token in arg for token in forbidden) for arg in argv):
                raise ValueError("verification command contains shell syntax")
            out.append(argv)
        return out

    @staticmethod
    def _row(row):
        if row is None:
            return None
        d = dict(row)
        d["files"] = json.loads(d.pop("files_json"))
        d["verification_commands"] = json.loads(d["verification_commands"])
        d["verification"] = None if d["verification_json"] is None else json.loads(d["verification_json"])
        d["external_action_authorized"] = bool(d["external_action_authorized"])
        return d

    def get(self, change_id):
        with self._db() as c:
            row = c.execute("SELECT * FROM controlled_change_sets WHERE change_id=?", (change_id,)).fetchone()
        if row is None:
            raise KeyError(change_id)
        return self._row(row)

    def events(self, change_id):
        self.get(change_id)
        with self._db() as c:
            rows = c.execute(
                "SELECT * FROM controlled_change_events WHERE change_id=? ORDER BY created_at,event_id", (change_id,)
            ).fetchall()
        return [dict(r) for r in rows]

    def create_change_set(self, proposal_id, *, files, verification_commands, created_by="creator"):
        created_by = self._text(created_by, "created_by")
        proposal = self.proposals.get(proposal_id)
        if proposal["status"] != self.proposals.PROPOSED:
            raise ValueError("change set requires a proposed integration record")
        if proposal.get("integration_authorized") is not False:
            raise ValueError("proposal authorization state is incompatible")

        normalized_files = self._normalize_files(files)
        declared = set(proposal["affected_files"])
        actual = {f["path"] for f in normalized_files}
        if actual != declared:
            raise ValueError("change set files must exactly match proposal affected_files")
        commands = self._normalize_commands(verification_commands)
        body = {
            "record_type": "controlled_change_set",
            "proposal_id": proposal_id,
            "proposal_digest": proposal["proposal_digest"],
            "files": normalized_files,
            "verification_commands": commands,
            "created_by": created_by,
        }
        digest = hashlib.sha256(self._canonical(body).encode("utf-8")).hexdigest()
        change_id = f"controlled-change:{digest[:24]}"
        with self._db() as c:
            existing = c.execute("SELECT * FROM controlled_change_sets WHERE change_digest=?", (digest,)).fetchone()
            if existing is not None:
                return self._row(existing)
            now = self._now()
            c.execute(
                """INSERT INTO controlled_change_sets(
                    change_id,change_digest,proposal_id,proposal_digest,files_json,verification_commands,
                    created_by,created_at,status,external_action_authorized
                ) VALUES(?,?,?,?,?,?,?,?,?,0)""",
                (change_id, digest, proposal_id, proposal["proposal_digest"], self._canonical(normalized_files),
                 self._canonical(commands), created_by, now, self.PENDING),
            )
            c.execute("INSERT INTO controlled_change_events VALUES(?,?,?,?,?,?)", (
                f"change-created:{change_id}", change_id, "CHANGE_SET_CREATED", created_by,
                "Immutable change set created; execution remains unauthorized.", now,
            ))
        return self.get(change_id)

    def authorize(self, change_id, *, authorized_by, reason, expected_change_digest):
        authorized_by = self._text(authorized_by, "authorized_by")
        reason = self._text(reason, "reason")
        item = self.get(change_id)
        if item["status"] != self.PENDING:
            raise ValueError("change set is not pending authorization")
        if expected_change_digest != item["change_digest"]:
            raise ValueError("authorization digest does not match exact change set")
        payload = {
            "change_id": change_id,
            "change_digest": item["change_digest"],
            "proposal_id": item["proposal_id"],
            "proposal_digest": item["proposal_digest"],
            "authorized_by": authorized_by,
            "reason": reason,
        }
        authorization_digest = hashlib.sha256(self._canonical(payload).encode("utf-8")).hexdigest()
        now = self._now()
        with self._db() as c:
            c.execute("""UPDATE controlled_change_sets SET status=?,authorized_by=?,authorization_reason=?,
                         authorized_at=?,authorization_digest=? WHERE change_id=? AND status=?""",
                      (self.AUTHORIZED, authorized_by, reason, now, authorization_digest, change_id, self.PENDING))
            if c.total_changes != 1:
                raise ValueError("authorization state changed concurrently")
            c.execute("INSERT INTO controlled_change_events VALUES(?,?,?,?,?,?)", (
                f"change-authorized:{change_id}", change_id, "CHANGE_AUTHORIZED", authorized_by,
                "Explicit authorization bound to exact change digest; external actions remain unauthorized.", now,
            ))
        return self.get(change_id)

    @classmethod
    def _resolve_under(cls, root, relpath):
        root = Path(root).resolve()
        target = (root / relpath).resolve()
        try:
            target.relative_to(root)
        except ValueError as e:
            raise ValueError("resolved path escapes workspace") from e
        return target

    def _preflight(self, item, workspace):
        root = Path(workspace).resolve()
        if not root.is_dir():
            raise ValueError("workspace must be an existing directory")
        for spec in item["files"]:
            target = self._resolve_under(root, spec["path"])
            expected = spec["expected_sha256"]
            if expected is None:
                if target.exists():
                    raise ValueError(f"expected new file already exists: {spec['path']}")
            else:
                if not target.is_file():
                    raise ValueError(f"expected existing file is missing: {spec['path']}")
                actual = self._sha256_bytes(target.read_bytes())
                if actual != expected:
                    raise ValueError(f"pre-change digest mismatch: {spec['path']}")
        return root

    def _backup(self, item, root):
        backup_root = Path(self.database).parent / "controlled_change_backups" / item["change_id"].replace(":", "_")
        if backup_root.exists():
            shutil.rmtree(backup_root)
        backup_root.mkdir(parents=True, exist_ok=False)
        manifest = []
        for spec in item["files"]:
            target = self._resolve_under(root, spec["path"])
            exists = target.is_file()
            entry = {"path": spec["path"], "existed": exists}
            if exists:
                data = target.read_bytes()
                entry["sha256"] = self._sha256_bytes(data)
                backup_target = backup_root / spec["path"]
                backup_target.parent.mkdir(parents=True, exist_ok=True)
                backup_target.write_bytes(data)
            manifest.append(entry)
        (backup_root / "manifest.json").write_text(self._canonical(manifest), encoding="utf-8")
        return backup_root, manifest

    def _restore(self, root, backup_root, manifest):
        for entry in manifest:
            target = self._resolve_under(root, entry["path"])
            if entry["existed"]:
                source = backup_root / entry["path"]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read_bytes())
            elif target.exists():
                if target.is_file() or target.is_symlink():
                    target.unlink()
                else:
                    shutil.rmtree(target)

    def execute(self, change_id, *, workspace, actor_id="executor", timeout_seconds=120):
        actor_id = self._text(actor_id, "actor_id")
        if not isinstance(timeout_seconds, int) or isinstance(timeout_seconds, bool) or not 1 <= timeout_seconds <= 3600:
            raise ValueError("timeout_seconds must be an integer from 1 to 3600")
        item = self.get(change_id)
        if item["status"] != self.AUTHORIZED or not item["authorization_digest"]:
            raise PermissionError("change set requires explicit authorization before execution")
        proposal = self.proposals.get(item["proposal_id"])
        if proposal["proposal_digest"] != item["proposal_digest"]:
            raise ValueError("proposal digest changed after change-set creation")
        root = self._preflight(item, workspace)
        backup_root, manifest = self._backup(item, root)
        verification = []
        now = self._now()
        try:
            for spec in item["files"]:
                target = self._resolve_under(root, spec["path"])
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(spec["content"], encoding="utf-8")
                if self._sha256_bytes(target.read_bytes()) != spec["content_sha256"]:
                    raise RuntimeError(f"post-write digest mismatch: {spec['path']}")
            for argv in item["verification_commands"]:
                proc = subprocess.run(
                    argv, cwd=str(root), capture_output=True, text=True,
                    timeout=timeout_seconds, shell=False, env=os.environ.copy(),
                )
                result = {
                    "argv": argv,
                    "returncode": proc.returncode,
                    "stdout": proc.stdout[-20000:],
                    "stderr": proc.stderr[-20000:],
                }
                verification.append(result)
                if proc.returncode != 0:
                    raise RuntimeError(f"verification failed: {' '.join(argv)}")
        except Exception as exc:
            self._restore(root, backup_root, manifest)
            with self._db() as c:
                c.execute("""UPDATE controlled_change_sets SET status=?,executed_at=?,workspace=?,backup_path=?,
                             verification_json=?,error=? WHERE change_id=?""",
                          (self.ROLLED_BACK, self._now(), str(root), str(backup_root),
                           self._canonical(verification), str(exc), change_id))
                c.execute("INSERT INTO controlled_change_events VALUES(?,?,?,?,?,?)", (
                    str(uuid.uuid4()), change_id, "EXECUTION_ROLLED_BACK", actor_id,
                    f"Execution failed and workspace was restored: {exc}", self._now(),
                ))
            return self.get(change_id)

        with self._db() as c:
            c.execute("""UPDATE controlled_change_sets SET status=?,executed_at=?,workspace=?,backup_path=?,
                         verification_json=?,error=NULL WHERE change_id=?""",
                      (self.APPLIED, self._now(), str(root), str(backup_root), self._canonical(verification), change_id))
            c.execute("INSERT INTO controlled_change_events VALUES(?,?,?,?,?,?)", (
                str(uuid.uuid4()), change_id, "EXECUTION_APPLIED", actor_id,
                "Authorized change applied to supplied workspace and verification passed.", self._now(),
            ))
        return self.get(change_id)

    def authorize_external_action(self, *args, **kwargs):
        raise PermissionError("controlled change executor cannot authorize external actions")

    def self_authorize(self, *args, **kwargs):
        raise PermissionError("controlled change executor cannot authorize itself")
