from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True)
class PatternObservation:
    observation_id: str
    correlation_id: str
    strength: float
    observed_at: str


@dataclass(frozen=True)
class PatternTrend:
    correlation_id: str
    observations: int
    average_strength: float
    latest_strength: float
    trend: str


class EvolutionPatternMemory:
    """Bounded temporal memory for repeated evolution patterns."""

    def __init__(self, max_observations=1000):
        if max_observations < 1:
            raise ValueError("max_observations must be positive")
        self.max_observations = max_observations
        self._items = {}

    def record(self, observation_id, correlation_id, strength, observed_at=None):
        if not observation_id or not correlation_id:
            raise ValueError("observation_id and correlation_id are required")
        if observation_id in self._items:
            raise ValueError("duplicate observation_id")
        if not 0 <= strength <= 1:
            raise ValueError("strength must be between 0 and 1")
        if observed_at is None:
            observed_at = datetime.now(timezone.utc).isoformat()
        self._items[observation_id] = PatternObservation(
            observation_id, correlation_id, strength, observed_at
        )
        if len(self._items) > self.max_observations:
            oldest = min(self._items.values(), key=lambda x: x.observed_at)
            del self._items[oldest.observation_id]
        return self._items[observation_id]

    def observations(self, correlation_id):
        rows = [x for x in self._items.values() if x.correlation_id == correlation_id]
        return tuple(sorted(rows, key=lambda x: x.observed_at))

    def trend(self, correlation_id):
        rows = self.observations(correlation_id)
        if not rows:
            return None
        values = [x.strength for x in rows]
        avg = round(sum(values) / len(values), 6)
        latest = values[-1]
        if len(values) < 2:
            trend = "INSUFFICIENT_HISTORY"
        elif latest > values[-2]:
            trend = "RISING"
        elif latest < values[-2]:
            trend = "FALLING"
        else:
            trend = "STABLE"
        return PatternTrend(correlation_id, len(values), avg, latest, trend)

    def repeated(self, correlation_id, minimum=2):
        return len(self.observations(correlation_id)) >= minimum
