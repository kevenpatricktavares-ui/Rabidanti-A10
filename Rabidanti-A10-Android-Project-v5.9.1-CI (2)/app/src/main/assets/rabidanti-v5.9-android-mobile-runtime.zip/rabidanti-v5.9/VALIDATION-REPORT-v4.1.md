# Rabidanti v4.1 — Validation Report

## Baseline

Input artifact: `rabidanti-v4.00-runtime-mvp.zip`

- Input SHA-256: `d9a741a2bfff3067b9f823e4ac8052bddae2d5d07c7d29f1969e36585f5470e5`
- Input `VERSION`: `4.0.0`
- Baseline regression: `506 passed`

## Implemented

v4.1 introduces `rabidanti_api.py`, a loopback-only local HTTP API/service layer over `RabidantiRuntime`, plus the `rabidanti.py serve` command.

Security and operational properties verified in code/tests:

- non-loopback bind addresses are rejected;
- mutation endpoints require a bearer token of at least 24 characters;
- generated tokens are ephemeral and are not persisted in the runtime database;
- bearer token comparison uses constant-time comparison;
- request bodies are JSON-only and limited to 64 KiB;
- arbitrary HTTP DELETE/PUT/PATCH operations are not execution surfaces;
- no shell/command execution endpoint is exposed;
- API mutations are audited in runtime events;
- tasks created through the API survive runtime restart;
- startup still grants no external-action, Core-integration, or scientific-validation authority.

Initial API surface:

- `GET /health`
- `GET /v1/status`
- `GET /v1/doctor`
- `GET /v1/tasks`
- `GET /v1/evidence`
- `GET /v1/events`
- `GET /v1/workflows`
- `POST /v1/tasks` (bearer token required)

## Tests

- v4.0 baseline before changes: **506 passed / 0 failed**
- v4.1-specific tests: **10 passed / 0 failed**
- full v4.1 regression: **516 passed / 0 failed**
- Python `compileall`: **PASS**

Five historical v4.0 tests initially failed only because they hard-coded the literal version `4.0.0`. They were changed to compare against the current `VERSION` file while preserving all runtime invariants. After that correction the full suite passed.

## Limitations

- The API is designed for loopback/local use only; it is not claimed to be internet-facing hardened.
- TLS is not implemented because the service is intentionally loopback-only in this version.
- No external platform connector becomes active merely because the API is running.
- Docker/Podman availability and OS-level container isolation remain environment-dependent and were not added by v4.1.
- v4.1 is a service layer, not yet the graphical Sala/UI.
