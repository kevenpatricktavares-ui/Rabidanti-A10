# Rabidanti v3.66

Adds durable versioned strategy configuration and reversible rollback.

Core rule: **evolution must be versioned, approved, observable and reversible.**

The module does not automatically change production strategy. A caller must explicitly approve and activate a proposed version. Rollback creates a new version containing the selected historical weights, preserving the audit trail.
