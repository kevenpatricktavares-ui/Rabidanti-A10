from __future__ import annotations

import json
import sqlite3
import urllib.error
import urllib.request
from pathlib import Path

import pytest

from rabidanti_api import RabidantiApiService
from rabidanti_connectors import (
    ConnectorAccess,
    ConnectorCapability,
    ConnectorDefinition,
    ConnectorPermissionError,
    ConnectorRateLimitError,
    ConnectorRegistry,
)
from rabidanti_runtime import RabidantiRuntime


def definition(*, secret=False, rate=30):
    return ConnectorDefinition(
        connector_id="demo.connector",
        display_name="Demo Connector",
        version="1.0",
        capabilities=(
            ConnectorCapability("items.read", ConnectorAccess.READ, "read demo items"),
            ConnectorCapability("items.write", ConnectorAccess.WRITE, "write demo items"),
        ),
        required_secrets=("DEMO_TOKEN",) if secret else (),
        rate_limit_per_minute=rate,
    )


def handler(calls):
    def _handler(capability, payload, context):
        calls.append((capability, payload, context.actor))
        return {"ok": True, "capability": capability}
    return _handler


def test_write_capability_is_forced_to_require_approval():
    cap = ConnectorCapability("x.write", ConnectorAccess.WRITE)
    assert cap.approval_required is True


def test_register_is_disabled_by_default_and_lists_metadata(tmp_path):
    calls = []
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3")
    reg.register(definition(), handler(calls))
    item = reg.get("demo.connector")
    assert item["enabled"] is False
    assert item["runtime_handler_loaded"] is True
    assert item["capabilities"][1]["approval_required"] is True


def test_enable_requires_explicit_actor_and_reason(tmp_path):
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3")
    reg.register(definition(), handler([]))
    with pytest.raises(ValueError):
        reg.set_enabled("demo.connector", True, actor="", reason="because")
    with pytest.raises(ValueError):
        reg.set_enabled("demo.connector", True, actor="owner", reason="")
    assert reg.set_enabled("demo.connector", True, actor="owner", reason="test")["enabled"] is True


def test_missing_required_secret_blocks_invocation(tmp_path):
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3", secret_getter=lambda name: None)
    reg.register(definition(secret=True), handler([]))
    reg.set_enabled("demo.connector", True, actor="owner", reason="test")
    with pytest.raises(ConnectorPermissionError, match="required connector secrets"):
        reg.invoke("demo.connector", "items.read", {"q": "x"})


def test_read_invocation_needs_enable_but_not_action_approval(tmp_path):
    calls = []
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3")
    reg.register(definition(), handler(calls))
    with pytest.raises(ConnectorPermissionError, match="disabled"):
        reg.invoke("demo.connector", "items.read", {"q": "x"})
    reg.set_enabled("demo.connector", True, actor="owner", reason="test")
    result = reg.invoke("demo.connector", "items.read", {"q": "x"})
    assert result["ok"] is True
    assert calls == [("items.read", {"q": "x"}, "rabidanti")]
    logs = reg.invocations()
    assert logs[0]["outcome"] == "SUCCEEDED"
    assert "payload" not in logs[0]


def test_write_approval_is_exact_and_one_time(tmp_path):
    calls = []
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3")
    reg.register(definition(), handler(calls))
    reg.set_enabled("demo.connector", True, actor="owner", reason="test")
    payload = {"id": 7, "value": "approved"}
    with pytest.raises(ConnectorPermissionError, match="approval"):
        reg.invoke("demo.connector", "items.write", payload)
    approval = reg.approve(
        "demo.connector", "items.write", payload, actor="owner", reason="apply approved change"
    )
    with pytest.raises(ConnectorPermissionError, match="exact request"):
        reg.invoke("demo.connector", "items.write", {"id": 8}, approval_id=approval["approval_id"])
    result = reg.invoke(
        "demo.connector", "items.write", payload, approval_id=approval["approval_id"]
    )
    assert result["ok"] is True
    with pytest.raises(ConnectorPermissionError, match="already been consumed"):
        reg.invoke("demo.connector", "items.write", payload, approval_id=approval["approval_id"])
    assert reg.approvals()[0]["consumed"] is True


def test_rate_limit_is_enforced(tmp_path):
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3")
    reg.register(definition(rate=1), handler([]))
    reg.set_enabled("demo.connector", True, actor="owner", reason="test")
    reg.invoke("demo.connector", "items.read", {})
    with pytest.raises(ConnectorRateLimitError):
        reg.invoke("demo.connector", "items.read", {})


def test_restart_preserves_metadata_but_not_executable_handler(tmp_path):
    db = tmp_path / "connectors.sqlite3"
    first = ConnectorRegistry(db)
    first.register(definition(), handler([]))
    first.set_enabled("demo.connector", True, actor="owner", reason="test")
    second = ConnectorRegistry(db)
    item = second.get("demo.connector")
    assert item["enabled"] is True
    assert item["runtime_handler_loaded"] is False
    with pytest.raises(ConnectorPermissionError, match="handler is not loaded"):
        second.invoke("demo.connector", "items.read", {})


def test_secret_values_and_raw_payload_are_not_persisted(tmp_path):
    secret = "TOP-SECRET-123456"
    reg = ConnectorRegistry(tmp_path / "connectors.sqlite3", secret_getter=lambda name: secret)
    reg.register(definition(secret=True), handler([]))
    reg.set_enabled("demo.connector", True, actor="owner", reason="test")
    reg.invoke("demo.connector", "items.read", {"private": "RAW-PAYLOAD-MARKER"})
    raw = (tmp_path / "connectors.sqlite3").read_bytes()
    assert secret.encode() not in raw
    assert b"RAW-PAYLOAD-MARKER" not in raw


def test_runtime_integrates_connector_status_and_audit(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    runtime.register_connector(definition(), handler([]))
    runtime.set_connector_enabled("demo.connector", True, actor="creator", reason="controlled test")
    status = runtime.status()
    # Built-in connectors may exist in newer releases; preserve the v4.4 invariant
    # that the explicitly registered demo connector is present and enabled.
    rows = runtime.list_connectors()
    demo = next(x for x in rows if x["connector_id"] == "demo.connector")
    assert demo["enabled"] is True
    assert status["connectors"]["registered"] == len(rows)
    assert status["connectors"]["enabled"] == sum(1 for x in rows if x["enabled"])
    types = [x["event_type"] for x in runtime.runtime_events(20)]
    assert "CONNECTOR_REGISTERED" in types
    assert "CONNECTOR_ENABLED" in types
    runtime.stop()


def _request(url, *, method="GET", token=None, body=None):
    headers = {}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, method=method, headers=headers, data=data)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode())


def test_api_exposes_connector_control_and_approval_but_not_generic_invoke(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    runtime.register_connector(definition(), handler([]))
    token = "a-very-strong-local-api-token-123"
    service = RabidantiApiService(runtime, port=0, token=token)
    addr = service.start(background=True)
    base = f"http://{addr.host}:{addr.port}"
    try:
        code, data = _request(base + "/v1/connectors")
        assert code == 200 and data["items"][0]["connector_id"] == "demo.connector"
        code, _ = _request(base + "/v1/connectors/control", method="POST", body={
            "connector_id": "demo.connector", "enabled": True, "actor": "creator", "reason": "test"
        })
        assert code == 401
        code, item = _request(base + "/v1/connectors/control", method="POST", token=token, body={
            "connector_id": "demo.connector", "enabled": True, "actor": "creator", "reason": "test"
        })
        assert code == 200 and item["enabled"] is True
        payload = {"id": 1}
        code, approval = _request(base + "/v1/connectors/approve", method="POST", token=token, body={
            "connector_id": "demo.connector", "capability": "items.write", "payload": payload,
            "actor": "creator", "reason": "approved test write"
        })
        assert code == 201 and approval["consumed"] is False
        code, _ = _request(base + "/v1/connectors/invoke", method="POST", token=token, body={})
        assert code == 404
    finally:
        service.stop()
        runtime.stop()
