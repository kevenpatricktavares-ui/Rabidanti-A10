"""
Rabidanti v3.11 — Durable Worker Queue.

A SQLite-backed queue that stores work items durably and coordinates claims
through the v3.10 lease layer. It is designed as an adapter/foundation for
remote workers; it does not claim external broker or cloud deployment.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

from distributed_coordination import DistributedCoordinator


class QueueItemState(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


@dataclass
class QueueItem:
    item_id: str
    task_id: str
    payload: Any
    priority: int
    state: QueueItemState
    attempts: int
    max_attempts: int
    result: Any = None
    error: Optional[str] = None
    created_at: float = 0.0
    updated_at: float = 0.0
    dependencies: tuple[str, ...] = ()


class DurableWorkerQueue:
    """Durable SQLite queue with worker lease coordination."""

    def __init__(self, db_path: str, lease_seconds: int = 60):
        if lease_seconds < 1:
            raise ValueError("lease_seconds must be >= 1")
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            db_path, check_same_thread=False, isolation_level=None
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        if db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")
            self._conn.execute("PRAGMA synchronous = NORMAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS queue_items (
                item_id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL UNIQUE,
                payload_json TEXT,
                priority INTEGER NOT NULL DEFAULT 0,
                state TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                max_attempts INTEGER NOT NULL DEFAULT 3,
                result_json TEXT,
                error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                dependencies_json TEXT
            )
            """
        )
        try:
            self._conn.execute("ALTER TABLE queue_items ADD COLUMN dependencies_json TEXT")
        except sqlite3.OperationalError:
            pass
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_queue_ready "
            "ON queue_items(state, priority DESC, created_at ASC)"
        )
        self.coordinator = DistributedCoordinator(db_path, lease_seconds=lease_seconds)

    @staticmethod
    def _enc(v):
        return None if v is None else json.dumps(v, ensure_ascii=False, default=str)

    @staticmethod
    def _dec(v):
        return None if v is None else json.loads(v)

    def enqueue(
        self,
        payload: Any,
        priority: int = 0,
        max_attempts: int = 3,
        task_id: Optional[str] = None,
        item_id: Optional[str] = None,
        dependencies: Optional[list[str] | tuple[str, ...]] = None,
    ) -> QueueItem:
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        deps = tuple(dict.fromkeys(str(x) for x in (dependencies or ())))
        if task_id is not None and task_id in deps:
            raise ValueError("task cannot depend on itself")
        now = time.time()
        item = QueueItem(
            item_id=item_id or str(uuid.uuid4()),
            task_id=task_id or str(uuid.uuid4()),
            payload=payload,
            priority=int(priority),
            state=QueueItemState.QUEUED,
            attempts=0,
            max_attempts=max_attempts,
            created_at=now,
            updated_at=now,
            dependencies=deps,
        )
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO queue_items(
                    item_id,task_id,payload_json,priority,state,attempts,
                    max_attempts,result_json,error,created_at,updated_at,dependencies_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    item.item_id, item.task_id, self._enc(item.payload),
                    item.priority, item.state.value, 0, max_attempts,
                    None, None, now, now, self._enc(list(item.dependencies)),
                ),
            )
        return item

    def _row(self, r):
        return QueueItem(
            item_id=r["item_id"],
            task_id=r["task_id"],
            payload=self._dec(r["payload_json"]),
            priority=int(r["priority"]),
            state=QueueItemState(r["state"]),
            attempts=int(r["attempts"]),
            max_attempts=int(r["max_attempts"]),
            result=self._dec(r["result_json"]),
            error=r["error"],
            created_at=float(r["created_at"]),
            updated_at=float(r["updated_at"]),
            dependencies=tuple(self._dec(r["dependencies_json"]) or []),
        )

    def get_by_task_id(self, task_id: str) -> Optional[QueueItem]:
        with self._lock:
            r = self._conn.execute("SELECT * FROM queue_items WHERE task_id=?", (task_id,)).fetchone()
        return None if r is None else self._row(r)

    def list(self) -> list[QueueItem]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM queue_items ORDER BY created_at ASC").fetchall()
        return [self._row(r) for r in rows]

    def get(self, item_id: str) -> Optional[QueueItem]:
        with self._lock:
            r = self._conn.execute(
                "SELECT * FROM queue_items WHERE item_id=?", (item_id,)
            ).fetchone()
        return None if r is None else self._row(r)

    def ready(self) -> list[QueueItem]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT q.* FROM queue_items q
                WHERE q.state=?
                  AND NOT EXISTS (
                    SELECT 1 FROM json_each(COALESCE(q.dependencies_json, '[]')) d
                    LEFT JOIN queue_items dep ON dep.task_id = d.value
                    WHERE dep.task_id IS NULL OR dep.state != ?
                  )
                ORDER BY q.priority DESC, q.created_at ASC
                """,
                (QueueItemState.QUEUED.value, QueueItemState.COMPLETED.value),
            ).fetchall()
        return [self._row(r) for r in rows]

    def claim(self, item_id: str, worker_id: str) -> Optional[QueueItem]:
        """Claim one item only if the worker wins the distributed lease."""
        with self._lock:
            item = self.get(item_id)
            if item is None:
                raise KeyError(item_id)
            if item.state != QueueItemState.QUEUED:
                return None

            lease = self.coordinator.try_claim(item.task_id, worker_id)
            if lease is None:
                return None

            now = time.time()
            self._conn.execute(
                """
                UPDATE queue_items
                SET state=?, attempts=attempts+1, updated_at=?
                WHERE item_id=? AND state=?
                """,
                (
                    QueueItemState.RUNNING.value, now,
                    item_id, QueueItemState.QUEUED.value,
                ),
            )
            return self.get(item_id)

    def heartbeat(self, item_id: str, worker_id: str):
        item = self.get(item_id)
        if item is None:
            raise KeyError(item_id)
        if item.state != QueueItemState.RUNNING:
            raise ValueError("item is not running")
        return self.coordinator.heartbeat(item.task_id, worker_id)

    def complete(self, item_id: str, worker_id: str, result: Any = None) -> QueueItem:
        with self._lock:
            item = self.get(item_id)
            if item is None:
                raise KeyError(item_id)
            if item.state != QueueItemState.RUNNING:
                raise ValueError("item is not running")
            lease = self.coordinator.get(item.task_id)
            if lease is None or lease.worker_id != worker_id:
                raise PermissionError("worker does not own item")
            now = time.time()
            self._conn.execute(
                """
                UPDATE queue_items
                SET state=?, result_json=?, error=NULL, updated_at=?
                WHERE item_id=?
                """,
                (QueueItemState.COMPLETED.value, self._enc(result), now, item_id),
            )
            self.coordinator.release(item.task_id, worker_id)
            return self.get(item_id)

    def fail(self, item_id: str, worker_id: str, error: str) -> QueueItem:
        with self._lock:
            item = self.get(item_id)
            if item is None:
                raise KeyError(item_id)
            if item.state != QueueItemState.RUNNING:
                raise ValueError("item is not running")
            lease = self.coordinator.get(item.task_id)
            if lease is None or lease.worker_id != worker_id:
                raise PermissionError("worker does not own item")
            next_state = (
                QueueItemState.QUEUED
                if item.attempts < item.max_attempts
                else QueueItemState.FAILED
            )
            now = time.time()
            self._conn.execute(
                """
                UPDATE queue_items
                SET state=?, error=?, updated_at=?
                WHERE item_id=?
                """,
                (next_state.value, error, now, item_id),
            )
            self.coordinator.release(item.task_id, worker_id)
            return self.get(item_id)

    def recover_expired(self) -> list[str]:
        """Return lease-expired running items to QUEUED, unless attempts exhausted."""
        expired_tasks = self.coordinator.recover_expired()
        recovered = []
        with self._lock:
            for task_id in expired_tasks:
                row = self._conn.execute(
                    "SELECT * FROM queue_items WHERE task_id=?", (task_id,)
                ).fetchone()
                if row is None or row["state"] != QueueItemState.RUNNING.value:
                    continue
                next_state = (
                    QueueItemState.QUEUED
                    if int(row["attempts"]) < int(row["max_attempts"])
                    else QueueItemState.FAILED
                )
                self._conn.execute(
                    """
                    UPDATE queue_items SET state=?, error=?, updated_at=?
                    WHERE task_id=?
                    """,
                    (
                        next_state.value,
                        "Recovered after worker lease expiry",
                        time.time(),
                        task_id,
                    ),
                )
                recovered.append(row["item_id"])
        return recovered

    def cancel(self, item_id: str, reason: str = "cancelled") -> QueueItem:
        with self._lock:
            item = self.get(item_id)
            if item is None:
                raise KeyError(item_id)
            if item.state in {
                QueueItemState.COMPLETED,
                QueueItemState.FAILED,
                QueueItemState.CANCELLED,
            }:
                raise ValueError("item cannot be cancelled")
            self._conn.execute(
                "UPDATE queue_items SET state=?, error=?, updated_at=? WHERE item_id=?",
                (QueueItemState.CANCELLED.value, reason, time.time(), item_id),
            )
            if item.state == QueueItemState.RUNNING:
                lease = self.coordinator.get(item.task_id)
                if lease:
                    self.coordinator.release(item.task_id, lease.worker_id)
            return self.get(item_id)

    def close(self):
        self.coordinator.close()
        self._conn.close()
