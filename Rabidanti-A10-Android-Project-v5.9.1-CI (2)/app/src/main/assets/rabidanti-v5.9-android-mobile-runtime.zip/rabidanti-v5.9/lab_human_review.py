"""Rabidanti v3.97 — Laboratory Human Review & Decision Workflow.

Creates a persistent, auditable human-review workflow for laboratory evidence
that passed the v3.96 readiness gate. Human review is a governance decision,
not scientific validation and not authority to integrate code or perform an
external action.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sqlite3

from lab_evidence_readiness import LabEvidenceReadinessGate


class LabHumanReviewWorkflow:
    """Persist creator review decisions over immutable evidence snapshots.

    A review is bound to one readiness assessment / evidence snapshot. Once a
    decision is recorded it is immutable. New evidence creates a new readiness
    assessment and therefore a new review, preserving the complete history.
    """

    PENDING = "PENDING_HUMAN_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    MORE_EVIDENCE = "MORE_EVIDENCE_REQUIRED"
    DECISIONS = {APPROVED, REJECTED, MORE_EVIDENCE}

    def __init__(self, experiment_manager, evidence_memory, database="rabidanti_lab_human_review.sqlite3"):
        if experiment_manager is None or evidence_memory is None:
            raise ValueError("experiment_manager and evidence_memory are required")
        self.manager = experiment_manager
        self.memory = evidence_memory
        self.gate = LabEvidenceReadinessGate(experiment_manager, evidence_memory)
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS lab_human_reviews(
                review_id TEXT PRIMARY KEY,
                experiment_id TEXT NOT NULL,
                readiness_id TEXT NOT NULL UNIQUE,
                evidence_snapshot_digest TEXT NOT NULL,
                status TEXT NOT NULL,
                requested_by TEXT NOT NULL,
                requested_at TEXT NOT NULL,
                decided_by TEXT,
                decision_rationale TEXT,
                decided_at TEXT,
                integration_authorized INTEGER NOT NULL DEFAULT 0,
                scientifically_validated INTEGER NOT NULL DEFAULT 0
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS lab_human_review_events(
                event_id TEXT PRIMARY KEY,
                review_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                actor_id TEXT NOT NULL,
                rationale TEXT NOT NULL,
                evidence_snapshot_digest TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(review_id) REFERENCES lab_human_reviews(review_id)
            )""")

    def _db(self):
        c = sqlite3.connect(self.database)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _text(value, name):
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{name} must be non-empty text")
        return value.strip()

    @staticmethod
    def _canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)

    @staticmethod
    def _review_id(readiness_id):
        digest = hashlib.sha256(readiness_id.encode("utf-8")).hexdigest()[:24]
        return f"human-review:{digest}"

    @staticmethod
    def _decision_node_id(review_id):
        return f"human-review-decision:{review_id}"

    def _ensure_link(self, from_id, relation, to_id, note=""):
        trace = self.memory.trace(from_id)
        for link in trace["links"]:
            if link["from_id"] == from_id and link["relation"] == relation and link["to_id"] == to_id:
                return link
        return self.memory.link(from_id, relation, to_id, note=note)

    def _row(self, row):
        if row is None:
            return None
        d = dict(row)
        d["integration_authorized"] = bool(d["integration_authorized"])
        d["scientifically_validated"] = bool(d["scientifically_validated"])
        return d

    def get(self, review_id):
        with self._db() as c:
            row = c.execute("SELECT * FROM lab_human_reviews WHERE review_id=?", (review_id,)).fetchone()
        if row is None:
            raise KeyError(review_id)
        return self._row(row)

    def events(self, review_id):
        self.get(review_id)
        with self._db() as c:
            rows = c.execute(
                "SELECT * FROM lab_human_review_events WHERE review_id=? ORDER BY created_at,event_id",
                (review_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    def open_review(self, experiment_id, *, requested_by="creator"):
        requested_by = self._text(requested_by, "requested_by")
        readiness = self.gate.assess(experiment_id, persist=True)
        if readiness["classification"] != self.gate.READY:
            raise ValueError(
                f"experiment is not ready for human review: {readiness['classification']}"
            )
        readiness_id = readiness["readiness_id"]
        review_id = self._review_id(readiness_id)
        now = self._now()
        with self._db() as c:
            existing = c.execute(
                "SELECT * FROM lab_human_reviews WHERE readiness_id=?", (readiness_id,)
            ).fetchone()
            if existing is not None:
                return self._row(existing)
            c.execute(
                """INSERT INTO lab_human_reviews(
                    review_id,experiment_id,readiness_id,evidence_snapshot_digest,status,
                    requested_by,requested_at,decided_by,decision_rationale,decided_at,
                    integration_authorized,scientifically_validated
                ) VALUES(?,?,?,?,?,?,?,?,?,?,0,0)""",
                (
                    review_id,
                    experiment_id,
                    readiness_id,
                    readiness["evidence_snapshot_digest"],
                    self.PENDING,
                    requested_by,
                    now,
                    None,
                    None,
                    None,
                ),
            )
            event_id = f"review-opened:{review_id}"
            c.execute(
                "INSERT INTO lab_human_review_events VALUES(?,?,?,?,?,?,?)",
                (
                    event_id,
                    review_id,
                    "REVIEW_OPENED",
                    requested_by,
                    "Evidence met the readiness gate and was submitted for human review.",
                    readiness["evidence_snapshot_digest"],
                    now,
                ),
            )
        # The readiness node already exists because assess(..., persist=True).
        self._ensure_link(
            readiness_id,
            "SUBMITTED_FOR_HUMAN_REVIEW",
            f"experiment:{experiment_id}",
            "Review workflow opened; no integration authority granted",
        )
        return self.get(review_id)

    def decide(self, review_id, decision, *, decided_by, rationale):
        decided_by = self._text(decided_by, "decided_by")
        rationale = self._text(rationale, "rationale")
        if decision not in self.DECISIONS:
            raise ValueError("decision must be APPROVED, REJECTED, or MORE_EVIDENCE_REQUIRED")
        review = self.get(review_id)
        if review["status"] != self.PENDING:
            raise ValueError("review already has a final decision")

        readiness = self.memory.get_node(review["readiness_id"])
        if readiness["kind"] != "DECISION":
            raise ValueError("readiness evidence node has incompatible kind")
        meta = readiness["metadata"]
        if meta.get("classification") != self.gate.READY:
            raise ValueError("review is not bound to a READY_FOR_HUMAN_REVIEW assessment")
        if meta.get("evidence_snapshot_digest") != review["evidence_snapshot_digest"]:
            raise ValueError("review evidence snapshot does not match persisted readiness evidence")

        now = self._now()
        payload = {
            "record_type": "human_review_decision",
            "review_id": review_id,
            "experiment_id": review["experiment_id"],
            "readiness_id": review["readiness_id"],
            "decision": decision,
            "decided_by": decided_by,
            "rationale": rationale,
            "evidence_snapshot_digest": review["evidence_snapshot_digest"],
            "scientifically_validated": False,
            "integration_authorized": False,
            "external_action_authorized": False,
            "identity_assurance": "ASSERTED_ONLY",
            "created_at": now,
        }
        node_id = self._decision_node_id(review_id)
        try:
            self.memory.add_node(
                "DECISION",
                f"Human review {review['experiment_id']}",
                f"Human laboratory review decision: {decision}",
                node_id=node_id,
                content=self._canonical({k: v for k, v in payload.items() if k != "created_at"}),
                metadata=payload,
            )
        except ValueError as e:
            # A duplicate here would mean state has diverged from the review
            # ledger; fail closed rather than silently overwriting history.
            raise ValueError("human review decision evidence already exists") from e

        with self._db() as c:
            current = c.execute(
                "SELECT status FROM lab_human_reviews WHERE review_id=?", (review_id,)
            ).fetchone()
            if current is None:
                raise KeyError(review_id)
            if current["status"] != self.PENDING:
                raise ValueError("review already has a final decision")
            c.execute(
                """UPDATE lab_human_reviews SET status=?,decided_by=?,decision_rationale=?,decided_at=?
                   WHERE review_id=?""",
                (decision, decided_by, rationale, now, review_id),
            )
            event_id = f"review-decision:{review_id}"
            c.execute(
                "INSERT INTO lab_human_review_events VALUES(?,?,?,?,?,?,?)",
                (
                    event_id,
                    review_id,
                    decision,
                    decided_by,
                    rationale,
                    review["evidence_snapshot_digest"],
                    now,
                ),
            )

        self._ensure_link(
            review["readiness_id"],
            "HUMAN_REVIEW_DECIDED_AS",
            node_id,
            "Human governance decision; not scientific validation or integration authorization",
        )
        self._ensure_link(
            f"experiment:{review['experiment_id']}",
            "HAS_HUMAN_REVIEW_DECISION",
            node_id,
            "Decision bound to one immutable evidence snapshot",
        )
        return self.get(review_id)

    def history(self, experiment_id):
        self.manager.get(experiment_id)
        with self._db() as c:
            rows = c.execute(
                "SELECT * FROM lab_human_reviews WHERE experiment_id=? ORDER BY requested_at,review_id",
                (experiment_id,),
            ).fetchall()
        reviews = [self._row(r) for r in rows]
        return {
            "experiment_id": experiment_id,
            "reviews": reviews,
            "integration_authorized": False,
            "scientifically_validated": False,
            "limitation": (
                "Reviewer identity is recorded as asserted text; this module does not authenticate identity. "
                "Human review is governance evidence, not scientific validation or execution authority."
            ),
        }

    def authorize_integration(self, *args, **kwargs):
        raise PermissionError("human laboratory review cannot authorize Core integration")

    def authorize_external_action(self, *args, **kwargs):
        raise PermissionError("human laboratory review cannot authorize external actions")
