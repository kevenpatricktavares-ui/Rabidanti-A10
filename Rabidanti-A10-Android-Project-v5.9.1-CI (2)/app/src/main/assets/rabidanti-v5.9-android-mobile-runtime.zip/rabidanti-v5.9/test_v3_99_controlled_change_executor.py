import hashlib
from pathlib import Path
import sqlite3
import pytest

from lab_controlled_change_executor import ControlledChangeExecutor


class StubProposals:
    PROPOSED = "PROPOSED_FOR_INTEGRATION_REVIEW"

    def __init__(self, *, affected_files=None):
        self.record = {
            "proposal_id": "integration-proposal:p1",
            "proposal_digest": "a" * 64,
            "status": self.PROPOSED,
            "affected_files": affected_files or ["app.py"],
            "integration_authorized": False,
        }

    def get(self, proposal_id):
        if proposal_id != self.record["proposal_id"]:
            raise KeyError(proposal_id)
        return dict(self.record)


def sha(data: bytes):
    return hashlib.sha256(data).hexdigest()


def make_executor(tmp_path, affected_files=None):
    p = StubProposals(affected_files=affected_files)
    e = ControlledChangeExecutor(p, tmp_path / "changes.sqlite3")
    return p, e


def make_workspace(tmp_path, old="VALUE = 1\n", *, passing=True):
    w = tmp_path / "workspace"
    w.mkdir()
    (w / "app.py").write_text(old, encoding="utf-8")
    expected = 2 if passing else 999
    (w / "test_sample.py").write_text(
        f"import app\n\ndef test_value():\n    assert app.VALUE == {expected}\n", encoding="utf-8"
    )
    return w, old


def create_change(executor, old, *, content="VALUE = 2\n"):
    return executor.create_change_set(
        "integration-proposal:p1",
        files=[{"path": "app.py", "content": content, "expected_sha256": sha(old.encode())}],
        verification_commands=[["python", "-m", "pytest", "-q", "test_sample.py"]],
        created_by="creator",
    )


def test_change_set_is_persistent_pending_and_non_external(tmp_path):
    _, e = make_executor(tmp_path)
    _, old = make_workspace(tmp_path)
    c = create_change(e, old)
    assert c["status"] == e.PENDING
    assert c["external_action_authorized"] is False
    restarted = ControlledChangeExecutor(e.proposals, e.database)
    assert restarted.get(c["change_id"])["change_digest"] == c["change_digest"]


def test_change_set_must_exactly_match_proposal_files(tmp_path):
    _, e = make_executor(tmp_path, affected_files=["app.py", "other.py"])
    _, old = make_workspace(tmp_path)
    with pytest.raises(ValueError, match="exactly match"):
        create_change(e, old)


def test_change_set_rejects_unsafe_paths_and_unallowlisted_commands(tmp_path):
    _, e = make_executor(tmp_path)
    for path in ("../app.py", "/tmp/app.py", r"C:\\app.py"):
        with pytest.raises(ValueError, match="path"):
            e.create_change_set(
                "integration-proposal:p1",
                files=[{"path": path, "content": "x", "expected_sha256": None}],
                verification_commands=[["python", "-m", "pytest"]],
            )
    with pytest.raises(ValueError, match="allowlisted"):
        e.create_change_set(
            "integration-proposal:p1",
            files=[{"path": "app.py", "content": "x", "expected_sha256": None}],
            verification_commands=[["bash", "-lc", "pytest"]],
        )


def test_authorization_is_bound_to_exact_change_digest(tmp_path):
    _, e = make_executor(tmp_path)
    _, old = make_workspace(tmp_path)
    c = create_change(e, old)
    with pytest.raises(ValueError, match="digest"):
        e.authorize(c["change_id"], authorized_by="creator", reason="approved", expected_change_digest="0" * 64)
    a = e.authorize(c["change_id"], authorized_by="creator", reason="approved after review", expected_change_digest=c["change_digest"])
    assert a["status"] == e.AUTHORIZED
    assert a["authorization_digest"]
    with pytest.raises(ValueError, match="not pending"):
        e.authorize(c["change_id"], authorized_by="creator", reason="again", expected_change_digest=c["change_digest"])


def test_execution_requires_explicit_authorization(tmp_path):
    _, e = make_executor(tmp_path)
    w, old = make_workspace(tmp_path)
    c = create_change(e, old)
    with pytest.raises(PermissionError, match="explicit authorization"):
        e.execute(c["change_id"], workspace=w)
    assert (w / "app.py").read_text() == old


def test_authorized_change_applies_and_verification_passes(tmp_path):
    _, e = make_executor(tmp_path)
    w, old = make_workspace(tmp_path, passing=True)
    c = create_change(e, old)
    e.authorize(c["change_id"], authorized_by="creator", reason="approved", expected_change_digest=c["change_digest"])
    result = e.execute(c["change_id"], workspace=w)
    assert result["status"] == e.APPLIED
    assert (w / "app.py").read_text() == "VALUE = 2\n"
    assert result["verification"][0]["returncode"] == 0
    assert Path(result["backup_path"]).is_dir()


def test_failed_verification_rolls_back_original_bytes(tmp_path):
    _, e = make_executor(tmp_path)
    w, old = make_workspace(tmp_path, passing=False)
    c = create_change(e, old)
    e.authorize(c["change_id"], authorized_by="creator", reason="approved", expected_change_digest=c["change_digest"])
    result = e.execute(c["change_id"], workspace=w)
    assert result["status"] == e.ROLLED_BACK
    assert (w / "app.py").read_text() == old
    assert result["verification"][0]["returncode"] != 0
    assert "verification failed" in result["error"]


def test_prechange_digest_mismatch_fails_closed_before_write(tmp_path):
    _, e = make_executor(tmp_path)
    w, old = make_workspace(tmp_path)
    c = create_change(e, old)
    e.authorize(c["change_id"], authorized_by="creator", reason="approved", expected_change_digest=c["change_digest"])
    (w / "app.py").write_text("VALUE = 77\n", encoding="utf-8")
    with pytest.raises(ValueError, match="pre-change digest mismatch"):
        e.execute(c["change_id"], workspace=w)
    assert (w / "app.py").read_text() == "VALUE = 77\n"
    assert e.get(c["change_id"])["status"] == e.AUTHORIZED


def test_new_file_is_removed_during_rollback(tmp_path):
    p, e = make_executor(tmp_path, affected_files=["new_module.py"])
    w = tmp_path / "workspace"
    w.mkdir()
    (w / "test_sample.py").write_text("def test_fail():\n    assert False\n", encoding="utf-8")
    c = e.create_change_set(
        p.record["proposal_id"],
        files=[{"path": "new_module.py", "content": "X = 1\n", "expected_sha256": None}],
        verification_commands=[["python", "-m", "pytest", "-q", "test_sample.py"]],
    )
    e.authorize(c["change_id"], authorized_by="creator", reason="approved", expected_change_digest=c["change_digest"])
    result = e.execute(c["change_id"], workspace=w)
    assert result["status"] == e.ROLLED_BACK
    assert not (w / "new_module.py").exists()


def test_identical_change_set_is_idempotent(tmp_path):
    _, e = make_executor(tmp_path)
    _, old = make_workspace(tmp_path)
    a = create_change(e, old)
    b = create_change(e, old)
    assert a["change_id"] == b["change_id"]
    with sqlite3.connect(e.database) as c:
        assert c.execute("SELECT COUNT(*) FROM controlled_change_sets").fetchone()[0] == 1


def test_proposal_digest_tampering_blocks_execution(tmp_path):
    p, e = make_executor(tmp_path)
    w, old = make_workspace(tmp_path)
    c = create_change(e, old)
    e.authorize(c["change_id"], authorized_by="creator", reason="approved", expected_change_digest=c["change_digest"])
    p.record["proposal_digest"] = "b" * 64
    with pytest.raises(ValueError, match="proposal digest changed"):
        e.execute(c["change_id"], workspace=w)
    assert (w / "app.py").read_text() == old


def test_executor_cannot_self_authorize_or_authorize_external_actions(tmp_path):
    _, e = make_executor(tmp_path)
    with pytest.raises(PermissionError, match="cannot authorize itself"):
        e.self_authorize()
    with pytest.raises(PermissionError, match="external actions"):
        e.authorize_external_action()
