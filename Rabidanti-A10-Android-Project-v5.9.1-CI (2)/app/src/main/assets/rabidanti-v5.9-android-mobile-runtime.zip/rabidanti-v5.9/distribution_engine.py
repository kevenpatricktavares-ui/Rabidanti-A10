"""Rabidanti v3.40 — sales-to-distribution preparation."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class DistributionBrief:
    project_id: str
    product_name: str
    channels: tuple[str, ...]
    assets: tuple[str, ...]
    sales_events: tuple[str, ...]
    status: str = "PREPARED"
    limitations: tuple[str, ...] = ()
    def to_dict(self) -> dict[str, Any]: return asdict(self)

class DistributionEngine:
    def prepare(self, project_id: str, product: Mapping[str, Any], sales: Mapping[str, Any], channels: tuple[str, ...] | None = None) -> DistributionBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not product: raise ValueError("product must not be empty")
        if not sales: raise ValueError("sales must not be empty")
        selected = tuple(channels or ("web", "social", "marketplace", "email", "video"))
        if not selected or any(not str(c).strip() for c in selected): raise ValueError("channels must not be empty")
        name = str(product.get("name") or product.get("title") or "Digital Product").strip()
        events = tuple(sales.get("events") or ())
        assets = tuple(f"{c}:product-package" for c in selected)
        limits = (
            "Distribution is preparation only; no external publication is claimed.",
            "External accounts, permissions and platform policies require approved connectors.",
        )
        return DistributionBrief(str(project_id), name, selected, assets, events, "PREPARED", limits)
