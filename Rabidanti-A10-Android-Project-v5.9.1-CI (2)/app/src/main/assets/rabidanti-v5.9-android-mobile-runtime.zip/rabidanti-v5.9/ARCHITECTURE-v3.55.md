# Rabidanti v3.55 — World Knowledge Graph

Adds a persistent provenance-aware graph of entities and typed relations.

## Guarantees
- Entities and relations persist in SQLite.
- Relations carry status, confidence, optional source and claim provenance.
- Traversal exposes the related entity and provenance.
- A relation is `PROPOSED` by default and is never treated as truth merely because it exists.
- Invalid references, confidence values, and future timestamps are rejected.

## Scope
This is a knowledge-graph foundation. It does not infer arbitrary facts, crawl the web, or replace source verification. Later layers can connect verified claim assessments and world/laboratory entities into this graph.
