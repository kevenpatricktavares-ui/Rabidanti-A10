# Rabidanti v2.5 — Specialized Product Integration

## Purpose
Connect the specialized modules without changing the stable core pipeline.

## Integrated modules
Product Context
-> Persona Adaptation
-> Character Consistency
-> Content / Interactive Experience
-> Audiovisual Explanation
-> Quality Review
-> Human Approval

## Rules
- Specialized modules remain modular.
- Integration does not grant external permissions.
- No automatic publication.
- Persona adaptation cannot alter factual claims.
- Character identity remains consistent.
- Audiovisual content must match approved information.
- Interactive outputs must follow declared rules.
- Human approval remains mandatory before external publication.

## Next infrastructure layer
Connector Core, Jobs/Workers, Dashboard/Connection Center, security hardening,
end-to-end testing, deployment and observability.
