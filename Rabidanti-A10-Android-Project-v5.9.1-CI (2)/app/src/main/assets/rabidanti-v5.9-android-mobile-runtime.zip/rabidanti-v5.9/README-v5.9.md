# Rabidanti v5.9 — Android Compatibility & Mobile Runtime

Rabidanti v5.9 adds Android/Termux as a supported host path without changing the
Core architecture.

## Quick start on Android

Extract the release inside Termux, then run:

```bash
pkg update
pkg install python
chmod +x SETUP-ANDROID-TERMUX.sh START-RABIDANTI-ANDROID.sh
./SETUP-ANDROID-TERMUX.sh
./START-RABIDANTI-ANDROID.sh
```

The Sala remains local to the device at `http://127.0.0.1:8765/ui/` unless a
different port is selected.

For a readiness check without starting the product:

```bash
python rabidanti_android.py doctor
```

See `ANDROID-TERMUX.md` for the complete Android guide.

## Architecture rule

Android is a host adapter only. Runtime, SQLite state, encrypted vault,
connectors, Proposal Bridge, Permission Gate, Lab, evidence and audit remain the
same components used by the desktop/source product.

## Model limitation

A local Ollama service is not assumed to be present on Android. Model
unavailability is reported rather than hidden, and no external provider is
selected automatically.
