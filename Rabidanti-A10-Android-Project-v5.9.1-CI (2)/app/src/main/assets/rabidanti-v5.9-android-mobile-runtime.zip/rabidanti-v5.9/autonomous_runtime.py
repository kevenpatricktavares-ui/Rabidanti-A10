
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
from threading import Lock
from typing import Optional

class TaskState(str, Enum):
    QUEUED="QUEUED"
    RUNNING="RUNNING"
    WAITING="WAITING"
    COMPLETED="COMPLETED"
    FAILED="FAILED"
    CANCELLED="CANCELLED"

class TaskPriority(int, Enum):
    LOW=10
    NORMAL=50
    HIGH=80
    CRITICAL=100

@dataclass
class AutonomousTask:
    task_id: str
    name: str
    priority: TaskPriority = TaskPriority.NORMAL
    state: TaskState = TaskState.QUEUED
    dependencies: list[str] = field(default_factory=list)
    attempts: int = 0
    max_attempts: int = 3
    owner: Optional[str] = None
    result: object = None
    error: Optional[str] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

class AutonomousTaskRuntime:
    """In-process autonomous task state machine.

    It deliberately delegates actual execution to the existing Job/Worker
    infrastructure. This layer decides what may run and tracks its lifecycle.
    """

    def __init__(self):
        self.tasks={}
        self.lock=Lock()

    def add(self, task: AutonomousTask):
        with self.lock:
            if task.task_id in self.tasks:
                raise ValueError("task already exists")
            self.tasks[task.task_id]=task

    def get(self, task_id):
        with self.lock:
            return self.tasks.get(task_id)

    def ready(self, task_id):
        with self.lock:
            t=self.tasks[task_id]
            if t.state != TaskState.QUEUED:
                return False
            return all(
                dep in self.tasks and self.tasks[dep].state == TaskState.COMPLETED
                for dep in t.dependencies
            )

    def claim(self, task_id, worker_id):
        with self.lock:
            t=self.tasks[task_id]
            if not self._ready_locked(t):
                return False
            if t.owner is not None:
                return False
            t.owner=worker_id
            t.state=TaskState.RUNNING
            t.attempts += 1
            t.updated_at=datetime.now(timezone.utc)
            return True

    def complete(self, task_id, worker_id, result=None):
        with self.lock:
            t=self.tasks[task_id]
            self._check_owner(t,worker_id)
            t.result=result
            t.state=TaskState.COMPLETED
            t.updated_at=datetime.now(timezone.utc)

    def fail(self, task_id, worker_id, error):
        with self.lock:
            t=self.tasks[task_id]
            self._check_owner(t,worker_id)
            t.error=str(error)
            t.owner=None
            t.state=TaskState.QUEUED if t.attempts < t.max_attempts else TaskState.FAILED
            t.updated_at=datetime.now(timezone.utc)

    def cancel(self, task_id):
        with self.lock:
            t=self.tasks[task_id]
            if t.state in (TaskState.COMPLETED, TaskState.FAILED):
                return False
            t.state=TaskState.CANCELLED
            t.owner=None
            t.updated_at=datetime.now(timezone.utc)
            return True

    def runnable(self):
        with self.lock:
            return sorted(
                [t for t in self.tasks.values() if self._ready_locked(t)],
                key=lambda x:(-int(x.priority),x.created_at,x.task_id)
            )

    def _ready_locked(self,t):
        if t.state != TaskState.QUEUED or t.owner is not None:
            return False
        return all(
            dep in self.tasks and self.tasks[dep].state == TaskState.COMPLETED
            for dep in t.dependencies
        )

    @staticmethod
    def _check_owner(t,worker_id):
        if t.owner != worker_id:
            raise PermissionError("task owned by another worker")
