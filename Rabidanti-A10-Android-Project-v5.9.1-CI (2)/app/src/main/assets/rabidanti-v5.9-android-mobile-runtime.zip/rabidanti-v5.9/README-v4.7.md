# Rabidanti v4.7 — Model Gateway & Conversation Layer

A v4.7 adiciona conversa persistente com um modelo local via API Ollama em loopback.

## Arranque

```bash
python rabidanti.py room
```

Por defeito:
- provider: `ollama`
- URL: `http://127.0.0.1:11434`
- model: `llama3.2`

## Configuração

```bash
python rabidanti.py config set ai.model qwen3
python rabidanti.py config set ai.timeout_seconds 90
```

`ai.base_url` só aceita hosts loopback.

## Segurança
O conteúdo gerado pelo modelo é tratado exclusivamente como texto. Não executa ferramentas, conectores, shell, publicação, pagamentos ou alterações do Core. Todas essas capacidades continuam dependentes das camadas explícitas de autorização do Rabidanti.

## Limitação
Ollama e um modelo local precisam ser instalados separadamente para chat real. Os testes desta versão usam HTTP controlado/mock e não provam disponibilidade de um modelo local no computador do utilizador.
