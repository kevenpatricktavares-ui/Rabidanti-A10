from __future__ import annotations
import json
from pathlib import Path
import pytest
from windows_handoff import HandoffError, inspect, inspect_windows_toolchain
from rabidanti_release import validate_release_tree


def _minimal_tree(tmp_path: Path) -> Path:
    root = tmp_path / "root"
    root.mkdir()
    for name in [
        "Rabidanti.spec", "build_windows.bat", "build_release_windows.bat",
        "verify_windows_release.ps1", "native_release_check.py",
        "installer_windows.iss", "requirements-dev.txt", "windows-toolchain.json",
    ]:
        src = Path(name)
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(src.read_bytes())
    wf = root / ".github/workflows/windows-native-release.yml"
    wf.parent.mkdir(parents=True, exist_ok=True)
    wf.write_bytes(Path('.github/workflows/windows-native-release.yml').read_bytes())
    (root / "VERSION").write_text(Path("VERSION").read_text(), encoding="utf-8")
    return root


def test_version_is_at_least_5_6():
    version = tuple(map(int, Path("VERSION").read_text().strip().split(".")))
    assert version >= (5, 6, 0)


def test_release_preflight_requires_handoff_components():
    result = validate_release_tree(Path("."))
    assert result["checks"] >= 25
    for name in ["windows-toolchain.json", "windows_handoff.py", "prepare_windows_build.ps1", "BUILD-WINDOWS-RELEASE.cmd"]:
        assert Path(name).exists()


def test_source_handoff_is_ready_but_not_native_validated():
    result = inspect(Path("."))
    assert result["source_tree_ready"] is True
    assert result["native_release_validated"] is False
    assert result["version"] == Path("VERSION").read_text().strip()


def test_handoff_rejects_missing_release_input(tmp_path):
    root = _minimal_tree(tmp_path)
    (root / "Rabidanti.spec").unlink()
    with pytest.raises(HandoffError, match="missing release inputs"):
        inspect(root)


def test_handoff_rejects_fabricated_native_evidence(tmp_path):
    root = _minimal_tree(tmp_path)
    (root / "release-manifest.json").write_text("{}")
    with pytest.raises(HandoffError, match="must not contain fabricated"):
        inspect(root)


def test_toolchain_contract_is_explicit_and_x64():
    contract = json.loads(Path("windows-toolchain.json").read_text())
    assert contract["schema"] == 1
    assert contract["architecture"] == "x64"
    assert contract["inno_setup"]["major"] == 6


def test_non_windows_environment_cannot_be_declared_toolchain_ready():
    result = inspect_windows_toolchain(Path("."))
    if result["host"]["system"].lower() != "windows":
        assert result["toolchain_checks"]["windows_host"] is False
        assert result["toolchain_ready"] is False


def test_prepare_script_requires_windows_and_generates_report():
    text = Path("prepare_windows_build.ps1").read_text(encoding="utf-8")
    assert 'Windows_NT' in text
    assert 'windows_handoff.py --toolchain --output' in text
    assert 'requirements-dev.txt' in text


def test_one_command_launcher_prepares_before_native_build():
    text = Path("BUILD-WINDOWS-RELEASE.cmd").read_text(encoding="utf-8").lower()
    assert text.index("prepare_windows_build.ps1") < text.index("build_release_windows.bat")
    assert "native_release_check.py" in text


def test_release_build_refuses_without_handoff_report():
    text = Path("build_release_windows.bat").read_text(encoding="utf-8")
    assert 'windows-build-handoff.json missing' in text
    assert 'prepare_windows_build.ps1' in text


def test_ci_uses_reproducible_preparation_step():
    text = Path(".github/workflows/windows-native-release.yml").read_text(encoding="utf-8")
    assert "Prepare reproducible Windows toolchain" in text
    assert "prepare_windows_build.ps1 -BootstrapPython" in text
    assert "build_release_windows.bat" in text


def test_handoff_document_never_claims_source_zip_is_native_release():
    text = Path("WINDOWS-BUILD-HANDOFF.md").read_text(encoding="utf-8")
    assert "not" in text.lower()
    assert "release-manifest.json" in text
    assert "windows-release-validation.json" in text
