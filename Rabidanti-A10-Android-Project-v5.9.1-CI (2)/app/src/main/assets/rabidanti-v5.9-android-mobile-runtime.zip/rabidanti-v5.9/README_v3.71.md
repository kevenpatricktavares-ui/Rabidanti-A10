# Rabidanti v3.71 — Evolution Evidence & Decision Engine

Decision layer between evolution proposals and approval.

Evidence -> assessment -> decision -> experiment or approval.

Factors: evidence confidence, expected impact, risk, estimated cost, reversibility.

The engine never activates, deploys, changes Core configuration, or bypasses approval.
