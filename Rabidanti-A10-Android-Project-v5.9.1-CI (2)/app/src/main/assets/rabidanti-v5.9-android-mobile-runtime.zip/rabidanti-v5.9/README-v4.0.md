# Rabidanti v4.0 — Runtime MVP

Rabidanti v4.0 is the first unified executable local runtime built on the validated modules through v3.99.

## What is real in v4.0

- One persistent state directory.
- Unified initialization of durable queue, workflows, tasks, scheduler and worker health.
- Unified Laboratory access: experiment manager, evidence memory, readiness gate, human review, integration proposals and controlled change executor.
- Persistent runtime event audit trail.
- Recovery of abandoned RUNNING autonomous tasks and expired queue leases on startup.
- CLI entry point and interactive shell.
- Explicit safety state: startup grants no permission to self-authorize, integrate Core changes automatically, or perform external actions.

## Start

Python 3.10+ is required.

```bash
python rabidanti.py status
python rabidanti.py doctor
python rabidanti.py task add "Investigate opportunity" --priority HIGH
python rabidanti.py task list
python rabidanti.py shell
```

Use a custom persistent state directory:

```bash
python rabidanti.py --state-dir /path/to/state status
```

On Windows, `rabidanti.bat` starts the interactive shell. On Linux/macOS, `./rabidanti.sh` does the same.

## Interactive shell

Commands currently exposed:

- `status`
- `doctor`
- `task add <name>`
- `task list`
- `evidence [text]`
- `events`
- `help`
- `exit`

## Boundaries

v4.0 is a local Runtime MVP, not the final product. It does not yet provide:

- a graphical desktop UI;
- a local HTTP/API service;
- packaged standalone Windows executable;
- real external platform connectors and credential management;
- validated OS-level container isolation in environments without Docker/Podman;
- continuous 24/7 remote hosting by itself.

Evidence provenance remains distinct from scientific validation. Controlled code changes still require explicit authorization and retain rollback/test safeguards.
