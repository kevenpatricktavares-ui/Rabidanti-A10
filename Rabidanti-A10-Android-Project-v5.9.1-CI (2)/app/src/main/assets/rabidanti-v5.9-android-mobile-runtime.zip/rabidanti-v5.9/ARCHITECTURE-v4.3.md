# Rabidanti Architecture v4.3 — Configuration & Secrets Boundary

## Goal

Prepare the local runtime for real connectors without allowing credentials to leak into source code, SQLite state, ordinary configuration, browser storage, or audit events.

## Components

### `RabidantiConfig`

Schema-limited JSON configuration stored at `state/config.json`.

Properties:
- allowlist only;
- validation before commit;
- atomic temp-file + replace write;
- restrictive POSIX permissions;
- no secret-shaped keys.

### `RabidantiSecrets`

Non-persistent secret resolver with precedence:

`session memory` → `RABIDANTI_SECRET_<NAME>` → legacy API-token environment variable.

Only metadata (`name`, `configured`, `source`) is exposed through status APIs.

### Runtime integration

`RabidantiRuntime` owns both managers. Runtime status exposes configuration and only a count of configured secrets. Audit details pass through recursive key-based redaction before SQLite persistence.

### API/Sala boundary

The loopback API exposes read-only metadata without authentication, while all configuration/secret mutations require the existing bearer token. Secret values are never returned by the API. The Sala keeps both mutation token and newly entered secret value only in JavaScript memory/DOM fields; it does not use localStorage, sessionStorage, or cookies.

## Security invariant

Possessing/configuring a credential is **not** the same as permission to use it. External actions remain subject to future connector-specific authorization and approval policies.
