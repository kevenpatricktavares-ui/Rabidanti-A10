# Rabidanti v3.30 — Business Pipeline Workflow

The Core Orchestrator now exposes the canonical Rabidanti business pipeline as a durable workflow definition.

Flow:
Research → Opportunity → Product → Content → Review → Render → Brand → Landing → Sales → Distribution → Ads → Analytics → Learning

The workflow uses stable stage contracts and payloads. Concrete domain-agent implementations are intentionally not fabricated: a queue item is executable only when a worker handler for its stage is registered.

The definition supports DAG planning and safe parallelism where dependencies permit it. Persistence, queueing, recovery and execution remain delegated to the existing durable infrastructure.
