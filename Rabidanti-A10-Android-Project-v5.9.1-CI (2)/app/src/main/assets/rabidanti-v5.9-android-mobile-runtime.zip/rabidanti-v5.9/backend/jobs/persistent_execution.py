import json
import time
from typing import Any, Callable, List
from .job_manager import Job, JobManager, JobPriority, JobState
from backend.persistence.repositories import JobRepository

def _hydrate(row) -> Job:
    result = json.loads(row["result_json"]) if row.get("result_json") else None
    return Job(
        id=row["id"], project_id=row["project_id"], agent=row["agent"], stage=row["stage"],
        priority=JobPriority(row["priority"]), state=JobState(row["state"]),
        retries=row["retries"], max_retries=row["max_retries"],
        requires_approval=bool(row["requires_approval"]),
        approval_granted=bool(row["approval_granted"]), error=row.get("error"),
        result=result, created_at=row["created_at"], updated_at=row["updated_at"])

class PersistentJobManager(JobManager):
    def __init__(self, repository: JobRepository, lease_seconds: int = 300):
        super().__init__()
        self.repository = repository
        self.lease_seconds = max(30, int(lease_seconds))
        self.recover_interrupted()

    def recover_interrupted(self) -> List[Job]:
        recovered = []
        for row in self.repository.list_states([JobState.RUNNING.value]):
            job = _hydrate(row)
            if job.retries < job.max_retries:
                retries, state = job.retries + 1, JobState.RETRY
            else:
                retries, state = job.retries, JobState.FAILED
            row2 = self.repository.update_runtime(
                job.id, state.value, retries=retries,
                error="worker interrupted; recovered after restart",
                worker_id="", lease_until=0)
            recovered.append(_hydrate(row2))
        return recovered

    def create(self, project_id, agent, stage, priority=JobPriority.NORMAL,
               max_retries=3, requires_approval=False):
        job = super().create(project_id, agent, stage, priority, max_retries, requires_approval)
        self.repository.save(job)
        return job

    def get(self, job_id):
        row = self.repository.get(job_id)
        return _hydrate(row) if row else None

    def list(self, project_id=None):
        if project_id is None:
            return [_hydrate(r) for r in self.repository.list_all()]
        return [_hydrate(r) for r in self.repository.list(project_id)]

    def approve(self, job_id):
        job = self.get(job_id)
        if job is None: raise KeyError(f"job not found: {job_id}")
        if not job.requires_approval: raise ValueError("job does not require approval")
        if job.state != JobState.WAITING_APPROVAL: raise ValueError("job is not waiting for approval")
        return _hydrate(self.repository.update_runtime(
            job_id, JobState.QUEUED.value, approval_granted=True, worker_id="", lease_until=0))

    def run(self, job_id: str, handler: Callable[[], Any], worker_id: str = "worker") -> Job:
        job = self.get(job_id)
        if job is None: raise KeyError(f"job not found: {job_id}")
        if job.requires_approval and not job.approval_granted:
            return _hydrate(self.repository.update_runtime(job_id, JobState.WAITING_APPROVAL.value))
        claimed = self.repository.claim(job_id, worker_id, time.time() + self.lease_seconds)
        if not claimed or claimed["state"] != JobState.RUNNING.value:
            return _hydrate(claimed) if claimed else job
        try:
            result = handler()
            row = self.repository.update_runtime(
                job_id, JobState.COMPLETED.value, result=result, worker_id="", lease_until=0)
        except Exception as exc:
            current = self.get(job_id)
            retries = current.retries + 1
            state = JobState.RETRY if retries <= current.max_retries else JobState.FAILED
            row = self.repository.update_runtime(
                job_id, state.value, retries=retries, error=str(exc), worker_id="", lease_until=0)
        return _hydrate(row)

    def retry(self, job_id, handler, worker_id="worker"):
        job = self.get(job_id)
        if job is None: raise KeyError(f"job not found: {job_id}")
        if job.state not in {JobState.RETRY, JobState.FAILED}: raise ValueError("job is not retryable")
        if job.state == JobState.FAILED and job.retries >= job.max_retries:
            raise ValueError("maximum retries reached")
        return self.run(job_id, handler, worker_id)
