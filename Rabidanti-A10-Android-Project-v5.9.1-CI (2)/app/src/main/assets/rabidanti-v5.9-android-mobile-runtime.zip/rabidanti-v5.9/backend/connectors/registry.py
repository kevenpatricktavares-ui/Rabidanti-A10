
from typing import Dict, List, Optional

from .core import Connector, ConnectorPermission


class ConnectorRegistry:
    def __init__(self):
        self._connectors: Dict[str, Connector] = {}

    def register(self, connector: Connector) -> Connector:
        if connector.id in self._connectors:
            raise ValueError(f"connector already registered: {connector.id}")
        self._connectors[connector.id] = connector
        return connector

    def get(self, connector_id: str) -> Optional[Connector]:
        return self._connectors.get(connector_id)

    def list(self) -> List[Connector]:
        return list(self._connectors.values())

    def remove(self, connector_id: str) -> bool:
        if connector_id not in self._connectors:
            return False
        del self._connectors[connector_id]
        return True

    def request_permission(
        self,
        connector_id: str,
        permission: ConnectorPermission,
        approval_granted: bool = False,
    ):
        connector = self.get(connector_id)
        if connector is None:
            return {"allowed": False, "reason": "connector not found"}
        return connector.authorize(permission, approval_granted)
