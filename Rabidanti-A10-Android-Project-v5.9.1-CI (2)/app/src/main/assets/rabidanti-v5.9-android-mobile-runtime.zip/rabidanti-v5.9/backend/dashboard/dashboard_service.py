from dataclasses import asdict
from typing import Any, Dict, Iterable, Optional

from ..connectors.core import Connector
from ..jobs.job_manager import JobManager
from ..approvals.approval_center import ApprovalCenter


class DashboardService:
    """Read-only aggregation layer for the central Rabidanti control surface."""

    def __init__(
        self,
        job_manager: JobManager,
        connectors: Iterable[Connector],
        approval_center: ApprovalCenter,
    ):
        self.job_manager = job_manager
        self.connectors = list(connectors)
        self.approval_center = approval_center

    def snapshot(self, project_id: Optional[str] = None) -> Dict[str, Any]:
        jobs = self.job_manager.list(project_id)
        pending = self.approval_center.pending(project_id)
        connector_rows = [self._connector_row(c) for c in self.connectors]
        job_rows = [self._job_row(j) for j in jobs]

        counts: Dict[str, int] = {}
        for job in jobs:
            counts[job.state.value] = counts.get(job.state.value, 0) + 1

        return {
            "project_id": project_id,
            "jobs": job_rows,
            "job_counts": counts,
            "pending_approvals": [self._job_row(j) for j in pending],
            "connectors": connector_rows,
            "connector_counts": self._connector_counts(connector_rows),
            "approval_history": self.approval_center.history(),
        }

    @staticmethod
    def _job_row(job) -> Dict[str, Any]:
        row = asdict(job)
        row["priority"] = job.priority.value
        row["state"] = job.state.value
        return row

    @staticmethod
    def _connector_row(connector: Connector) -> Dict[str, Any]:
        return {
            "id": connector.id,
            "name": connector.name,
            "provider": connector.provider,
            "state": connector.state.value,
            "permissions": connector.capabilities(),
            "health": connector.health(),
        }

    @staticmethod
    def _connector_counts(rows) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for row in rows:
            state = row["state"]
            counts[state] = counts.get(state, 0) + 1
        return counts
