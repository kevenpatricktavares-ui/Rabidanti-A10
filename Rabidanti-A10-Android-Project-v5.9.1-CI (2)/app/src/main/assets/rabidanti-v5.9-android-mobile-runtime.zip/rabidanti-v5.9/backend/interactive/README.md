# Interactive Product Factory

First-class specifications for calculators, simulators, planners, assessments,
document generators, dashboards, educational tools, and niche web tools.

The module is specification-first: it validates product logic and integration
metadata but does not execute arbitrary code or publish externally.

Integration:
- Persona Engine: market/context adaptation.
- Character Engine: consistent explainer identity.
- Audiovisual Factory: demos and explanations.
