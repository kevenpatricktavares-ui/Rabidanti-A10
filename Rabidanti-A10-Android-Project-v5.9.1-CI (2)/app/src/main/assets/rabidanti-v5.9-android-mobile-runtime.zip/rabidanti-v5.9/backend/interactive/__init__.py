"""Rabidanti Interactive Product Factory."""
from .interactive_product_factory import InteractiveProductFactory, InteractiveProductBrief
