# Approval Center

The Approval Center lists jobs waiting for explicit authorization and records approval/rejection decisions.

Rejecting a waiting job moves it to `FAILED` with a reason. Approving a job moves it to `QUEUED`.

Approval does not modify connector permission lists.
