
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional
from datetime import datetime, timezone
import uuid


class JobState(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    RETRY = "RETRY"
    WAITING_APPROVAL = "WAITING_APPROVAL"


class JobPriority(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    NORMAL = "NORMAL"
    LOW = "LOW"


@dataclass
class Job:
    id: str
    project_id: str
    agent: str
    stage: str
    priority: JobPriority = JobPriority.NORMAL
    state: JobState = JobState.QUEUED
    retries: int = 0
    max_retries: int = 3
    requires_approval: bool = False
    approval_granted: bool = False
    error: Optional[str] = None
    result: Any = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class JobManager:
    """Small deterministic execution manager; persistence/worker daemons come later."""

    def __init__(self):
        self.jobs: Dict[str, Job] = {}

    def create(
        self,
        project_id: str,
        agent: str,
        stage: str,
        priority: JobPriority = JobPriority.NORMAL,
        max_retries: int = 3,
        requires_approval: bool = False,
    ) -> Job:
        job = Job(
            id=str(uuid.uuid4()),
            project_id=project_id,
            agent=agent,
            stage=stage,
            priority=priority,
            max_retries=max(0, max_retries),
            requires_approval=requires_approval,
        )
        if requires_approval:
            job.state = JobState.WAITING_APPROVAL
        self.jobs[job.id] = job
        return job

    def get(self, job_id: str) -> Optional[Job]:
        return self.jobs.get(job_id)

    def approve(self, job_id: str) -> Job:
        job = self._require(job_id)
        if not job.requires_approval:
            raise ValueError("job does not require approval")
        job.approval_granted = True
        if job.state == JobState.WAITING_APPROVAL:
            job.state = JobState.QUEUED
        self._touch(job)
        return job

    def run(self, job_id: str, handler: Callable[[], Any]) -> Job:
        job = self._require(job_id)

        if job.requires_approval and not job.approval_granted:
            job.state = JobState.WAITING_APPROVAL
            self._touch(job)
            return job

        job.state = JobState.RUNNING
        job.error = None
        self._touch(job)

        try:
            job.result = handler()
            job.state = JobState.COMPLETED
            self._touch(job)
            return job
        except Exception as exc:
            job.error = str(exc)
            if job.retries < job.max_retries:
                job.retries += 1
                job.state = JobState.RETRY
            else:
                job.state = JobState.FAILED
            self._touch(job)
            return job

    def retry(self, job_id: str, handler: Callable[[], Any]) -> Job:
        job = self._require(job_id)
        if job.state not in {JobState.RETRY, JobState.FAILED}:
            raise ValueError("job is not retryable")
        if job.state == JobState.FAILED and job.retries >= job.max_retries:
            raise ValueError("maximum retries reached")
        return self.run(job_id, handler)

    def list(self, project_id: Optional[str] = None) -> List[Job]:
        values = list(self.jobs.values())
        if project_id is not None:
            values = [j for j in values if j.project_id == project_id]
        return values

    def _require(self, job_id: str) -> Job:
        job = self.get(job_id)
        if job is None:
            raise KeyError(f"job not found: {job_id}")
        return job

    @staticmethod
    def _touch(job: Job):
        job.updated_at = datetime.now(timezone.utc).isoformat()
