from dataclasses import dataclass
from enum import Enum

class AuthorityMode(str, Enum):
    NORMAL = "normal"
    AUTONOMY_MAX = "autonomy_max"

@dataclass
class AuthorityState:
    mode: AuthorityMode = AuthorityMode.NORMAL

    def grant_max_autonomy(self):
        self.mode = AuthorityMode.AUTONOMY_MAX

    def revoke_autonomy(self):
        self.mode = AuthorityMode.NORMAL

    @property
    def is_max_autonomy(self):
        return self.mode == AuthorityMode.AUTONOMY_MAX
