# Connector Core

Universal interface for external services.

Each connector has:
- identity
- provider
- connection state
- explicit permissions
- health
- capabilities
- authorization checks

Sensitive permissions:
- PUBLISH
- DELETE
- SPEND

Those actions require explicit approval even when the connector declares the
permission. This module does not pretend to connect to external services; real
providers will be added through concrete connector implementations.
