import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .sqlite_store import SQLiteStore


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class RepositoryError(ValueError):
    pass


class ProjectRepository:
    def __init__(self, store: SQLiteStore): self.store = store
    def create(self, project_id: str, owner_id: str, name: str) -> Dict[str, Any]:
        row = {"id": project_id, "owner_id": owner_id, "name": name, "created_at": now_iso()}
        self.store.execute("INSERT INTO projects(id, owner_id, name, created_at) VALUES (?, ?, ?, ?)", tuple(row.values()))
        return row
    def get(self, project_id: str, owner_id: Optional[str] = None):
        sql = "SELECT * FROM projects WHERE id = ?"; params = [project_id]
        if owner_id is not None: sql += " AND owner_id = ?"; params.append(owner_id)
        rows = self.store.query(sql, params); return rows[0] if rows else None
    def list(self, owner_id: str):
        return self.store.query("SELECT * FROM projects WHERE owner_id = ? ORDER BY created_at", (owner_id,))


class UserRepository:
    def __init__(self, store: SQLiteStore): self.store = store
    def create(self, user_id: str, username: str, password_hash: str, role: str = "user"):
        row = {"id": user_id, "username": username, "password_hash": password_hash, "role": role, "created_at": now_iso()}
        self.store.execute("INSERT INTO users(id, username, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)", tuple(row.values()))
        return {k:v for k,v in row.items() if k != "password_hash"}
    def get_by_username(self, username: str):
        rows = self.store.query("SELECT * FROM users WHERE username = ?", (username,)); return rows[0] if rows else None
    def get(self, user_id: str):
        rows = self.store.query("SELECT id, username, role, created_at FROM users WHERE id = ?", (user_id,)); return rows[0] if rows else None


class JobRepository:
    def __init__(self, store: SQLiteStore): self.store = store
    def save(self, job) -> Dict[str, Any]:
        self.store.execute("""INSERT INTO jobs(id, project_id, agent, stage, priority, state, retries, max_retries,
            requires_approval, approval_granted, error, result_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET state=excluded.state, retries=excluded.retries,
            approval_granted=excluded.approval_granted, error=excluded.error,
            result_json=excluded.result_json, updated_at=excluded.updated_at""",
            (job.id, job.project_id, job.agent, job.stage, job.priority.value, job.state.value,
             job.retries, job.max_retries, int(job.requires_approval), int(job.approval_granted),
             job.error, json.dumps(job.result, ensure_ascii=False, default=str) if job.result is not None else None,
             job.created_at, job.updated_at))
        return self.get(job.id)
    def get(self, job_id: str):
        rows = self.store.query("SELECT * FROM jobs WHERE id = ?", (job_id,)); return rows[0] if rows else None
    def get_for_project(self, job_id: str, project_id: str):
        rows = self.store.query("SELECT * FROM jobs WHERE id = ? AND project_id = ?", (job_id, project_id)); return rows[0] if rows else None
    def list(self, project_id: str): return self.store.query("SELECT * FROM jobs WHERE project_id = ? ORDER BY created_at", (project_id,))
    def list_all(self):
        return self.store.query("SELECT * FROM jobs ORDER BY created_at")
    def list_states(self, states):
        states = list(states)
        if not states: return []
        marks = ",".join("?" for _ in states)
        return self.store.query(f"SELECT * FROM jobs WHERE state IN ({marks}) ORDER BY created_at", states)
    def update_runtime(self, job_id: str, state: str, *, retries=None, error=None,
                       result=None, worker_id=None, lease_until=None, approval_granted=None):
        sets = ["state = ?", "updated_at = ?"]
        params = [state, now_iso()]
        if retries is not None: sets += ["retries = ?"]; params += [retries]
        if error is not None: sets += ["error = ?"]; params += [error]
        if result is not None:
            sets += ["result_json = ?"]
            params += [json.dumps(result, ensure_ascii=False, default=str)]
        if worker_id is not None: sets += ["worker_id = ?"]; params += [worker_id]
        if lease_until is not None: sets += ["lease_until = ?"]; params += [lease_until]
        if approval_granted is not None: sets += ["approval_granted = ?"]; params += [int(approval_granted)]
        params += [job_id]
        self.store.execute(f"UPDATE jobs SET {', '.join(sets)} WHERE id = ?", params)
        return self.get(job_id)
    def claim(self, job_id: str, worker_id: str, lease_until: float):
        self.store.execute(
            "UPDATE jobs SET state='RUNNING', worker_id=?, lease_until=?, error=NULL, updated_at=? "
            "WHERE id=? AND state IN ('QUEUED','RETRY')",
            (worker_id, lease_until, now_iso(), job_id))
        return self.get(job_id)


class ConnectorRepository:
    def __init__(self, store: SQLiteStore): self.store = store
    def save(self, connector):
        self.store.execute("""INSERT INTO connectors(id,name,provider,state,permissions_json,metadata_json,updated_at)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,provider=excluded.provider,
            state=excluded.state,permissions_json=excluded.permissions_json,metadata_json=excluded.metadata_json,updated_at=excluded.updated_at""",
            (connector.id, connector.name, connector.provider, connector.state.value,
             json.dumps(connector.capabilities()), json.dumps(connector.metadata, ensure_ascii=False, default=str), now_iso()))
        return self.get(connector.id)
    def _normalize(self, row):
        if not row: return None
        row["permissions"] = json.loads(row.pop("permissions_json"))
        row["metadata"] = json.loads(row.pop("metadata_json"))
        return row
    def get(self, connector_id):
        rows = self.store.query("SELECT * FROM connectors WHERE id = ?", (connector_id,)); return self._normalize(rows[0]) if rows else None
    def list(self): return [self._normalize(r) for r in self.store.query("SELECT * FROM connectors ORDER BY id")]


class ApprovalRepository:
    def __init__(self, store: SQLiteStore): self.store = store
    def record(self, job_id: str, decision: str, reason: Optional[str]):
        self.store.execute("INSERT INTO approvals(job_id,decision,reason,decided_at) VALUES (?,?,?,?)", (job_id, decision, reason, now_iso()))
    def history(self): return self.store.query("SELECT * FROM approvals ORDER BY id")


class AuditRepository:
    def __init__(self, store: SQLiteStore): self.store = store
    def record(self, actor_id: Optional[str], project_id: Optional[str], event: str, status: str, metadata: Optional[Dict[str, Any]] = None):
        self.store.execute("INSERT INTO audit_events(actor_id,project_id,event,status,metadata_json,created_at) VALUES (?,?,?,?,?,?)",
                           (actor_id, project_id, event, status, json.dumps(metadata or {}, ensure_ascii=False, default=str), now_iso()))
    def list(self, actor_id: Optional[str] = None, project_id: Optional[str] = None):
        sql = "SELECT * FROM audit_events"; clauses=[]; params=[]
        if actor_id is not None: clauses.append("actor_id = ?"); params.append(actor_id)
        if project_id is not None: clauses.append("project_id = ?"); params.append(project_id)
        if clauses: sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY id"
        return self.store.query(sql, params)
