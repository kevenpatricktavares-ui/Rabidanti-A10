import os, uuid
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field

from ..persistence import SQLiteStore, ProjectRepository, UserRepository, JobRepository, ConnectorRepository, ApprovalRepository, AuditRepository
from ..security import SessionManager, hash_password, verify_password
from ..jobs.job_manager import JobPriority
from ..jobs.persistent_execution import PersistentJobManager
from ..connectors.core import Connector, ConnectorPermission, ConnectorState


class AppState:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or os.getenv("RABIDANTI_DB", "rabidanti.db")
        self.store = SQLiteStore(self.db_path)
        self.users = UserRepository(self.store)
        self.projects = ProjectRepository(self.store)
        self.jobs = JobRepository(self.store)
        self.connectors = ConnectorRepository(self.store)
        self.approvals = ApprovalRepository(self.store)
        self.audit = AuditRepository(self.store)
        self.sessions = SessionManager(store=self.store)
        self.job_manager = PersistentJobManager(self.jobs)

    def audit_event(self, actor_id, project_id, event, status="OK", metadata=None):
        self.audit.record(actor_id, project_id, event, status, metadata)


state = AppState()
app = FastAPI(title="Rabidanti API", version="3.2.0")


class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=100)
    password: str = Field(min_length=8)

class LoginIn(BaseModel):
    username: str
    password: str

class ProjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)

class JobIn(BaseModel):
    agent: str
    stage: str
    priority: JobPriority = JobPriority.NORMAL
    max_retries: int = Field(default=3, ge=0, le=20)
    requires_approval: bool = False

class ConnectorIn(BaseModel):
    id: str
    name: str
    provider: str
    permissions: list[ConnectorPermission] = []
    metadata: dict = {}


def current_session(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="authentication required")
    session = state.sessions.validate(authorization[7:])
    if not session: raise HTTPException(status_code=401, detail="invalid or expired session")
    return session


def owned_project(project_id: str, session=Depends(current_session)):
    project = state.projects.get(project_id, session.user_id)
    if not project: raise HTTPException(status_code=404, detail="project not found")
    return project


@app.get("/health")
def health(): return {"status":"ok", "version":"3.2.0"}

@app.post("/auth/register", status_code=201)
def register(data: RegisterIn):
    if state.users.get_by_username(data.username): raise HTTPException(status_code=409, detail="username already exists")
    user = state.users.create(str(uuid.uuid4()), data.username, hash_password(data.password))
    state.audit_event(user["id"], None, "register")
    return user

@app.post("/auth/login")
def login(data: LoginIn):
    row = state.users.get_by_username(data.username)
    if not row or not verify_password(data.password, row["password_hash"]):
        if row: state.audit_event(row["id"], None, "login", "DENIED")
        raise HTTPException(status_code=401, detail="invalid credentials")
    session = state.sessions.create(row["id"])
    state.audit_event(row["id"], None, "login")
    return {"access_token": session.token, "token_type":"bearer", "expires_at":session.expires_at, "user_id":row["id"], "role":row["role"]}

@app.post("/auth/logout")
def logout(authorization: Optional[str] = Header(default=None), session=Depends(current_session)):
    token = authorization[7:]
    state.sessions.revoke(token); state.audit_event(session.user_id, None, "logout")
    return {"status":"logged_out"}

@app.get("/me")
def me(session=Depends(current_session)): return state.users.get(session.user_id)

@app.post("/projects", status_code=201)
def create_project(data: ProjectIn, session=Depends(current_session)):
    project = state.projects.create(str(uuid.uuid4()), session.user_id, data.name)
    state.audit_event(session.user_id, project["id"], "project_create")
    return project

@app.get("/projects")
def list_projects(session=Depends(current_session)): return state.projects.list(session.user_id)

@app.get("/projects/{project_id}")
def get_project(project=Depends(owned_project)): return project

@app.post("/projects/{project_id}/jobs", status_code=201)
def create_job(data: JobIn, project=Depends(owned_project), session=Depends(current_session)):
    job = state.job_manager.create(project["id"], data.agent, data.stage, data.priority, data.max_retries, data.requires_approval)
    row = state.jobs.save(job); state.audit_event(session.user_id, project["id"], "job_create", metadata={"job_id":job.id})
    return row

@app.get("/projects/{project_id}/jobs")
def list_jobs(project=Depends(owned_project)): return state.jobs.list(project["id"])

@app.get("/projects/{project_id}/jobs/{job_id}")
def get_job(job_id: str, project=Depends(owned_project)):
    row = state.jobs.get_for_project(job_id, project["id"])
    if not row: raise HTTPException(status_code=404, detail="job not found")
    return row

@app.post("/projects/{project_id}/jobs/{job_id}/approve")
def approve_job(job_id: str, project=Depends(owned_project), session=Depends(current_session)):
    row = state.jobs.get_for_project(job_id, project["id"])
    if not row: raise HTTPException(status_code=404, detail="job not found")
    if not row["requires_approval"]: raise HTTPException(status_code=400, detail="job does not require approval")
    if row["state"] != "WAITING_APPROVAL": raise HTTPException(status_code=400, detail="job is not waiting for approval")
    try:
        approved = state.job_manager.approve(job_id)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    if approved.project_id != project["id"]:
        raise HTTPException(status_code=404, detail="job not found")
    state.approvals.record(job_id, "APPROVED", None)
    state.audit_event(session.user_id, project["id"], "job_approve", metadata={"job_id":job_id})
    return state.jobs.get(job_id)

@app.post("/projects/{project_id}/jobs/{job_id}/reject")
def reject_job(job_id: str, project=Depends(owned_project), session=Depends(current_session)):
    row = state.jobs.get_for_project(job_id, project["id"])
    if not row: raise HTTPException(status_code=404, detail="job not found")
    if row["state"] != "WAITING_APPROVAL": raise HTTPException(status_code=400, detail="job is not waiting for approval")
    state.store.execute("UPDATE jobs SET state='FAILED', error='approval rejected', updated_at=datetime('now') WHERE id=? AND project_id=?", (job_id, project["id"]))
    state.approvals.record(job_id, "REJECTED", "approval rejected")
    state.audit_event(session.user_id, project["id"], "job_reject", metadata={"job_id":job_id})
    return state.jobs.get(job_id)

@app.post("/connectors", status_code=201)
def register_connector(data: ConnectorIn, session=Depends(current_session)):
    c = Connector(data.id, data.name, data.provider, data.permissions, ConnectorState.DISCONNECTED, data.metadata)
    row = state.connectors.save(c); state.audit_event(session.user_id, None, "connector_register", metadata={"connector_id":data.id})
    return row

@app.get("/connectors")
def list_connectors(session=Depends(current_session)): return state.connectors.list()

@app.get("/approvals/history")
def approval_history(session=Depends(current_session)): return state.approvals.history()

@app.get("/dashboard")
def dashboard(session=Depends(current_session)):
    projects = state.projects.list(session.user_id)
    jobs = []
    for project in projects: jobs.extend(state.jobs.list(project["id"]))
    return {"projects": projects, "jobs": jobs, "connectors": state.connectors.list(), "approval_history": state.approvals.history()}

@app.get("/audit")
def audit(session=Depends(current_session)):
    user = state.users.get(session.user_id)
    if not user or user["role"] != "admin": raise HTTPException(status_code=403, detail="admin role required")
    return state.audit.list()
