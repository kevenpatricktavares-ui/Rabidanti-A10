# Job & Execution Foundation

Jobs are operational tasks, distinct from agents and connectors.

States:
QUEUED -> RUNNING -> COMPLETED
                 -> RETRY -> RUNNING
                 -> FAILED
QUEUED -> WAITING_APPROVAL -> QUEUED

The current foundation provides deterministic in-process execution and retry
state transitions. Persistent queues, worker processes and distributed execution
will be added in the next infrastructure layer.

Sensitive/irreversible operations should set requires_approval=True.
