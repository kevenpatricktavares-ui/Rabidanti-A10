
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class ProductExperience:
    product_name: str
    product_type: str
    persona: Dict[str, Any] = field(default_factory=dict)
    character: Dict[str, Any] = field(default_factory=dict)
    audiovisual: Dict[str, Any] = field(default_factory=dict)
    interactive: Dict[str, Any] = field(default_factory=dict)
    experience_flow: List[str] = field(default_factory=list)
    consistency_rules: List[str] = field(default_factory=list)
    review_requirements: List[str] = field(default_factory=list)


class ProductExperienceIntegrator:
    """Connects specialized product modules into one coherent experience."""

    def build(
        self,
        product_name: str,
        product_type: str,
        persona: Dict[str, Any] | None = None,
        character: Dict[str, Any] | None = None,
        audiovisual: Dict[str, Any] | None = None,
        interactive: Dict[str, Any] | None = None,
    ) -> ProductExperience:
        persona = persona or {}
        character = character or {}
        audiovisual = audiovisual or {}
        interactive = interactive or {}

        flow = [
            "product_context",
            "persona_adaptation",
            "character_consistency",
            "content_or_interaction",
            "audiovisual_explanation",
            "quality_review",
            "human_approval",
        ]

        if interactive:
            flow.insert(4, "interactive_experience")

        return ProductExperience(
            product_name=product_name,
            product_type=product_type,
            persona=persona,
            character=character,
            audiovisual=audiovisual,
            interactive=interactive,
            experience_flow=flow,
            consistency_rules=[
                "Persona adaptation must not change factual product claims.",
                "Character identity must remain consistent across appearances.",
                "Audiovisual narration must match the approved product information.",
                "Interactive outputs must follow declared rules and validation.",
                "Market adaptation must not introduce stereotypes or discriminatory targeting.",
            ],
            review_requirements=[
                "Review factual claims and formulas.",
                "Review rights and required assets.",
                "Review synthetic identity disclosure when applicable.",
                "Require human approval before external publication.",
            ],
        )

    def validate(self, experience: ProductExperience) -> Dict[str, Any]:
        errors = []
        warnings = []

        if not experience.product_name.strip():
            errors.append("product_name is required")
        if not experience.product_type.strip():
            errors.append("product_type is required")

        if experience.character:
            if not experience.character.get("name"):
                errors.append("character integration requires a name")
            if experience.character.get("disclosure") is None:
                warnings.append("character disclosure should be explicitly defined")

        if experience.audiovisual:
            if not experience.audiovisual.get("scenes") and not experience.audiovisual.get("format"):
                warnings.append("audiovisual context lacks scenes or format metadata")

        if experience.interactive:
            if not experience.interactive.get("inputs"):
                warnings.append("interactive product has no declared inputs")
            if not experience.interactive.get("outputs"):
                warnings.append("interactive product has no declared outputs")

        if not experience.experience_flow:
            errors.append("experience_flow is required")

        return {
            "valid": not errors,
            "errors": errors,
            "warnings": warnings,
            "requires_human_review": True,
            "ready_for_external_publication": False,
        }
