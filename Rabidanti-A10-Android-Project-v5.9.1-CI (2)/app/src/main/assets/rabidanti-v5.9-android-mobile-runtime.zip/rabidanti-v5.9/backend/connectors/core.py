
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List


class ConnectorPermission(str, Enum):
    READ = "READ"
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    PUBLISH = "PUBLISH"
    DELETE = "DELETE"
    SPEND = "SPEND"


class ConnectorState(str, Enum):
    DISCONNECTED = "DISCONNECTED"
    CONNECTED = "CONNECTED"
    ERROR = "ERROR"


@dataclass
class Connector:
    id: str
    name: str
    provider: str
    permissions: List[ConnectorPermission] = field(default_factory=list)
    state: ConnectorState = ConnectorState.DISCONNECTED
    metadata: Dict[str, Any] = field(default_factory=dict)

    def connect(self) -> Dict[str, Any]:
        self.state = ConnectorState.CONNECTED
        return {"id": self.id, "status": self.state.value}

    def disconnect(self) -> Dict[str, Any]:
        self.state = ConnectorState.DISCONNECTED
        return {"id": self.id, "status": self.state.value}

    def health(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "provider": self.provider,
            "status": self.state.value,
            "healthy": self.state == ConnectorState.CONNECTED,
        }

    def capabilities(self) -> List[str]:
        return [p.value for p in self.permissions]

    def has_permission(self, permission: ConnectorPermission) -> bool:
        return permission in self.permissions

    def authorize(
        self,
        permission: ConnectorPermission,
        approval_granted: bool = False,
    ) -> Dict[str, Any]:
        if not self.has_permission(permission):
            return {
                "allowed": False,
                "reason": f"permission {permission.value} is not granted",
            }

        sensitive = {
            ConnectorPermission.PUBLISH,
            ConnectorPermission.DELETE,
            ConnectorPermission.SPEND,
        }
        if permission in sensitive and not approval_granted:
            return {
                "allowed": False,
                "reason": "explicit approval required for sensitive action",
            }

        if self.state != ConnectorState.CONNECTED:
            return {
                "allowed": False,
                "reason": "connector is not connected",
            }

        return {"allowed": True, "reason": "authorized"}


SENSITIVE_PERMISSIONS = {
    ConnectorPermission.PUBLISH,
    ConnectorPermission.DELETE,
    ConnectorPermission.SPEND,
}
