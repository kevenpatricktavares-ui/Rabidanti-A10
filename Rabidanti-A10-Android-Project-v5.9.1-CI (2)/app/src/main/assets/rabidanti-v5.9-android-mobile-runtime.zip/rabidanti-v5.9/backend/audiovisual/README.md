# Audiovisual Factory

Creates structured audiovisual production briefs for courses, promotional
videos, short-form content, product demos, audio lessons and narrated slides.

The factory currently prepares and validates production structure. It does not
pretend that an external video, voice or avatar provider has been connected.

Humanized output should prioritize natural pacing, conversational narration,
personality, examples and coherent character behavior.

Before publication: factual claims, rights/licenses, voice/music/visual assets,
character consistency and human approval must be checked.
