import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass
from typing import Optional
from datetime import datetime, timezone

from ..persistence.sqlite_store import SQLiteStore


class SecurityError(ValueError):
    pass


def hash_password(password: str, iterations: int = 310_000) -> str:
    if not isinstance(password, str) or len(password) < 8:
        raise SecurityError("password must contain at least 8 characters")
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_hex, digest_hex = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256": return False
        expected = bytes.fromhex(digest_hex)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(iterations))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError): return False


@dataclass(frozen=True)
class Session:
    token: str
    user_id: str
    expires_at: float


class SessionManager:
    def __init__(self, ttl_seconds: int = 3600, store: Optional[SQLiteStore] = None):
        if ttl_seconds <= 0: raise ValueError("ttl_seconds must be positive")
        self.ttl_seconds = ttl_seconds
        self.store = store
        self._sessions = {}

    def create(self, user_id: str) -> Session:
        token = secrets.token_urlsafe(32)
        expires = time.time() + self.ttl_seconds
        session = Session(token, user_id, expires)
        if self.store:
            self.store.execute("INSERT INTO sessions(token,user_id,expires_at,created_at,revoked_at) VALUES (?,?,?,?,NULL)",
                               (token,user_id,expires,datetime.now(timezone.utc).isoformat()))
        else: self._sessions[token] = session
        return session

    def validate(self, token: str) -> Optional[Session]:
        if self.store:
            rows = self.store.query("SELECT token,user_id,expires_at,revoked_at FROM sessions WHERE token = ?", (token,))
            if not rows or rows[0]["revoked_at"] is not None: return None
            if rows[0]["expires_at"] <= time.time():
                self.store.execute("DELETE FROM sessions WHERE token = ?", (token,)); return None
            return Session(token, rows[0]["user_id"], rows[0]["expires_at"])
        session = self._sessions.get(token)
        if session is None: return None
        if session.expires_at <= time.time(): self._sessions.pop(token, None); return None
        return session

    def revoke(self, token: str) -> bool:
        if self.store:
            result = self.store.query("SELECT token FROM sessions WHERE token = ? AND revoked_at IS NULL", (token,))
            if not result: return False
            self.store.execute("UPDATE sessions SET revoked_at = ? WHERE token = ?", (time.time(), token)); return True
        return self._sessions.pop(token, None) is not None
