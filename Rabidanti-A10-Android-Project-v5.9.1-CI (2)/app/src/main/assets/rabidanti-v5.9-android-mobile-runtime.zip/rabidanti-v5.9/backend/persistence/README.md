# Persistence

SQLiteStore is the v3.0 persistence foundation. It uses transactions, WAL mode and foreign-key enforcement.
