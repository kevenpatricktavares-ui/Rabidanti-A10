from dataclasses import dataclass
from backend.jobs.job_manager import JobPriority, JobState
from backend.jobs.persistent_execution import PersistentJobManager

@dataclass
class PersistentQueueResult:
    processed: int
    completed: int
    retried: int
    failed: int
    waiting_approval: int

class PersistentExecutionQueue:
    _priority_rank = {JobPriority.CRITICAL: 0, JobPriority.HIGH: 1, JobPriority.NORMAL: 2, JobPriority.LOW: 3}

    def __init__(self, manager: PersistentJobManager):
        self.manager = manager

    def pending(self):
        jobs = [j for j in self.manager.list() if j.state in {JobState.QUEUED, JobState.RETRY, JobState.WAITING_APPROVAL}]
        return sorted(jobs, key=lambda j: self._priority_rank[j.priority])

    def process_one(self, handlers, worker_id="worker"):
        jobs = self.pending()
        if not jobs: return None
        job = jobs[0]
        if job.state == JobState.WAITING_APPROVAL:
            return job
        handler = handlers.get(job.stage)
        if handler is None:
            self.manager.repository.update_runtime(
                job.id, JobState.FAILED.value,
                error=f"no handler registered for stage: {job.stage}",
                worker_id="", lease_until=0)
            return self.manager.get(job.id)
        return self.manager.run(job.id, handler, worker_id)

    def drain(self, handlers, worker_id="worker", max_cycles=100):
        processed = completed = retried = failed = waiting = 0
        for _ in range(max(0, max_cycles)):
            job = self.process_one(handlers, worker_id)
            if job is None: break
            processed += 1
            if job.state == JobState.COMPLETED: completed += 1
            elif job.state == JobState.RETRY: retried += 1
            elif job.state == JobState.FAILED: failed += 1
            elif job.state == JobState.WAITING_APPROVAL:
                waiting += 1
                break
        return PersistentQueueResult(processed, completed, retried, failed, waiting)

class PersistentWorker:
    def __init__(self, worker_id, queue):
        self.worker_id, self.queue, self.running = worker_id, queue, False
    def start_once(self, handlers):
        self.running = True
        try: return self.queue.process_one(handlers, self.worker_id)
        finally: self.running = False
