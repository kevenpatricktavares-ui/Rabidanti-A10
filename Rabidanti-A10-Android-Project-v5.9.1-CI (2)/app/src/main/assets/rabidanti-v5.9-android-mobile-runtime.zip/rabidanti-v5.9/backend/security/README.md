# Security

Provides password hashing/verification and expiring, revocable sessions. Higher-level authorization remains the responsibility of the application layer.
