
from dataclasses import dataclass, field
from typing import Any, Dict, List

SUPPORTED_TYPES = {
    "calculator",
    "simulator",
    "planner",
    "assessment",
    "document_generator",
    "dashboard",
    "educational_tool",
    "niche_web_tool",
}


@dataclass
class InteractiveProductBrief:
    title: str
    product_type: str
    audience: str
    problem: str
    objective: str
    inputs: List[Dict[str, Any]] = field(default_factory=list)
    outputs: List[Dict[str, Any]] = field(default_factory=list)
    rules: List[Dict[str, Any]] = field(default_factory=list)
    validation_rules: List[str] = field(default_factory=list)
    ux_flow: List[str] = field(default_factory=list)
    required_assets: List[str] = field(default_factory=list)
    audiovisual_hook: Dict[str, Any] = field(default_factory=dict)
    character_context: Dict[str, Any] = field(default_factory=dict)
    persona_context: Dict[str, Any] = field(default_factory=dict)
    compliance_notes: List[str] = field(default_factory=list)
    deployment_target: str = "web"


class InteractiveProductFactory:
    """Specification-first factory for interactive digital products."""

    def build(
        self, title, product_type, audience, problem, objective,
        inputs, outputs, rules, persona_context=None,
        character_context=None, audiovisual_hook=None,
        deployment_target="web"
    ):
        return InteractiveProductBrief(
            title=title.strip(),
            product_type=product_type,
            audience=audience.strip(),
            problem=problem.strip(),
            objective=objective.strip(),
            inputs=inputs,
            outputs=outputs,
            rules=rules,
            persona_context=persona_context or {},
            character_context=character_context or {},
            audiovisual_hook=audiovisual_hook or {},
            deployment_target=deployment_target,
            validation_rules=[
                "Validate inputs before calculation or transformation.",
                "Trace outputs to declared inputs and rules.",
                "Do not execute arbitrary code.",
                "Require appropriate human review for high-impact decisions.",
                "Review formulas, claims, rights, and assets before publication.",
            ],
            compliance_notes=[
                "Collect only necessary personal data.",
                "Never expose secrets or credentials in client-side logic.",
                "Do not present estimates as guaranteed outcomes.",
                "Require human approval before external publication when applicable.",
            ],
        )

    def validate(self, brief):
        errors, warnings = [], []

        required = {
            "title": brief.title,
            "audience": brief.audience,
            "problem": brief.problem,
            "objective": brief.objective,
        }
        errors += [f"{k} is required" for k, v in required.items() if not v]

        if brief.product_type not in SUPPORTED_TYPES:
            errors.append(f"unsupported product_type: {brief.product_type}")
        if not brief.inputs:
            errors.append("at least one input is required")
        if not brief.outputs:
            errors.append("at least one output is required")
        if not brief.rules:
            errors.append("at least one rule/formula/logic definition is required")

        for i, item in enumerate(brief.inputs):
            if not isinstance(item, dict) or not item.get("name"):
                errors.append(f"input[{i}] requires a name")
        for i, item in enumerate(brief.outputs):
            if not isinstance(item, dict) or not item.get("name"):
                errors.append(f"output[{i}] requires a name")
        for i, rule in enumerate(brief.rules):
            if not isinstance(rule, dict) or not rule.get("description"):
                errors.append(f"rule[{i}] requires a description")

        if brief.product_type in {"calculator", "simulator"}:
            if not any(
                isinstance(r, dict) and ("formula" in r or "calculation" in r)
                for r in brief.rules
            ):
                warnings.append(
                    "calculator/simulator should declare formula or calculation logic explicitly"
                )

        if brief.character_context and not brief.character_context.get("name"):
            warnings.append("character_context was supplied without a character name")
        if brief.persona_context and not brief.persona_context.get("market"):
            warnings.append("persona_context was supplied without a market")
        if not brief.audiovisual_hook:
            warnings.append("no audiovisual explanation hook supplied")

        return {
            "valid": not errors,
            "errors": errors,
            "warnings": warnings,
            "ready_for_external_publication": False,
            "requires_human_review": True,
        }
