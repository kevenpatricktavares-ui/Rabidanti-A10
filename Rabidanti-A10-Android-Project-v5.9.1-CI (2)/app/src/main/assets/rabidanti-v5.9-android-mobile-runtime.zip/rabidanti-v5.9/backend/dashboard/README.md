# Dashboard + Connection Center

v2.9 adds a read-only aggregation layer for the central Rabidanti control surface.

It exposes:
- job states and counts;
- pending approvals;
- connector state, health and declared capabilities;
- approval history;
- optional project scoping.

The dashboard does not invent external integrations and does not grant connector permissions. Approval changes the state of the approved job only; connector authorization remains governed by the connector's declared permissions and sensitive-action approval gate.
