# Queue + Workers

Priority-aware in-process execution queue and worker abstraction.

Flow:
Agent -> Job -> Queue -> Worker -> Handler -> Result

Approval-required jobs remain outside the executable queue until approved.
Retryable failures return to the queue while retry budget remains.
Missing handlers fail safely.
