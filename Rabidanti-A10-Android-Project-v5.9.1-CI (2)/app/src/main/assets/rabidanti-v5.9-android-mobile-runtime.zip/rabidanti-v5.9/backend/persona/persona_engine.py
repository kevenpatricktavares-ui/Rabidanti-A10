from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List

@dataclass
class Persona:
    name: str
    market: str
    language: str
    goals: List[str] = field(default_factory=list)
    needs: List[str] = field(default_factory=list)
    pain_points: List[str] = field(default_factory=list)
    objections: List[str] = field(default_factory=list)
    preferred_channels: List[str] = field(default_factory=list)
    preferred_formats: List[str] = field(default_factory=list)
    knowledge_level: str = "general"
    communication_style: str = "clear and conversational"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

class PersonaEngine:
    LEVELS = {"beginner", "intermediate", "advanced", "general"}

    def build(self, data: Dict[str, Any]) -> Persona:
        for field_name in ("name", "market", "language"):
            if not str(data.get(field_name, "")).strip():
                raise ValueError(f"{field_name} is required.")
        level = str(data.get("knowledge_level", "general")).lower().strip()
        if level not in self.LEVELS:
            raise ValueError("invalid knowledge_level")
        return Persona(
            name=str(data["name"]).strip(),
            market=str(data["market"]).strip(),
            language=str(data["language"]).strip(),
            goals=self._list(data.get("goals")),
            needs=self._list(data.get("needs")),
            pain_points=self._list(data.get("pain_points")),
            objections=self._list(data.get("objections")),
            preferred_channels=self._list(data.get("preferred_channels")),
            preferred_formats=self._list(data.get("preferred_formats")),
            knowledge_level=level,
            communication_style=str(data.get("communication_style", "clear and conversational")).strip(),
        )

    def adaptation_guide(self, persona: Persona) -> Dict[str, Any]:
        return {
            "market": persona.market,
            "language": persona.language,
            "product": {
                "goals": persona.goals,
                "needs": persona.needs,
                "pain_points": persona.pain_points,
                "preferred_formats": persona.preferred_formats,
            },
            "marketing": {
                "objections": persona.objections,
                "preferred_channels": persona.preferred_channels,
            },
            "safety": {
                "avoid_stereotypes": True,
                "no_discriminatory_targeting": True,
                "no_exploitation_of_vulnerabilities": True,
            },
        }

    @staticmethod
    def _list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            value = [value]
        return [str(x).strip() for x in value if str(x).strip()]
