from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

class EvolutionState(str, Enum):
    PROPOSED='PROPOSED'; EXPERIMENTING='EXPERIMENTING'; PROMOTION_PENDING='PROMOTION_PENDING'
    ACTIVATION_PENDING='ACTIVATION_PENDING'; ACTIVE='ACTIVE'; HEALTH_REVIEW='HEALTH_REVIEW'
    ROLLBACK_RECOMMENDED='ROLLBACK_RECOMMENDED'; ROLLED_BACK='ROLLED_BACK'; REJECTED='REJECTED'

_TRANSITIONS={
 EvolutionState.PROPOSED:{EvolutionState.EXPERIMENTING,EvolutionState.REJECTED},
 EvolutionState.EXPERIMENTING:{EvolutionState.PROMOTION_PENDING,EvolutionState.REJECTED},
 EvolutionState.PROMOTION_PENDING:{EvolutionState.ACTIVATION_PENDING,EvolutionState.REJECTED},
 EvolutionState.ACTIVATION_PENDING:{EvolutionState.ACTIVE,EvolutionState.REJECTED},
 EvolutionState.ACTIVE:{EvolutionState.HEALTH_REVIEW},
 EvolutionState.HEALTH_REVIEW:{EvolutionState.ROLLBACK_RECOMMENDED},
 EvolutionState.ROLLBACK_RECOMMENDED:{EvolutionState.ROLLED_BACK,EvolutionState.REJECTED},
 EvolutionState.ROLLED_BACK:set(), EvolutionState.REJECTED:set(),
}

@dataclass
class EvolutionRecord:
    evolution_id:str; strategy_key:str; state:EvolutionState=EvolutionState.PROPOSED
    experiment_id:Optional[str]=None; promotion_id:Optional[str]=None
    active_version:Optional[str]=None; previous_version:Optional[str]=None
    rollback_target:Optional[str]=None; health_status:Optional[str]=None
    history:List[dict]=field(default_factory=list)

class EvolutionController:
    def __init__(self): self._records:Dict[str,EvolutionRecord]={}
    def create(self,evolution_id,strategy_key):
        if not evolution_id or not strategy_key: raise ValueError('evolution_id and strategy_key are required')
        if evolution_id in self._records: raise ValueError('duplicate evolution_id')
        r=EvolutionRecord(evolution_id,strategy_key); self._record(r,'created'); self._records[evolution_id]=r; return r
    def get(self,evolution_id): return self._records[evolution_id]
    def list_records(self): return list(self._records.values())
    def _record(self,r,event): r.history.append({'state':r.state.value,'event':event})
    def _transition(self,r,target):
        if target not in _TRANSITIONS[r.state]: raise ValueError(f'invalid transition: {r.state} -> {target}')
        r.state=target; self._record(r,'transition')
    def start_experiment(self,evolution_id,experiment_id):
        if not experiment_id: raise ValueError('experiment_id is required')
        r=self.get(evolution_id)
        if r.experiment_id: raise ValueError('experiment already assigned')
        r.experiment_id=experiment_id; self._transition(r,EvolutionState.EXPERIMENTING); return r
    def mark_promotion_pending(self,evolution_id,promotion_id):
        if not promotion_id: raise ValueError('promotion_id is required')
        r=self.get(evolution_id); r.promotion_id=promotion_id; self._transition(r,EvolutionState.PROMOTION_PENDING); return r
    def request_activation(self,evolution_id):
        r=self.get(evolution_id); self._transition(r,EvolutionState.ACTIVATION_PENDING); return r
    def activate(self,evolution_id,new_version,approval=False):
        if not approval: raise PermissionError('explicit approval required for activation')
        if not new_version: raise ValueError('new_version is required')
        r=self.get(evolution_id)
        if r.state is not EvolutionState.ACTIVATION_PENDING: raise ValueError('activation requires ACTIVATION_PENDING')
        r.previous_version=r.active_version; r.active_version=new_version; self._transition(r,EvolutionState.ACTIVE); return r
    def begin_health_review(self,evolution_id,health_status):
        if not health_status: raise ValueError('health_status is required')
        r=self.get(evolution_id); r.health_status=health_status; self._transition(r,EvolutionState.HEALTH_REVIEW); return r
    def recommend_rollback(self,evolution_id,rollback_target):
        if not rollback_target: raise ValueError('rollback_target is required')
        r=self.get(evolution_id); r.rollback_target=rollback_target; self._transition(r,EvolutionState.ROLLBACK_RECOMMENDED); return r
    def apply_rollback(self,evolution_id,approval=False):
        if not approval: raise PermissionError('explicit approval required for rollback')
        r=self.get(evolution_id)
        if r.state is not EvolutionState.ROLLBACK_RECOMMENDED: raise ValueError('rollback requires ROLLBACK_RECOMMENDED')
        if not r.rollback_target: raise ValueError('rollback target is required')
        r.active_version=r.rollback_target; self._transition(r,EvolutionState.ROLLED_BACK); return r
    def reject(self,evolution_id):
        r=self.get(evolution_id); self._transition(r,EvolutionState.REJECTED); return r
