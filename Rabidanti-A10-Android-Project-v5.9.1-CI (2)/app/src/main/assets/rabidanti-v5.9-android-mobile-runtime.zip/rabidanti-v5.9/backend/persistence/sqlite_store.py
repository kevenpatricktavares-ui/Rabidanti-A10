import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterable, Optional


class SQLiteStore:
    """Small transactional persistence layer for Rabidanti runtime state."""

    def __init__(self, path: str = "rabidanti.db"):
        self.path = str(Path(path))
        self._initialize()

    def _connect(self):
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        return conn

    def _initialize(self):
        with self._connect() as conn:
            conn.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                expires_at REAL NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at REAL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL,
                name TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                agent TEXT NOT NULL,
                stage TEXT NOT NULL,
                priority TEXT NOT NULL,
                state TEXT NOT NULL,
                retries INTEGER NOT NULL,
                max_retries INTEGER NOT NULL,
                requires_approval INTEGER NOT NULL,
                approval_granted INTEGER NOT NULL,
                error TEXT,
                result_json TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_jobs_project ON jobs(project_id);
            CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state);
            CREATE TABLE IF NOT EXISTS connectors (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                provider TEXT NOT NULL,
                state TEXT NOT NULL,
                permissions_json TEXT NOT NULL,
                metadata_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL,
                decision TEXT NOT NULL,
                reason TEXT,
                decided_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor_id TEXT,
                project_id TEXT,
                event TEXT NOT NULL,
                status TEXT NOT NULL,
                metadata_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_audit_project ON audit_events(project_id);
            ''')
        with self._connect() as conn:
            cols = {row["name"] for row in conn.execute("PRAGMA table_info(jobs)").fetchall()}
            if "worker_id" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN worker_id TEXT")
            if "lease_until" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN lease_until REAL")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_lease ON jobs(lease_until)")

    def execute(self, sql: str, params: Iterable[Any] = ()) -> None:
        with self._connect() as conn:
            conn.execute(sql, tuple(params))

    def query(self, sql: str, params: Iterable[Any] = ()):
        with self._connect() as conn:
            return [dict(r) for r in conn.execute(sql, tuple(params)).fetchall()]

    def transaction(self, statements):
        with self._connect() as conn:
            for sql, params in statements:
                conn.execute(sql, tuple(params))

    @staticmethod
    def json(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)
