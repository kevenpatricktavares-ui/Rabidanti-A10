from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..jobs.job_manager import Job, JobManager, JobState


@dataclass
class ApprovalDecision:
    job_id: str
    decision: str
    reason: Optional[str] = None


class ApprovalCenter:
    """Centralizes approval decisions without granting connector permissions."""

    def __init__(self, job_manager: JobManager):
        self.job_manager = job_manager
        self.decisions: List[ApprovalDecision] = []

    def pending(self, project_id: Optional[str] = None) -> List[Job]:
        return [
            job for job in self.job_manager.list(project_id)
            if job.state == JobState.WAITING_APPROVAL
        ]

    def approve(self, job_id: str, reason: Optional[str] = None) -> Job:
        job = self.job_manager.approve(job_id)
        self.decisions.append(ApprovalDecision(job_id, "APPROVED", reason))
        return job

    def reject(self, job_id: str, reason: str = "approval rejected") -> Job:
        job = self.job_manager.get(job_id)
        if job is None:
            raise KeyError(f"job not found: {job_id}")
        if job.state != JobState.WAITING_APPROVAL:
            raise ValueError("job is not waiting for approval")
        job.state = JobState.FAILED
        job.error = reason
        JobManager._touch(job)
        self.decisions.append(ApprovalDecision(job_id, "REJECTED", reason))
        return job

    def history(self) -> List[Dict[str, Any]]:
        return [
            {"job_id": d.job_id, "decision": d.decision, "reason": d.reason}
            for d in self.decisions
        ]
