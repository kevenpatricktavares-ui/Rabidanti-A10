from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List

@dataclass
class Character:
    name: str
    role: str
    personality: List[str] = field(default_factory=list)
    values: List[str] = field(default_factory=list)
    background: str = ""
    specialization: List[str] = field(default_factory=list)
    voice_style: str = "natural and conversational"
    vocabulary: List[str] = field(default_factory=list)
    visual_direction: str = ""
    avatar_description: str = ""
    behavior_rules: List[str] = field(default_factory=list)
    product_knowledge: List[str] = field(default_factory=list)
    disclosure: str = "virtual character; not a real person"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

class CharacterEngine:
    ROLES = {
        "expert", "teacher", "presenter", "consultant",
        "demonstrator", "sales_communicator"
    }

    def build(self, data: Dict[str, Any]) -> Character:
        name = str(data.get("name", "")).strip()
        role = str(data.get("role", "")).strip().lower()

        if not name:
            raise ValueError("character name is required")
        if role not in self.ROLES:
            raise ValueError("invalid character role")

        return Character(
            name=name,
            role=role,
            personality=self._list(data.get("personality")),
            values=self._list(data.get("values")),
            background=str(data.get("background", "")).strip(),
            specialization=self._list(data.get("specialization")),
            voice_style=str(data.get("voice_style", "natural and conversational")).strip(),
            vocabulary=self._list(data.get("vocabulary")),
            visual_direction=str(data.get("visual_direction", "")).strip(),
            avatar_description=str(data.get("avatar_description", "")).strip(),
            behavior_rules=self._list(data.get("behavior_rules")),
            product_knowledge=self._list(data.get("product_knowledge")),
            disclosure=str(
                data.get("disclosure", "virtual character; not a real person")
            ).strip(),
        )

    def validate_consistency(self, character: Character) -> Dict[str, Any]:
        return {
            "identity_present": bool(character.name and character.role),
            "personality_defined": bool(character.personality),
            "specialization_defined": bool(character.specialization),
            "voice_defined": bool(character.voice_style),
            "visual_defined": bool(
                character.visual_direction or character.avatar_description
            ),
            "disclosure_present": bool(character.disclosure),
            "consistent_identity_required": True,
            "real_person_impersonation_allowed": False,
            "fabricated_credentials_allowed": False,
            "fabricated_testimonials_allowed": False,
        }

    @staticmethod
    def _list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            value = [value]
        return [str(x).strip() for x in value if str(x).strip()]
