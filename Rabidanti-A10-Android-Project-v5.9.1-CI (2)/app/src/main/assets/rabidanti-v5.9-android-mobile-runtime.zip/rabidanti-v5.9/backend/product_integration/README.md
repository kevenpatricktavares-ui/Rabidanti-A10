# Product Experience Integration

Unifies Persona, Character, Audiovisual and Interactive Product modules around a
single product experience.

This is an orchestration/consistency layer. It does not publish externally and
does not override approval or safety requirements.
