from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List

@dataclass
class Scene:
    number: int
    purpose: str
    visual_direction: str
    narration: str
    on_screen_text: str = ""
    duration_seconds: int = 10
    character_present: bool = False
    required_assets: List[str] = field(default_factory=list)

@dataclass
class AudiovisualBrief:
    title: str
    format: str
    audience: str
    objective: str
    tone: str
    language: str
    character_name: str = ""
    scenes: List[Scene] = field(default_factory=list)
    audio_direction: str = "natural narration with clear pacing"
    editing_direction: str = "dynamic but readable"
    review_requirements: List[str] = field(default_factory=list)
    export_targets: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

class AudiovisualFactory:
    FORMATS = {
        "course_lesson",
        "promo_video",
        "short_form",
        "product_demo",
        "audio_lesson",
        "narrated_slides",
    }

    def build(self, data: Dict[str, Any]) -> AudiovisualBrief:
        title = str(data.get("title", "")).strip()
        fmt = str(data.get("format", "")).strip().lower()
        audience = str(data.get("audience", "")).strip()
        objective = str(data.get("objective", "")).strip()
        language = str(data.get("language", "")).strip()

        if not title or not audience or not objective or not language:
            raise ValueError("title, audience, objective and language are required")
        if fmt not in self.FORMATS:
            raise ValueError("invalid audiovisual format")

        raw_scenes = data.get("scenes", [])
        scenes = []
        for i, raw in enumerate(raw_scenes, 1):
            scenes.append(Scene(
                number=i,
                purpose=str(raw.get("purpose", "")).strip(),
                visual_direction=str(raw.get("visual_direction", "")).strip(),
                narration=str(raw.get("narration", "")).strip(),
                on_screen_text=str(raw.get("on_screen_text", "")).strip(),
                duration_seconds=max(1, int(raw.get("duration_seconds", 10))),
                character_present=bool(raw.get("character_present", False)),
                required_assets=self._list(raw.get("required_assets")),
            ))

        return AudiovisualBrief(
            title=title,
            format=fmt,
            audience=audience,
            objective=objective,
            tone=str(data.get("tone", "natural and humanized")).strip(),
            language=language,
            character_name=str(data.get("character_name", "")).strip(),
            scenes=scenes,
            audio_direction=str(
                data.get("audio_direction", "natural narration with clear pacing")
            ).strip(),
            editing_direction=str(
                data.get("editing_direction", "dynamic but readable")
            ).strip(),
            review_requirements=self._list(data.get("review_requirements")) or [
                "fact and claim review",
                "rights and licenses review",
                "voice/music/visual asset review",
                "character consistency review",
                "human approval before publication",
            ],
            export_targets=self._list(data.get("export_targets")),
        )

    def validate(self, brief: AudiovisualBrief) -> Dict[str, Any]:
        total_duration = sum(scene.duration_seconds for scene in brief.scenes)
        return {
            "has_scenes": bool(brief.scenes),
            "has_narration": all(bool(s.narration) for s in brief.scenes) if brief.scenes else False,
            "humanized_audio_direction": bool(brief.audio_direction),
            "character_consistency_required": bool(brief.character_name),
            "rights_review_required": True,
            "fact_review_required": True,
            "human_approval_required": True,
            "total_duration_seconds": total_duration,
            "ready_for_external_publication": False,
        }

    @staticmethod
    def _list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            value = [value]
        return [str(x).strip() for x in value if str(x).strip()]
