# Character Engine

Creates persistent virtual characters for educational, presentation,
demonstration and legitimate sales communication.

A character has identity, personality, values, background, specialization,
voice style, vocabulary, visual direction, behavior rules and product knowledge.

Characters must not impersonate real people without authorization, fabricate
credentials or testimonials, or misrepresent a synthetic character as a real person.
