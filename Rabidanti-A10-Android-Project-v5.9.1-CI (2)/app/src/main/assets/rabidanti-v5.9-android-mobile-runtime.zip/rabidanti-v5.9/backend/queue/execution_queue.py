
from dataclasses import dataclass
from typing import Callable, List, Optional
from backend.jobs import Job, JobManager, JobPriority, JobState


@dataclass
class QueueResult:
    processed: int
    completed: int
    retried: int
    failed: int
    waiting_approval: int


class ExecutionQueue:
    _priority_rank = {
        JobPriority.CRITICAL: 0, JobPriority.HIGH: 1,
        JobPriority.NORMAL: 2, JobPriority.LOW: 3,
    }

    def __init__(self, manager: Optional[JobManager] = None):
        self.manager = manager or JobManager()
        self._queued: List[str] = []

    def enqueue(self, job: Job) -> Job:
        if job.state == JobState.WAITING_APPROVAL:
            return job
        if job.id not in self._queued:
            self._queued.append(job.id)
        return job

    def pending(self) -> List[Job]:
        jobs = []
        for job_id in self._queued:
            job = self.manager.get(job_id)
            if job is not None and job.state in {JobState.QUEUED, JobState.RETRY}:
                jobs.append(job)
        return sorted(jobs, key=lambda j: self._priority_rank[j.priority])

    def approve_and_enqueue(self, job_id: str) -> Job:
        return self.enqueue(self.manager.approve(job_id))

    def process_one(self, handlers: dict[str, Callable[[], object]]) -> Optional[Job]:
        pending = self.pending()
        if not pending:
            return None
        job = pending[0]
        handler = handlers.get(job.stage)
        if handler is None:
            job.state = JobState.FAILED
            job.error = f"no handler registered for stage: {job.stage}"
            if job.id in self._queued:
                self._queued.remove(job.id)
            return job

        result = self.manager.run(job.id, handler)
        if result.state in {JobState.COMPLETED, JobState.FAILED}:
            if result.id in self._queued:
                self._queued.remove(result.id)
        elif result.state == JobState.RETRY:
            if result.id in self._queued:
                self._queued.remove(result.id)
            self._queued.append(result.id)
        return result

    def drain(self, handlers: dict[str, Callable[[], object]], max_cycles: int = 100) -> QueueResult:
        processed = completed = retried = failed = waiting = 0
        for _ in range(max(0, max_cycles)):
            job = self.process_one(handlers)
            if job is None:
                break
            processed += 1
            if job.state == JobState.COMPLETED: completed += 1
            elif job.state == JobState.RETRY: retried += 1
            elif job.state == JobState.FAILED: failed += 1
            elif job.state == JobState.WAITING_APPROVAL: waiting += 1
        return QueueResult(processed, completed, retried, failed, waiting)


class Worker:
    def __init__(self, worker_id: str, queue: ExecutionQueue):
        self.worker_id = worker_id
        self.queue = queue
        self.running = False

    def start_once(self, handlers):
        self.running = True
        try:
            return self.queue.process_one(handlers)
        finally:
            self.running = False
