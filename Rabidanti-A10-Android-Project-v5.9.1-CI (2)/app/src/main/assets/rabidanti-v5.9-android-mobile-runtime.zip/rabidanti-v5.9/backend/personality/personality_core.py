from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import List, Dict

def now():
    return datetime.now(timezone.utc).isoformat()

@dataclass
class Belief:
    topic: str
    statement: str
    confidence: float
    evidence: List[str] = field(default_factory=list)
    status: str = "provisional"
    updated_at: str = field(default_factory=now)

@dataclass
class PersonalityMemory:
    identity_notes: List[str] = field(default_factory=list)
    interests: List[str] = field(default_factory=list)
    principles: List[str] = field(default_factory=list)
    experiences: List[str] = field(default_factory=list)
    relationship_notes: List[str] = field(default_factory=list)
    beliefs: List[Belief] = field(default_factory=list)
    questions: List[str] = field(default_factory=list)

class PersonalityCore:
    """Private personality-development memory, separate from business data."""

    def __init__(self, memory=None):
        self.memory = memory or PersonalityMemory()

    def add_interest(self, value: str):
        value = value.strip()
        if value and value not in self.memory.interests:
            self.memory.interests.append(value)

    def add_experience(self, value: str):
        value = value.strip()
        if value:
            self.memory.experiences.append(value)

    def add_principle(self, value: str):
        value = value.strip()
        if value and value not in self.memory.principles:
            self.memory.principles.append(value)

    def add_question(self, value: str):
        value = value.strip()
        if value:
            self.memory.questions.append(value)

    def update_belief(self, topic, statement, confidence, evidence=None, status="provisional"):
        belief = Belief(
            topic=topic.strip(),
            statement=statement.strip(),
            confidence=max(0.0, min(1.0, float(confidence))),
            evidence=list(evidence or []),
            status=status,
        )
        self.memory.beliefs.append(belief)
        return belief

    def snapshot(self) -> Dict:
        return asdict(self.memory)
