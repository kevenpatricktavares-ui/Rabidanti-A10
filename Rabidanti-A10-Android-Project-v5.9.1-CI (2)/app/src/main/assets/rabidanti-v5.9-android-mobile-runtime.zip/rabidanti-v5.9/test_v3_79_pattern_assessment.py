from evolution_pattern_memory import EvolutionPatternMemory
from evolution_pattern_assessment import EvolutionPatternAssessment

def trend(values,cid="c"):
    m=EvolutionPatternMemory()
    for i,v in enumerate(values):
        m.record(str(i),cid,v,f"2026-01-{i+1:02d}T00:00:00+00:00")
    return m.trend(cid)

def test_strong():
    x=EvolutionPatternAssessment().assess(trend([.8,.85,.9,.95,.98]))
    assert x.status=="STRONG_EVIDENCE" and x.evidence_score>=.75

def test_moderate():
    x=EvolutionPatternAssessment().assess(trend([.65,.66,.65,.66]))
    assert x.status=="MODERATE_EVIDENCE"

def test_weak():
    x=EvolutionPatternAssessment().assess(trend([.7,.5]))
    assert x.status=="WEAK_EVIDENCE"

def test_insufficient():
    x=EvolutionPatternAssessment(3).assess(trend([.9]))
    assert x.status=="INSUFFICIENT_HISTORY" and x.evidence_score==0

def test_unknown_safe():
    a=EvolutionPatternAssessment()
    class T:
        correlation_id="x"; observations=3
        average_strength=.7; latest_strength=.7; trend="UNKNOWN"
    x=a.assess(T())
    assert x.status=="WEAK_EVIDENCE" and x.evidence_score==0

def test_no_authority():
    a=EvolutionPatternAssessment()
    assert not hasattr(a,"activate") and not hasattr(a,"deploy") and not hasattr(a,"apply")

def test_invalid():
    try: EvolutionPatternAssessment(0); assert False
    except ValueError: pass
    try: EvolutionPatternAssessment().assess(None); assert False
    except ValueError: pass
