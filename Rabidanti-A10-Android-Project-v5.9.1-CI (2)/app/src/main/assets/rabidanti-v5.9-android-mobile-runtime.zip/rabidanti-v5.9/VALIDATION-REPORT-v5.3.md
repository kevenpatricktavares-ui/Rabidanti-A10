# Validation Report — Rabidanti v5.3

## Baseline

Entrada: Rabidanti v5.2.0, SHA-256 `aa61ce827053ac3dee1f27a4a1c8bf88fe1ee610b2e8875c541622e35228a84f`.

Baseline previamente validada: 650 testes aprovados.

## Alterações v5.3

- `rabidanti_recovery.py`: backups, restore, crash recovery, heartbeat, update staging e state schema migration.
- `rabidanti_launcher.py`: RecoverySession no lifecycle desktop.
- `rabidanti.py`: comandos product de backup/recovery/update/migration.
- VERSION e metadata Windows atualizados para 5.3.0.
- 14 testes específicos novos.

## Resultado de desenvolvimento

- v4/v5: 170 passed
- v3: 157 passed
- históricos `tests/`: 337 passed
- total: 664 passed / 0 failed

## Limitações

- Nenhum update é aplicado automaticamente.
- Nenhum download remoto de update é realizado.
- Executável/instalador Windows ainda não foram construídos neste ambiente.
- Heartbeat mede liveness local, mas não faz restart automático.
- Restore é overlay e não remove ficheiros adicionais.
