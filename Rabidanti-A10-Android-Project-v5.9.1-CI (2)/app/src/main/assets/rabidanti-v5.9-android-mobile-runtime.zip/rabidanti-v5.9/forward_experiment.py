from __future__ import annotations
import hashlib, sqlite3, time
from dataclasses import dataclass, asdict
from enum import Enum

class ExperimentState(str, Enum):
    PROPOSED="PROPOSED"; RUNNING="RUNNING"; COMPLETED="COMPLETED"; PROMOTION_PENDING="PROMOTION_PENDING"; APPROVED="APPROVED"; REJECTED="REJECTED"
class Arm(str, Enum): CONTROL="CONTROL"; TREATMENT="TREATMENT"

@dataclass(frozen=True)
class ForwardExperiment:
    experiment_id:str; factor:str; baseline_weight:float; proposed_weight:float; allocation:float=.5; state:ExperimentState=ExperimentState.PROPOSED; created_at:float=0.0; updated_at:float=0.0
    def validate(self):
        if not str(self.experiment_id).strip(): raise ValueError("experiment_id is required")
        if not str(self.factor).strip(): raise ValueError("factor is required")
        if any(not -1<=float(v)<=1 for v in (self.baseline_weight,self.proposed_weight)): raise ValueError("weights must be between -1 and 1")
        if not 0<float(self.allocation)<1: raise ValueError("allocation must be between 0 and 1")

@dataclass(frozen=True)
class ExperimentAssignment:
    experiment_id:str; candidate_id:str; arm:Arm; assigned_at:float
    def to_dict(self):
        d=asdict(self); d["arm"]=self.arm.value; return d
@dataclass(frozen=True)
class ExperimentObservation:
    experiment_id:str; candidate_id:str; arm:Arm; outcome:str; recorded_at:float
@dataclass(frozen=True)
class ForwardExperimentEvaluation:
    experiment_id:str; control_count:int; treatment_count:int; control_completion_rate:float|None; treatment_completion_rate:float|None; completion_rate_delta:float|None; recommendation:str; rationale:str
    def to_dict(self): return asdict(self)

class ForwardExperimentStore:
    def __init__(self, db_path=":memory:"):
        self.conn=sqlite3.connect(db_path,check_same_thread=False); self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("CREATE TABLE IF NOT EXISTS experiments (experiment_id TEXT PRIMARY KEY,factor TEXT NOT NULL,baseline_weight REAL NOT NULL,proposed_weight REAL NOT NULL,allocation REAL NOT NULL,state TEXT NOT NULL,created_at REAL NOT NULL,updated_at REAL NOT NULL)")
        self.conn.execute("CREATE TABLE IF NOT EXISTS experiment_assignments (experiment_id TEXT NOT NULL,candidate_id TEXT NOT NULL,arm TEXT NOT NULL,assigned_at REAL NOT NULL,PRIMARY KEY(experiment_id,candidate_id))")
        self.conn.execute("CREATE TABLE IF NOT EXISTS experiment_observations (experiment_id TEXT NOT NULL,candidate_id TEXT NOT NULL,arm TEXT NOT NULL,outcome TEXT NOT NULL,recorded_at REAL NOT NULL,PRIMARY KEY(experiment_id,candidate_id))"); self.conn.commit()
    def create(self,e):
        e.validate(); now=float(e.created_at or time.time()); upd=float(e.updated_at or now)
        self.conn.execute("INSERT INTO experiments VALUES (?,?,?,?,?,?,?,?)",(e.experiment_id,e.factor,e.baseline_weight,e.proposed_weight,e.allocation,e.state.value,now,upd)); self.conn.commit()
    def get(self,eid):
        r=self.conn.execute("SELECT experiment_id,factor,baseline_weight,proposed_weight,allocation,state,created_at,updated_at FROM experiments WHERE experiment_id=?",(eid,)).fetchone()
        if r is None: raise KeyError(eid)
        return ForwardExperiment(r[0],r[1],r[2],r[3],r[4],ExperimentState(r[5]),r[6],r[7])
    def transition(self,eid,state):
        cur=self.get(eid); allowed={ExperimentState.PROPOSED:{ExperimentState.RUNNING,ExperimentState.REJECTED},ExperimentState.RUNNING:{ExperimentState.COMPLETED,ExperimentState.REJECTED},ExperimentState.COMPLETED:{ExperimentState.PROMOTION_PENDING,ExperimentState.REJECTED},ExperimentState.PROMOTION_PENDING:{ExperimentState.APPROVED,ExperimentState.REJECTED},ExperimentState.APPROVED:set(),ExperimentState.REJECTED:set()}
        if state not in allowed[cur.state]: raise ValueError(f"invalid transition {cur.state.value}->{state.value}")
        self.conn.execute("UPDATE experiments SET state=?,updated_at=? WHERE experiment_id=?",(state.value,time.time(),eid)); self.conn.commit(); return self.get(eid)
    def save_assignment(self,a):
        self.conn.execute("INSERT OR IGNORE INTO experiment_assignments VALUES (?,?,?,?)",(a.experiment_id,a.candidate_id,a.arm.value,a.assigned_at)); self.conn.commit()
    def assignment(self,eid,cid):
        r=self.conn.execute("SELECT experiment_id,candidate_id,arm,assigned_at FROM experiment_assignments WHERE experiment_id=? AND candidate_id=?",(eid,cid)).fetchone(); return None if r is None else ExperimentAssignment(r[0],r[1],Arm(r[2]),r[3])
    def record(self,o):
        if o.outcome.upper() not in {"COMPLETED","FAILED","CANCELLED"}: raise ValueError("outcome must be COMPLETED, FAILED, or CANCELLED")
        a=self.assignment(o.experiment_id,o.candidate_id)
        if a is None: raise ValueError("candidate has no experiment assignment")
        if a.arm!=o.arm: raise ValueError("observation arm does not match assignment")
        self.conn.execute("INSERT INTO experiment_observations VALUES (?,?,?,?,?)",(o.experiment_id,o.candidate_id,o.arm.value,o.outcome.upper(),o.recorded_at or time.time())); self.conn.commit()
    def observations(self,eid):
        rows=self.conn.execute("SELECT experiment_id,candidate_id,arm,outcome,recorded_at FROM experiment_observations WHERE experiment_id=? ORDER BY recorded_at,candidate_id",(eid,)).fetchall(); return [ExperimentObservation(r[0],r[1],Arm(r[2]),r[3],r[4]) for r in rows]

class ForwardExperimentEngine:
    MIN_ARM=3; MIN_DELTA=.05
    def __init__(self,store): self.store=store
    def start(self,eid): return self.store.transition(eid,ExperimentState.RUNNING)
    def assign(self,eid,cid,now=None):
        e=self.store.get(eid)
        if e.state!=ExperimentState.RUNNING: raise ValueError("experiment must be RUNNING to assign work")
        if not str(cid).strip(): raise ValueError("candidate_id is required")
        old=self.store.assignment(eid,cid)
        if old: return old
        h=hashlib.sha256(f"{eid}:{cid}".encode()).hexdigest(); bucket=int(h[:16],16)/(16**16); arm=Arm.TREATMENT if bucket<e.allocation else Arm.CONTROL
        a=ExperimentAssignment(eid,cid,arm,float(now or time.time())); self.store.save_assignment(a); return a
    def record(self,eid,cid,outcome,now=None):
        a=self.store.assignment(eid,cid)
        if a is None: raise ValueError("candidate has no experiment assignment")
        o=ExperimentObservation(eid,cid,a.arm,str(outcome).upper(),float(now or time.time())); self.store.record(o); return o
    def evaluate(self,eid):
        groups={Arm.CONTROL:[],Arm.TREATMENT:[]}
        for o in self.store.observations(eid):
            if o.outcome in {"COMPLETED","FAILED"}: groups[o.arm].append(o)
        c,t=groups[Arm.CONTROL],groups[Arm.TREATMENT]; cc,tc=len(c),len(t)
        if cc<self.MIN_ARM or tc<self.MIN_ARM: return ForwardExperimentEvaluation(eid,cc,tc,None,None,None,"INSUFFICIENT_EVIDENCE","Each arm needs at least three decisive outcomes before comparison.")
        cr=sum(o.outcome=="COMPLETED" for o in c)/cc; tr=sum(o.outcome=="COMPLETED" for o in t)/tc; d=round(tr-cr,6)
        rec="PROMISING_TREATMENT" if d>=self.MIN_DELTA else "REJECT_TREATMENT" if d<=-self.MIN_DELTA else "NO_CLEAR_DIFFERENCE"
        return ForwardExperimentEvaluation(eid,cc,tc,round(cr,6),round(tr,6),d,rec,"Forward comparison is descriptive evidence only; it does not establish causality or authorize a production change.")
    def complete_for_review(self,eid):
        if self.store.get(eid).state!=ExperimentState.RUNNING: raise ValueError("experiment must be RUNNING")
        ev=self.evaluate(eid); self.store.transition(eid,ExperimentState.COMPLETED)
        if ev.recommendation=="PROMISING_TREATMENT": self.store.transition(eid,ExperimentState.PROMOTION_PENDING)
        return ev
    def approve(self,eid):
        if self.store.get(eid).state!=ExperimentState.PROMOTION_PENDING: raise ValueError("only promotion-pending experiments can be approved")
        return self.store.transition(eid,ExperimentState.APPROVED)
