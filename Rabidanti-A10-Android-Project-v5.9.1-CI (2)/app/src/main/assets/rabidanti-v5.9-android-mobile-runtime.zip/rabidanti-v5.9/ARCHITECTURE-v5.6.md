# Rabidanti v5.6 — Windows Release Handoff & Reproducible Build Pack

## Purpose
v5.6 turns the validated source release into a controlled handoff package for the first real Windows-native build. It does not claim that a Windows executable has already been built.

## Additions
- `windows-toolchain.json`: explicit Windows x64 build contract.
- `windows_handoff.py`: cross-platform source/handoff and Windows toolchain inspection.
- `prepare_windows_build.ps1`: prepares an isolated Windows build environment and emits `windows-build-handoff.json`.
- `BUILD-WINDOWS-RELEASE.cmd`: one-command Windows path from source to validated release evidence.
- `WINDOWS-BUILD-HANDOFF.md`: concise native build operator guide.
- release preflight expanded to 25 checks.
- GitHub Windows workflow now runs the reproducible preparation step before native build.

## Trust boundary
`windows-build-handoff.json` is environment readiness evidence only. It is not native release evidence.
A release is native-validated only when the Windows pipeline produces both `release-manifest.json` and `windows-release-validation.json`, and `native_release_check.py` passes against the built artifacts.
