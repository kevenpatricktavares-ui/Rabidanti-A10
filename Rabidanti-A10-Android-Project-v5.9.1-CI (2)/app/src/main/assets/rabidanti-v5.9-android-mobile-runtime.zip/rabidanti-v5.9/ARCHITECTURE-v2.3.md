# Rabidanti v2.3 — Audiovisual Factory Foundation

Pipeline target:

Product Brief
→ Audiovisual Brief
→ scenes/storyboard
→ character/voice direction
→ visual/audio assets
→ render
→ review
→ approval
→ export/distribution

This version implements the production specification and validation layer.
It does not claim an external voice, avatar, image or video generation service
is connected.

Humanized audiovisual requirements:
- natural narration and pacing;
- coherent personality;
- examples and storytelling where appropriate;
- dynamic but readable editing;
- cultural/language adaptation;
- consistent character identity.

Commercial and factual safeguards remain mandatory.
