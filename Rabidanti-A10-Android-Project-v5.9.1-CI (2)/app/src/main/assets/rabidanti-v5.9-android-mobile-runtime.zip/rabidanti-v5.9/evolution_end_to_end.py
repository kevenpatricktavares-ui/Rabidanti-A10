"""v3.83 controlled end-to-end evolution orchestration."""
from dataclasses import dataclass
from backend.evolution_controller import EvolutionController, EvolutionState, EvolutionRecord
from evolution_evidence_runtime import EvolutionEvidenceRuntime
from evolution_evidence_fusion import EvidenceFusion

@dataclass(frozen=True)
class EvolutionCycleResult:
    evolution_id: str
    proposal_id: str
    decision: str
    score: float
    controller_state: str
    approval_required: bool
    event_id: str

class EndToEndEvolutionCycle:
    """Connects durable evidence decisions to the authoritative controller.

    This class orchestrates; it does not bypass the controller, activate without
    explicit approval, deploy, publish, spend, or mutate Core configuration.
    """
    def __init__(self, evidence_runtime: EvolutionEvidenceRuntime, controller=None):
        if evidence_runtime is None:
            raise ValueError("evidence_runtime is required")
        self.evidence_runtime = evidence_runtime
        self.controller = controller or EvolutionController()

    def evaluate_and_register(self, *, evolution_id, proposal_id, strategy_key,
                              fusion: EvidenceFusion, reversibility, risk, cost,
                              event_id):
        if not evolution_id or not evolution_id.strip():
            raise ValueError("evolution_id is required")
        if not strategy_key or not strategy_key.strip():
            raise ValueError("strategy_key is required")
        result = self.evidence_runtime.evaluate(
            proposal_id, fusion, reversibility=reversibility, risk=risk,
            cost=cost, event_id=event_id)
        record = self.controller.create(evolution_id, strategy_key)
        if result.decision == "REJECT":
            record = self.controller.reject(evolution_id)
        return EvolutionCycleResult(
            evolution_id, proposal_id, result.decision, result.score,
            record.state.value, result.approval_required, event_id)

    def start_experiment(self, evolution_id, experiment_id):
        return self.controller.start_experiment(evolution_id, experiment_id)

    def promote(self, evolution_id, promotion_id):
        return self.controller.mark_promotion_pending(evolution_id, promotion_id)

    def request_activation(self, evolution_id):
        return self.controller.request_activation(evolution_id)

    def approve_activation(self, evolution_id, new_version):
        return self.controller.activate(evolution_id, new_version, approval=True)

    def health_review(self, evolution_id, health_status):
        return self.controller.begin_health_review(evolution_id, health_status)

    def recommend_rollback(self, evolution_id, rollback_target):
        return self.controller.recommend_rollback(evolution_id, rollback_target)

    def approve_rollback(self, evolution_id):
        return self.controller.apply_rollback(evolution_id, approval=True)

    def reject(self, evolution_id):
        return self.controller.reject(evolution_id)
