# Rabidanti v3.43 — Analytics → Learning Integration

Analytics observations now feed the Learning Engine through the durable stage artifact store.

Flow: Ads → Analytics → Learning.

Learning produces explicit observations, hypotheses, experiment proposals, learnings and next actions. Missing data produces WAITING_FOR_DATA. It never invents measurements or treats hypotheses as causal facts.

This release does not publish ads, spend money, or claim live platform data without a verified connector.
