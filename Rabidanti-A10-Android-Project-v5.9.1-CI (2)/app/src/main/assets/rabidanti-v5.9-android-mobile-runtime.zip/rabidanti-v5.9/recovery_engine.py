"""Rabidanti v3.18 — conservative health-driven recovery."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional
import time

from durable_worker_queue import DurableWorkerQueue
from worker_supervisor import WorkerSupervisor, WorkerStatus
from observability import ObservabilityStore
from health_monitor import HealthMonitor, HealthReport


@dataclass(frozen=True)
class RecoveryAction:
    kind: str
    target: str
    status: str
    message: str
    timestamp: float
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RecoveryReport:
    before: HealthReport
    actions: list[RecoveryAction]
    after: HealthReport


class RecoveryEngine:
    """Apply only bounded, reversible recovery actions.

    It never retries arbitrary application logic directly. Queue lease recovery
    remains the source of truth for abandoned work; stale idle workers may be
    reactivated because they have no active work.
    """

    def __init__(self, queue: DurableWorkerQueue, monitor: HealthMonitor,
                 supervisor: Optional[WorkerSupervisor] = None,
                 observability: Optional[ObservabilityStore] = None):
        self.queue = queue
        self.monitor = monitor
        self.supervisor = supervisor or monitor.supervisor
        self.observability = observability or monitor.observability

    def recover(self, now: Optional[float] = None) -> RecoveryReport:
        now = time.time() if now is None else float(now)
        before = self.monitor.analyze(now=now)
        actions: list[RecoveryAction] = []

        # Recover abandoned queue work through its durable lease mechanism.
        recovered = self.queue.recover_expired()
        for item_id in recovered:
            action = RecoveryAction(
                "QUEUE_LEASE_RECOVERY", item_id, "APPLIED",
                "Recovered queue item after worker lease expiry.", now,
                {"item_id": item_id},
            )
            actions.append(action)
            self.observability.event("recovery_applied", item_id=item_id, detail=action.kind)

        # Only revive stale workers that explicitly report zero active work.
        if self.supervisor is not None:
            self.supervisor.stale(now=now)
            stale = [r for r in self.supervisor.list() if r.status == WorkerStatus.STALE]
            for record in stale:
                if record.active != 0:
                    actions.append(RecoveryAction(
                        "STALE_WORKER", record.worker_id, "SKIPPED",
                        "Stale worker has active work; lease recovery must handle abandoned work.",
                        now, {"active": record.active},
                    ))
                    continue
                try:
                    self.supervisor.recover_idle_stale(record.worker_id)
                    actions.append(RecoveryAction(
                        "IDLE_WORKER_RECOVERY", record.worker_id, "APPLIED",
                        "Reactivated stale worker with no active work.", now,
                    ))
                except (KeyError, RuntimeError) as exc:
                    actions.append(RecoveryAction(
                        "IDLE_WORKER_RECOVERY", record.worker_id, "SKIPPED",
                        "Worker could not be safely reactivated.", now,
                        {"error": str(exc)},
                    ))

        for action in actions:
            self.observability.metric("recovery.applied" if action.status == "APPLIED" else "recovery.skipped", 1)

        after = self.monitor.check_and_record(now=now)
        return RecoveryReport(before=before, actions=actions, after=after)
