"""Rabidanti v3.32 — deterministic Research Engine.

This engine turns a business objective and supplied research context into a
structured research brief. It deliberately does not invent live market data;
external/current evidence can be supplied through the context and provenance
is preserved in the result.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping
import re


@dataclass(frozen=True)
class ResearchBrief:
    project_id: str
    objective: str
    demand_signals: tuple[str, ...]
    pain_points: tuple[str, ...]
    objections: tuple[str, ...]
    market_gaps: tuple[str, ...]
    hypotheses: tuple[str, ...]
    evidence: tuple[dict[str, Any], ...]
    limitations: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class ResearchEngine:
    """Create a traceable research brief from supplied inputs.

    The engine is intentionally evidence-bounded: it only treats explicit
    context fields as evidence and labels missing live/current evidence as a
    limitation rather than fabricating market facts.
    """

    _FIELDS = {
        "demand_signals": ("demand_signals", "signals", "demands"),
        "pain_points": ("pain_points", "pains", "problems"),
        "objections": ("objections", "barriers", "concerns"),
        "market_gaps": ("market_gaps", "gaps", "opportunity_gaps"),
    }

    def research(self, project_id: str, objective: str, context: Mapping[str, Any] | None = None) -> ResearchBrief:
        if not str(project_id).strip():
            raise ValueError("project_id must not be empty")
        if not str(objective).strip():
            raise ValueError("objective must not be empty")
        ctx = dict(context or {})

        extracted: dict[str, list[str]] = {}
        for target, aliases in self._FIELDS.items():
            extracted[target] = self._clean_items(self._first_present(ctx, aliases))

        # Preserve useful textual context when the structured fields are absent.
        free_text = self._clean_text(ctx.get("research_text") or ctx.get("market_context") or "")
        if free_text and not any(extracted.values()):
            extracted["demand_signals"] = self._extract_sentences(free_text, ("need", "want", "demand", "looking for", "seeking"))
            extracted["pain_points"] = self._extract_sentences(free_text, ("problem", "pain", "difficult", "challenge", "frustrat"))
            extracted["objections"] = self._extract_sentences(free_text, ("concern", "risk", "expensive", "doubt", "objection"))
            extracted["market_gaps"] = self._extract_sentences(free_text, ("gap", "missing", "lack", "underserved", "no good"))

        hypotheses = self._hypotheses(objective, extracted)
        evidence = self._evidence(ctx)
        limitations = []
        if not evidence:
            limitations.append("No external evidence source was supplied; findings are hypothesis-level.")
        if not extracted["demand_signals"]:
            limitations.append("No explicit demand signals were supplied.")
        if not extracted["market_gaps"]:
            limitations.append("No explicit market gaps were supplied.")

        return ResearchBrief(
            project_id=str(project_id), objective=str(objective).strip(),
            demand_signals=tuple(extracted["demand_signals"]),
            pain_points=tuple(extracted["pain_points"]),
            objections=tuple(extracted["objections"]),
            market_gaps=tuple(extracted["market_gaps"]),
            hypotheses=tuple(hypotheses), evidence=tuple(evidence),
            limitations=tuple(limitations),
        )

    def _first_present(self, ctx: Mapping[str, Any], aliases: tuple[str, ...]) -> Any:
        for key in aliases:
            if key in ctx and ctx[key] not in (None, "", []):
                return ctx[key]
        return []

    @staticmethod
    def _clean_text(value: Any) -> str:
        return re.sub(r"\s+", " ", str(value)).strip()

    def _clean_items(self, value: Any) -> list[str]:
        if isinstance(value, str):
            raw = re.split(r"\n|;|•", value)
        elif isinstance(value, (list, tuple, set)):
            raw = list(value)
        else:
            return []
        out = []
        for item in raw:
            text = self._clean_text(item)
            if text and text not in out:
                out.append(text)
        return out[:20]

    def _extract_sentences(self, text: str, keywords: tuple[str, ...]) -> list[str]:
        chunks = re.split(r"(?<=[.!?])\s+|\n|;", text)
        return [c for c in (self._clean_text(x) for x in chunks) if c and any(k in c.lower() for k in keywords)][:10]

    def _hypotheses(self, objective: str, extracted: Mapping[str, list[str]]) -> list[str]:
        hypotheses = [f"A product addressing '{objective.strip()}' could solve a validated customer need."]
        if extracted["pain_points"]:
            hypotheses.append("Reducing the stated pain points may increase perceived value.")
        if extracted["market_gaps"]:
            hypotheses.append("The stated gaps may represent an underserved product opportunity.")
        if extracted["objections"]:
            hypotheses.append("Addressing the stated objections should be tested before scaling.")
        return hypotheses[:8]

    def _evidence(self, ctx: Mapping[str, Any]) -> list[dict[str, Any]]:
        raw = ctx.get("evidence", ctx.get("sources", []))
        if not isinstance(raw, (list, tuple)):
            return []
        out = []
        for item in raw[:20]:
            if isinstance(item, Mapping):
                record = {str(k): v for k, v in item.items()}
                if any(str(v).strip() for v in record.values() if v is not None):
                    out.append(record)
            elif str(item).strip():
                out.append({"source": str(item).strip()})
        return out
