# Rabidanti v4.6 — Live Connector Setup & Provider Management

## Objetivo

A v4.6 transforma o suporte OAuth/Gmail da v4.5 num ciclo operacional local e auditável sem aumentar a autoridade externa do Rabidanti.

## Componentes adicionados

### ProviderStateStore (`rabidanti_providers.py`)

SQLite persistente para **metadados**, nunca credenciais. Guarda:

- provider e scopes;
- estado (`NOT_CONNECTED`, `CONNECTED`, `REVOKED`, etc.);
- expiração conhecida do access token;
- data da ligação, refresh e teste;
- resultado do último teste;
- erros operacionais seguros.

Tokens, client secrets e refresh tokens não são guardados nesta base.

### OAuth refresh e callback local

`OAuthPKCEManager` passa a suportar:

- pesquisa segura de fluxo pelo `state`;
- refresh de access token por refresh token;
- deteção de `invalid_grant` / `invalid_token` como revogação;
- rotação de refresh token quando o provider a devolve.

O endpoint loopback `/oauth/callback` pode concluir o Authorization Code Flow sem colocar tokens na URL, HTML ou logs.

### Runtime provider management

O runtime passa a:

- registar o provider `google_gmail_readonly`;
- expor estado seguro de providers;
- configurar Google Client ID/Secret em sessão ou vault;
- atualizar metadados após OAuth;
- fazer refresh automático quando a expiração conhecida se aproxima;
- marcar refresh revogado;
- testar ligação Gmail através do mesmo permission gate do connector framework.

### Sala / API

API nova:

- `GET /v1/providers`
- `POST /v1/providers/google-gmail/setup`
- `POST /v1/providers/google-gmail/oauth/start`
- `POST /v1/providers/google-gmail/oauth/exchange`
- `POST /v1/providers/google-gmail/refresh`
- `POST /v1/providers/google-gmail/test`
- `GET /oauth/callback`

Todas as mutações administrativas exigem Bearer Token, exceto o callback OAuth loopback, protegido pelo `state` criptograficamente aleatório do próprio fluxo.

A Sala inclui configuração, início do OAuth, teste de ligação e refresh manual. Não usa `localStorage`, `sessionStorage` nem cookies para segredos.

## Fronteiras preservadas

- Gmail permanece **read-only**.
- O connector continua desativado por defeito.
- OAuth não concede autorização geral para ações externas.
- Não existe endpoint HTTP genérico de invocação de connector.
- Tokens não são guardados em `providers.sqlite3`.
- A master key do vault continua fora do vault.
- Uma conta Google real ainda precisa ser explicitamente autorizada para validação live.

## Refresh automático

Se `token_expires_at` indicar expiração próxima, a resolução de `GMAIL_ACCESS_TOKEN` tenta refresh antes da chamada Gmail. Para funcionar após reinício, o runtime precisa encontrar:

- `GOOGLE_CLIENT_ID`;
- `GMAIL_REFRESH_TOKEN`;
- opcionalmente `GOOGLE_CLIENT_SECRET`.

Esses valores devem existir em sessão, ambiente ou vault desbloqueado.

## Limitação deliberada

A v4.6 não afirma que OAuth/Gmail foram validados contra uma conta Google real. Os testes de rede são feitos com transportes/respostas controlados e o código fica preparado para validação live posterior.
