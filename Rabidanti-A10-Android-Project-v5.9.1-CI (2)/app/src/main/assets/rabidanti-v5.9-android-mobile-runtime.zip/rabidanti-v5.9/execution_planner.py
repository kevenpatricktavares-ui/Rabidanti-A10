"""Rabidanti v3.22 — capacity-aware execution planning."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional
import time

from capacity_intelligence import CapacityIntelligence

@dataclass(frozen=True)
class PlannedItem:
    item_id: str
    priority: int
    ready: bool = True
    dependencies_satisfied: bool = True

@dataclass(frozen=True)
class ExecutionPlan:
    timestamp: float
    available_slots: int
    selected: tuple[str, ...]
    deferred: tuple[str, ...]
    reason: str
    forecast_recommendation: Optional[str]

class ExecutionPlanner:
    """Create bounded, non-mutating execution plans from ready work."""
    def __init__(self, capacity: CapacityIntelligence):
        self.capacity = capacity

    def plan(self, items: list[PlannedItem], available_slots: int,
             now: Optional[float] = None) -> ExecutionPlan:
        if available_slots < 0:
            raise ValueError("available_slots must be >= 0")
        now = time.time() if now is None else float(now)
        eligible = [x for x in items if x.ready and x.dependencies_satisfied]
        eligible.sort(key=lambda x: (-x.priority, x.item_id))
        selected = tuple(x.item_id for x in eligible[:available_slots])
        selected_set = set(selected)
        deferred = tuple(x.item_id for x in items if x.item_id not in selected_set)
        forecast_recommendation = None
        try:
            forecast_recommendation = self.capacity.forecast(now=now).recommendation
        except RuntimeError:
            pass
        if available_slots == 0:
            reason = "NO_CAPACITY"
        elif not eligible:
            reason = "NO_ELIGIBLE_WORK"
        elif len(selected) < len(eligible):
            reason = "CAPACITY_BOUND"
        else:
            reason = "PRIORITY_ORDER"
        return ExecutionPlan(now, available_slots, selected, deferred, reason, forecast_recommendation)
