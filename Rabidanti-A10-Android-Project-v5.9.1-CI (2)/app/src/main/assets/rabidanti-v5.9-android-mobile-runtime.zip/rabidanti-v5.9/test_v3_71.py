import pytest
from evolution_evidence_decision import *
def a(**x):
    b=dict(evidence_confidence=.9,expected_impact=.8,risk=.2,estimated_cost=.2,reversibility=.9); b.update(x); return EvidenceAssessment(**b)
def test_high(): 
    d=EvolutionEvidenceDecisionEngine().evaluate("p",a()); assert d.decision is Decision.APPROVAL_REQUIRED and d.approval_required
def test_weak(): 
    d=EvolutionEvidenceDecisionEngine().evaluate("p",a(evidence_confidence=.4)); assert d.decision is Decision.INVESTIGATE
def test_bad():
    d=EvolutionEvidenceDecisionEngine().evaluate("p",a(expected_impact=.1,risk=.95,estimated_cost=.95,reversibility=.1,evidence_confidence=.71)); assert d.decision is Decision.REJECT
def test_invalid():
    with pytest.raises(ValueError): EvolutionEvidenceDecisionEngine().evaluate("p",a(risk=1.2))
def test_duplicate():
    e=EvolutionEvidenceDecisionEngine(); e.evaluate("p",a())
    with pytest.raises(ValueError): e.evaluate("p",a())
def test_no_activation():
    d=EvolutionEvidenceDecisionEngine().evaluate("p",a()); assert not hasattr(d,"activate")
