from __future__ import annotations

import json
from pathlib import Path

import pytest

from native_release_check import NativeEvidenceError, validate as validate_native_evidence
from rabidanti_release import (
    ReleaseValidationError,
    create_release_manifest,
    validate_pe,
    validate_release_tree,
)


def _fake_pe(path: Path, *, subsystem: int = 2, machine: int = 0x8664) -> None:
    data = bytearray(4096)
    data[0:2] = b"MZ"
    pe_offset = 0x80
    data[0x3C:0x40] = pe_offset.to_bytes(4, "little")
    data[pe_offset:pe_offset + 4] = b"PE\0\0"
    coff = pe_offset + 4
    data[coff:coff + 2] = machine.to_bytes(2, "little")
    data[coff + 16:coff + 18] = (240).to_bytes(2, "little")
    optional = coff + 20
    data[optional:optional + 2] = (0x20B).to_bytes(2, "little")
    data[optional + 68:optional + 70] = subsystem.to_bytes(2, "little")
    path.write_bytes(data)


def _write_native_evidence(root: Path, exe: Path, installer: Path, version: str) -> None:
    manifest = create_release_manifest(root, exe, installer)
    windows = {
        "schema": 1,
        "product": "Rabidanti",
        "version": version,
        "end_to_end_windows_validated": True,
        "checks": {
            "built_exe_build_info": "PASS",
            "built_exe_fresh_state": "PASS",
            "silent_install": "PASS",
            "installed_exe_build_info": "PASS",
            "silent_uninstall": "PASS",
        },
        "executable_sha256": manifest["artifacts"]["executable"]["sha256"],
        "installer_sha256": manifest["artifacts"]["installer"]["sha256"],
    }
    (root / "windows-release-validation.json").write_text(json.dumps(windows), encoding="utf-8")


def test_version_is_at_least_5_5():
    version = tuple(map(int, Path("VERSION").read_text().strip().split(".")))
    assert version >= (5, 5, 0)


def test_release_preflight_requires_windows_native_verification_components():
    result = validate_release_tree(Path("."))
    assert result["checks"] >= 21
    assert Path("verify_windows_release.ps1").exists()
    assert Path("native_release_check.py").exists()
    assert Path(".github/workflows/windows-native-release.yml").exists()


def test_pe_validator_reports_architecture_format_and_gui_subsystem(tmp_path):
    exe = tmp_path / "Rabidanti.exe"
    _fake_pe(exe)
    result = validate_pe(exe)
    assert result["machine"] == "x64"
    assert result["pe_format"] == "PE32+"
    assert result["subsystem"] == "windows_gui"


def test_release_manifest_rejects_console_subsystem_executable(tmp_path):
    root = tmp_path / "root"
    root.mkdir()
    (root / "VERSION").write_text("5.5.0\n")
    exe = tmp_path / "Rabidanti.exe"
    _fake_pe(exe, subsystem=3)
    with pytest.raises(ReleaseValidationError, match="GUI subsystem"):
        create_release_manifest(root, exe)


def test_release_manifest_separates_structural_from_end_to_end_validation(tmp_path):
    root = tmp_path / "root"
    root.mkdir()
    (root / "VERSION").write_text("5.5.0\n")
    exe = tmp_path / "Rabidanti.exe"
    setup = tmp_path / "Rabidanti-Setup-5.5.0.exe"
    _fake_pe(exe)
    _fake_pe(setup)
    result = create_release_manifest(root, exe, setup)
    assert result["native_build_validated"] is True
    assert result["end_to_end_windows_validated"] is False
    assert result["schema"] == 2


def test_native_evidence_checker_accepts_consistent_windows_evidence(tmp_path):
    root = tmp_path
    version = "5.5.0"
    (root / "VERSION").write_text(version + "\n")
    (root / "dist").mkdir()
    (root / "installer-dist").mkdir()
    exe = root / "dist" / "Rabidanti.exe"
    setup = root / "installer-dist" / f"Rabidanti-Setup-{version}.exe"
    _fake_pe(exe)
    _fake_pe(setup)
    _write_native_evidence(root, exe, setup, version)
    result = validate_native_evidence(root)
    assert result["native_release_verified"] is True


def test_native_evidence_checker_rejects_hash_tampering(tmp_path):
    root = tmp_path
    version = "5.5.0"
    (root / "VERSION").write_text(version + "\n")
    (root / "dist").mkdir()
    (root / "installer-dist").mkdir()
    exe = root / "dist" / "Rabidanti.exe"
    setup = root / "installer-dist" / f"Rabidanti-Setup-{version}.exe"
    _fake_pe(exe)
    _fake_pe(setup)
    _write_native_evidence(root, exe, setup, version)
    exe.write_bytes(exe.read_bytes() + b"tamper")
    with pytest.raises(NativeEvidenceError, match="hash mismatch"):
        validate_native_evidence(root)


def test_native_evidence_checker_requires_windows_end_to_end_pass(tmp_path):
    root = tmp_path
    version = "5.5.0"
    (root / "VERSION").write_text(version + "\n")
    (root / "dist").mkdir()
    (root / "installer-dist").mkdir()
    exe = root / "dist" / "Rabidanti.exe"
    setup = root / "installer-dist" / f"Rabidanti-Setup-{version}.exe"
    _fake_pe(exe)
    _fake_pe(setup)
    _write_native_evidence(root, exe, setup, version)
    payload = json.loads((root / "windows-release-validation.json").read_text())
    payload["end_to_end_windows_validated"] = False
    (root / "windows-release-validation.json").write_text(json.dumps(payload))
    with pytest.raises(NativeEvidenceError, match="did not pass"):
        validate_native_evidence(root)


def test_windows_verifier_tests_install_run_and_uninstall():
    text = Path("verify_windows_release.ps1").read_text(encoding="utf-8")
    assert "/VERYSILENT" in text
    assert "installed Rabidanti.exe not found" in text
    assert "unins000.exe" in text
    assert "end_to_end_windows_validated = $true" in text


def test_release_build_requires_windows_verifier_after_manifest():
    text = Path("build_release_windows.bat").read_text(encoding="utf-8").lower()
    assert text.index("rabidanti_release.py postbuild") < text.index("verify_windows_release.ps1")
    assert "windows-release-validation.json" in text


def test_windows_ci_workflow_builds_and_uploads_only_validated_artifacts():
    text = Path(".github/workflows/windows-native-release.yml").read_text(encoding="utf-8")
    assert "runs-on: windows-latest" in text
    assert "build_release_windows.bat" in text
    assert "python native_release_check.py" in text
    assert "windows-release-validation.json" in text


def test_source_release_does_not_fabricate_native_evidence():
    assert not Path("release-manifest.json").exists()
    assert not Path("windows-release-validation.json").exists()


def test_product_build_info_reports_current_version(tmp_path):
    from rabidanti_product import ProductFoundation
    info = ProductFoundation(tmp_path).build_info()
    assert info["version"] == Path("VERSION").read_text().strip()


def test_emit_can_write_json_evidence_without_stdout(tmp_path, monkeypatch):
    import rabidanti
    target = tmp_path / "evidence.json"
    monkeypatch.setenv("RABIDANTI_OUTPUT_FILE", str(target))
    rabidanti.emit({"ok": True, "value": 7})
    saved = json.loads(target.read_text())
    assert saved == {"ok": True, "value": 7}


def test_windows_verifier_uses_output_file_channel_for_windowed_exe():
    text = Path("verify_windows_release.ps1").read_text(encoding="utf-8")
    assert "RABIDANTI_OUTPUT_FILE" in text
    assert "did not produce build-info evidence" in text
    assert "did not produce status evidence" in text
