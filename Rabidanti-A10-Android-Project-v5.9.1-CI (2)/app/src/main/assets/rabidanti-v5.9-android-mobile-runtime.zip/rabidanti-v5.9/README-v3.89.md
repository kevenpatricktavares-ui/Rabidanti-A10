# Rabidanti v3.89 — Laboratory Container Backend

Adds a read-only container-runtime probe and a conservative container execution plan. The plan uses a digest-pinned image, read-only root filesystem, non-root UID, dropped capabilities, no-new-privileges, memory/CPU/PID limits, temporary filesystem, and networking disabled by default.

**Safety boundary:** this module does not execute the plan and does not prove the host/container runtime enforces every control. It is not a complete sandbox or security audit. Review the plan and host configuration before any future executor is enabled. Never use this as authorization to run untrusted code on a sensitive host.

Run tests with `pytest -q` from the project root.
