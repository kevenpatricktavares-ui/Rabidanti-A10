"""Rabidanti v3.38 — deterministic landing-page specification."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping
import html

@dataclass(frozen=True)
class LandingBrief:
    project_id: str
    title: str
    headline: str
    subheadline: str
    audience: str
    sections: tuple[str, ...]
    cta: str
    brand_name: str
    product_asset: str
    status: str = "READY_FOR_REVIEW"
    limitations: tuple[str, ...] = ()
    def to_dict(self) -> dict[str, Any]: return asdict(self)

class LandingEngine:
    def build(self, project_id: str, product: Mapping[str, Any], brand: Mapping[str, Any], render: Mapping[str, Any]) -> LandingBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not product: raise ValueError("product must not be empty")
        if not brand: raise ValueError("brand must not be empty")
        if not render: raise ValueError("render must not be empty")
        name = str(product.get("name") or product.get("title") or "Digital Product").strip()
        audience = str(product.get("target_audience") or "intended audience").strip()
        problem = str(product.get("problem") or product.get("objective") or "a practical challenge").strip()
        promise = str(brand.get("promise") or product.get("value_proposition") or "").strip()
        sections = ("hero", "problem", "value_proposition", "what_you_get", "social_proof_placeholder", "faq", "call_to_action")
        limits = (
            "Social proof is a placeholder until real evidence/testimonials are supplied.",
            "Landing page requires final legal, pricing, claims and publication review.",
        )
        return LandingBrief(str(project_id), name, promise or f"A practical way to address {problem}.",
                            f"Designed for {audience}.", audience, sections, "Get access", str(brand.get("name") or name),
                            str(render.get("output_path") or ""), "READY_FOR_REVIEW", limits)

    def render_html(self, brief: LandingBrief) -> str:
        e = html.escape
        sections = "".join(f"<section><h2>{e(s.replace('_',' ').title())}</h2></section>" for s in brief.sections)
        return f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{e(brief.title)}</title></head><body><main><header><p>{e(brief.brand_name)}</p><h1>{e(brief.headline)}</h1><p>{e(brief.subheadline)}</p><a href='#cta'>{e(brief.cta)}</a></header>{sections}<section id='cta'><h2>{e(brief.cta)}</h2></section></main></body></html>"
