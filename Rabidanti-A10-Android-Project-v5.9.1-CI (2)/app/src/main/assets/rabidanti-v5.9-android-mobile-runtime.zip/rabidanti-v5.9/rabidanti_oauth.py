"""Rabidanti v4.5 — OAuth 2.0 Authorization Code + PKCE helper.

Pending flow verifiers are stored only inside the encrypted credential vault.
Token exchange uses fixed provider endpoints supplied by trusted code; callers
cannot pass arbitrary token URLs through the public runtime interface.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Optional
from urllib.parse import urlencode
import base64
import hashlib
import json
import secrets
import uuid

import httpx

from rabidanti_vault import EncryptedCredentialVault


@dataclass(frozen=True)
class OAuthProvider:
    provider_id: str
    authorization_endpoint: str
    token_endpoint: str
    scopes: tuple[str, ...]


GOOGLE_GMAIL_READONLY = OAuthProvider(
    provider_id="google_gmail_readonly",
    authorization_endpoint="https://accounts.google.com/o/oauth2/v2/auth",
    token_endpoint="https://oauth2.googleapis.com/token",
    scopes=("https://www.googleapis.com/auth/gmail.readonly",),
)


class OAuthError(RuntimeError):
    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class OAuthRevokedError(OAuthError):
    pass


class OAuthPKCEManager:
    def __init__(
        self,
        vault: EncryptedCredentialVault,
        *,
        post: Optional[Callable[..., Any]] = None,
    ) -> None:
        self.vault = vault
        self._post = post or httpx.post

    @staticmethod
    def _challenge(verifier: str) -> str:
        digest = hashlib.sha256(verifier.encode("ascii")).digest()
        return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    def start(self, provider: OAuthProvider, *, client_id: str, redirect_uri: str) -> dict[str, Any]:
        if not client_id or not redirect_uri:
            raise ValueError("client_id and redirect_uri are required")
        flow_id = uuid.uuid4().hex
        state = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        record = {
            "provider_id": provider.provider_id,
            "state": state,
            "verifier": verifier,
            "redirect_uri": redirect_uri,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.vault.set(f"OAUTH_FLOW_{flow_id.upper()}", json.dumps(record, sort_keys=True))
        query = urlencode({
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(provider.scopes),
            "state": state,
            "code_challenge": self._challenge(verifier),
            "code_challenge_method": "S256",
            "access_type": "offline",
            "prompt": "consent",
        })
        return {
            "flow_id": flow_id,
            "authorization_url": provider.authorization_endpoint + "?" + query,
            "state": state,
            "provider": provider.provider_id,
            "scopes": list(provider.scopes),
        }


    def find_flow_by_state(self, provider: OAuthProvider, state: str) -> str:
        if not isinstance(state, str) or not state:
            raise OAuthError("OAuth state is required")
        for name in self.vault.names():
            if not name.startswith("OAUTH_FLOW_"):
                continue
            raw = self.vault.get(name)
            if not raw:
                continue
            try:
                record = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if record.get("provider_id") != provider.provider_id:
                continue
            if secrets.compare_digest(str(record.get("state", "")), state):
                return name[len("OAUTH_FLOW_"):].lower()
        raise OAuthError("OAuth flow not found for state")

    def refresh(
        self,
        provider: OAuthProvider,
        *,
        client_id: str,
        refresh_token: str,
        client_secret: Optional[str] = None,
    ) -> dict[str, Any]:
        if not client_id or not refresh_token:
            raise OAuthError("client_id and refresh_token are required")
        payload = {
            "client_id": client_id,
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        }
        if client_secret:
            payload["client_secret"] = client_secret
        response = self._post(provider.token_endpoint, data=payload, timeout=20.0)
        status = int(getattr(response, "status_code", 500))
        if status >= 400:
            try:
                body = response.json()
            except Exception:
                body = {}
            error = str(body.get("error", "")) if isinstance(body, dict) else ""
            exc_cls = OAuthRevokedError if status in {400, 401} and error in {"invalid_grant", "invalid_token"} else OAuthError
            raise exc_cls(f"token refresh failed with HTTP {status}", status_code=status)
        token_data = response.json()
        access_token = token_data.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise OAuthError("refresh response did not contain access_token")
        self.vault.set("GMAIL_ACCESS_TOKEN", access_token)
        replacement = token_data.get("refresh_token")
        if isinstance(replacement, str) and replacement:
            self.vault.set("GMAIL_REFRESH_TOKEN", replacement)
        return {
            "token_type": token_data.get("token_type"),
            "expires_in": token_data.get("expires_in"),
            "scope": token_data.get("scope"),
            "access_token_stored": True,
            "refresh_token_rotated": bool(replacement),
        }

    def exchange(
        self,
        provider: OAuthProvider,
        *,
        flow_id: str,
        state: str,
        code: str,
        client_id: str,
        client_secret: Optional[str] = None,
    ) -> dict[str, Any]:
        key = f"OAUTH_FLOW_{flow_id.upper()}"
        raw = self.vault.get(key)
        if raw is None:
            raise OAuthError("OAuth flow not found or already consumed")
        record = json.loads(raw)
        if record.get("provider_id") != provider.provider_id:
            raise OAuthError("OAuth provider mismatch")
        if not secrets.compare_digest(str(record.get("state", "")), state):
            raise OAuthError("OAuth state mismatch")
        payload = {
            "client_id": client_id,
            "code": code,
            "code_verifier": record["verifier"],
            "grant_type": "authorization_code",
            "redirect_uri": record["redirect_uri"],
        }
        if client_secret:
            payload["client_secret"] = client_secret
        response = self._post(provider.token_endpoint, data=payload, timeout=20.0)
        if getattr(response, "status_code", 500) >= 400:
            raise OAuthError(f"token exchange failed with HTTP {response.status_code}", status_code=response.status_code)
        token_data = response.json()
        access_token = token_data.get("access_token")
        if not isinstance(access_token, str) or not access_token:
            raise OAuthError("token response did not contain access_token")
        self.vault.set("GMAIL_ACCESS_TOKEN", access_token)
        refresh = token_data.get("refresh_token")
        if isinstance(refresh, str) and refresh:
            self.vault.set("GMAIL_REFRESH_TOKEN", refresh)
        safe = {
            "token_type": token_data.get("token_type"),
            "expires_in": token_data.get("expires_in"),
            "scope": token_data.get("scope"),
            "refresh_token_stored": bool(refresh),
            "access_token_stored": True,
        }
        self.vault.delete(key)
        return safe
