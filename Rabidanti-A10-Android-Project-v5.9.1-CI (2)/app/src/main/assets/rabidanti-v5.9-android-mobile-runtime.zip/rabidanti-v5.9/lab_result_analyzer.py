"""Rabidanti v3.92 — evidence-aware experiment result analysis.

This module does not infer scientific truth from free-form output. A reviewer
must classify each predeclared criterion and attach a concise evidence note.
Blocked runs cannot be marked as passed or failed.
"""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib, json, uuid
from lab_evidence_integration import LabEvidenceIntegration

class LabResultAnalyzer:
    CRITERION_STATES = {"PASS", "FAIL", "INCONCLUSIVE"}
    def __init__(self, experiment_manager, evidence_memory=None):
        self.manager = experiment_manager
        self.evidence = LabEvidenceIntegration(experiment_manager, evidence_memory) if evidence_memory is not None else None

    def analyze(self, experiment_id, run_id, criterion_results, *, reviewer, evidence_refs=()):
        exp = self.manager.get(experiment_id)
        if exp.status != "ANALYSIS":
            raise ValueError("experiment must be in ANALYSIS before result review")
        if not isinstance(reviewer, str) or not reviewer.strip():
            raise ValueError("reviewer is required")
        if not isinstance(criterion_results, dict):
            raise ValueError("criterion_results must map every criterion to a reviewed result")
        if not isinstance(evidence_refs, (list, tuple)) or any(not isinstance(x, str) or not x.strip() for x in evidence_refs):
            raise ValueError("evidence_refs must contain non-empty strings")
        result_entries = [e for e in self.manager.list_entries(experiment_id, "RESULT") if e["metadata"].get("run_id") == run_id]
        if not result_entries:
            raise ValueError("no recorded execution result exists for this run_id")
        run = result_entries[-1]["metadata"]
        if run.get("executed") is not True:
            report = {"analysis_id": str(uuid.uuid4()), "experiment_id": experiment_id, "run_id": run_id,
                      "classification": "BLOCKED", "reviewer": reviewer.strip(), "criteria": {},
                      "evidence_refs": list(evidence_refs), "limitations": ["Execution was not verified; criteria cannot be judged from this run."],
                      "integration_authorized": False, "created_at": datetime.now(timezone.utc).isoformat()}
            self._persist(experiment_id, report)
            if self.evidence is not None:
                self.evidence.record_analysis(experiment_id, report)
            return report
        expected = set(exp.success_criteria)
        if set(criterion_results) != expected:
            raise ValueError("each predeclared criterion must be reviewed exactly once")
        normalized = {}
        for criterion in exp.success_criteria:
            item = criterion_results[criterion]
            if not isinstance(item, dict) or item.get("state") not in self.CRITERION_STATES:
                raise ValueError(f"criterion '{criterion}' must have state PASS, FAIL, or INCONCLUSIVE")
            evidence = item.get("evidence")
            if not isinstance(evidence, str) or not evidence.strip():
                raise ValueError(f"criterion '{criterion}' requires an evidence note")
            normalized[criterion] = {"state": item["state"], "evidence": evidence.strip()[:2000]}
        states = {v["state"] for v in normalized.values()}
        classification = "FAILED" if "FAIL" in states else ("PASSED" if states == {"PASS"} else "INCONCLUSIVE")
        canonical = json.dumps({"run_id": run_id, "criteria": normalized, "evidence_refs": list(evidence_refs)}, sort_keys=True, separators=(",", ":"))
        report = {"analysis_id": str(uuid.uuid4()), "experiment_id": experiment_id, "run_id": run_id,
                  "classification": classification, "reviewer": reviewer.strip(), "criteria": normalized,
                  "evidence_refs": list(evidence_refs), "evidence_digest": hashlib.sha256(canonical.encode()).hexdigest(),
                  "limitations": ["Classification depends on reviewer-provided evidence; it is not independent proof of reproducibility."],
                  "integration_authorized": False, "created_at": datetime.now(timezone.utc).isoformat()}
        self._persist(experiment_id, report)
        if self.evidence is not None:
            self.evidence.record_analysis(experiment_id, report)
        if classification in {"PASSED", "FAILED"}:
            self.manager.transition(experiment_id, classification, f"{report['analysis_id']}:status", f"Reviewer classified evidence as {classification}")
        return report

    def _persist(self, experiment_id, report):
        self.manager.add_entry(experiment_id, f"{report['analysis_id']}:analysis", "RECOMMENDATION",
                               f"Result classification: {report['classification']}", report)
