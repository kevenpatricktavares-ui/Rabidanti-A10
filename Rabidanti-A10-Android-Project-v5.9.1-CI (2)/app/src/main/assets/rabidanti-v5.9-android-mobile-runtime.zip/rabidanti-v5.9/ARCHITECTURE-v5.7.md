# Rabidanti v5.7 — Product Self-Test & Operational Readiness

v5.7 introduces an integrated self-test boundary for the assembled local product. The self-test is intentionally isolated from the user's real persistent state and does not exercise external providers or model inference.

## Flow

Product self-test → temporary state → runtime start → local doctor/integrity → task write/read → audit verification → clean stop → restart → persistence verification → cleanup.

## Safety invariants

- No persistent user state is created or modified.
- No connector is enabled.
- No Gmail/OAuth request is made.
- No Ollama/model request is made.
- No reasoning proposal is executed.
- No external action is authorized.
- Container runtime availability is reported as optional, not silently treated as validated isolation.
- A passing self-test is operational readiness evidence, not scientific validation and not native Windows release evidence.
