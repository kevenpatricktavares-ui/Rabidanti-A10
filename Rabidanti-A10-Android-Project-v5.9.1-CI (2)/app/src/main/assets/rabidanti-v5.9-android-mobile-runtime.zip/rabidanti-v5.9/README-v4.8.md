# Rabidanti v4.8

Local Model Manager + Agent Reasoning Runtime.

## New commands

```bash
python rabidanti.py model status
python rabidanti.py model list
python rabidanti.py reason "Analisa esta oportunidade e propõe próximos passos"
python rabidanti.py proposals --limit 50
```

## Model configuration

```bash
python rabidanti.py config set ai.model '"llama3.2"'
python rabidanti.py config set ai.fallback_model '"qwen3"'
```

The Ollama endpoint remains loopback-only. Model discovery uses `/api/tags`. If the primary model is absent and the configured fallback is installed, the fallback is used for chat/reasoning.

## Reasoning safety
The planning layer returns text plus zero or more proposals. Proposals are persisted but **never executed by the reasoning layer**. They have `execution_authorized=false`, `external_action_authorized=false`, and `tool_execution_authorized=false`.

A model cannot grant itself connector permission, shell access, Core modification, publishing, spending, deletion, or external-action authority.
