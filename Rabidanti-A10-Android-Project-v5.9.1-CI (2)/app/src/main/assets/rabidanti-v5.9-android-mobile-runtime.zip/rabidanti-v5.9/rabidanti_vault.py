"""Rabidanti v4.5 — encrypted local credential vault.

The vault encrypts secret values at rest with Fernet using a PBKDF2-HMAC-SHA256
key derived from a master key that must be supplied outside the vault file.
The master key is never persisted by this module.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Optional
import base64
import json
import os
import re
import secrets
import tempfile

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

_NAME = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")


class VaultError(RuntimeError):
    pass


class VaultLocked(VaultError):
    pass


class VaultIntegrityError(VaultError):
    pass


class EncryptedCredentialVault:
    VERSION = 1
    KDF_ITERATIONS = 600_000

    def __init__(self, path: str | os.PathLike[str], master_key: Optional[str] = None) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._master_key = master_key
        self._data: dict[str, Any] = {"version": self.VERSION, "salt": None, "items": {}}
        if self.path.exists():
            self._load()

    @staticmethod
    def normalize_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValueError("credential name must be a string")
        normalized = name.strip().upper()
        if not _NAME.fullmatch(normalized):
            raise ValueError("credential name must match [A-Z][A-Z0-9_]{1,63}")
        return normalized

    @property
    def unlocked(self) -> bool:
        return isinstance(self._master_key, str) and len(self._master_key) >= 24

    def unlock(self, master_key: str) -> None:
        if not isinstance(master_key, str) or len(master_key) < 24:
            raise ValueError("vault master key must contain at least 24 characters")
        self._master_key = master_key
        if self.path.exists() and self._data.get("items"):
            # Authenticate immediately by decrypting one entry.
            name = next(iter(self._data["items"]))
            self.get(name)

    def lock(self) -> None:
        self._master_key = None

    def _load(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise VaultIntegrityError(f"invalid vault file: {exc}") from exc
        if not isinstance(raw, dict) or raw.get("version") != self.VERSION:
            raise VaultIntegrityError("unsupported or invalid vault format")
        if not isinstance(raw.get("items"), dict):
            raise VaultIntegrityError("invalid vault item store")
        salt = raw.get("salt")
        if salt is not None:
            try:
                decoded = base64.urlsafe_b64decode(salt.encode("ascii"))
            except Exception as exc:
                raise VaultIntegrityError("invalid vault salt") from exc
            if len(decoded) != 16:
                raise VaultIntegrityError("invalid vault salt length")
        self._data = raw

    def _ensure_salt(self) -> bytes:
        current = self._data.get("salt")
        if current:
            return base64.urlsafe_b64decode(current.encode("ascii"))
        salt = secrets.token_bytes(16)
        self._data["salt"] = base64.urlsafe_b64encode(salt).decode("ascii")
        return salt

    def _fernet(self) -> Fernet:
        if not self.unlocked:
            raise VaultLocked("vault is locked; provide RABIDANTI_VAULT_MASTER_KEY or unlock explicitly")
        salt = self._ensure_salt()
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=self.KDF_ITERATIONS)
        key = base64.urlsafe_b64encode(kdf.derive(self._master_key.encode("utf-8")))
        return Fernet(key)

    def _persist(self) -> None:
        payload = json.dumps(self._data, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
        fd, temp_name = tempfile.mkstemp(prefix=".vault-", suffix=".tmp", dir=str(self.path.parent), text=True)
        try:
            if os.name != "nt":
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
            if os.name != "nt":
                os.chmod(self.path, 0o600)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def set(self, name: str, value: str) -> None:
        name = self.normalize_name(name)
        if not isinstance(value, str) or len(value) < 1:
            raise ValueError("credential value must be a non-empty string")
        token = self._fernet().encrypt(value.encode("utf-8")).decode("ascii")
        self._data["items"][name] = token
        self._persist()

    def get(self, name: str) -> Optional[str]:
        name = self.normalize_name(name)
        token = self._data.get("items", {}).get(name)
        if token is None:
            return None
        try:
            return self._fernet().decrypt(token.encode("ascii")).decode("utf-8")
        except InvalidToken as exc:
            raise VaultIntegrityError("vault authentication failed; wrong master key or modified vault") from exc

    def delete(self, name: str) -> bool:
        name = self.normalize_name(name)
        existed = name in self._data.get("items", {})
        if existed:
            del self._data["items"][name]
            self._persist()
        return existed

    def names(self) -> list[str]:
        return sorted(self._data.get("items", {}))

    def status(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "exists": self.path.exists(),
            "unlocked": self.unlocked,
            "credential_count": len(self._data.get("items", {})),
            "credential_names": self.names(),
            "master_key_persisted": False,
            "encryption": "Fernet/PBKDF2-HMAC-SHA256",
            "kdf_iterations": self.KDF_ITERATIONS,
        }
