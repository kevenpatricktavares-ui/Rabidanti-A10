"""Rabidanti v3.66 — versioned strategy configuration and rollback.

Provides an explicit, auditable configuration boundary for strategy changes.
A proposed strategy is immutable, approval is explicit, activation creates a
new version, and rollback restores a previous active version without deleting
history.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Mapping


class StrategyState(str, Enum):
    PROPOSED = "PROPOSED"
    APPROVED = "APPROVED"
    ACTIVE = "ACTIVE"
    ROLLED_BACK = "ROLLED_BACK"
    REJECTED = "REJECTED"


@dataclass(frozen=True)
class StrategyVersion:
    strategy_id: str
    version: int
    weights: dict[str, float]
    state: StrategyState
    parent_version: int | None
    reason: str
    created_at: float
    activated_at: float | None = None
    hash: str = ""

    def to_dict(self) -> dict:
        return asdict(self) | {"state": self.state.value}


class VersionedStrategyStore:
    """Durable SQLite store for immutable strategy versions."""

    def __init__(self, db_path: str = ":memory:"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS strategy_versions (
                strategy_id TEXT NOT NULL,
                version INTEGER NOT NULL,
                weights_json TEXT NOT NULL,
                state TEXT NOT NULL,
                parent_version INTEGER,
                reason TEXT NOT NULL,
                created_at REAL NOT NULL,
                activated_at REAL,
                content_hash TEXT NOT NULL,
                PRIMARY KEY(strategy_id, version)
            )"""
        )
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_strategy_state ON strategy_versions(strategy_id, state)")
        self.conn.commit()

    @staticmethod
    def _normalize(weights: Mapping[str, float]) -> dict[str, float]:
        if not weights:
            raise ValueError("weights are required")
        result = {str(k): round(float(v), 8) for k, v in weights.items()}
        if any(not k.strip() for k in result):
            raise ValueError("weight names must be non-empty")
        if any(not -1.0 <= v <= 1.0 for v in result.values()):
            raise ValueError("weights must be between -1 and 1")
        return dict(sorted(result.items()))

    @staticmethod
    def _hash(strategy_id: str, version: int, weights: Mapping[str, float], parent: int | None) -> str:
        raw = json.dumps({"strategy_id": strategy_id, "version": version, "weights": dict(sorted(weights.items())), "parent_version": parent}, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode()).hexdigest()

    def _row(self, row) -> StrategyVersion:
        return StrategyVersion(row[0], int(row[1]), json.loads(row[2]), StrategyState(row[3]), row[4], row[5], row[6], row[7], row[8])

    def get(self, strategy_id: str, version: int) -> StrategyVersion:
        row = self.conn.execute("SELECT strategy_id,version,weights_json,state,parent_version,reason,created_at,activated_at,content_hash FROM strategy_versions WHERE strategy_id=? AND version=?", (strategy_id, version)).fetchone()
        if row is None:
            raise KeyError("strategy version not found")
        return self._row(row)

    def active(self, strategy_id: str) -> StrategyVersion:
        row = self.conn.execute("SELECT strategy_id,version,weights_json,state,parent_version,reason,created_at,activated_at,content_hash FROM strategy_versions WHERE strategy_id=? AND state=? ORDER BY version DESC LIMIT 1", (strategy_id, StrategyState.ACTIVE.value)).fetchone()
        if row is None:
            raise KeyError("no active strategy")
        return self._row(row)

    def list(self, strategy_id: str) -> list[StrategyVersion]:
        rows = self.conn.execute("SELECT strategy_id,version,weights_json,state,parent_version,reason,created_at,activated_at,content_hash FROM strategy_versions WHERE strategy_id=? ORDER BY version", (strategy_id,)).fetchall()
        return [self._row(r) for r in rows]

    def create_initial(self, strategy_id: str, weights: Mapping[str, float], reason: str = "initial strategy") -> StrategyVersion:
        if self.list(strategy_id):
            raise ValueError("strategy already exists")
        normalized = self._normalize(weights)
        now = time.time()
        content_hash = self._hash(strategy_id, 1, normalized, None)
        self.conn.execute("INSERT INTO strategy_versions VALUES (?,?,?,?,?,?,?,?,?)", (strategy_id, 1, json.dumps(normalized, sort_keys=True), StrategyState.ACTIVE.value, None, reason, now, now, content_hash))
        self.conn.commit()
        return self.get(strategy_id, 1)

    def propose(self, strategy_id: str, weights: Mapping[str, float], reason: str) -> StrategyVersion:
        active = self.active(strategy_id)
        normalized = self._normalize(weights)
        if normalized == active.weights:
            raise ValueError("proposed strategy is identical to active strategy")
        version = max(v.version for v in self.list(strategy_id)) + 1
        now = time.time()
        content_hash = self._hash(strategy_id, version, normalized, active.version)
        self.conn.execute("INSERT INTO strategy_versions VALUES (?,?,?,?,?,?,?,?,?)", (strategy_id, version, json.dumps(normalized, sort_keys=True), StrategyState.PROPOSED.value, active.version, str(reason).strip(), now, None, content_hash))
        self.conn.commit()
        return self.get(strategy_id, version)

    def approve(self, strategy_id: str, version: int) -> StrategyVersion:
        item = self.get(strategy_id, version)
        if item.state != StrategyState.PROPOSED:
            raise ValueError("only PROPOSED strategies can be approved")
        self.conn.execute("UPDATE strategy_versions SET state=? WHERE strategy_id=? AND version=?", (StrategyState.APPROVED.value, strategy_id, version))
        self.conn.commit()
        return self.get(strategy_id, version)

    def activate(self, strategy_id: str, version: int) -> StrategyVersion:
        item = self.get(strategy_id, version)
        if item.state != StrategyState.APPROVED:
            raise ValueError("strategy must be APPROVED before activation")
        now = time.time()
        self.conn.execute("UPDATE strategy_versions SET state=?, activated_at=? WHERE strategy_id=? AND state=?", (StrategyState.ROLLED_BACK.value, now, strategy_id, StrategyState.ACTIVE.value))
        self.conn.execute("UPDATE strategy_versions SET state=?, activated_at=? WHERE strategy_id=? AND version=?", (StrategyState.ACTIVE.value, now, strategy_id, version))
        self.conn.commit()
        return self.get(strategy_id, version)

    def reject(self, strategy_id: str, version: int) -> StrategyVersion:
        item = self.get(strategy_id, version)
        if item.state != StrategyState.PROPOSED:
            raise ValueError("only PROPOSED strategies can be rejected")
        self.conn.execute("UPDATE strategy_versions SET state=? WHERE strategy_id=? AND version=?", (StrategyState.REJECTED.value, strategy_id, version))
        self.conn.commit()
        return self.get(strategy_id, version)

    def rollback(self, strategy_id: str, target_version: int, reason: str = "rollback") -> StrategyVersion:
        target = self.get(strategy_id, target_version)
        current = self.active(strategy_id)
        if target.version == current.version:
            raise ValueError("target version is already active")
        version = max(v.version for v in self.list(strategy_id)) + 1
        now = time.time()
        normalized = dict(target.weights)
        content_hash = self._hash(strategy_id, version, normalized, current.version)
        self.conn.execute("UPDATE strategy_versions SET state=? WHERE strategy_id=? AND state=?", (StrategyState.ROLLED_BACK.value, strategy_id, StrategyState.ACTIVE.value))
        self.conn.execute("INSERT INTO strategy_versions VALUES (?,?,?,?,?,?,?,?,?)", (strategy_id, version, json.dumps(normalized, sort_keys=True), StrategyState.ACTIVE.value, current.version, reason, now, now, content_hash))
        self.conn.commit()
        return self.get(strategy_id, version)

    def close(self) -> None:
        self.conn.close()
