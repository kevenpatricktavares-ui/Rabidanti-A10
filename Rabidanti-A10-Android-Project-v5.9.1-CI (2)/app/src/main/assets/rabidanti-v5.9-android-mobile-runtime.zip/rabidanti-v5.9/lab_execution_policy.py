"""Rabidanti v3.88: explicit execution policy and host capability assessment.

This module does not claim to create an OS sandbox. It helps deployments fail
closed when a required isolation profile is unavailable and records which
controls are policy requirements versus controls actually enforced by the host.
"""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json, os, platform, shutil

@dataclass(frozen=True)
class IsolationAssessment:
    profile: str
    platform: str
    container_runtime: str | None
    available_controls: tuple[str, ...]
    missing_controls: tuple[str, ...]
    safe_for_untrusted_code: bool
    assessed_at: str
    digest: str

class LabExecutionPolicy:
    REQUIRED = frozenset({"cpu_limit", "memory_limit", "process_limit", "network_isolation", "non_root", "disposable_filesystem"})
    PROFILES = {"trusted_smoke": frozenset({"timeout", "output_cap", "allowlist", "temporary_workspace", "restricted_environment"}),
                "untrusted_code": REQUIRED | frozenset({"timeout", "output_cap", "allowlist", "temporary_workspace", "restricted_environment"})}

    @classmethod
    def assess(cls, profile="trusted_smoke", declared_controls=()):
        if profile not in cls.PROFILES:
            raise ValueError("unknown isolation profile")
        declared = frozenset(declared_controls)
        if any(not isinstance(x, str) for x in declared):
            raise ValueError("control names must be strings")
        runtime = shutil.which("podman") or shutil.which("docker")
        available = set(declared)
        # These are host capabilities, not proof that a workload uses them.
        if os.name == "posix": available.add("posix_resource_limits_available")
        if runtime: available.add("container_runtime_available")
        missing = sorted(cls.PROFILES[profile] - declared)
        safe = not missing and profile == "untrusted_code"
        payload = {"profile":profile,"platform":platform.platform(),"container_runtime":runtime,
                   "available_controls":sorted(available),"missing_controls":missing,
                   "safe_for_untrusted_code":safe,"assessed_at":datetime.now(timezone.utc).isoformat()}
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return IsolationAssessment(profile, payload["platform"], runtime, tuple(sorted(available)), tuple(missing), safe, payload["assessed_at"], digest)

    @classmethod
    def require_profile(cls, profile="untrusted_code", declared_controls=()):
        assessment = cls.assess(profile, declared_controls)
        if profile == "untrusted_code" and not assessment.safe_for_untrusted_code:
            raise PermissionError("untrusted-code execution blocked: isolation controls are not all explicitly declared")
        return assessment

    @staticmethod
    def to_json(assessment):
        return json.dumps(asdict(assessment), indent=2, ensure_ascii=False)
