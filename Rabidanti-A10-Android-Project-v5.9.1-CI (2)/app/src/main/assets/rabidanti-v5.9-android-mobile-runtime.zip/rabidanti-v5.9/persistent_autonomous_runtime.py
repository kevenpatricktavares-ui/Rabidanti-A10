"""
Persistent Autonomous Task Runtime — Rabidanti v3.9

SQLite-backed persistence for autonomous tasks. The runtime keeps task state,
dependencies, ownership, retry counters, results and errors across process
restarts. RUNNING tasks can be recovered to QUEUED when explicitly recovered
at startup, preventing stale ownership from blocking future work.

This module is intentionally single-process/persistence-focused. Distributed
locking, external queues, autoscaling and cloud deployment remain later work.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Optional


class PersistentTaskState(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    WAITING = "WAITING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class PersistentTaskPriority(str, Enum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


_PRIORITY_WEIGHT = {
    PersistentTaskPriority.LOW: 0,
    PersistentTaskPriority.NORMAL: 1,
    PersistentTaskPriority.HIGH: 2,
    PersistentTaskPriority.CRITICAL: 3,
}


@dataclass
class PersistentAutonomousTask:
    task_id: str
    name: str
    priority: PersistentTaskPriority = PersistentTaskPriority.NORMAL
    state: PersistentTaskState = PersistentTaskState.QUEUED
    dependencies: list[str] = field(default_factory=list)
    attempts: int = 0
    max_attempts: int = 3
    owner: Optional[str] = None
    result: Any = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)


class PersistentAutonomousTaskRuntime:
    """Durable task state machine backed by SQLite."""

    def __init__(self, db_path: str = ":memory:") -> None:
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            db_path,
            check_same_thread=False,
            isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._configure()
        self._init_schema()

    def _configure(self) -> None:
        self._conn.execute("PRAGMA foreign_keys = ON")
        if self.db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")
            self._conn.execute("PRAGMA synchronous = NORMAL")

    def _init_schema(self) -> None:
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS autonomous_tasks (
                task_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                priority TEXT NOT NULL,
                state TEXT NOT NULL,
                dependencies_json TEXT NOT NULL,
                attempts INTEGER NOT NULL,
                max_attempts INTEGER NOT NULL,
                owner TEXT,
                result_json TEXT,
                error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS autonomous_task_events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT NOT NULL,
                event TEXT NOT NULL,
                worker TEXT,
                details_json TEXT,
                created_at REAL NOT NULL,
                FOREIGN KEY(task_id) REFERENCES autonomous_tasks(task_id)
                    ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_autonomous_tasks_state_priority
                ON autonomous_tasks(state, priority);
            CREATE INDEX IF NOT EXISTS idx_autonomous_task_events_task
                ON autonomous_task_events(task_id, event_id);
            """
        )

    @staticmethod
    def _encode(value: Any) -> Optional[str]:
        if value is None:
            return None
        return json.dumps(value, ensure_ascii=False, default=str)

    @staticmethod
    def _decode(value: Optional[str]) -> Any:
        return None if value is None else json.loads(value)

    def _row_to_task(self, row: sqlite3.Row) -> PersistentAutonomousTask:
        return PersistentAutonomousTask(
            task_id=row["task_id"],
            name=row["name"],
            priority=PersistentTaskPriority(row["priority"]),
            state=PersistentTaskState(row["state"]),
            dependencies=json.loads(row["dependencies_json"]),
            attempts=int(row["attempts"]),
            max_attempts=int(row["max_attempts"]),
            owner=row["owner"],
            result=self._decode(row["result_json"]),
            error=row["error"],
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
        )

    def _event(self, task_id: str, event: str, worker: Optional[str] = None, details: Any = None) -> None:
        self._conn.execute(
            """
            INSERT INTO autonomous_task_events(task_id,event,worker,details_json,created_at)
            VALUES(?,?,?,?,?)
            """,
            (task_id, event, worker, self._encode(details), time.time()),
        )

    def add(
        self,
        name: str,
        priority: PersistentTaskPriority = PersistentTaskPriority.NORMAL,
        dependencies: Optional[Iterable[str]] = None,
        max_attempts: int = 3,
        task_id: Optional[str] = None,
    ) -> PersistentAutonomousTask:
        if not name or not name.strip():
            raise ValueError("name is required")
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        task = PersistentAutonomousTask(
            task_id=task_id or str(uuid.uuid4()),
            name=name.strip(),
            priority=PersistentTaskPriority(priority),
            dependencies=list(dependencies or []),
            max_attempts=max_attempts,
        )
        now = time.time()
        task.created_at = task.updated_at = now
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO autonomous_tasks(
                    task_id,name,priority,state,dependencies_json,attempts,
                    max_attempts,owner,result_json,error,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    task.task_id, task.name, task.priority.value, task.state.value,
                    json.dumps(task.dependencies), task.attempts, task.max_attempts,
                    task.owner, self._encode(task.result), task.error,
                    task.created_at, task.updated_at,
                ),
            )
            self._event(task.task_id, "ADDED", details={"name": task.name})
        return task

    def get(self, task_id: str) -> Optional[PersistentAutonomousTask]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM autonomous_tasks WHERE task_id=?", (task_id,)
            ).fetchone()
        return None if row is None else self._row_to_task(row)

    def _dependencies_complete(self, task: PersistentAutonomousTask) -> bool:
        for dep_id in task.dependencies:
            dep = self.get(dep_id)
            if dep is None or dep.state != PersistentTaskState.COMPLETED:
                return False
        return True

    def ready(self) -> list[PersistentAutonomousTask]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT * FROM autonomous_tasks
                WHERE state=?
                """,
                (PersistentTaskState.QUEUED.value,),
            ).fetchall()
        tasks = [self._row_to_task(r) for r in rows]
        tasks = [t for t in tasks if self._dependencies_complete(t)]
        return sorted(
            tasks,
            key=lambda t: (-_PRIORITY_WEIGHT[t.priority], t.created_at),
        )

    def runnable(self) -> list[PersistentAutonomousTask]:
        return self.ready()

    def claim(self, task_id: str, worker: str) -> PersistentAutonomousTask:
        if not worker or not worker.strip():
            raise ValueError("worker is required")
        with self._lock:
            task = self.get(task_id)
            if task is None:
                raise KeyError(task_id)
            if task.state != PersistentTaskState.QUEUED:
                raise ValueError("task is not queued")
            if not self._dependencies_complete(task):
                raise ValueError("dependencies are not complete")
            now = time.time()
            self._conn.execute(
                """
                UPDATE autonomous_tasks
                SET state=?, owner=?, attempts=attempts+1, updated_at=?
                WHERE task_id=? AND state=?
                """,
                (
                    PersistentTaskState.RUNNING.value, worker.strip(), now,
                    task_id, PersistentTaskState.QUEUED.value,
                ),
            )
            updated = self.get(task_id)
            if updated is None or updated.state != PersistentTaskState.RUNNING:
                raise RuntimeError("failed to claim task")
            self._event(task_id, "CLAIMED", worker=worker)
            return updated

    def complete(self, task_id: str, worker: str, result: Any = None) -> PersistentAutonomousTask:
        with self._lock:
            task = self.get(task_id)
            if task is None:
                raise KeyError(task_id)
            if task.state != PersistentTaskState.RUNNING:
                raise ValueError("task is not running")
            if task.owner != worker:
                raise PermissionError("worker does not own task")
            now = time.time()
            self._conn.execute(
                """
                UPDATE autonomous_tasks
                SET state=?, owner=NULL, result_json=?, error=NULL, updated_at=?
                WHERE task_id=?
                """,
                (
                    PersistentTaskState.COMPLETED.value,
                    self._encode(result), now, task_id,
                ),
            )
            self._event(task_id, "COMPLETED", worker=worker, details={"result": result})
            return self.get(task_id)  # type: ignore[return-value]

    def fail(self, task_id: str, worker: str, error: str) -> PersistentAutonomousTask:
        with self._lock:
            task = self.get(task_id)
            if task is None:
                raise KeyError(task_id)
            if task.state != PersistentTaskState.RUNNING:
                raise ValueError("task is not running")
            if task.owner != worker:
                raise PermissionError("worker does not own task")
            next_state = (
                PersistentTaskState.QUEUED
                if task.attempts < task.max_attempts
                else PersistentTaskState.FAILED
            )
            now = time.time()
            self._conn.execute(
                """
                UPDATE autonomous_tasks
                SET state=?, owner=NULL, error=?, updated_at=?
                WHERE task_id=?
                """,
                (next_state.value, error, now, task_id),
            )
            self._event(task_id, "FAILED" if next_state == PersistentTaskState.FAILED else "RETRY",
                        worker=worker, details={"error": error})
            return self.get(task_id)  # type: ignore[return-value]

    def cancel(self, task_id: str, reason: Optional[str] = None) -> PersistentAutonomousTask:
        with self._lock:
            task = self.get(task_id)
            if task is None:
                raise KeyError(task_id)
            if task.state in {
                PersistentTaskState.COMPLETED,
                PersistentTaskState.FAILED,
                PersistentTaskState.CANCELLED,
            }:
                raise ValueError("task cannot be cancelled in its current state")
            now = time.time()
            self._conn.execute(
                """
                UPDATE autonomous_tasks
                SET state=?, owner=NULL, error=?, updated_at=?
                WHERE task_id=?
                """,
                (PersistentTaskState.CANCELLED.value, reason, now, task_id),
            )
            self._event(task_id, "CANCELLED", details={"reason": reason})
            return self.get(task_id)  # type: ignore[return-value]

    def recover_running(self) -> list[PersistentAutonomousTask]:
        """Recover RUNNING tasks after restart into QUEUED.

        Ownership is cleared so a new worker can safely claim them. The attempt
        already consumed remains counted; if the task has exhausted attempts,
        it is marked FAILED instead.
        """
        recovered: list[PersistentAutonomousTask] = []
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM autonomous_tasks WHERE state=?",
                (PersistentTaskState.RUNNING.value,),
            ).fetchall()
            for row in rows:
                task = self._row_to_task(row)
                if task.attempts >= task.max_attempts:
                    new_state = PersistentTaskState.FAILED
                else:
                    new_state = PersistentTaskState.QUEUED
                now = time.time()
                self._conn.execute(
                    """
                    UPDATE autonomous_tasks
                    SET state=?, owner=NULL, error=?, updated_at=?
                    WHERE task_id=?
                    """,
                    (
                        new_state.value,
                        "Recovered after runtime restart" if new_state == PersistentTaskState.QUEUED
                        else "Attempts exhausted during runtime recovery",
                        now,
                        task.task_id,
                    ),
                )
                self._event(task.task_id, "RECOVERED", details={"new_state": new_state.value})
                updated = self.get(task.task_id)
                if updated is not None:
                    recovered.append(updated)
        return recovered

    def list(self, state: Optional[PersistentTaskState] = None) -> list[PersistentAutonomousTask]:
        with self._lock:
            if state is None:
                rows = self._conn.execute(
                    "SELECT * FROM autonomous_tasks ORDER BY created_at"
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM autonomous_tasks WHERE state=? ORDER BY created_at",
                    (PersistentTaskState(state).value,),
                ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def history(self, task_id: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT event_id,event,worker,details_json,created_at
                FROM autonomous_task_events
                WHERE task_id=?
                ORDER BY event_id
                """,
                (task_id,),
            ).fetchall()
        return [
            {
                "event_id": int(r["event_id"]),
                "event": r["event"],
                "worker": r["worker"],
                "details": self._decode(r["details_json"]),
                "created_at": float(r["created_at"]),
            }
            for r in rows
        ]

    def close(self) -> None:
        with self._lock:
            self._conn.close()
