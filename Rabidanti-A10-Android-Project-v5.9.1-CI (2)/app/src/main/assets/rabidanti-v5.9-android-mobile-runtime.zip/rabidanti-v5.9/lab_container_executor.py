"""Rabidanti v3.90: fail-closed container plan executor.

Only executes an operator-approved, digest-pinned, no-network container plan.
Runtime must be present and reachable. This is not a substitute for host hardening.
"""
from dataclasses import dataclass
import hashlib
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

@dataclass(frozen=True)
class ExecutionResult:
    status: str
    executed: bool
    return_code: int | None
    stdout: str
    stderr: str
    started_at: str
    finished_at: str
    audit_digest: str

class LabContainerExecutor:
    MAX_TIMEOUT = 300
    MAX_OUTPUT = 8000

    @classmethod
    def execute(cls, plan, probe, *, approved=False, timeout=None):
        """Execute a reviewed plan only if all fail-closed gates pass.

        `approved` must be explicitly true for this invocation; no persistent
        approval is inferred. Network-enabled plans are rejected.
        """
        if not isinstance(plan, dict) or not isinstance(probe, dict):
            raise ValueError("plan and probe must be dictionaries")
        args = plan.get("runtime_args")
        if not isinstance(args, list) or len(args) < 10 or not all(isinstance(x, str) for x in args):
            raise ValueError("invalid runtime plan")
        if plan.get("execution_performed") is not False:
            raise ValueError("plan must be an unexecuted plan")
        if plan.get("network_enabled") is not False or "--network=none" not in args:
            raise PermissionError("network-enabled plans are not permitted by this executor")
        if not approved:
            raise PermissionError("explicit per-run operator approval required")
        if timeout is None:
            timeout = plan.get("timeout_seconds", 30)
        if not isinstance(timeout, int) or not 1 <= timeout <= cls.MAX_TIMEOUT:
            raise ValueError("timeout must be an integer from 1 to 300 seconds")
        # Enforce critical flags independently of the plan builder.
        required = ("--rm", "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--user=65534:65534", "--network=none")
        if any(flag not in args for flag in required):
            raise PermissionError("plan is missing a mandatory isolation flag")
        image = next((a for a in args if "@sha256:" in a), None)
        if not image or len(image.rsplit("@sha256:", 1)[1]) != 64:
            raise ValueError("digest-pinned image required")
        # Ensure the writable bind mount source exists and is an absolute directory.
        mount_index = args.index("--mount") if "--mount" in args else -1
        if mount_index < 0 or mount_index + 1 >= len(args):
            raise ValueError("bind mount missing")
        mount = args[mount_index + 1]
        mount_parts = mount.split(",")
        fields = dict(part.split("=", 1) for part in mount_parts if "=" in part)
        workspace = fields.get("src")
        if fields.get("type") != "bind" or fields.get("dst") != "/work" or "rw" not in mount_parts:
            raise ValueError("unexpected workspace mount")
        if not workspace or not os.path.isabs(workspace) or not Path(workspace).is_dir():
            raise ValueError("workspace must be an existing absolute directory")
        if probe.get("available") is not True or probe.get("daemon_reachable") is not True:
            return cls._result("blocked_runtime_unavailable", False, None, "", "Container runtime unavailable or unreachable", None, None)
        runtime = probe.get("runtime")
        if runtime not in ("docker", "podman"):
            raise ValueError("unsupported runtime")
        runtime_path = shutil.which(runtime)
        if not runtime_path:
            return cls._result("blocked_runtime_missing", False, None, "", "Runtime executable not found", None, None)
        started = datetime.now(timezone.utc).isoformat()
        try:
            p = subprocess.run([runtime_path, "run", *args], capture_output=True, text=True,
                timeout=min(timeout, plan.get("timeout_seconds", timeout)), check=False,
                env={"PATH": "/usr/bin:/bin", "LANG": "C", "HOME": "/tmp"})
            status = "completed" if p.returncode == 0 else "failed"
            return cls._result(status, True, p.returncode, (p.stdout or "")[:cls.MAX_OUTPUT], (p.stderr or "")[:cls.MAX_OUTPUT], started, datetime.now(timezone.utc).isoformat())
        except subprocess.TimeoutExpired as exc:
            out = exc.stdout or ""; err = exc.stderr or ""
            if isinstance(out, bytes): out = out.decode("utf-8", "replace")
            if isinstance(err, bytes): err = err.decode("utf-8", "replace")
            return cls._result("timeout", True, None, out[:cls.MAX_OUTPUT], err[:cls.MAX_OUTPUT], started, datetime.now(timezone.utc).isoformat())
        except OSError as exc:
            return cls._result("execution_error", False, None, "", str(exc)[:cls.MAX_OUTPUT], started, datetime.now(timezone.utc).isoformat())

    @staticmethod
    def _result(status, executed, return_code, stdout, stderr, started, finished):
        body = {"status":status,"executed":executed,"return_code":return_code,"stdout":stdout,"stderr":stderr,"started_at":started,"finished_at":finished}
        digest = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
        return ExecutionResult(status, executed, return_code, stdout, stderr, started or "", finished or "", digest)
