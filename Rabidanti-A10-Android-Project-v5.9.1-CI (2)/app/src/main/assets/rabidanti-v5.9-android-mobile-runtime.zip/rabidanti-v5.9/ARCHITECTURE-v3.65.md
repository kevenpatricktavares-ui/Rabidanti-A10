# Rabidanti v3.65 — Controlled Experiment Promotion

v3.65 adds governance between a promising forward experiment and any possible production change.

Flow:
`Forward Experiment → Evidence → PROMOTION_PENDING → Explicit Approval → Approved Proposal → Explicit Apply`

Rules:
- A promising result is not automatically a production change.
- Production weights are never mutated by the experiment engine or promotion controller.
- Dependencies, capacity, approvals, durable queue claims and worker ownership remain authoritative.
- Applying a proposal requires an explicit caller approval flag and returns a new configuration for the application's versioned configuration boundary.
- Proposal snapshots are checked against the experiment before application.
- Insufficient, rejected or non-promising evidence cannot be promoted.
- Association and forward completion-rate differences are not treated as causal proof.
