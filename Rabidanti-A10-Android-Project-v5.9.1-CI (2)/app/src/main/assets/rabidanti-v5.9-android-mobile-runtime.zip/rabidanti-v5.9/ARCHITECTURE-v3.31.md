# Rabidanti v3.31 — Business Stage Execution Contracts

## Purpose
Wire the canonical business workflow to explicit, stable worker handler names.

## Flow
Core → Business Pipeline → handler contract → Durable Queue → Worker → registered domain engine

## Important boundary
This version does not fabricate domain engines. A stage without a registered implementation fails explicitly instead of producing fake business results.

## Handler names
`business.stage.<stage>` for each canonical stage.

## Context
Each handler receives project, stage, objective, pipeline version and contextual data.

## Validation
The pipeline now carries its handler identity in every durable payload. The registry adapts these payloads to the runner's handler interface.
