# Rabidanti v5.9

Current release documentation: `README-v5.9.md` and `ARCHITECTURE-v5.9.md`.

# Rabidanti v5.8

Rabidanti v5.8 adds a **read-only Observability & Diagnostics Dashboard** to the local Sala.

Open the **Operações** tab to see runtime health, task/queue failures, workers, recovery/liveness, model availability, providers, connectors, recent audit events and operational alerts in one place.

CLI equivalent:

```bash
python rabidanti.py --state-dir .rabidanti observe
```

The observability layer does not execute remediation, grant approvals, invoke connectors, unlock secrets, or authorize external actions.

For Windows native build handoff, see `WINDOWS-BUILD-HANDOFF.md`. For the integrated isolated readiness check, use:

```bash
python rabidanti.py --state-dir .rabidanti product self-test
```

See `README-v5.8.md`, `ARCHITECTURE-v5.8.md`, and `VALIDATION-REPORT-v5.8.md` for details.
