from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from rabidanti_desktop import DesktopInstanceLease, AlreadyRunningError, _pid_alive
from rabidanti_launcher import launcher_args
from rabidanti_product import default_state_dir


def test_version_is_at_least_5_2():
    version = tuple(map(int, Path('VERSION').read_text().strip().split('.')))
    assert version >= (5, 2, 0)


def test_default_launcher_uses_product_state_and_room(monkeypatch, tmp_path):
    monkeypatch.setenv('RABIDANTI_STATE_DIR', str(tmp_path / 'state'))
    args = launcher_args([])
    assert args[-1] == 'room'
    assert args[:2] == ['--state-dir', str((tmp_path / 'state').resolve())]


def test_desktop_lease_acquire_and_release(tmp_path):
    lease = DesktopInstanceLease(tmp_path)
    payload = lease.acquire()
    assert payload['pid'] == os.getpid()
    assert lease.path.exists()
    data = json.loads(lease.path.read_text())
    assert data['token'] == payload['token']
    lease.release()
    assert not lease.path.exists()


def test_desktop_lease_blocks_live_owner(tmp_path):
    lease = DesktopInstanceLease(tmp_path)
    lease.acquire()
    try:
        with pytest.raises(AlreadyRunningError):
            DesktopInstanceLease(tmp_path).acquire()
    finally:
        lease.release()


def test_desktop_lease_recovers_stale_owner(tmp_path):
    path = tmp_path / 'desktop-instance.lock'
    path.write_text(json.dumps({'pid': 99999999, 'token': 'old'}))
    lease = DesktopInstanceLease(tmp_path)
    payload = lease.acquire()
    try:
        assert payload['pid'] == os.getpid()
        assert json.loads(path.read_text())['token'] == payload['token']
    finally:
        lease.release()


def test_release_does_not_remove_someone_elses_lock(tmp_path):
    lease = DesktopInstanceLease(tmp_path)
    lease.acquire()
    path = lease.path
    path.write_text(json.dumps({'pid': os.getpid(), 'token': 'different'}))
    lease.release()
    assert path.exists()


def test_pyinstaller_spec_is_windowed_and_has_metadata():
    text = Path('Rabidanti.spec').read_text()
    assert 'console=False' in text
    assert 'icon="assets/rabidanti.ico"' in text
    assert 'version="rabidanti_version_info.txt"' in text


def test_icon_and_windows_version_metadata_exist():
    icon = Path('assets/rabidanti.ico')
    assert icon.exists() and icon.stat().st_size > 1000
    info = Path('rabidanti_version_info.txt').read_text()
    current = Path('VERSION').read_text().strip()
    assert f"ProductVersion', '{current}'" in info
    assert "OriginalFilename', 'Rabidanti.exe'" in info


def test_installer_is_per_user_and_build_requires_real_exe():
    iss = Path('installer_windows.iss').read_text()
    assert 'PrivilegesRequired=lowest' in iss
    assert '{localappdata}\\Programs\\Rabidanti' in iss
    build = Path('build_windows.bat').read_text()
    assert 'dist\\Rabidanti.exe' in build
    assert 'product build-info' in build


def test_source_windows_launcher_uses_pythonw():
    text = Path('START-RABIDANTI.bat').read_text().lower()
    assert 'pythonw.exe' in text
    assert 'start "rabidanti"' in text
