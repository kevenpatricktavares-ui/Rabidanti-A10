"""Rabidanti v3.21 — capacity history, lightweight forecasting and prioritization."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import time

from resource_capacity import ResourceCapacityMonitor, CapacityReport

@dataclass(frozen=True)
class CapacitySample:
    timestamp: float
    queued: int
    active: int
    capacity: int

@dataclass(frozen=True)
class CapacityForecast:
    horizon_seconds: float
    current_queue: int
    projected_queue: float
    queue_trend_per_second: float
    estimated_clear_seconds: Optional[float]
    pressure: str
    recommendation: str
    timestamp: float

class CapacityIntelligence:
    """Keep bounded local history and derive conservative capacity forecasts."""
    def __init__(self, monitor: ResourceCapacityMonitor, max_samples: int = 120):
        if max_samples < 2:
            raise ValueError("max_samples must be >= 2")
        self.monitor = monitor
        self.max_samples = int(max_samples)
        self._samples: list[CapacitySample] = []

    def observe(self, capacity: int, active: int, now: Optional[float] = None) -> CapacityReport:
        report = self.monitor.analyze(capacity, active, now=now)
        self._samples.append(CapacitySample(report.timestamp, report.queued, report.active, report.capacity))
        if len(self._samples) > self.max_samples:
            del self._samples[:-self.max_samples]
        return report

    @property
    def samples(self) -> tuple[CapacitySample, ...]:
        return tuple(self._samples)

    def forecast(self, horizon_seconds: float = 60.0, now: Optional[float] = None) -> CapacityForecast:
        if horizon_seconds <= 0:
            raise ValueError("horizon_seconds must be > 0")
        if not self._samples:
            raise RuntimeError("at least one observation is required")
        now = time.time() if now is None else float(now)
        current = self._samples[-1]
        if len(self._samples) < 2:
            trend = 0.0
        else:
            first, last = self._samples[0], self._samples[-1]
            dt = last.timestamp - first.timestamp
            trend = (last.queued - first.queued) / dt if dt > 0 else 0.0
        projected = max(0.0, current.queued + trend * horizon_seconds)
        clear_seconds: Optional[float] = None
        if current.queued > 0 and trend < 0:
            clear_seconds = current.queued / abs(trend)
        pressure = "RISING" if trend > 1e-9 else "FALLING" if trend < -1e-9 else "STABLE"
        if projected > current.capacity * 2:
            recommendation = "PRIORITIZE_AND_REDUCE_INTAKE"
        elif trend > 0 and current.queued > 0:
            recommendation = "PRIORITIZE_BACKLOG"
        elif current.queued and clear_seconds is not None:
            recommendation = "CONTINUE_PROCESSING"
        else:
            recommendation = "MAINTAIN"
        return CapacityForecast(horizon_seconds, current.queued, projected, trend,
                                clear_seconds, pressure, recommendation, now)

    def priority_plan(self, priorities: list[int], available_slots: int) -> list[int]:
        """Return highest-priority values first without mutating queue state."""
        if available_slots < 0:
            raise ValueError("available_slots must be >= 0")
        return sorted(priorities, reverse=True)[:available_slots]
