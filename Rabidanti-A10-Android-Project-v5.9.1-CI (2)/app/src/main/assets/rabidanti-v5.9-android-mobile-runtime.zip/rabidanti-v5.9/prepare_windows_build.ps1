param(
    [switch]$BootstrapPython,
    [string]$Report = "windows-build-handoff.json"
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

if ($env:OS -ne "Windows_NT") { throw "This preparation script must run on Windows." }
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw "Python Launcher (py.exe) is required." }

if (-not (Test-Path ".build-venv\Scripts\python.exe")) {
    if (-not $BootstrapPython) { throw "Build venv missing. Re-run with -BootstrapPython." }
    py -3 -m venv .build-venv
}

$Python = Join-Path $Root ".build-venv\Scripts\python.exe"
if ($BootstrapPython) {
    & $Python -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed" }
    & $Python -m pip install -r requirements-dev.txt
    if ($LASTEXITCODE -ne 0) { throw "requirements-dev install failed" }
}

& $Python windows_handoff.py --toolchain --output $Report
$Code = $LASTEXITCODE
if ($Code -eq 3) {
    Write-Host "Windows toolchain is incomplete. Inspect $Report."
    Write-Host "Install Inno Setup 6 (ISCC.exe) and re-run this script."
    exit 3
}
if ($Code -ne 0) { exit $Code }
Write-Host "Windows build environment is ready. Report: $Report"
