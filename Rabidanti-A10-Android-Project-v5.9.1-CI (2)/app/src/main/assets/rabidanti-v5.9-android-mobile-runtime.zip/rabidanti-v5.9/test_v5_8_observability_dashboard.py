from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import json
import urllib.request

from rabidanti_observability import OperationalObservability
from rabidanti_api import RabidantiApiService
from rabidanti_runtime import RabidantiRuntime
from rabidanti import build_parser


class FakeRuntime:
    version = "5.8.0"
    def __init__(self, root: Path):
        root.mkdir(parents=True, exist_ok=True)
        self.paths = SimpleNamespace(root=root)
        self._status = {
            "tasks": {"total": 0, "counts": {"FAILED": 0}},
            "queue": {"total": 0, "counts": {"FAILED": 0}},
            "workers": {"healthy": True, "total": 0, "counts": {}, "stale_worker_ids": []},
            "connectors": {"registered": 0, "enabled": 0},
        }
        self._doctor = {"healthy": True, "checks": [{"name": "version", "ok": True, "detail": "5.8.0"}, {"name": "container_runtime", "ok": True, "detail": "available"}]}
        self._model = {"reachable": True, "selected": "local-model", "model": "local-model"}
        self._providers = []
        self._connectors = []
    def status(self): return self._status
    def doctor(self): return self._doctor
    def provider_status(self): return self._providers
    def list_connectors(self): return self._connectors
    def model_status(self): return self._model
    def runtime_events(self, limit=25): return [{"event_type":"TEST","created_at":"now","instance_id":"i","details":{}}]


def test_observability_healthy_snapshot_is_read_only(tmp_path):
    out = OperationalObservability(FakeRuntime(tmp_path)).snapshot()
    assert out["overall"] == "OK"
    assert out["healthy"] is True
    assert out["alerts"] == []
    assert out["safety"] == {"read_only": True, "automatic_remediation": False, "external_action_authorized": False, "self_authorization": False}
    assert out["product_self_test"]["automatic_run"] is False


def test_doctor_required_failure_is_critical(tmp_path):
    r=FakeRuntime(tmp_path); r._doctor={"healthy":False,"checks":[{"name":"runtime_db","ok":False,"detail":"corrupt"},{"name":"container_runtime","ok":True,"detail":"ok"}]}
    out=OperationalObservability(r).snapshot()
    assert out["overall"] == "CRITICAL"
    assert any(a["code"] == "DOCTOR_RUNTIME_DB" for a in out["alerts"])


def test_container_missing_is_warning_not_critical(tmp_path):
    r=FakeRuntime(tmp_path); r._doctor["checks"][-1]={"name":"container_runtime","ok":False,"detail":"missing"}
    out=OperationalObservability(r).snapshot()
    assert out["overall"] == "WARNING"
    assert any(a["code"] == "CONTAINER_RUNTIME_UNAVAILABLE" for a in out["alerts"])


def test_stale_worker_is_critical(tmp_path):
    r=FakeRuntime(tmp_path); r._status["workers"]={"healthy":False,"total":1,"counts":{"STALE":1},"stale_worker_ids":["w1"]}
    out=OperationalObservability(r).snapshot()
    assert out["overall"] == "CRITICAL"
    assert any(a["code"] == "STALE_WORKERS" and "w1" in a["detail"] for a in out["alerts"])


def test_failed_tasks_and_queue_are_warnings(tmp_path):
    r=FakeRuntime(tmp_path); r._status["tasks"]={"total":2,"counts":{"FAILED":2}}; r._status["queue"]={"total":1,"counts":{"FAILED":1}}
    out=OperationalObservability(r).snapshot()
    codes={a["code"] for a in out["alerts"]}
    assert {"FAILED_TASKS","FAILED_QUEUE_ITEMS"} <= codes
    assert out["overall"] == "WARNING"


def test_provider_and_model_alerts(tmp_path):
    r=FakeRuntime(tmp_path); r._providers=[{"provider_id":"google.gmail","display_name":"Gmail","status":"REVOKED"}]; r._model={"reachable":False,"error":"offline","selected":None}
    out=OperationalObservability(r).snapshot()
    codes={a["code"] for a in out["alerts"]}
    assert "PROVIDER_REVOKED" in codes and "MODEL_UNREACHABLE" in codes


def test_enabled_connector_without_handler_is_critical(tmp_path):
    r=FakeRuntime(tmp_path); r._connectors=[{"connector_id":"x","enabled":True,"secrets_ready":False,"runtime_handler_loaded":False}]
    out=OperationalObservability(r).snapshot()
    codes={a["code"] for a in out["alerts"]}
    assert "CONNECTOR_SECRETS_MISSING" in codes
    assert "CONNECTOR_HANDLER_MISSING" in codes
    assert out["overall"] == "CRITICAL"


def test_api_exposes_read_only_observability(tmp_path):
    runtime=RabidantiRuntime(tmp_path / "state")
    runtime.start()
    runtime.observability_snapshot=lambda: {"overall":"OK","safety":{"read_only":True,"automatic_remediation":False,"external_action_authorized":False,"self_authorization":False}}
    service=RabidantiApiService(runtime, port=0)
    try:
        addr=service.start()
        with urllib.request.urlopen(f"http://{addr.host}:{addr.port}/v1/observability", timeout=5) as response:
            data=json.loads(response.read())
        assert data["overall"] == "OK" and data["safety"]["read_only"] is True
    finally:
        service.stop(); runtime.stop()


def test_cli_has_observe_command():
    args=build_parser().parse_args(["observe"])
    assert args.command == "observe"


def test_sala_contains_operations_dashboard_and_read_only_endpoint():
    html=Path("ui/index.html").read_text(encoding="utf-8")
    js=Path("ui/app.js").read_text(encoding="utf-8")
    assert 'data-tab="observability"' in html
    assert 'id="observability"' in html
    assert "/v1/observability" in js
    assert "automatic remediation" not in js.lower()
    assert "remediação automática: não" in js


def test_version_is_at_least_5_8():
    version = tuple(int(x) for x in Path("VERSION").read_text().strip().split("."))
    assert version >= (5, 8, 0)
