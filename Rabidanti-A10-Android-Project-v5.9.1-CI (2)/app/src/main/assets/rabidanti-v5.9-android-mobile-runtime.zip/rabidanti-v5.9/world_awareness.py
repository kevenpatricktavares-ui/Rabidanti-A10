"""Rabidanti v3.46 — World Awareness foundation.

Evidence-first ingestion of externally obtained world information. This module
stores provenance, publication/fetched timestamps, freshness and normalized
signals. It deliberately does not fetch the web itself and never claims that a
source was verified unless the caller records verification.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Optional
import json, sqlite3, threading, time, uuid

@dataclass(frozen=True)
class WorldSource:
    source_id: str
    title: str
    locator: str
    publisher: str
    kind: str
    published_at: Optional[float]
    fetched_at: float
    verified: bool
    content_hash: str
    summary: str
    def to_dict(self): return asdict(self)

@dataclass(frozen=True)
class WorldSignal:
    signal_id: str
    source_id: str
    topic: str
    statement: str
    confidence: float
    freshness: float
    created_at: float
    def to_dict(self): return asdict(self)

class WorldAwarenessStore:
    def __init__(self, db_path: str):
        self.db_path=db_path; self._lock=threading.RLock()
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory=sqlite3.Row
        if db_path != ':memory:': self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS world_sources (
            source_id TEXT PRIMARY KEY, title TEXT NOT NULL, locator TEXT NOT NULL,
            publisher TEXT NOT NULL, kind TEXT NOT NULL, published_at REAL,
            fetched_at REAL NOT NULL, verified INTEGER NOT NULL, content_hash TEXT NOT NULL,
            summary TEXT NOT NULL)''')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS world_signals (
            signal_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, topic TEXT NOT NULL,
            statement TEXT NOT NULL, confidence REAL NOT NULL, freshness REAL NOT NULL,
            created_at REAL NOT NULL)''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_world_sources_fetched ON world_sources(fetched_at)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_world_signals_topic ON world_signals(topic)')
    def save_source(self, s: WorldSource):
        with self._lock:
            self._conn.execute('INSERT OR REPLACE INTO world_sources VALUES(?,?,?,?,?,?,?,?,?,?)',
                (s.source_id,s.title,s.locator,s.publisher,s.kind,s.published_at,s.fetched_at,int(s.verified),s.content_hash,s.summary))
    def source(self, source_id):
        with self._lock: r=self._conn.execute('SELECT * FROM world_sources WHERE source_id=?',(source_id,)).fetchone()
        return None if not r else WorldSource(**dict(r)|{'verified':bool(r['verified'])})
    def sources(self, limit=100):
        with self._lock: rows=self._conn.execute('SELECT * FROM world_sources ORDER BY fetched_at DESC LIMIT ?',(int(limit),)).fetchall()
        return [WorldSource(**dict(r)|{'verified':bool(r['verified'])}) for r in rows]
    def save_signal(self, s: WorldSignal):
        with self._lock: self._conn.execute('INSERT OR REPLACE INTO world_signals VALUES(?,?,?,?,?,?,?)',tuple(asdict(s).values()))
    def signals(self, topic=None, limit=100):
        with self._lock:
            if topic: rows=self._conn.execute('SELECT * FROM world_signals WHERE topic=? ORDER BY created_at DESC LIMIT ?',(topic,int(limit))).fetchall()
            else: rows=self._conn.execute('SELECT * FROM world_signals ORDER BY created_at DESC LIMIT ?',(int(limit),)).fetchall()
        return [WorldSignal(**dict(r)) for r in rows]

class WorldAwareness:
    def __init__(self, store: WorldAwarenessStore): self.store=store
    def ingest_source(self, *, title, locator, publisher, kind='web', published_at=None, verified=False, content_hash='', summary=''):
        if not all(str(x).strip() for x in (title,locator,publisher,kind)): raise ValueError('title, locator, publisher and kind are required')
        if published_at is not None and float(published_at) > time.time()+60: raise ValueError('published_at cannot be materially in the future')
        s=WorldSource('world-'+uuid.uuid4().hex,title.strip(),locator.strip(),publisher.strip(),kind.strip(),published_at,time.time(),bool(verified),content_hash.strip(),summary.strip())
        self.store.save_source(s); return s
    def add_signal(self, source_id, *, topic, statement, confidence, now=None):
        if self.store.source(source_id) is None: raise KeyError('world source not found')
        if not topic.strip() or not statement.strip(): raise ValueError('topic and statement are required')
        if not 0 <= float(confidence) <= 1: raise ValueError('confidence must be between 0 and 1')
        source=self.store.source(source_id); now=time.time() if now is None else float(now)
        age=max(0.0,now-source.fetched_at); freshness=round(1.0/(1.0+age/86400.0),4)
        s=WorldSignal('wsignal-'+uuid.uuid4().hex,source_id,topic.strip(),statement.strip(),float(confidence),freshness,now)
        self.store.save_signal(s); return s
    def snapshot(self, topic=None, limit=100):
        signals=self.store.signals(topic,limit)
        sources={s.source_id:s for s in self.store.sources(500)}
        return {'topic':topic,'sources':[s.to_dict() for s in self.store.sources(limit)],'signals':[x.to_dict() for x in signals],
                'verified_source_count':sum(1 for s in sources.values() if s.verified)}
