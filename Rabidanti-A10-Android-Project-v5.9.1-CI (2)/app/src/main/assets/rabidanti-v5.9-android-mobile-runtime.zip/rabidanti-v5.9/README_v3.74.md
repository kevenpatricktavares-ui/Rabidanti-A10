# Rabidanti v3.74 — Evolution Runtime

Coordinates the controlled evolution loop:

signal/evidence -> decision -> gate -> persistent audit -> controller

The runtime is an orchestration layer only. It cannot activate strategies,
change Core state, bypass approval, or replace the Evolution Controller.
