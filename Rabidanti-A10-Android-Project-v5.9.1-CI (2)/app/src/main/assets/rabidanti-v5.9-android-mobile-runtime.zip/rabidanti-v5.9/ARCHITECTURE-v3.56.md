# Rabidanti v3.56 — Verified Knowledge Graph Integration

Connects Source Verification to the World Knowledge Graph while preserving provenance and uncertainty.

## Flow
Source Acquisition -> Verification/Evidence Fusion -> Claim Assessment -> Knowledge Graph
World Awareness -> Signal Entity -> Knowledge Graph (descriptive only)

## Rules
- VERIFIED/SUPPORTED assessments can be materialized with claim_id and confidence.
- CONTESTED remains CONTESTED.
- CONTRADICTED maps to REJECTED rather than silently becoming truth.
- INSUFFICIENT is not materialized by `materialize_if_supported`.
- World signals become descriptive entities only; signals are not facts.
- Existing graph relations remain provenance-aware and queryable.
