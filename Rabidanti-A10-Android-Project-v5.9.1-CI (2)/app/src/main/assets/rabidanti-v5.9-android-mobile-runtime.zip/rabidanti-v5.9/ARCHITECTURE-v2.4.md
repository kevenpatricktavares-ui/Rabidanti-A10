# Rabidanti v2.4 — Interactive Product Foundation

Interactive products are now a first-class product category.

Types:
- calculator
- simulator
- planner
- assessment
- document_generator
- dashboard
- educational_tool
- niche_web_tool

Flow:
Research -> Opportunity -> Product -> Interactive Product Brief
-> Persona/Character/Audiovisual context -> validation -> human review
-> future rendering/deployment.

Safety boundary:
No arbitrary code execution, unnecessary personal-data collection, secret
exposure, or automatic external publication.

Done criteria:
structured brief, validation, declared logic, integrations, automated tests.
