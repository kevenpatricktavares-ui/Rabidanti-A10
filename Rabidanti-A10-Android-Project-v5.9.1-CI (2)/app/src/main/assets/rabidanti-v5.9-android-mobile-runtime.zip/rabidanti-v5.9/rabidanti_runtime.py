"""Rabidanti v4.0 — unified local runtime MVP.

This module assembles the durable building blocks developed through v3.99 into
one explicit runtime. It is a local control plane: it does not imply cloud
operation, unrestricted autonomy, external-account access, or scientific truth.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
import json
import os
import shutil
import sqlite3
import sys
import uuid

from core_orchestrator import CoreOrchestrator
from durable_worker_queue import DurableWorkerQueue
from workflow_orchestrator import PersistentWorkflowOrchestrator
from persistent_autonomous_runtime import (
    PersistentAutonomousTaskRuntime,
    PersistentTaskPriority,
    PersistentTaskState,
)
from persistent_scheduler import PersistentScheduler
from worker_supervisor import WorkerSupervisor
from lab_experiment_manager import LabExperimentManager
from lab_evidence_memory import LabEvidenceMemory
from lab_evidence_integration import LabEvidenceIntegration
from lab_evidence_readiness import LabEvidenceReadinessGate
from lab_human_review import LabHumanReviewWorkflow
from lab_integration_proposal import LabIntegrationProposalWorkflow
from lab_controlled_change_executor import ControlledChangeExecutor
from rabidanti_config import RabidantiConfig, RabidantiSecrets, redact_sensitive
from rabidanti_connectors import ConnectorDefinition, ConnectorRegistry
from rabidanti_vault import EncryptedCredentialVault, VaultError
from rabidanti_oauth import OAuthPKCEManager, GOOGLE_GMAIL_READONLY, OAuthError, OAuthRevokedError
from gmail_connector import GmailReadOnlyHandler, gmail_definition
from rabidanti_providers import ProviderStateStore
from rabidanti_model_gateway import LocalOllamaGateway
from rabidanti_conversation import ConversationEngine
from rabidanti_model_manager import ModelManager
from rabidanti_reasoning import AgentReasoningRuntime
from rabidanti_proposal_bridge import ProposalExecutionBridge
from rabidanti_onboarding import FirstRunOnboarding
from rabidanti_observability import OperationalObservability


@dataclass(frozen=True)
class RuntimePaths:
    root: Path
    queue_db: Path
    tasks_db: Path
    workers_db: Path
    scheduler_db: Path
    laboratory_db: Path
    evidence_db: Path
    human_review_db: Path
    proposals_db: Path
    changes_db: Path
    runtime_db: Path
    config_file: Path
    connectors_db: Path
    vault_file: Path
    providers_db: Path
    conversations_db: Path
    reasoning_db: Path
    proposal_bridge_db: Path
    onboarding_file: Path

    @classmethod
    def under(cls, root: str | os.PathLike[str]) -> "RuntimePaths":
        base = Path(root).expanduser().resolve()
        return cls(
            root=base,
            queue_db=base / "queue.sqlite3",
            tasks_db=base / "tasks.sqlite3",
            workers_db=base / "workers.sqlite3",
            scheduler_db=base / "scheduler.sqlite3",
            laboratory_db=base / "laboratory.sqlite3",
            evidence_db=base / "evidence.sqlite3",
            human_review_db=base / "human_review.sqlite3",
            proposals_db=base / "integration_proposals.sqlite3",
            changes_db=base / "controlled_changes.sqlite3",
            runtime_db=base / "runtime.sqlite3",
            config_file=base / "config.json",
            connectors_db=base / "connectors.sqlite3",
            vault_file=base / "credentials.vault.json",
            providers_db=base / "providers.sqlite3",
            conversations_db=base / "conversations.sqlite3",
            reasoning_db=base / "reasoning.sqlite3",
            proposal_bridge_db=base / "proposal_bridge.sqlite3",
            onboarding_file=base / "onboarding.json",
        )


class RabidantiRuntime:
    """Unified, persistent, local Rabidanti runtime.

    The runtime exposes already-implemented subsystems through one lifecycle and
    one state directory. It intentionally does not auto-authorize integration or
    external actions.
    """

    RUNTIME_SCHEMA_VERSION = 1

    def __init__(self, state_dir: str | os.PathLike[str] = ".rabidanti") -> None:
        self.paths = RuntimePaths.under(state_dir)
        self.paths.root.mkdir(parents=True, exist_ok=True)
        self.version = self._read_version()
        self.config = RabidantiConfig(self.paths.config_file)
        self.secrets = RabidantiSecrets()
        self.vault = EncryptedCredentialVault(
            self.paths.vault_file, os.environ.get("RABIDANTI_VAULT_MASTER_KEY")
        )
        self.onboarding = FirstRunOnboarding(self.paths.onboarding_file)
        self.instance_id = f"runtime-{uuid.uuid4().hex}"
        self.started = False

        self.queue = DurableWorkerQueue(str(self.paths.queue_db))
        self.workflows = PersistentWorkflowOrchestrator(str(self.paths.queue_db), self.queue)
        self.core = CoreOrchestrator(self.workflows)
        self.tasks = PersistentAutonomousTaskRuntime(str(self.paths.tasks_db))
        self.workers = WorkerSupervisor(str(self.paths.workers_db))
        self.scheduler = PersistentScheduler(str(self.paths.scheduler_db))

        self.lab = LabExperimentManager(str(self.paths.laboratory_db))
        self.evidence = LabEvidenceMemory(str(self.paths.evidence_db))
        self.evidence_integration = LabEvidenceIntegration(self.lab, self.evidence)
        self.readiness = LabEvidenceReadinessGate(self.lab, self.evidence)
        self.human_reviews = LabHumanReviewWorkflow(
            self.lab, self.evidence, str(self.paths.human_review_db)
        )
        self.integration_proposals = LabIntegrationProposalWorkflow(
            self.human_reviews, self.evidence, str(self.paths.proposals_db)
        )
        self.change_executor = ControlledChangeExecutor(
            self.integration_proposals, str(self.paths.changes_db)
        )
        self._init_runtime_db()
        self.providers = ProviderStateStore(self.paths.providers_db)
        self.providers.register(
            GOOGLE_GMAIL_READONLY.provider_id,
            "Google Gmail Read-Only",
            scopes=GOOGLE_GMAIL_READONLY.scopes,
        )
        self.connectors = ConnectorRegistry(
            str(self.paths.connectors_db),
            secret_getter=self.get_secret,
            audit_callback=self._event,
        )
        self.oauth = OAuthPKCEManager(self.vault)
        self._register_builtin_connectors()
        self.model_gateway = self._build_model_gateway()
        self.model_manager = ModelManager(self.model_gateway)
        self.conversations = ConversationEngine(self.paths.conversations_db, self.model_gateway)
        self.reasoning = AgentReasoningRuntime(self.paths.reasoning_db, self.model_gateway)
        self.proposal_bridge = ProposalExecutionBridge(
            self.paths.proposal_bridge_db, self.reasoning, self.connectors, self.add_task, self._event
        )

    def _register_builtin_connectors(self) -> None:
        """Load built-in connector code without enabling external access."""
        handler = GmailReadOnlyHandler(self.get_secret)
        self.connectors.register(gmail_definition(), handler)


    def _build_model_gateway(self, model_override: Optional[str] = None) -> LocalOllamaGateway:
        return LocalOllamaGateway(
            base_url=self.config.get("ai.base_url"),
            model=model_override or self.config.get("ai.model"),
            timeout_seconds=self.config.get("ai.timeout_seconds"),
        )

    def _refresh_ai_runtime(self, *, resolve_model: bool = False) -> None:
        gateway = self._build_model_gateway()
        manager = ModelManager(gateway)
        if resolve_model:
            selection = manager.select(self.config.get("ai.model"), self.config.get("ai.fallback_model"))
            if selection.selected != gateway.model:
                gateway = self._build_model_gateway(selection.selected)
                manager = ModelManager(gateway)
        self.model_gateway = gateway
        self.model_manager = manager
        self.conversations.gateway = self.model_gateway
        self.reasoning.gateway = self.model_gateway

    def model_status(self) -> dict[str, Any]:
        cfg=self.get_config().get("ai", {})
        self._refresh_ai_runtime()
        managed=self.model_manager.status(cfg.get("model"), cfg.get("fallback_model"))
        return {"provider": cfg.get("provider"), "base_url": cfg.get("base_url"), "model": cfg.get("model"), "fallback_model": cfg.get("fallback_model"), **managed, "external_action_authorized": False}

    def list_models(self) -> dict[str, Any]:
        self._refresh_ai_runtime()
        cfg=self.get_config().get("ai", {})
        return {"items": self.model_manager.installed_models(), "configured": cfg.get("model"), "fallback_model": cfg.get("fallback_model"), "external_action_authorized": False}

    def reason(self, request: str, context: Optional[str] = None) -> dict[str, Any]:
        self._refresh_ai_runtime(resolve_model=True)
        result=self.reasoning.reason(request, context)
        self._event("REASONING_PROPOSAL_CREATED", {"reasoning_id": result["reasoning_id"], "proposal_count": len(result["proposed_actions"]), "model": result["model"]})
        return result

    def reasoning_proposals(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.reasoning.proposals(limit)

    def review_reasoning_proposal(self, proposal_id: str, *, decision: str, actor: str, reason: str) -> dict[str, Any]:
        return self.proposal_bridge.review(proposal_id, decision=decision, actor=actor, reason=reason)

    def authorize_reasoning_proposal(self, proposal_id: str, *, actor: str, reason: str) -> dict[str, Any]:
        return self.proposal_bridge.authorize(proposal_id, actor=actor, reason=reason)

    def execute_reasoning_proposal(self, proposal_id: str, *, actor: str) -> dict[str, Any]:
        return self.proposal_bridge.execute(proposal_id, actor=actor)

    def proposal_reviews(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.proposal_bridge.reviews(limit)

    def proposal_executions(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.proposal_bridge.executions(limit)

    def chat(self, message: str, conversation_id: Optional[str] = None) -> dict[str, Any]:
        # Resolve an installed primary/fallback model before sending the message.
        self._refresh_ai_runtime(resolve_model=True)
        result=self.conversations.chat(message, conversation_id)
        self._event("CONVERSATION_MESSAGE", {"conversation_id": result["conversation_id"], "model": result["message"]["model"]})
        return result

    def list_conversations(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.conversations.list_conversations(limit)

    def conversation_messages(self, conversation_id: str, limit: int = 100) -> list[dict[str, Any]]:
        return self.conversations.messages(conversation_id, limit)

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _read_version() -> str:
        version_file = Path(__file__).with_name("VERSION")
        return version_file.read_text(encoding="utf-8").strip()

    def _runtime_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.paths.runtime_db))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_runtime_db(self) -> None:
        with self._runtime_conn() as c:
            c.execute(
                """CREATE TABLE IF NOT EXISTS runtime_events(
                    event_id TEXT PRIMARY KEY,
                    instance_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    version TEXT NOT NULL,
                    details_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )"""
            )
            c.execute(
                """CREATE TABLE IF NOT EXISTS runtime_metadata(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )"""
            )
            c.execute(
                "INSERT OR REPLACE INTO runtime_metadata(key,value) VALUES(?,?)",
                ("schema_version", str(self.RUNTIME_SCHEMA_VERSION)),
            )

    def _event(self, event_type: str, details: Optional[dict[str, Any]] = None) -> None:
        with self._runtime_conn() as c:
            c.execute(
                "INSERT INTO runtime_events VALUES(?,?,?,?,?,?)",
                (
                    f"event-{uuid.uuid4().hex}",
                    self.instance_id,
                    event_type,
                    self.version,
                    json.dumps(redact_sensitive(details or {}), sort_keys=True, default=str),
                    self._now(),
                ),
            )

    def start(self, *, recover: bool = True) -> dict[str, Any]:
        if self.started:
            return self.status()
        recovered_tasks: list[Any] = []
        recovered_queue: list[str] = []
        if recover:
            recovered_tasks = self.tasks.recover_running()
            recovered_queue = self.queue.recover_expired()
        self.started = True
        self._event(
            "RUNTIME_STARTED",
            {
                "recover": recover,
                "recovered_tasks": [t.task_id for t in recovered_tasks],
                "recovered_queue_items": list(recovered_queue),
            },
        )
        return self.status()

    def stop(self) -> None:
        if self.started:
            self._event("RUNTIME_STOPPED")
            self.started = False
        self.close()

    def close(self) -> None:
        for component in (self.workflows, self.queue, self.tasks, self.workers):
            close = getattr(component, "close", None)
            if callable(close):
                try:
                    close()
                except sqlite3.ProgrammingError:
                    pass

    def __enter__(self) -> "RabidantiRuntime":
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.stop()

    def add_task(
        self,
        name: str,
        *,
        priority: str = "NORMAL",
        dependencies: Optional[list[str]] = None,
        max_attempts: int = 3,
        task_id: Optional[str] = None,
    ) -> dict[str, Any]:
        task = self.tasks.add(
            name=name,
            priority=PersistentTaskPriority(priority.upper()),
            dependencies=dependencies,
            max_attempts=max_attempts,
            task_id=task_id,
        )
        self._event("TASK_ADDED", {"task_id": task.task_id, "name": task.name})
        return self._task_dict(task)

    def list_tasks(self, state: Optional[str] = None) -> list[dict[str, Any]]:
        state_enum = None if state is None else PersistentTaskState(state.upper())
        return [self._task_dict(t) for t in self.tasks.list(state_enum)]

    @staticmethod
    def _task_dict(task: Any) -> dict[str, Any]:
        return {
            "task_id": task.task_id,
            "name": task.name,
            "priority": task.priority.value,
            "state": task.state.value,
            "dependencies": list(task.dependencies),
            "attempts": task.attempts,
            "max_attempts": task.max_attempts,
            "owner": task.owner,
            "result": task.result,
            "error": task.error,
            "created_at": task.created_at,
            "updated_at": task.updated_at,
        }


    def get_config(self) -> dict[str, Any]:
        return self.config.as_dict()

    def update_config(self, changes: dict[str, Any]) -> dict[str, Any]:
        updated = self.config.update(changes)
        self._event("CONFIG_UPDATED", {"keys": sorted(changes)})
        return updated

    def _raw_secret(self, name: str) -> Optional[str]:
        value = self.secrets.get(name)
        if value is not None:
            return value
        if self.vault.unlocked:
            try:
                return self.vault.get(name)
            except VaultError:
                return None
        return None

    def get_secret(self, name: str) -> Optional[str]:
        normalized = self.secrets.normalize_name(name)
        if normalized == "GMAIL_ACCESS_TOKEN":
            try:
                if self.providers.token_needs_refresh(GOOGLE_GMAIL_READONLY.provider_id):
                    self.refresh_google_gmail()
            except OAuthRevokedError as exc:
                self.providers.mark_revoked(GOOGLE_GMAIL_READONLY.provider_id, str(exc))
                self._event("PROVIDER_REVOKED", {"provider": GOOGLE_GMAIL_READONLY.provider_id})
                return None
            except (OAuthError, RuntimeError, ValueError) as exc:
                self.providers.mark_error(GOOGLE_GMAIL_READONLY.provider_id, str(exc))
                self._event("PROVIDER_REFRESH_FAILED", {"provider": GOOGLE_GMAIL_READONLY.provider_id, "error": str(exc)})
                return None
        return self._raw_secret(normalized)

    def secret_status(self, names: Optional[list[str]] = None) -> list[dict[str, Any]]:
        rows = {item["name"]: item for item in self.secrets.status(names)}
        candidates = set(names or []) | set(self.vault.names()) | set(rows)
        for raw in sorted(candidates):
            name = self.secrets.normalize_name(raw)
            if name in rows and rows[name].get("configured"):
                continue
            rows[name] = {
                "name": name,
                "configured": self.vault.unlocked and name in self.vault.names(),
                "source": "encrypted_vault" if self.vault.unlocked and name in self.vault.names() else None,
            }
        return [rows[k] for k in sorted(rows)]

    def onboarding_status(self) -> dict[str, Any]:
        status = self.onboarding.status()
        try:
            model = self.model_status()
        except Exception as exc:
            model = {"reachable": False, "selected": None, "error": type(exc).__name__}
        return {
            **status,
            "model": model,
            "vault": self.vault.status(),
            "config": {
                "ai": self.config.as_dict().get("ai", {}),
                "ui": self.config.as_dict().get("ui", {}),
                "logging": self.config.as_dict().get("logging", {}),
            },
        }

    def unlock_vault(self, master_key: str) -> dict[str, Any]:
        self.vault.unlock(master_key)
        self._event("VAULT_UNLOCKED", {"source": "local-session"})
        return self.vault.status()

    def complete_onboarding(
        self,
        *,
        model: str,
        fallback_model: str = "",
        auto_open_browser: bool = True,
        logging_level: str = "INFO",
        vault_master_key: Optional[str] = None,
    ) -> dict[str, Any]:
        if vault_master_key:
            self.unlock_vault(vault_master_key)
        changes = {
            "ai.model": model,
            "ai.fallback_model": fallback_model,
            "ui.auto_open_browser": auto_open_browser,
            "logging.level": logging_level,
        }
        self.update_config(changes)
        result = self.onboarding.complete(
            config_changes=changes,
            selected_model=model,
            fallback_model=fallback_model,
            vault_was_unlocked=self.vault.unlocked,
        )
        self._event("ONBOARDING_COMPLETED", {
            "model": model,
            "fallback_model": fallback_model,
            "vault_unlocked": self.vault.unlocked,
        })
        return self.onboarding_status()

    def vault_status(self) -> dict[str, Any]:
        return self.vault.status()

    def vault_set(self, name: str, value: str) -> dict[str, Any]:
        normalized = self.secrets.normalize_name(name)
        self.vault.set(normalized, value)
        self._event("VAULT_CREDENTIAL_SET", {"name": normalized})
        return {"name": normalized, "configured": True, "source": "encrypted_vault"}

    def vault_delete(self, name: str) -> dict[str, Any]:
        normalized = self.secrets.normalize_name(name)
        deleted = self.vault.delete(normalized)
        self._event("VAULT_CREDENTIAL_DELETED", {"name": normalized, "deleted": deleted})
        return {"name": normalized, "deleted": deleted}

    def configure_google_gmail_credentials(
        self, *, client_id: str, client_secret: Optional[str] = None, persist: bool = False
    ) -> dict[str, Any]:
        if not isinstance(client_id, str) or not client_id.strip():
            raise ValueError("client_id is required")
        client_id = client_id.strip()
        if len(client_id) > 500:
            raise ValueError("client_id is too long")
        if client_secret is not None and (not isinstance(client_secret, str) or not client_secret):
            raise ValueError("client_secret must be a non-empty string when provided")
        if persist:
            if not self.vault.unlocked:
                raise VaultError("vault must be unlocked to persist provider credentials")
            self.vault.set("GOOGLE_CLIENT_ID", client_id)
            if client_secret:
                self.vault.set("GOOGLE_CLIENT_SECRET", client_secret)
            source = "encrypted_vault"
        else:
            self.secrets.set_session("GOOGLE_CLIENT_ID", client_id)
            if client_secret:
                self.secrets.set_session("GOOGLE_CLIENT_SECRET", client_secret)
            source = "session"
        self._event(
            "PROVIDER_CREDENTIALS_CONFIGURED",
            {"provider": GOOGLE_GMAIL_READONLY.provider_id, "source": source, "client_secret_configured": bool(client_secret)},
        )
        return {
            "provider_id": GOOGLE_GMAIL_READONLY.provider_id,
            "client_id_configured": True,
            "client_secret_configured": bool(client_secret),
            "source": source,
        }

    def oauth_google_gmail_start(self, *, client_id: Optional[str] = None, redirect_uri: str) -> dict[str, Any]:
        resolved_client_id = client_id or self._raw_secret("GOOGLE_CLIENT_ID")
        if not resolved_client_id:
            raise ValueError("GOOGLE_CLIENT_ID is required")
        if client_id:
            # Keep the client id available for the loopback callback in this process.
            self.secrets.set_session("GOOGLE_CLIENT_ID", client_id)
        result = self.oauth.start(GOOGLE_GMAIL_READONLY, client_id=resolved_client_id, redirect_uri=redirect_uri)
        self._event("OAUTH_FLOW_STARTED", {"provider": "google_gmail_readonly", "flow_id": result["flow_id"]})
        return result

    def oauth_google_gmail_exchange(
        self, *, flow_id: str, state: str, code: str, client_id: Optional[str] = None, client_secret: Optional[str] = None
    ) -> dict[str, Any]:
        resolved_client_id = client_id or self._raw_secret("GOOGLE_CLIENT_ID")
        if not resolved_client_id:
            raise ValueError("GOOGLE_CLIENT_ID is required")
        result = self.oauth.exchange(
            GOOGLE_GMAIL_READONLY, flow_id=flow_id, state=state, code=code,
            client_id=resolved_client_id, client_secret=client_secret or self._raw_secret("GOOGLE_CLIENT_SECRET"),
        )
        self.providers.record_authorized(
            GOOGLE_GMAIL_READONLY.provider_id,
            expires_in=result.get("expires_in"),
            scopes=result.get("scope"),
        )
        self._event("OAUTH_FLOW_COMPLETED", {"provider": "google_gmail_readonly", "flow_id": flow_id})
        return result

    def oauth_google_gmail_complete_callback(self, *, state: str, code: str) -> dict[str, Any]:
        flow_id = self.oauth.find_flow_by_state(GOOGLE_GMAIL_READONLY, state)
        return self.oauth_google_gmail_exchange(flow_id=flow_id, state=state, code=code)

    def refresh_google_gmail(self) -> dict[str, Any]:
        client_id = self._raw_secret("GOOGLE_CLIENT_ID")
        refresh_token = self._raw_secret("GMAIL_REFRESH_TOKEN")
        if not client_id:
            raise OAuthError("GOOGLE_CLIENT_ID is required for token refresh")
        if not refresh_token:
            raise OAuthError("GMAIL_REFRESH_TOKEN is required for token refresh")
        try:
            result = self.oauth.refresh(
                GOOGLE_GMAIL_READONLY,
                client_id=client_id,
                refresh_token=refresh_token,
                client_secret=self._raw_secret("GOOGLE_CLIENT_SECRET"),
            )
        except OAuthRevokedError as exc:
            self.providers.mark_revoked(GOOGLE_GMAIL_READONLY.provider_id, str(exc))
            self._event("PROVIDER_REVOKED", {"provider": GOOGLE_GMAIL_READONLY.provider_id})
            raise
        except OAuthError as exc:
            self.providers.mark_error(GOOGLE_GMAIL_READONLY.provider_id, str(exc))
            self._event("PROVIDER_REFRESH_FAILED", {"provider": GOOGLE_GMAIL_READONLY.provider_id, "error": str(exc)})
            raise
        self.providers.record_refresh(
            GOOGLE_GMAIL_READONLY.provider_id, expires_in=result.get("expires_in"), scopes=result.get("scope")
        )
        self._event("PROVIDER_TOKEN_REFRESHED", {"provider": GOOGLE_GMAIL_READONLY.provider_id})
        return result

    def provider_status(self) -> list[dict[str, Any]]:
        connectors = {x["connector_id"]: x for x in self.list_connectors()}
        out = []
        for item in self.providers.list():
            if item["provider_id"] == GOOGLE_GMAIL_READONLY.provider_id:
                connector = connectors.get("gmail.readonly", {})
                access_present = self._raw_secret("GMAIL_ACCESS_TOKEN") is not None
                refresh_present = self._raw_secret("GMAIL_REFRESH_TOKEN") is not None
                client_id_present = self._raw_secret("GOOGLE_CLIENT_ID") is not None
                row = dict(item)
                row.update({
                    "connector_id": "gmail.readonly",
                    "connector_enabled": bool(connector.get("enabled")),
                    "access_token_present": access_present,
                    "refresh_token_present": refresh_present,
                    "client_id_present": client_id_present,
                    "automatic_refresh_ready": bool(refresh_present and client_id_present),
                })
                if row["status"] == "NOT_CONNECTED" and access_present:
                    row["status"] = "TOKEN_PRESENT_UNVERIFIED"
                out.append(row)
            else:
                out.append(item)
        return out

    def test_google_gmail_connection(self, *, actor: str = "local-user") -> dict[str, Any]:
        provider_id = GOOGLE_GMAIL_READONLY.provider_id
        try:
            profile = self.invoke_connector("gmail.readonly", "gmail.profile", {}, actor=actor)
        except Exception as exc:
            text = str(exc)
            if "HTTP 401" in text or "HTTP 403" in text:
                self.providers.mark_revoked(provider_id, text)
            self.providers.record_test(provider_id, False, text)
            self._event("PROVIDER_CONNECTION_TEST", {"provider": provider_id, "ok": False, "error": text})
            raise
        self.providers.record_test(provider_id, True)
        self._event("PROVIDER_CONNECTION_TEST", {"provider": provider_id, "ok": True})
        return {
            "provider_id": provider_id,
            "ok": True,
            "email_address": profile.get("emailAddress") if isinstance(profile, dict) else None,
            "messages_total": profile.get("messagesTotal") if isinstance(profile, dict) else None,
        }

    def set_session_secret(self, name: str, value: str) -> dict[str, Any]:
        normalized = self.secrets.normalize_name(name)
        self.secrets.set_session(normalized, value)
        self._event("SESSION_SECRET_SET", {"name": normalized})
        return {"name": normalized, "configured": True, "source": "session"}

    def clear_session_secret(self, name: str) -> dict[str, Any]:
        normalized = self.secrets.normalize_name(name)
        self.secrets.clear_session(normalized)
        self._event("SESSION_SECRET_CLEARED", {"name": normalized})
        return {"name": normalized, "configured": self.secrets.configured(normalized)}


    def register_connector(self, definition: ConnectorDefinition, handler: Any) -> None:
        """Register executable connector code for the current process.

        Registration does not enable the connector and grants no external action
        permission. Future connector packages should call this during startup.
        """
        self.connectors.register(definition, handler)

    def list_connectors(self) -> list[dict[str, Any]]:
        return self.connectors.list()

    def set_connector_enabled(
        self, connector_id: str, enabled: bool, *, actor: str, reason: str
    ) -> dict[str, Any]:
        return self.connectors.set_enabled(connector_id, enabled, actor=actor, reason=reason)

    def approve_connector_action(
        self, connector_id: str, capability: str, payload: dict[str, Any], *, actor: str, reason: str
    ) -> dict[str, Any]:
        return self.connectors.approve(
            connector_id, capability, payload, actor=actor, reason=reason
        )

    def invoke_connector(
        self, connector_id: str, capability: str, payload: dict[str, Any], *,
        actor: str = "rabidanti", approval_id: Optional[str] = None
    ) -> Any:
        return self.connectors.invoke(
            connector_id, capability, payload, actor=actor, approval_id=approval_id
        )

    def connector_approvals(self, connector_id: Optional[str] = None, limit: int = 100) -> list[dict[str, Any]]:
        return self.connectors.approvals(connector_id=connector_id, limit=limit)

    def connector_invocations(self, connector_id: Optional[str] = None, limit: int = 100) -> list[dict[str, Any]]:
        return self.connectors.invocations(connector_id=connector_id, limit=limit)

    def search_evidence(
        self, *, kind: Optional[str] = None, text: Optional[str] = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        return self.evidence.search(kind=kind, text_query=text, limit=limit)

    def runtime_events(self, limit: int = 100) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be between 1 and 1000")
        with self._runtime_conn() as c:
            rows = c.execute(
                "SELECT * FROM runtime_events ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            item["details"] = json.loads(item.pop("details_json"))
            out.append(item)
        return out

    def status(self) -> dict[str, Any]:
        tasks = self.tasks.list()
        task_counts = {state.value: 0 for state in PersistentTaskState}
        for task in tasks:
            task_counts[task.state.value] += 1

        workflows = self.workflows.list()
        workflow_counts: dict[str, int] = {}
        for item in workflows:
            workflow_counts[item.state.value] = workflow_counts.get(item.state.value, 0) + 1

        queue_items = self.queue.list()
        queue_counts: dict[str, int] = {}
        for item in queue_items:
            queue_counts[item.state.value] = queue_counts.get(item.state.value, 0) + 1

        evidence_nodes = self.evidence.search(limit=1000)
        evidence_counts: dict[str, int] = {}
        for node in evidence_nodes:
            evidence_counts[node["kind"]] = evidence_counts.get(node["kind"], 0) + 1

        connectors = self.connectors.list()
        connector_enabled = sum(1 for item in connectors if item["enabled"])

        return {
            "program": "Rabidanti",
            "version": self.version,
            "runtime_state": "RUNNING" if self.started else "INITIALIZED",
            "instance_id": self.instance_id,
            "state_dir": str(self.paths.root),
            "tasks": {"total": len(tasks), "counts": task_counts},
            "workflows": {"total": len(workflows), "counts": workflow_counts},
            "queue": {"total": len(queue_items), "counts": queue_counts},
            "workers": self.workers.health_snapshot(),
            "evidence": {"visible_total": len(evidence_nodes), "counts": evidence_counts},
            "configuration": self.config.as_dict(),
            "secrets": {"configured": sum(1 for x in self.secret_status() if x["configured"]), "vault": self.vault.status()},
            "ai": {"provider": self.config.get("ai.provider"), "model": self.config.get("ai.model"), "fallback_model": self.config.get("ai.fallback_model")},
            "connectors": {"registered": len(connectors), "enabled": connector_enabled},
            "providers": {"items": self.provider_status()},
            "safety": {
                "self_authorization": False,
                "external_action_authorized": False,
                "automatic_core_integration": False,
            },
        }

    def observability_snapshot(self) -> dict[str, Any]:
        """Return a read-only operational health snapshot for humans."""
        return OperationalObservability(self).snapshot()

    def doctor(self) -> dict[str, Any]:
        checks: list[dict[str, Any]] = []

        def add(name: str, ok: bool, detail: str) -> None:
            checks.append({"name": name, "ok": bool(ok), "detail": detail})

        add("version", bool(self.version), self.version or "missing")
        add("python", sys.version_info >= (3, 10), sys.version.split()[0])
        add("state_dir", self.paths.root.is_dir(), str(self.paths.root))
        add("config", self.paths.config_file.is_file(), str(self.paths.config_file))
        add("credential_vault", True, "unlocked" if self.vault.unlocked else "locked; encrypted persistence requires external master key")
        probe = self.paths.root / f".write-test-{uuid.uuid4().hex}"
        try:
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            add("state_writable", True, "writable")
        except OSError as exc:
            add("state_writable", False, str(exc))

        try:
            with self._runtime_conn() as c:
                result = c.execute("PRAGMA integrity_check").fetchone()[0]
            add("runtime_db", result == "ok", result)
        except sqlite3.Error as exc:
            add("runtime_db", False, str(exc))

        try:
            with sqlite3.connect(str(self.paths.connectors_db)) as c:
                result = c.execute("PRAGMA integrity_check").fetchone()[0]
            add("connectors_db", result == "ok", result)
        except sqlite3.Error as exc:
            add("connectors_db", False, str(exc))

        try:
            with sqlite3.connect(str(self.paths.providers_db)) as c:
                result = c.execute("PRAGMA integrity_check").fetchone()[0]
            add("providers_db", result == "ok", result)
        except sqlite3.Error as exc:
            add("providers_db", False, str(exc))

        docker = shutil.which("docker")
        podman = shutil.which("podman")
        add(
            "container_runtime",
            bool(docker or podman),
            docker or podman or "Docker/Podman unavailable; OS-level container isolation is not validated.",
        )
        return {
            "program": "Rabidanti",
            "version": self.version,
            "healthy": all(c["ok"] for c in checks if c["name"] != "container_runtime"),
            "checks": checks,
            "limitations": [
                "Persistent configuration never stores secrets; secrets are environment/session-only.",
                "Gmail read-only connector code is built in but remains disabled until explicitly enabled and credentialed.",
                "OAuth/Gmail behavior is validated against mocks unless a real Google account is explicitly authorized.",
                "No external action is authorized by runtime startup.",
                "Container isolation requires Docker or Podman and remains environment-dependent.",
                "Evidence provenance is not equivalent to scientific validation.",
            ],
        }
