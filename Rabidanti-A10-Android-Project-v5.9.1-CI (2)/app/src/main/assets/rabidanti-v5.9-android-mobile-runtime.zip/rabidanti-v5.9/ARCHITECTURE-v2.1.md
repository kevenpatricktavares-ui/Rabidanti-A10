# Rabidanti v2.1 — Intelligence Foundation

Adds:
- Persona Engine for legitimate market adaptation.
- Private Personality Core for identity, interests, experiences, principles and provisional beliefs.
- Reversible Authority Model separating autonomy from operational authority.

This is a foundation, not a claim of sentience or unlimited knowledge. World awareness,
proactive communication, voice, continuous learning, Character Engine, audiovisual
production and interactive products remain subsequent modules.

Irreversible or sensitive external actions remain permission-controlled.
