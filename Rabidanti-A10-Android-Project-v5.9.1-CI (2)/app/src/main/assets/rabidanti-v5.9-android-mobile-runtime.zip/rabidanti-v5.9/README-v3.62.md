# Rabidanti v3.62

## Controlled Adaptive Experimentation

Rabidanti can now shadow-test bounded adaptive prioritization proposals against recorded outcomes without changing production behavior.

The system separates:
1. observation;
2. proposal;
3. retrospective shadow evaluation;
4. approval and forward testing;
5. future production adoption.

No proposal is automatically applied.
