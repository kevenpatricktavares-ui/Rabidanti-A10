# Rabidanti v5.5 — Validation Report

## Baseline

Input: Rabidanti v5.4 Windows Release Candidate.

Input SHA-256:
`44730e697c8776ed6697c947be2b9e18fa7fc53bcd397166f7ca3f8771e27af4`

## Changes

- VERSION -> `5.5.0`.
- PE validation expanded to architecture, PE format and subsystem.
- Build manifest schema upgraded to 2.
- Structural native-build validation separated from Windows end-to-end validation.
- `verify_windows_release.ps1` added for executable/install/uninstall validation on Windows.
- `native_release_check.py` added to reconcile version and SHA-256 evidence.
- optional Windows CI workflow added.
- `ProductFoundation.build_info()` now reports the application version.
- `RABIDANTI_OUTPUT_FILE` added so a windowed executable can emit machine-readable diagnostics without a console.
- build scripts updated to use file-based evidence.
- historical v3.87 smoke timeout increased from 3s to 10s; the dedicated 1s timeout test remains unchanged.

## Tests

- v5.x: 76 passed
- v4.x: 121 passed
- v3.x: 157 passed
- historical tests/: 337 passed
- total: **691 passed / 0 failed**
- compileall: PASS
- release preflight: **21/21 PASS**

## Native Windows status

Not validated in this environment. PyInstaller, Wine and Inno Setup are unavailable here and the host is Linux.

No `release-manifest.json`, `windows-release-validation.json`, `Rabidanti.exe` or `Rabidanti-Setup-*.exe` is fabricated in the source package.

The Windows-native release is only valid after `build_release_windows.bat` completes on Windows and `native_release_check.py` returns success against the real artefacts.
