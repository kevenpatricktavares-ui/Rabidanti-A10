from __future__ import annotations

from datetime import datetime, timezone
import json
import sqlite3
import urllib.error
import urllib.request

import httpx
import pytest

from gmail_connector import gmail_definition
from rabidanti_api import RabidantiApiService
from rabidanti_oauth import OAuthPKCEManager, OAuthRevokedError, GOOGLE_GMAIL_READONLY
from rabidanti_providers import ProviderStateStore
from rabidanti_runtime import RabidantiRuntime
from rabidanti_vault import EncryptedCredentialVault, VaultError

MASTER = "v4.6 provider master key with enough entropy 12345"


def test_provider_store_persists_metadata_without_tokens(tmp_path):
    db = tmp_path / "providers.sqlite3"
    store = ProviderStateStore(db)
    store.register("google_gmail_readonly", "Gmail", scopes=("gmail.readonly",))
    row = store.record_authorized("google_gmail_readonly", expires_in=3600, scopes="gmail.readonly")
    assert row["status"] == "CONNECTED"
    assert row["token_expires_at"]
    raw = db.read_bytes()
    assert b"access-token-secret" not in raw
    assert b"refresh-token-secret" not in raw


def test_provider_store_detects_expiry_and_records_refresh(tmp_path):
    store = ProviderStateStore(tmp_path / "p.sqlite3")
    store.register("p", "Provider")
    with sqlite3.connect(store.db_path) as c:
        c.execute("UPDATE providers SET token_expires_at=? WHERE provider_id='p'", ("2000-01-01T00:00:00+00:00",))
    assert store.token_needs_refresh("p") is True
    row = store.record_refresh("p", expires_in=3600)
    assert row["last_refresh_at"] is not None
    assert store.token_needs_refresh("p") is False


def test_oauth_find_flow_by_state_and_refresh_rotates_access_token(tmp_path):
    vault = EncryptedCredentialVault(tmp_path / "vault.json", MASTER)
    calls = []
    class Response:
        status_code = 200
        def json(self):
            return {"access_token": "new-access", "expires_in": 3600, "token_type": "Bearer"}
    mgr = OAuthPKCEManager(vault, post=lambda url, **kwargs: (calls.append((url, kwargs)) or Response()))
    started = mgr.start(GOOGLE_GMAIL_READONLY, client_id="client-id-123", redirect_uri="http://127.0.0.1/cb")
    assert mgr.find_flow_by_state(GOOGLE_GMAIL_READONLY, started["state"]) == started["flow_id"]
    out = mgr.refresh(GOOGLE_GMAIL_READONLY, client_id="client-id-123", refresh_token="refresh-token")
    assert out["access_token_stored"] is True
    assert vault.get("GMAIL_ACCESS_TOKEN") == "new-access"
    assert calls[-1][1]["data"]["grant_type"] == "refresh_token"


def test_oauth_refresh_marks_invalid_grant_as_revoked_error(tmp_path):
    vault = EncryptedCredentialVault(tmp_path / "vault.json", MASTER)
    class Response:
        status_code = 400
        def json(self): return {"error": "invalid_grant"}
    mgr = OAuthPKCEManager(vault, post=lambda *a, **k: Response())
    with pytest.raises(OAuthRevokedError):
        mgr.refresh(GOOGLE_GMAIL_READONLY, client_id="client-id-123", refresh_token="bad-refresh")


def test_runtime_registers_provider_and_exposes_safe_status(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        rows = rt.provider_status()
        gmail = next(x for x in rows if x["provider_id"] == "google_gmail_readonly")
        assert gmail["status"] == "NOT_CONNECTED"
        assert gmail["access_token_present"] is False
        blob = json.dumps(gmail)
        assert MASTER not in blob
    finally:
        rt.stop()


def test_runtime_session_provider_credentials_are_not_persisted(tmp_path):
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        out = rt.configure_google_gmail_credentials(client_id="client-id", client_secret="client-secret", persist=False)
        assert out["source"] == "session"
        assert rt.get_secret("GOOGLE_CLIENT_ID") == "client-id"
        files = b"".join(p.read_bytes() for p in (tmp_path / "state").glob("*") if p.is_file())
        assert b"client-secret" not in files
        assert b"client-id" not in files
    finally:
        rt.stop()


def test_runtime_persistent_provider_credentials_require_unlocked_vault(tmp_path):
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        with pytest.raises(VaultError):
            rt.configure_google_gmail_credentials(client_id="client-id-123", persist=True)
    finally:
        rt.stop()


def test_runtime_oauth_exchange_records_provider_expiry(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    class Response:
        status_code = 200
        def json(self):
            return {"access_token":"a1", "refresh_token":"r1", "expires_in":1200, "scope":"gmail.readonly", "token_type":"Bearer"}
    rt.oauth._post = lambda *a, **k: Response()
    try:
        rt.configure_google_gmail_credentials(client_id="client-id-123", persist=False)
        start = rt.oauth_google_gmail_start(redirect_uri="http://127.0.0.1/cb")
        rt.oauth_google_gmail_exchange(flow_id=start["flow_id"], state=start["state"], code="code")
        row = rt.provider_status()[0]
        assert row["status"] == "CONNECTED"
        assert row["token_expires_at"]
        assert row["refresh_token_present"] is True
    finally:
        rt.stop()


def test_runtime_auto_refreshes_expired_gmail_token(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    class Response:
        status_code = 200
        def json(self): return {"access_token":"fresh-access", "expires_in":3600, "token_type":"Bearer"}
    rt.oauth._post = lambda *a, **k: Response()
    try:
        rt.vault_set("GMAIL_ACCESS_TOKEN", "expired-access")
        rt.vault_set("GMAIL_REFRESH_TOKEN", "refresh-token")
        rt.vault_set("GOOGLE_CLIENT_ID", "client-id")
        rt.providers.record_authorized("google_gmail_readonly", expires_in=3600)
        with sqlite3.connect(str(rt.paths.providers_db)) as c:
            c.execute("UPDATE providers SET token_expires_at='2000-01-01T00:00:00+00:00' WHERE provider_id='google_gmail_readonly'")
        assert rt.get_secret("GMAIL_ACCESS_TOKEN") == "fresh-access"
        row = rt.provider_status()[0]
        assert row["last_refresh_at"] is not None
    finally:
        rt.stop()


def test_runtime_revoked_refresh_marks_provider_and_returns_no_access_token(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    class Response:
        status_code = 400
        def json(self): return {"error":"invalid_grant"}
    rt.oauth._post = lambda *a, **k: Response()
    try:
        rt.vault_set("GMAIL_ACCESS_TOKEN", "expired-token")
        rt.vault_set("GMAIL_REFRESH_TOKEN", "revoked-refresh")
        rt.vault_set("GOOGLE_CLIENT_ID", "client-id-123")
        rt.providers.record_authorized("google_gmail_readonly", expires_in=3600)
        with sqlite3.connect(str(rt.paths.providers_db)) as c:
            c.execute("UPDATE providers SET token_expires_at='2000-01-01T00:00:00+00:00' WHERE provider_id='google_gmail_readonly'")
        assert rt.get_secret("GMAIL_ACCESS_TOKEN") is None
        assert rt.providers.get("google_gmail_readonly")["status"] == "REVOKED"
    finally:
        rt.stop()


def test_connection_test_uses_connector_permission_boundary(tmp_path):
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        rt.set_session_secret("GMAIL_ACCESS_TOKEN", "token-12345")
        with pytest.raises(Exception, match="disabled"):
            rt.test_google_gmail_connection()
        assert rt.providers.get("google_gmail_readonly")["last_test_ok"] is False
    finally:
        rt.stop()


def test_connection_test_records_success_with_mock_handler(tmp_path):
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        rt.set_session_secret("GMAIL_ACCESS_TOKEN", "token-12345")
        rt.register_connector(gmail_definition(), lambda cap, payload, ctx: {"emailAddress":"user@example.com", "messagesTotal":7})
        rt.set_connector_enabled("gmail.readonly", True, actor="owner", reason="test")
        out = rt.test_google_gmail_connection(actor="owner")
        assert out["ok"] is True and out["email_address"] == "user@example.com"
        assert rt.providers.get("google_gmail_readonly")["last_test_ok"] is True
    finally:
        rt.stop()


def _request(url, *, method="GET", token=None, body=None):
    headers = {}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, method=method, headers=headers, data=data)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status, resp.headers.get("Content-Type", ""), resp.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.headers.get("Content-Type", ""), exc.read().decode()


def test_api_provider_status_and_setup_are_bearer_protected(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    rt.start()
    token="provider-api-token-long-enough-123456"
    service=RabidantiApiService(rt, port=0, token=token)
    addr=service.start(background=True); base=f"http://{addr.host}:{addr.port}"
    try:
        code, _, raw = _request(base+"/v1/providers")
        assert code == 200 and json.loads(raw)["items"][0]["provider_id"] == "google_gmail_readonly"
        code, _, _ = _request(base+"/v1/providers/google-gmail/setup", method="POST", body={"client_id":"client-id-123"})
        assert code == 401
        code, _, raw = _request(base+"/v1/providers/google-gmail/setup", method="POST", token=token, body={"client_id":"client-id-123","persist":False})
        assert code == 200 and json.loads(raw)["source"] == "session"
    finally:
        service.stop(); rt.stop()


def test_loopback_oauth_callback_completes_flow_without_exposing_tokens(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    rt.start()
    class Response:
        status_code=200
        def json(self): return {"access_token":"secret-access", "refresh_token":"secret-refresh", "expires_in":3600}
    rt.oauth._post=lambda *a, **k: Response()
    rt.configure_google_gmail_credentials(client_id="client-id-123", persist=False)
    token="provider-api-token-long-enough-123456"
    service=RabidantiApiService(rt, port=0, token=token)
    addr=service.start(background=True); base=f"http://{addr.host}:{addr.port}"
    try:
        code, _, raw = _request(base+"/v1/providers/google-gmail/oauth/start", method="POST", token=token, body={})
        start=json.loads(raw); assert code == 201
        code, ctype, html = _request(base+f"/oauth/callback?state={start['state']}&code=abc")
        assert code == 200 and "text/html" in ctype and "Gmail ligado" in html
        assert "secret-access" not in html and "secret-refresh" not in html
        assert rt.providers.get("google_gmail_readonly")["status"] == "CONNECTED"
    finally:
        service.stop(); rt.stop()


def test_sala_provider_setup_has_no_browser_persistence_calls():
    js = (__import__('pathlib').Path(__file__).with_name('ui') / 'app.js').read_text()
    html = (__import__('pathlib').Path(__file__).with_name('ui') / 'index.html').read_text()
    assert 'gmail-credentials-form' in html and 'gmail-oauth-start' in html
    assert '/v1/providers/google-gmail/oauth/start' in js
    assert 'localStorage' not in js and 'sessionStorage' not in js and 'document.cookie' not in js

def test_connection_test_marks_http_401_as_revoked(tmp_path):
    rt = RabidantiRuntime(tmp_path / "state")
    try:
        rt.set_session_secret("GMAIL_ACCESS_TOKEN", "token-12345")
        def unauthorized(cap, payload, ctx):
            raise RuntimeError("Gmail API request failed with HTTP 401")
        rt.register_connector(gmail_definition(), unauthorized)
        rt.set_connector_enabled("gmail.readonly", True, actor="owner", reason="test")
        with pytest.raises(RuntimeError, match="HTTP 401"):
            rt.test_google_gmail_connection(actor="owner")
        row = rt.providers.get("google_gmail_readonly")
        assert row["status"] == "REVOKED"
        assert row["last_test_ok"] is False
    finally:
        rt.stop()


def test_invalid_loopback_callback_state_does_not_exchange_token(tmp_path, monkeypatch):
    monkeypatch.setenv("RABIDANTI_VAULT_MASTER_KEY", MASTER)
    rt = RabidantiRuntime(tmp_path / "state")
    rt.start()
    calls=[]
    class Response:
        status_code=200
        def json(self): return {"access_token":"should-not-be-issued"}
    rt.oauth._post=lambda *a, **k: (calls.append(1) or Response())
    rt.configure_google_gmail_credentials(client_id="client-id-123", persist=False)
    token="provider-api-token-long-enough-123456"
    service=RabidantiApiService(rt, port=0, token=token)
    addr=service.start(background=True); base=f"http://{addr.host}:{addr.port}"
    try:
        code, _, raw = _request(base+"/v1/providers/google-gmail/oauth/start", method="POST", token=token, body={})
        assert code == 201
        code, _, _ = _request(base+"/oauth/callback?state=wrong-state&code=abc")
        assert code == 400
        assert calls == []
        assert rt.get_secret("GMAIL_ACCESS_TOKEN") is None
    finally:
        service.stop(); rt.stop()
