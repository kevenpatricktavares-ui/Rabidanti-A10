# Rabidanti v3.97

**Laboratory Human Review & Decision Workflow**

This version adds a persistent and auditable human-review stage after v3.96 readiness. An experiment may be approved, rejected, or returned for more evidence, with the reviewer identity (asserted), rationale, timestamp and exact evidence snapshot retained.

Approval here does **not** authorize Core integration, execution, publication, spending, contracts, payments or any other external action. It also does not declare scientific validation.

See `ARCHITECTURE-v3.97.md` and `test_v3_97_lab_human_review.py`.
