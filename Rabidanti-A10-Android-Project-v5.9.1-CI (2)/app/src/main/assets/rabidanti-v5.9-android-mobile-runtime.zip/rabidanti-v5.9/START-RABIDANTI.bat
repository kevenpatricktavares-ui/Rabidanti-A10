@echo off
setlocal
cd /d "%~dp0"
if exist "Rabidanti.exe" (
  start "Rabidanti" "%~dp0Rabidanti.exe"
  exit /b 0
)
if exist ".venv\Scripts\pythonw.exe" (
  start "Rabidanti" ".venv\Scripts\pythonw.exe" "%~dp0rabidanti_launcher.py"
  exit /b 0
)
where py >nul 2>nul || (
  echo Python 3.10+ is required for the source build. Use the packaged Rabidanti.exe when available.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv || exit /b 1
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || exit /b 1
)
start "Rabidanti" ".venv\Scripts\pythonw.exe" "%~dp0rabidanti_launcher.py"
endlocal
