"""Rabidanti v3.35 — Product-to-Content domain integration."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class ContentBrief:
    project_id: str
    objective: str
    title: str
    product_type: str
    audience: str
    value_proposition: str
    format: str
    outline: tuple[str, ...]
    source_stage: str = "product"
    product_name: str = ""
    limitations: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

class ContentEngine:
    """Create a traceable content plan from a persisted ProductBrief.

    This produces structured content direction, not a claim that the final
    content has been reviewed, rendered, or approved for publication.
    """
    def build(self, project_id: str, objective: str, product: Mapping[str, Any]) -> ContentBrief:
        if not str(project_id).strip():
            raise ValueError("project_id must not be empty")
        if not str(objective).strip():
            raise ValueError("objective must not be empty")
        p = dict(product or {})
        if not p:
            raise ValueError("product must not be empty")
        product_type = str(p.get("product_type") or "course").strip()
        name = str(p.get("name") or objective).strip()
        audience = str(p.get("target_audience") or "Audience must be defined and validated before launch.").strip()
        value = str(p.get("value_proposition") or "").strip()
        fmt = self._format_for(product_type)
        outline = self._outline(product_type, name)
        limitations = list(str(x) for x in (p.get("limitations") or ()) if str(x).strip())
        limitations.append("Content draft requires factual, rights, quality, and human review before publication.")
        return ContentBrief(str(project_id), str(objective).strip(), name, product_type,
                            audience, value, fmt, outline, "product", name,
                            tuple(dict.fromkeys(limitations)))

    @staticmethod
    def _format_for(product_type: str) -> str:
        return {
            "ebook": "structured_ebook",
            "course": "course_curriculum",
            "audiovisual": "video_script_and_storyboard",
            "audio": "audio_script",
            "interactive_tool": "tool_content_and_guidance",
            "workbook": "guided_workbook",
            "bundle": "multi_asset_content_plan",
        }.get(product_type, "structured_content")

    @staticmethod
    def _outline(product_type: str, name: str) -> tuple[str, ...]:
        base = ("Introduction and desired outcome", "Core concepts and practical examples",
                "Application steps", "Common mistakes and objections", "Action plan and next steps")
        if product_type == "course":
            return ("Course promise and orientation", "Foundations", "Guided practice", "Application", "Review and next steps")
        if product_type == "interactive_tool":
            return ("Problem and user goal", "How the tool works", "Inputs and interpretation", "Examples", "Action plan")
        return base
