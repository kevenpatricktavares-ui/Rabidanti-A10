# Rabidanti v3.41 — Distribution → Ads Integration

The business pipeline now connects Distribution preparation to Ads campaign preparation.

Flow:
`Product + Sales → Distribution → Ads`

Ads output includes channel, objective, audience context, creative variants, landing target, tracking events, experiment ID and an unapproved budget placeholder.

Safety/authority contract:
- No external ad publication is performed.
- No ad spend is performed.
- Budget is explicitly unapproved until an authorized connector/limit exists.
- Real platform execution remains behind connector permissions and approval gates.
- `READY_FOR_APPROVAL` is distinct from `PUBLISHED`.

This version is an integration foundation, not a claim of real Meta/Google execution.
