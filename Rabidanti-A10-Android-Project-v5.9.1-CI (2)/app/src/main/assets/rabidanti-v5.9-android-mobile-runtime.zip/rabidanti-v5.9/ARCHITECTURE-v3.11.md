# Rabidanti v3.11 — Durable Worker Queue

## Implemented
- SQLite-backed durable queue.
- Priority ordering.
- Persistent queue states.
- Worker claims coordinated by v3.10 leases.
- Heartbeats.
- Ownership checks.
- Completion/failure.
- Retry by returning failed work to QUEUED.
- Lease-expiry recovery.
- Cancellation.
- Queue survives process restart.

## Scope boundary
This is a durable queue/worker foundation using SQLite. It is not yet:
- Redis/RabbitMQ/Kafka/SQS/etc.;
- cloud-hosted;
- autoscaling;
- multi-region;
- a production SLA;
- a fully managed 24/7 service.

## Next
Build a worker runner that continuously consumes this queue, handles graceful
shutdown, heartbeats, recovery and bounded concurrency. Then add health
monitoring/resource budgets and an external queue adapter.
