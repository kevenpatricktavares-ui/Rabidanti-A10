# Rabidanti v3.37 — Review → Render

The render stage is now a real gated execution stage. It consumes persisted content and review artifacts and refuses to render unless review status is PASS. The built-in renderer creates a real PDF using ReportLab. This is a concrete PDF rendering path, not a claim of audiovisual rendering or publication.
