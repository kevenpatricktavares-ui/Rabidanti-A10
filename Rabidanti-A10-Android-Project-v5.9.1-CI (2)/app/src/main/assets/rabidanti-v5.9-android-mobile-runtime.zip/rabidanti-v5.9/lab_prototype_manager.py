"""Rabidanti v3.86 — versioned prototype and acceptance-test registry.

Records prototypes, immutable version snapshots, acceptance tests and integration proposals.
It does not execute submitted code or deploy/integrate prototypes.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import json, sqlite3

@dataclass(frozen=True)
class Prototype:
    prototype_id: str
    project_id: str
    title: str
    status: str
    current_version: int
    created_at: str
    updated_at: str

class LabPrototypeManager:
    STATUSES = {"DRAFT", "TESTING", "READY_FOR_REVIEW", "REJECTED", "INTEGRATED"}
    TRANSITIONS = {"DRAFT":{"TESTING","REJECTED"},"TESTING":{"DRAFT","READY_FOR_REVIEW","REJECTED"},"READY_FOR_REVIEW":{"TESTING","REJECTED","INTEGRATED"},"REJECTED":{"DRAFT"},"INTEGRATED":set()}
    TEST_STATES = {"NOT_RUN", "PASS", "FAIL", "BLOCKED"}
    def __init__(self, database="rabidanti_laboratory.sqlite3"):
        self.database=str(database); Path(self.database).parent.mkdir(parents=True,exist_ok=True)
        with self._db() as c:
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("CREATE TABLE IF NOT EXISTS lab_prototypes(prototype_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,title TEXT NOT NULL,status TEXT NOT NULL,current_version INTEGER NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS lab_prototype_versions(prototype_id TEXT NOT NULL,version INTEGER NOT NULL,description TEXT NOT NULL,artifact_refs TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(prototype_id,version),FOREIGN KEY(prototype_id) REFERENCES lab_prototypes(prototype_id))")
            c.execute("CREATE TABLE IF NOT EXISTS lab_acceptance_tests(test_id TEXT PRIMARY KEY,prototype_id TEXT NOT NULL,version INTEGER NOT NULL,title TEXT NOT NULL,criteria TEXT NOT NULL,state TEXT NOT NULL,result TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(prototype_id,version) REFERENCES lab_prototype_versions(prototype_id,version))")
            c.execute("CREATE TABLE IF NOT EXISTS lab_integration_proposals(proposal_id TEXT PRIMARY KEY,prototype_id TEXT NOT NULL,version INTEGER NOT NULL,rationale TEXT NOT NULL,risks TEXT NOT NULL,rollback_plan TEXT NOT NULL,approval_status TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(prototype_id,version) REFERENCES lab_prototype_versions(prototype_id,version))")
            c.execute("CREATE TABLE IF NOT EXISTS lab_prototype_events(event_id TEXT PRIMARY KEY,prototype_id TEXT NOT NULL,from_status TEXT,to_status TEXT NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(prototype_id) REFERENCES lab_prototypes(prototype_id))")
    def _db(self):
        c=sqlite3.connect(self.database); c.row_factory=sqlite3.Row; return c
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def _valid_text(*values):
        if any(not isinstance(v,str) or not v.strip() for v in values): raise ValueError("required text fields must be non-empty")
    def _prototype(self,r): return Prototype(**dict(r))
    def create(self, prototype_id, project_id, title, description, artifact_refs=()):
        self._valid_text(prototype_id,project_id,title,description)
        if not isinstance(artifact_refs,(list,tuple)) or any(not isinstance(x,str) or not x.strip() for x in artifact_refs): raise ValueError("artifact_refs must be non-empty strings")
        now=self._now()
        with self._db() as c:
            try:
                c.execute("INSERT INTO lab_prototypes VALUES(?,?,?,?,?,?,?)",(prototype_id.strip(),project_id.strip(),title.strip(),"DRAFT",1,now,now))
                c.execute("INSERT INTO lab_prototype_versions VALUES(?,?,?,?,?)",(prototype_id.strip(),1,description.strip(),json.dumps(list(dict.fromkeys(x.strip() for x in artifact_refs))),now))
            except sqlite3.IntegrityError as e: raise ValueError("duplicate prototype_id") from e
        return self.get(prototype_id)
    def get(self, prototype_id):
        with self._db() as c: r=c.execute("SELECT * FROM lab_prototypes WHERE prototype_id=?",(prototype_id,)).fetchone()
        if r is None: raise KeyError(prototype_id)
        return self._prototype(r)
    def version(self, prototype_id, version=None):
        p=self.get(prototype_id); version=version or p.current_version
        with self._db() as c: r=c.execute("SELECT * FROM lab_prototype_versions WHERE prototype_id=? AND version=?",(prototype_id,version)).fetchone()
        if r is None: raise KeyError((prototype_id,version))
        d=dict(r); d['artifact_refs']=json.loads(d['artifact_refs']); return d
    def create_version(self, prototype_id, description, artifact_refs=()):
        self._valid_text(description)
        if not isinstance(artifact_refs,(list,tuple)) or any(not isinstance(x,str) or not x.strip() for x in artifact_refs): raise ValueError("artifact_refs must be non-empty strings")
        p=self.get(prototype_id)
        if p.status in {"INTEGRATED","REJECTED"}: raise ValueError("prototype status does not permit a new version")
        n=p.current_version+1; now=self._now()
        with self._db() as c:
            c.execute("INSERT INTO lab_prototype_versions VALUES(?,?,?,?,?)",(prototype_id,n,description.strip(),json.dumps(list(dict.fromkeys(x.strip() for x in artifact_refs))),now))
            c.execute("UPDATE lab_prototypes SET current_version=?,updated_at=? WHERE prototype_id=?",(n,now,prototype_id))
        return self.version(prototype_id,n)
    def add_test(self, test_id, prototype_id, version, title, criteria):
        self._valid_text(test_id,title)
        if not isinstance(criteria,(list,tuple)) or not criteria or any(not isinstance(x,str) or not x.strip() for x in criteria): raise ValueError("at least one acceptance criterion is required")
        self.version(prototype_id,version); now=self._now()
        with self._db() as c:
            try: c.execute("INSERT INTO lab_acceptance_tests VALUES(?,?,?,?,?,?,?,?)",(test_id,prototype_id,version,title.strip(),json.dumps(list(dict.fromkeys(x.strip() for x in criteria))),"NOT_RUN","",now))
            except sqlite3.IntegrityError as e: raise ValueError("duplicate test_id") from e
        return self.get_test(test_id)
    def get_test(self,test_id):
        with self._db() as c: r=c.execute("SELECT * FROM lab_acceptance_tests WHERE test_id=?",(test_id,)).fetchone()
        if r is None: raise KeyError(test_id)
        d=dict(r); d['criteria']=json.loads(d['criteria']); return d
    def record_test(self,test_id,state,result):
        if state not in self.TEST_STATES-{"NOT_RUN"}: raise ValueError("invalid test state")
        self._valid_text(result)
        with self._db() as c:
            if c.execute("SELECT 1 FROM lab_acceptance_tests WHERE test_id=?",(test_id,)).fetchone() is None: raise KeyError(test_id)
            c.execute("UPDATE lab_acceptance_tests SET state=?,result=? WHERE test_id=?",(state,result.strip(),test_id))
        return self.get_test(test_id)
    def propose_integration(self,proposal_id,prototype_id,version,rationale,risks,rollback_plan):
        self._valid_text(proposal_id,rationale,risks,rollback_plan); p=self.get(prototype_id); self.version(prototype_id,version)
        if p.status!="READY_FOR_REVIEW": raise ValueError("prototype must be READY_FOR_REVIEW before integration proposal")
        now=self._now()
        with self._db() as c:
            try: c.execute("INSERT INTO lab_integration_proposals VALUES(?,?,?,?,?,?,?,?)",(proposal_id,prototype_id,version,rationale.strip(),risks.strip(),rollback_plan.strip(),"PENDING_HUMAN_APPROVAL",now))
            except sqlite3.IntegrityError as e: raise ValueError("duplicate proposal_id") from e
        return self.get_proposal(proposal_id)
    def get_proposal(self,proposal_id):
        with self._db() as c: r=c.execute("SELECT * FROM lab_integration_proposals WHERE proposal_id=?",(proposal_id,)).fetchone()
        if r is None: raise KeyError(proposal_id)
        return dict(r)
    def decide_proposal(self,proposal_id,decision):
        if decision not in {"APPROVED","REJECTED"}: raise ValueError("decision must be APPROVED or REJECTED")
        p=self.get_proposal(proposal_id)
        if p['approval_status']!="PENDING_HUMAN_APPROVAL": raise ValueError("proposal already decided")
        with self._db() as c: c.execute("UPDATE lab_integration_proposals SET approval_status=? WHERE proposal_id=?",(decision,proposal_id))
        return self.get_proposal(proposal_id)
    def transition(self,prototype_id,to_status,event_id,note="",human_approved=False):
        self._valid_text(event_id)
        if to_status not in self.STATUSES: raise ValueError("unknown status")
        p=self.get(prototype_id)
        if to_status not in self.TRANSITIONS[p.status]: raise ValueError(f"invalid transition: {p.status} -> {to_status}")
        if to_status=="READY_FOR_REVIEW":
            with self._db() as c: tests=c.execute("SELECT state FROM lab_acceptance_tests WHERE prototype_id=? AND version=?",(prototype_id,p.current_version)).fetchall()
            if not tests or any(t['state']!="PASS" for t in tests): raise ValueError("all acceptance tests for current version must PASS")
        if to_status=="INTEGRATED":
            if not human_approved: raise PermissionError("explicit human approval is required")
            with self._db() as c:
                approved=c.execute("SELECT 1 FROM lab_integration_proposals WHERE prototype_id=? AND version=? AND approval_status='APPROVED'",(prototype_id,p.current_version)).fetchone()
            if not approved: raise ValueError("an approved integration proposal for current version is required")
        now=self._now()
        with self._db() as c:
            try: c.execute("INSERT INTO lab_prototype_events VALUES(?,?,?,?,?,?)",(event_id,prototype_id,p.status,to_status,(note or "").strip(),now))
            except sqlite3.IntegrityError as e: raise ValueError("duplicate event_id") from e
            c.execute("UPDATE lab_prototypes SET status=?,updated_at=? WHERE prototype_id=?",(to_status,now,prototype_id))
        return self.get(prototype_id)
    def report(self,prototype_id):
        p=self.get(prototype_id)
        with self._db() as c:
            versions=[dict(r) for r in c.execute("SELECT * FROM lab_prototype_versions WHERE prototype_id=? ORDER BY version",(prototype_id,))]
            tests=[dict(r) for r in c.execute("SELECT * FROM lab_acceptance_tests WHERE prototype_id=? ORDER BY created_at,test_id",(prototype_id,))]
            proposals=[dict(r) for r in c.execute("SELECT * FROM lab_integration_proposals WHERE prototype_id=? ORDER BY created_at,proposal_id",(prototype_id,))]
        for v in versions: v['artifact_refs']=json.loads(v['artifact_refs'])
        for t in tests: t['criteria']=json.loads(t['criteria'])
        return {'prototype':p.__dict__,'versions':versions,'tests':tests,'integration_proposals':proposals,'integration_authorized':p.status=='INTEGRATED','note':'Prototype records do not execute or deploy code; integration requires explicit approval.'}
