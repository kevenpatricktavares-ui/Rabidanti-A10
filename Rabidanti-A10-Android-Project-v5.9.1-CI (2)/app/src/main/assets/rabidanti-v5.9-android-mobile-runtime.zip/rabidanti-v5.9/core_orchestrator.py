"""Rabidanti v3.29 — Core Orchestrator integration for durable workflows."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Iterable, Optional

from workflow_engine import WorkflowNode
from workflow_orchestrator import PersistentWorkflowOrchestrator, WorkflowProgress, WorkflowRecord, WorkflowState
from business_pipeline import BusinessPipelineSpec, build_business_pipeline


@dataclass(frozen=True)
class CoreWorkflowSpec:
    name: str
    nodes: tuple[WorkflowNode, ...]
    payloads: dict[str, object]
    max_attempts: int = 3
    metadata: Optional[dict[str, Any]] = None


class CoreOrchestrator:
    """Central facade through which Rabidanti Core manages durable workflows.

    This layer deliberately delegates persistence, dependency validation, queueing,
    recovery and execution state to the existing workflow/queue infrastructure.
    It does not pretend to execute domain agents that have not been connected yet.
    """

    def __init__(self, workflow_orchestrator: PersistentWorkflowOrchestrator):
        self.workflows = workflow_orchestrator

    def create_workflow(
        self,
        name: str,
        nodes: Iterable[WorkflowNode],
        payloads: Optional[dict[str, object]] = None,
        max_attempts: int = 3,
        metadata: Optional[dict[str, Any]] = None,
        workflow_id: Optional[str] = None,
    ) -> WorkflowRecord:
        enriched = dict(metadata or {})
        enriched.setdefault("created_by", "rabidanti-core")
        return self.workflows.create(
            name=name,
            nodes=nodes,
            payloads=payloads,
            max_attempts=max_attempts,
            workflow_id=workflow_id,
            metadata=enriched,
        )

    def create_business_pipeline(self, spec: BusinessPipelineSpec) -> WorkflowRecord:
        nodes, payloads = build_business_pipeline(spec)
        metadata = dict(spec.metadata or {})
        metadata.update({
            "pipeline": "business",
            "pipeline_version": "1.0",
            "project_id": spec.project_id,
        })
        return self.create_workflow(
            name=spec.name,
            nodes=nodes,
            payloads=payloads,
            max_attempts=spec.max_attempts,
            metadata=metadata,
        )

    def start_business_pipeline(self, spec: BusinessPipelineSpec) -> WorkflowRecord:
        return self.start(self.create_business_pipeline(spec).workflow_id)

    def start(self, workflow_id: str) -> WorkflowRecord:
        return self.workflows.start(workflow_id)

    def refresh(self, workflow_id: str) -> WorkflowRecord:
        return self.workflows.refresh(workflow_id)

    def progress(self, workflow_id: str) -> WorkflowProgress:
        return self.workflows.progress(workflow_id)

    def recover(self, workflow_id: str) -> WorkflowRecord:
        return self.workflows.recover_and_resume(workflow_id)

    def cancel(self, workflow_id: str, reason: str = "workflow cancelled by core") -> WorkflowRecord:
        return self.workflows.cancel(workflow_id, reason)

    def get(self, workflow_id: str) -> WorkflowRecord:
        return self.workflows.get(workflow_id)

    def list_workflows(self) -> list[WorkflowRecord]:
        return self.workflows.list()

    def status(self, workflow_id: str) -> dict[str, Any]:
        p = self.progress(workflow_id)
        return {
            "workflow_id": p.workflow_id,
            "state": p.state.value,
            "total": p.total,
            "queued": p.queued,
            "running": p.running,
            "completed": p.completed,
            "failed": p.failed,
            "cancelled": p.cancelled,
            "blocked": p.blocked,
            "percent": p.percent,
            "error": p.error,
        }
