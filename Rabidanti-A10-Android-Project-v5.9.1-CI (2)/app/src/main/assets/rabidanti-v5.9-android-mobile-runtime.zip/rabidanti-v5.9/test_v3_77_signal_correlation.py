from evolution_signal_correlation import EvolutionSignalCorrelator


def make():
    c=EvolutionSignalCorrelator()
    c.add_signal("h","health",.9,.8)
    c.add_signal("l","learning",.8,.7)
    c.add_signal("w","world_awareness",.9,.9)
    return c


def test_strong_cross_domain_correlation():
    c=make()
    x=c.correlate("c1",["h","l","w"])
    assert x.strength >= .60
    assert len(x.domains)==3


def test_weak_correlation_blocked():
    c=EvolutionSignalCorrelator()
    c.add_signal("a","health",.2,.1)
    c.add_signal("b","health",.2,.1)
    try:
        c.correlate("c",["a","b"])
        assert False
    except ValueError:
        assert True


def test_unknown_signal_blocked():
    c=make()
    try:
        c.correlate("c",["h","x"])
        assert False
    except ValueError:
        assert True


def test_duplicate_signal_blocked():
    c=make()
    try:
        c.correlate("c",["h","h"])
        assert False
    except ValueError:
        assert True


def test_duplicate_ids_and_signal_validation():
    c=make()
    try:
        c.add_signal("h","health",.8,.2)
        assert False
    except ValueError:
        assert True
    try:
        c.add_signal("x","health",1.1,.2)
        assert False
    except ValueError:
        assert True


def test_correlation_has_no_execution_authority():
    c=make()
    x=c.correlate("c2",["h","l"])
    assert x.correlation_id=="c2"
    assert not hasattr(c,"activate")
    assert not hasattr(c,"deploy")


def test_domain_summary():
    c=make()
    assert c.domain_summary()["health"]==1
    assert c.domain_summary()["learning"]==1
