import pytest
from lab_evidence_memory import LabEvidenceMemory

def test_trace_links_sources_to_experiment_artifacts_and_decisions(tmp_path):
    m=LabEvidenceMemory(tmp_path/"evidence.sqlite3")
    s=m.add_node("SOURCE","Paper A","Published method",uri="https://example.org/paper",content="abstract")
    e=m.add_node("EXPERIMENT","Experiment 1","Test of hypothesis")
    a=m.add_node("ARTIFACT","output.csv","Measured output",content="x,y\n1,2")
    d=m.add_node("DECISION","Hold for review","Evidence incomplete")
    m.link(e["node_id"],"BASED_ON",s["node_id"])
    m.link(e["node_id"],"PRODUCED",a["node_id"])
    m.link(e["node_id"],"INFORMED",d["node_id"])
    trace=m.trace(e["node_id"])
    assert len(trace["links"])==3
    assert len(trace["trace_digest"])==64
    assert trace["limitation"]

def test_content_digest_and_persistent_reopen(tmp_path):
    path=tmp_path/"evidence.sqlite3"
    m=LabEvidenceMemory(path)
    n=m.add_node("ARTIFACT","artifact","sample",node_id="a1",content="hello")
    assert n["content_digest"]==LabEvidenceMemory.digest_content("hello")
    assert LabEvidenceMemory(path).get_node("a1")["title"]=="artifact"

def test_rejects_unknown_kinds_duplicate_ids_and_missing_links(tmp_path):
    m=LabEvidenceMemory(tmp_path/"evidence.sqlite3")
    with pytest.raises(ValueError): m.add_node("CLAIM","bad")
    m.add_node("SOURCE","one",node_id="same")
    with pytest.raises(ValueError): m.add_node("SOURCE","duplicate",node_id="same")
    with pytest.raises(KeyError): m.link("same","SUPPORTS","missing")

def test_rejects_duplicate_links_and_bad_limits(tmp_path):
    m=LabEvidenceMemory(tmp_path/"evidence.sqlite3")
    m.add_node("SOURCE","s",node_id="s"); m.add_node("EXPERIMENT","e",node_id="e")
    m.link("e","BASED_ON","s")
    with pytest.raises(ValueError): m.link("e","BASED_ON","s")
    with pytest.raises(ValueError): m.search(limit=0)
