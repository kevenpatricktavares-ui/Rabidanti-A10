# Rabidanti v3.28 — Persistent Workflow Orchestrator

Adds a SQLite-backed workflow registry above the durable queue/DAG layers.
Workflows persist identity, task membership, state, timestamps, metadata and errors.
Progress is reconstructed from durable queue state after restart. Expired queue leases
can be recovered and an interrupted workflow can be resumed. This remains a local
SQLite/in-process foundation: it does not claim cloud deployment, external brokers,
autoscaling or 24/7 remote availability.
