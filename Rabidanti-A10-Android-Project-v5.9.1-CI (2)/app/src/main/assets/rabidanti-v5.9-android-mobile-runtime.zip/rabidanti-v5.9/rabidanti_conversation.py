"""Rabidanti v4.7 persistent local conversation engine."""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import sqlite3, uuid
from rabidanti_model_gateway import LocalOllamaGateway
from rabidanti_prompts import CONVERSATION_SYSTEM_PROMPT, CONVERSATION_PROMPT_VERSION
class ConversationEngine:
    def __init__(self, db_path: str|Path, gateway: LocalOllamaGateway):
        self.db_path=Path(db_path); self.gateway=gateway; self.db_path.parent.mkdir(parents=True,exist_ok=True); self._init()
    def _conn(self): c=sqlite3.connect(self.db_path); c.row_factory=sqlite3.Row; return c
    def _init(self):
        with self._conn() as c:
            c.execute("CREATE TABLE IF NOT EXISTS conversations(conversation_id TEXT PRIMARY KEY,title TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS messages(message_id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,model TEXT,created_at TEXT NOT NULL,FOREIGN KEY(conversation_id) REFERENCES conversations(conversation_id))")
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    def list_conversations(self,limit:int=50)->list[dict[str,Any]]:
        with self._conn() as c: rows=c.execute("SELECT * FROM conversations ORDER BY updated_at DESC LIMIT ?",(max(1,min(int(limit),200)),)).fetchall()
        return [dict(r) for r in rows]
    def messages(self,conversation_id:str,limit:int=100)->list[dict[str,Any]]:
        with self._conn() as c: rows=c.execute("SELECT message_id,role,content,model,created_at FROM messages WHERE conversation_id=? ORDER BY created_at ASC LIMIT ?",(conversation_id,max(1,min(int(limit),500)))).fetchall()
        return [dict(r) for r in rows]
    def chat(self,text:str,conversation_id:str|None=None)->dict[str,Any]:
        if not isinstance(text,str) or not text.strip() or len(text)>20000: raise ValueError("message must be 1..20000 characters")
        now=self._now(); cid=conversation_id or f"conv-{uuid.uuid4().hex}"
        with self._conn() as c:
            row=c.execute("SELECT conversation_id FROM conversations WHERE conversation_id=?",(cid,)).fetchone()
            if row is None:
                title=text.strip().replace("\n"," ")[:80]
                c.execute("INSERT INTO conversations VALUES(?,?,?,?)",(cid,title,now,now))
            elif conversation_id is None: raise RuntimeError("unexpected conversation id collision")
            c.execute("INSERT INTO messages VALUES(?,?,?,?,?,?)",(f"msg-{uuid.uuid4().hex}",cid,"user",text.strip(),None,now))
        history=self.messages(cid,limit=40)
        prompt=[{"role":"system","content":CONVERSATION_SYSTEM_PROMPT}]+[{"role":m["role"],"content":m["content"]} for m in history]
        reply=self.gateway.chat(prompt); now2=self._now()
        with self._conn() as c:
            mid=f"msg-{uuid.uuid4().hex}"; c.execute("INSERT INTO messages VALUES(?,?,?,?,?,?)",(mid,cid,"assistant",reply.content,reply.model,now2)); c.execute("UPDATE conversations SET updated_at=? WHERE conversation_id=?",(now2,cid))
        return {"conversation_id":cid,"message":{"message_id":mid,"role":"assistant","content":reply.content,"model":reply.model,"created_at":now2},"external_action_authorized":False,"tool_execution_authorized":False,"prompt_version":CONVERSATION_PROMPT_VERSION}
