# Rabidanti v3.42 — Ads → Analytics Integration

## Objetivo
Integrar o estágio de Analytics ao pipeline comercial para medir resultados de campanhas e funil sem inventar dados.

## Fluxo
`Distribution → Ads → Analytics`

O Analytics consome os artefatos persistidos de `ads` e `sales` e pode receber observações de métricas no contexto de execução. Quando não há observações, o estado é `WAITING_FOR_DATA`.

## Métricas
- impressions
- clicks
- checkout_starts
- purchases
- refunds
- spend
- revenue
- CTR
- click → checkout rate
- checkout → purchase rate
- purchase rate
- refund rate
- ROAS

Métricas sem denominador ou sem evidência permanecem `null`.

## Garantias
- Não afirma dados de plataformas externas sem conector.
- Não estima ou fabrica métricas ausentes.
- Não executa gasto publicitário.
- Não publica anúncios.
- Spend/revenue/ROAS só aparecem quando fornecidos como observação.
- O resultado continua sendo armazenável como artefato persistente.

## Próximo passo
`Analytics → Learning`, transformando observações em hipóteses, experimentos e aprendizados rastreáveis.
