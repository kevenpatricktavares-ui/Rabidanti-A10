"""Rabidanti v3.34 — evidence-bounded Product Engine integration."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class ProductBrief:
    project_id: str
    objective: str
    name: str
    product_type: str
    problem: str
    target_audience: str
    value_proposition: str
    source_stage: str = "opportunity"
    opportunity_score: float = 0.0
    hypotheses: tuple[str, ...] = ()
    evidence: tuple[dict[str, Any], ...] = ()
    limitations: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

class ProductEngine:
    """Turn an OpportunityBrief-shaped mapping into a conservative product brief.

    This creates a product definition, not a claim that the product is validated,
    market-ready, or automatically publishable.
    """
    def build(self, project_id: str, objective: str, opportunity: Mapping[str, Any]) -> ProductBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not str(objective).strip(): raise ValueError("objective must not be empty")
        o = dict(opportunity or {})
        if not o: raise ValueError("opportunity must not be empty")
        score = float(o.get("score", 0.0) or 0.0)
        problem = str(objective).strip()
        title = self._title(problem)
        product_type = self._choose_type(o)
        evidence = tuple(x for x in (o.get("evidence") or ()) if isinstance(x, dict))
        hypotheses = tuple(str(x) for x in (o.get("hypotheses") or ()) if str(x).strip())
        limitations = list(str(x) for x in (o.get("limitations") or ()) if str(x).strip())
        limitations.append("Product definition is a hypothesis; market validation is still required.")
        audience = str(o.get("target_audience") or "Audience must be defined and validated before launch.")
        value = f"Help the intended audience address '{problem}' through a {product_type.replace('_', ' ')}."
        return ProductBrief(str(project_id), problem, title, product_type, problem, audience,
                            value, "opportunity", score, hypotheses, evidence,
                            tuple(dict.fromkeys(limitations)))

    @staticmethod
    def _title(objective: str) -> str:
        clean = " ".join(objective.split())
        return clean[:72] + ("…" if len(clean) > 72 else "")

    @staticmethod
    def _choose_type(opportunity: Mapping[str, Any]) -> str:
        explicit = str(opportunity.get("recommended_product_type") or "").strip()
        allowed = {"ebook", "course", "audiovisual", "audio", "interactive_tool", "workbook", "bundle"}
        if explicit in allowed: return explicit
        score = float(opportunity.get("score", 0.0) or 0.0)
        gaps = opportunity.get("gap_score", 0.0) or 0.0
        return "interactive_tool" if score >= 70 and float(gaps) >= 50 else "course"
