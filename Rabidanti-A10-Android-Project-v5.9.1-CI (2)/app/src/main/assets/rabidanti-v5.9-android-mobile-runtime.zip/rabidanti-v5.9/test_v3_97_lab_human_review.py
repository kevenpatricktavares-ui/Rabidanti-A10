import sqlite3
import pytest

from lab_evidence_memory import LabEvidenceMemory
from lab_experiment_manager import LabExperimentManager
from lab_human_review import LabHumanReviewWorkflow


def make_ready(tmp_path):
    m = LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1", "p1", "human review", "hypothesis", "method", ["criterion A"])
    m.transition("e1", "RUNNING", "start")
    m.transition("e1", "ANALYSIS", "analysis")
    m.transition("e1", "PASSED", "pass")
    for rid in ("r1", "r2"):
        m.add_entry("e1", f"{rid}:result", "RESULT", "completed", {
            "run_id": rid, "experiment_id": "e1", "executed": True, "status": "completed"
        })
        m.add_entry("e1", f"a-{rid}:analysis", "RECOMMENDATION", "review", {
            "analysis_id": f"a-{rid}", "experiment_id": "e1", "run_id": rid,
            "classification": "PASSED", "integration_authorized": False,
        })
    m.add_entry("e1", "rep-1:reproducibility", "RECOMMENDATION", "repro", {
        "reproducibility_id": "rep-1", "experiment_id": "e1", "run_ids": ["r1", "r2"],
        "classification": "CONSISTENT", "integration_authorized": False,
    })
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    wf = LabHumanReviewWorkflow(m, mem, tmp_path / "reviews.sqlite3")
    return m, mem, wf


def test_ready_experiment_can_open_persistent_human_review(tmp_path):
    _, _, wf = make_ready(tmp_path)
    review = wf.open_review("e1", requested_by="creator-1")
    assert review["status"] == "PENDING_HUMAN_REVIEW"
    assert review["requested_by"] == "creator-1"
    assert review["integration_authorized"] is False
    assert wf.events(review["review_id"])[0]["event_type"] == "REVIEW_OPENED"


def test_not_ready_experiment_cannot_enter_human_review(tmp_path):
    m = LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1", "p1", "not ready", "hypothesis", "method", ["criterion A"])
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    wf = LabHumanReviewWorkflow(m, mem, tmp_path / "reviews.sqlite3")
    with pytest.raises(ValueError, match="not ready for human review"):
        wf.open_review("e1")


def test_approval_records_identity_rationale_and_evidence_without_authority(tmp_path):
    _, mem, wf = make_ready(tmp_path)
    review = wf.open_review("e1")
    decided = wf.decide(
        review["review_id"], "APPROVED", decided_by="creator-1", rationale="Evidence is adequate for proposal review."
    )
    assert decided["status"] == "APPROVED"
    assert decided["decided_by"] == "creator-1"
    assert decided["integration_authorized"] is False
    node = mem.get_node(f"human-review-decision:{review['review_id']}")
    assert node["metadata"]["scientifically_validated"] is False
    assert node["metadata"]["external_action_authorized"] is False
    assert node["metadata"]["identity_assurance"] == "ASSERTED_ONLY"


def test_reject_and_more_evidence_are_valid_final_decisions(tmp_path):
    for decision in ("REJECTED", "MORE_EVIDENCE_REQUIRED"):
        sub = tmp_path / decision.lower()
        sub.mkdir()
        _, _, wf = make_ready(sub)
        review = wf.open_review("e1")
        out = wf.decide(review["review_id"], decision, decided_by="creator", rationale="review rationale")
        assert out["status"] == decision


def test_decision_is_immutable_and_second_decision_fails_closed(tmp_path):
    _, _, wf = make_ready(tmp_path)
    review = wf.open_review("e1")
    wf.decide(review["review_id"], "APPROVED", decided_by="creator", rationale="first and final")
    with pytest.raises(ValueError, match="already has a final decision"):
        wf.decide(review["review_id"], "REJECTED", decided_by="creator", rationale="changed mind")


def test_review_survives_restart_and_history_is_auditable(tmp_path):
    m, mem, wf = make_ready(tmp_path)
    review = wf.open_review("e1", requested_by="creator")
    wf.decide(review["review_id"], "APPROVED", decided_by="creator", rationale="accepted")
    restarted = LabHumanReviewWorkflow(m, mem, tmp_path / "reviews.sqlite3")
    loaded = restarted.get(review["review_id"])
    history = restarted.history("e1")
    assert loaded["status"] == "APPROVED"
    assert history["reviews"][0]["review_id"] == review["review_id"]
    assert history["integration_authorized"] is False


def test_same_readiness_snapshot_does_not_create_duplicate_review(tmp_path):
    _, _, wf = make_ready(tmp_path)
    a = wf.open_review("e1", requested_by="creator")
    b = wf.open_review("e1", requested_by="someone-else")
    assert a["review_id"] == b["review_id"]
    with sqlite3.connect(wf.database) as c:
        assert c.execute("SELECT COUNT(*) FROM lab_human_reviews").fetchone()[0] == 1
        assert c.execute("SELECT COUNT(*) FROM lab_human_review_events").fetchone()[0] == 1


def test_identity_and_permissions_fail_closed(tmp_path):
    _, _, wf = make_ready(tmp_path)
    with pytest.raises(ValueError, match="requested_by"):
        wf.open_review("e1", requested_by="  ")
    review = wf.open_review("e1")
    with pytest.raises(ValueError, match="decided_by"):
        wf.decide(review["review_id"], "APPROVED", decided_by="", rationale="valid")
    with pytest.raises(PermissionError, match="Core integration"):
        wf.authorize_integration(review["review_id"])
    with pytest.raises(PermissionError, match="external actions"):
        wf.authorize_external_action(review["review_id"])
