import sqlite3
import pytest

from lab_evidence_memory import LabEvidenceMemory
from lab_evidence_readiness import LabEvidenceReadinessGate
from lab_experiment_manager import LabExperimentManager


def make_manager(tmp_path, status="PASSED"):
    m = LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1", "p1", "readiness", "hypothesis", "method", ["criterion A"])
    m.transition("e1", "RUNNING", "start")
    m.transition("e1", "ANALYSIS", "analysis")
    if status == "PASSED":
        m.transition("e1", "PASSED", "pass")
    return m


def add_run_and_analysis(m, rid, classification="PASSED"):
    m.add_entry("e1", f"{rid}:result", "RESULT", "completed", {
        "run_id": rid, "experiment_id": "e1", "executed": True, "status": "completed"
    })
    m.add_entry("e1", f"a-{rid}:analysis", "RECOMMENDATION", "review", {
        "analysis_id": f"a-{rid}", "experiment_id": "e1", "run_id": rid,
        "classification": classification,
        "criteria": {"criterion A": {"state": "PASS" if classification == "PASSED" else "FAIL", "evidence": "reviewed"}},
        "integration_authorized": False,
    })


def add_repro(m, classification="CONSISTENT", runs=("r1", "r2")):
    m.add_entry("e1", "rep-1:reproducibility", "RECOMMENDATION", "repro", {
        "reproducibility_id": "rep-1", "experiment_id": "e1", "run_ids": list(runs),
        "classification": classification, "integration_authorized": False,
    })


def test_ready_only_after_passed_runs_analyses_and_consistent_reproducibility(tmp_path):
    m = make_manager(tmp_path)
    add_run_and_analysis(m, "r1")
    add_run_and_analysis(m, "r2")
    add_repro(m)
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    report = LabEvidenceReadinessGate(m, mem).assess("e1")
    assert report["classification"] == "READY_FOR_HUMAN_REVIEW"
    assert report["human_review_required"] is True
    assert report["scientifically_validated"] is False
    assert report["integration_authorized"] is False


def test_insufficient_when_minimum_executed_runs_not_met(tmp_path):
    m = make_manager(tmp_path)
    add_run_and_analysis(m, "r1")
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    report = LabEvidenceReadinessGate(m, mem).assess("e1")
    assert report["classification"] == "INSUFFICIENT_EVIDENCE"
    assert report["human_review_required"] is False


def test_not_ready_on_failed_analysis_even_with_repro_record(tmp_path):
    m = make_manager(tmp_path)
    add_run_and_analysis(m, "r1")
    add_run_and_analysis(m, "r2", "FAILED")
    add_repro(m)
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    report = LabEvidenceReadinessGate(m, mem).assess("e1")
    assert report["classification"] == "NOT_READY"
    assert any("no PASSED analysis" in x for x in report["reasons"])


def test_reproducibility_must_be_consistent_and_cover_recorded_runs(tmp_path):
    m = make_manager(tmp_path)
    add_run_and_analysis(m, "r1")
    add_run_and_analysis(m, "r2")
    add_repro(m, classification="DIVERGENT")
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    report = LabEvidenceReadinessGate(m, mem).assess("e1")
    assert report["classification"] == "NOT_READY"
    assert "no CONSISTENT reproducibility" in " ".join(report["reasons"])


def test_persisted_assessment_is_idempotent_for_same_evidence_snapshot(tmp_path):
    m = make_manager(tmp_path)
    add_run_and_analysis(m, "r1")
    add_run_and_analysis(m, "r2")
    add_repro(m)
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    gate = LabEvidenceReadinessGate(m, mem)
    first = gate.assess("e1")
    second = gate.assess("e1")
    assert first["readiness_id"] == second["readiness_id"]
    with sqlite3.connect(mem.database) as c:
        decisions = c.execute("SELECT COUNT(*) FROM lab_evidence_nodes WHERE kind='DECISION'").fetchone()[0]
        links = c.execute("SELECT COUNT(*) FROM lab_evidence_links WHERE relation='HAS_READINESS_ASSESSMENT'").fetchone()[0]
    assert decisions == 1
    assert links == 1


def test_new_evidence_snapshot_creates_new_auditable_assessment(tmp_path):
    m = make_manager(tmp_path)
    add_run_and_analysis(m, "r1")
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    gate = LabEvidenceReadinessGate(m, mem)
    first = gate.assess("e1")
    add_run_and_analysis(m, "r2")
    add_repro(m)
    second = gate.assess("e1")
    assert first["readiness_id"] != second["readiness_id"]
    assert second["classification"] == "READY_FOR_HUMAN_REVIEW"


def test_gate_cannot_authorize_integration(tmp_path):
    m = make_manager(tmp_path)
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    gate = LabEvidenceReadinessGate(m, mem)
    with pytest.raises(PermissionError, match="cannot authorize"):
        gate.authorize_integration("e1")


def test_minimum_runs_validation(tmp_path):
    m = make_manager(tmp_path)
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    with pytest.raises(ValueError, match="integer >= 2"):
        LabEvidenceReadinessGate(m, mem).assess("e1", minimum_runs=1)
