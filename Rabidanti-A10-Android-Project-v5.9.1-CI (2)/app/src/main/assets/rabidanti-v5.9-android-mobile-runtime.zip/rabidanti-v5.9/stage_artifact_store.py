"""Rabidanti v3.33 — durable business-stage outputs."""
from __future__ import annotations
import json, sqlite3, threading, time
from typing import Any, Optional
class StageArtifactStore:
    def __init__(self, db_path: str):
        self._lock=threading.RLock(); self.db_path=db_path
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA foreign_keys=ON")
        if db_path != ':memory:': self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS stage_artifacts (
            project_id TEXT NOT NULL, stage TEXT NOT NULL, output_json TEXT NOT NULL,
            created_at REAL NOT NULL, updated_at REAL NOT NULL,
            PRIMARY KEY(project_id, stage))''')
    def put(self, project_id: str, stage: str, output: Any) -> None:
        now=time.time(); payload=json.dumps(output, ensure_ascii=False, default=str)
        with self._lock:
            self._conn.execute('''INSERT INTO stage_artifacts(project_id,stage,output_json,created_at,updated_at)
            VALUES(?,?,?,?,?) ON CONFLICT(project_id,stage) DO UPDATE SET output_json=excluded.output_json,updated_at=excluded.updated_at''',
            (str(project_id),str(stage),payload,now,now))
    def get(self, project_id: str, stage: str) -> Optional[Any]:
        with self._lock:
            row=self._conn.execute('SELECT output_json FROM stage_artifacts WHERE project_id=? AND stage=?',(str(project_id),str(stage))).fetchone()
        return None if row is None else json.loads(row[0])
