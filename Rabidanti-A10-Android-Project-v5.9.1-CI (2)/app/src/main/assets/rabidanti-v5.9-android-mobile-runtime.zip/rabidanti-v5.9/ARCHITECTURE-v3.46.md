# Rabidanti v3.46 — World Awareness Foundation

Adds an evidence-first World Awareness layer for externally obtained information.
It stores source provenance, timestamps, verification state, freshness and normalized signals.
This version intentionally does not perform network fetching; a future connector layer will supply source records from approved current-data providers.

Flow: external source -> provenance record -> normalized signal -> freshness/confidence -> Laboratory.
