from dataclasses import dataclass
import pytest
from lab_experiment_manager import LabExperimentManager
from lab_experiment_pipeline import LabExperimentPipeline

@dataclass
class FakeResult:
    status: str = "completed"
    executed: bool = True
    return_code: int = 0
    stdout: str = "ok"
    stderr: str = ""
    started_at: str = "start"
    finished_at: str = "finish"
    audit_digest: str = "a" * 64

class FakeExecutor:
    MAX_OUTPUT = 8000
    result = FakeResult()
    calls = 0
    @classmethod
    def execute(cls, plan, probe, *, approved=False, timeout=None):
        cls.calls += 1
        assert approved is True
        return cls.result

def make_manager(tmp_path):
    m = LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1", "p1", "test experiment", "hypothesis", "method", ["output is ok"])
    return m

def test_requires_per_run_approval_without_mutating_state(tmp_path):
    m = make_manager(tmp_path); FakeExecutor.calls = 0
    with pytest.raises(PermissionError):
        LabExperimentPipeline(m, FakeExecutor).run("e1", {}, {}, approved=False)
    assert m.get("e1").status == "PLANNED"
    assert FakeExecutor.calls == 0

def test_records_result_and_moves_to_analysis(tmp_path):
    m = make_manager(tmp_path); FakeExecutor.calls = 0; FakeExecutor.result = FakeResult()
    out = LabExperimentPipeline(m, FakeExecutor).run("e1", {}, {}, approved=True)
    assert out["executed"] is True and out["audit_digest"] == "a" * 64
    assert m.get("e1").status == "ANALYSIS"
    entries = m.list_entries("e1", "RESULT")
    assert len(entries) == 1 and entries[0]["metadata"]["run_id"] == out["run_id"]

def test_blocked_runtime_is_recorded_as_not_executed(tmp_path):
    m = make_manager(tmp_path); FakeExecutor.result = FakeResult(status="blocked_runtime_unavailable", executed=False, return_code=None)
    out = LabExperimentPipeline(m, FakeExecutor).run("e1", {}, {}, approved=True)
    assert not out["executed"]
    assert m.get("e1").status == "ANALYSIS"
    assert m.list_entries("e1", "RESULT")[0]["metadata"]["status"] == "blocked_runtime_unavailable"

def test_only_planned_experiment_can_launch(tmp_path):
    m = make_manager(tmp_path)
    m.transition("e1", "RUNNING", "manual-start")
    with pytest.raises(ValueError):
        LabExperimentPipeline(m, FakeExecutor).run("e1", {}, {}, approved=True)

def test_executor_exception_is_recorded_as_risk(tmp_path):
    class BrokenExecutor:
        MAX_OUTPUT = 8000
        @staticmethod
        def execute(*args, **kwargs): raise RuntimeError("simulated failure")
    m = make_manager(tmp_path)
    with pytest.raises(RuntimeError):
        LabExperimentPipeline(m, BrokenExecutor).run("e1", {}, {}, approved=True)
    assert m.get("e1").status == "ANALYSIS"
    assert len(m.list_entries("e1", "RISK")) == 1
