"""Rabidanti v3.36 — Content Review domain engine."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class ReviewBrief:
    project_id: str
    source_stage: str
    status: str
    score: int
    checks: tuple[dict[str, Any], ...]
    blockers: tuple[str, ...]
    recommendations: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

class ReviewEngine:
    """Deterministic quality gate for generated content before rendering."""
    def review(self, project_id: str, content: Mapping[str, Any]) -> ReviewBrief:
        if not str(project_id).strip():
            raise ValueError("project_id must not be empty")
        c = dict(content or {})
        if not c:
            raise ValueError("content must not be empty")
        checks: list[dict[str, Any]] = []
        blockers: list[str] = []
        recommendations: list[str] = []

        def check(name: str, passed: bool, detail: str) -> None:
            checks.append({"name": name, "passed": bool(passed), "detail": detail})
            if not passed:
                blockers.append(detail)

        check("identity", bool(str(c.get("title") or "").strip()), "Content title is missing.")
        outline = c.get("outline") or ()
        check("structure", isinstance(outline, (list, tuple)) and len(outline) >= 3,
              "Content outline is missing or too short.")
        check("audience", bool(str(c.get("audience") or "").strip()), "Target audience is missing.")
        check("format", bool(str(c.get("format") or "").strip()), "Content format is missing.")

        limitations = tuple(str(x) for x in (c.get("limitations") or ()) if str(x).strip())
        if not any("review" in x.lower() for x in limitations):
            recommendations.append("Add explicit factual, rights, quality, and human-review requirements.")
        recommendations.append("Verify factual claims, rights, assets, and platform requirements before publication.")
        recommendations.append("Keep human approval required for consequential publication decisions.")

        passed_count = sum(1 for x in checks if x["passed"])
        score = round(100 * passed_count / max(1, len(checks)))
        status = "PASS" if not blockers else "BLOCKED"
        return ReviewBrief(str(project_id), "content", status, score,
                           tuple(checks), tuple(dict.fromkeys(blockers)),
                           tuple(dict.fromkeys(recommendations)))
