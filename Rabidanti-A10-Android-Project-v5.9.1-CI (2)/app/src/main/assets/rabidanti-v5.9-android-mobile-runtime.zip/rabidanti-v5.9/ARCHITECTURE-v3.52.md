
### v3.52
Controlled World Intelligence Ingestion.
- Normalizes externally obtained records.
- Computes SHA-256 content hashes when content is supplied.
- Deduplicates by canonical locator or content hash.
- Preserves publisher, timestamps, provenance and caller-provided verification.
- Supports bounded batch ingestion.
- Never fetches the web and never infers verification.
