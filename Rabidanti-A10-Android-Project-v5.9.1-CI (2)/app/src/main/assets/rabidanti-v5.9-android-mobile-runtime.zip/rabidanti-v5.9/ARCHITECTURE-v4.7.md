# Rabidanti v4.7 — Model Gateway & Conversation Layer

## Objetivo
Adicionar uma camada conversacional persistente ao runtime local sem conceder ao modelo autoridade sobre ferramentas, conectores, Core ou ações externas.

## Componentes
- `rabidanti_model_gateway.py`: gateway local compatível com Ollama; apenas endpoints loopback.
- `rabidanti_conversation.py`: histórico persistente em SQLite e contexto de conversa.
- `rabidanti_runtime.py`: inicializa gateway e engine de conversa.
- `rabidanti_api.py`: endpoints locais de chat/conversas.
- `ui/`: aba Chat integrada na Sala.
- `rabidanti_config.py`: configuração de provider/model/base_url/timeout, restringindo `base_url` a loopback.

## Limites de segurança
- provider v4.7: `ollama` apenas;
- `ai.base_url` apenas `127.0.0.1`, `localhost` ou `::1`;
- request ao modelo usa `tools: []`;
- resposta do modelo é texto, não autorização;
- `external_action_authorized = false`;
- `tool_execution_authorized = false`;
- nenhum connector ou shell é invocado a partir da resposta do modelo.

## Persistência
Conversas e mensagens são guardadas em `conversations.sqlite3` no state-dir do runtime.

## Estado de validação
O gateway foi validado com HTTP mock compatível com Ollama. A presença de um servidor Ollama/modelo real não é presumida nem declarada nesta versão.
