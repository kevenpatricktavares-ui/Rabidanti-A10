"""Rabidanti v5.1 first-run onboarding state.

The onboarding record contains no credentials. It records only product setup
choices and completion metadata. Secrets such as API tokens and vault master
keys remain process-memory/environment only.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
import json
import os
import tempfile


class OnboardingError(ValueError):
    pass


class FirstRunOnboarding:
    SCHEMA_VERSION = 1
    _ALLOWED_CHANGES = {
        "ai.model",
        "ai.fallback_model",
        "ui.auto_open_browser",
        "logging.level",
    }

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _read(self) -> dict[str, Any] | None:
        if not self.path.exists():
            return None
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise OnboardingError(f"invalid onboarding state: {exc}") from exc
        if not isinstance(data, dict) or data.get("schema_version") != self.SCHEMA_VERSION:
            raise OnboardingError("invalid onboarding state format")
        return data

    def _persist(self, payload: Mapping[str, Any]) -> None:
        text = json.dumps(dict(payload), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        fd, temp_name = tempfile.mkstemp(prefix=".onboarding-", suffix=".tmp", dir=str(self.path.parent), text=True)
        try:
            if os.name != "nt":
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(text)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
            if os.name != "nt":
                os.chmod(self.path, 0o600)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def status(self) -> dict[str, Any]:
        data = self._read()
        if data is None:
            return {
                "completed": False,
                "schema_version": self.SCHEMA_VERSION,
                "completed_at": None,
                "selected_model": None,
                "fallback_model": None,
                "vault_was_unlocked": False,
                "external_action_authorized": False,
            }
        return dict(data)

    def complete(
        self,
        *,
        config_changes: Mapping[str, Any],
        selected_model: str,
        fallback_model: str = "",
        vault_was_unlocked: bool = False,
    ) -> dict[str, Any]:
        unknown = set(config_changes) - self._ALLOWED_CHANGES
        if unknown:
            raise OnboardingError(f"unsupported onboarding configuration: {', '.join(sorted(unknown))}")
        if not isinstance(selected_model, str) or not selected_model.strip():
            raise OnboardingError("selected_model is required")
        if not isinstance(fallback_model, str):
            raise OnboardingError("fallback_model must be a string")
        payload = {
            "schema_version": self.SCHEMA_VERSION,
            "completed": True,
            "completed_at": self._now(),
            "selected_model": selected_model.strip(),
            "fallback_model": fallback_model.strip(),
            "vault_was_unlocked": bool(vault_was_unlocked),
            "external_action_authorized": False,
        }
        self._persist(payload)
        return dict(payload)

    def reset(self) -> dict[str, Any]:
        if self.path.exists():
            self.path.unlink()
        return self.status()
