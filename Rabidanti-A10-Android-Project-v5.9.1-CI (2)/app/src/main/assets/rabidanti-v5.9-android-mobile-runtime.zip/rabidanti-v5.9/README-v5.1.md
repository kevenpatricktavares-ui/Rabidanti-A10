# Rabidanti v5.1 — First-Run Wizard & Desktop Product Experience

Versão: **5.1.0**

A v5.1 transforma o arranque da v5.0 numa experiência de produto mais próxima de uma aplicação desktop. O launcher continua local, mas agora entrega o token efémero diretamente à Sala através do fragmento URL, remove esse fragmento do endereço no navegador e abre a configuração inicial quando necessário.

## Primeiro arranque

1. Execute `START-RABIDANTI.bat` no Windows ou `START-RABIDANTI.sh` no Linux/macOS.
2. O launcher cria/usa o diretório persistente do utilizador.
3. A Sala abre no browser local (`127.0.0.1`).
4. No primeiro arranque, a aba **Primeiro arranque** é apresentada automaticamente.
5. O utilizador escolhe modelo principal, fallback, nível de log e preferência de abertura da Sala.
6. Opcionalmente, pode desbloquear o vault cifrado apenas para a sessão atual.

O wizard não instala Ollama, não descarrega modelos e não autoriza ações externas.

## Segurança do token local

O token efémero é colocado apenas no fragmento URL (`#...`), que não é enviado ao servidor HTTP. O JavaScript da Sala lê o fragmento, coloca o token apenas em memória/DOM e chama `history.replaceState` para o remover do endereço. Não é usado `localStorage`, `sessionStorage` ou cookies.

## Estado do onboarding

`onboarding.json` guarda apenas metadados não sensíveis: conclusão, data, modelo escolhido, fallback e indicação de que o vault esteve desbloqueado. A chave-mestra nunca é gravada.

## Vault

A Sala permite desbloquear o vault com a chave-mestra para a sessão atual. O valor não é persistido no disco nem registado nos eventos. Após reiniciar, a chave deve voltar a ser fornecida ou estar disponível externamente via `RABIDANTI_VAULT_MASTER_KEY`.

## Correção de API

A v5.1 removeu rotas de mutação de conectores que estavam indevidamente alcançáveis dentro do handler `GET`. As mutações continuam disponíveis apenas por `POST` autenticado.

## Estado de produto

A aplicação fonte é arrancável e o fluxo de primeiro arranque está validado. A geração de `Rabidanti.exe` continua preparada por PyInstaller, mas não foi construída neste ambiente porque PyInstaller não está disponível e não há acesso externo para o instalar.
