# Rabidanti v3.53 — Source Acquisition & Verification Layer

Adds bounded HTTP(S) source acquisition with timeout, size limits, content hashing, basic HTML text/title extraction and explicit acquisition status. Acquisition success is not factual verification and the module never marks a source as verified by itself. The next layer can combine multiple sources, publisher metadata and evidence to assess verification.
