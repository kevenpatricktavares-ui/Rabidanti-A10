# PyInstaller specification for Rabidanti desktop build specification. Version metadata is generated from VERSION.
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = collect_submodules("uvicorn") + collect_submodules("fastapi")

a = Analysis(
    ["rabidanti_launcher.py"],
    pathex=["."],
    binaries=[],
    datas=[("ui", "ui"), ("VERSION", ".")],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="Rabidanti",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    icon="assets/rabidanti.ico",
    version="rabidanti_version_info.txt",
)
