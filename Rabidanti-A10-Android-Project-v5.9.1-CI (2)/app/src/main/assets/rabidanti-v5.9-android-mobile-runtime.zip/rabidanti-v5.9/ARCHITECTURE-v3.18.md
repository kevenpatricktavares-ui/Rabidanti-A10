# Rabidanti v3.18 — Health-Driven Recovery

Adds a conservative RecoveryEngine over v3.17 health monitoring.

Flow: observe -> detect -> recover safely -> verify.

Recovery is bounded and reversible:
- expired queue leases are recovered by the durable queue;
- stale workers are reactivated only when active=0;
- stale workers with active work are skipped, leaving lease recovery responsible for abandoned work;
- every recovery decision is recorded in observability.

This remains a local SQLite/in-process foundation. It does not claim cloud
orchestration, autoscaling, external brokers, multi-region failover, or 24/7
production availability.
