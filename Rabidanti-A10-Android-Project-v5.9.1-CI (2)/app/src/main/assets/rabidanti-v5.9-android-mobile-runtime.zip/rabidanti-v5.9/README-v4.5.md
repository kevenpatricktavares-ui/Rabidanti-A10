# Rabidanti v4.5

v4.5 adds an encrypted local credential vault, OAuth 2.0 Authorization Code + PKCE support, and the first concrete connector: Gmail read-only.

## Master key
Set a strong master key outside the Rabidanti state directory:

```bash
export RABIDANTI_VAULT_MASTER_KEY='use-a-long-random-value-at-least-24-characters'
```

Windows PowerShell:

```powershell
$env:RABIDANTI_VAULT_MASTER_KEY='use-a-long-random-value-at-least-24-characters'
```

## Vault

```bash
python rabidanti.py vault status
python rabidanti.py vault set GOOGLE_CLIENT_SECRET
python rabidanti.py vault delete GOOGLE_CLIENT_SECRET
```

Values entered with `vault set` are encrypted before persistence. The master key is not saved by Rabidanti.

## Start Google/Gmail OAuth
Create OAuth credentials in Google Cloud with the Gmail read-only scope, then:

```bash
python rabidanti.py oauth gmail-start \
  --client-id YOUR_CLIENT_ID \
  --redirect-uri http://127.0.0.1:8765/oauth/callback
```

Open the returned authorization URL. After Google returns a `code` and `state`, exchange it:

```bash
python rabidanti.py oauth gmail-exchange \
  --flow-id FLOW_ID \
  --state STATE \
  --code CODE \
  --client-id YOUR_CLIENT_ID
```

If the OAuth client requires a client secret, store it first as `GOOGLE_CLIENT_SECRET` in the vault or session/environment secret store.

## Enable Gmail connector

```bash
python rabidanti.py connector set gmail.readonly on \
  --actor Esequiel \
  --reason 'Enable Gmail read-only access'
```

## Read Gmail

```bash
python rabidanti.py gmail profile
python rabidanti.py gmail list --query 'is:unread' --max-results 20
python rabidanti.py gmail get MESSAGE_ID --format metadata
```

v4.5 has no Gmail write/send/delete capability.

## Validation note
The HTTP/OAuth implementation is automatically tested against mocks. A real Google account was not connected during build validation, so live Google OAuth/API operation must still be validated with the creator's explicitly authorized account.
