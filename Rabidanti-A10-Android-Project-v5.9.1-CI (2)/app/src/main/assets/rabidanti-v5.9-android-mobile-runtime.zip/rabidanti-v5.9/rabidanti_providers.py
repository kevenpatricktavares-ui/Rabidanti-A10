"""Rabidanti v4.6 — persistent external provider state.

This module stores provider *metadata only*. OAuth access/refresh tokens and
client secrets remain in Rabidanti's secret boundary/vault and are never stored
in this SQLite database.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional
import json
import sqlite3


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ProviderStateStore:
    SCHEMA_VERSION = 1

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = str(Path(db_path).expanduser().resolve())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._conn() as c:
            c.execute(
                """CREATE TABLE IF NOT EXISTS providers(
                    provider_id TEXT PRIMARY KEY,
                    display_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    token_expires_at TEXT,
                    connected_at TEXT,
                    last_refresh_at TEXT,
                    last_test_at TEXT,
                    last_test_ok INTEGER,
                    revoked_at TEXT,
                    last_error TEXT,
                    scopes_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )"""
            )
            c.execute(
                """CREATE TABLE IF NOT EXISTS provider_metadata(
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )"""
            )
            c.execute(
                "INSERT OR REPLACE INTO provider_metadata(key,value) VALUES(?,?)",
                ("schema_version", str(self.SCHEMA_VERSION)),
            )

    def register(self, provider_id: str, display_name: str, *, scopes: tuple[str, ...] = ()) -> dict[str, Any]:
        if not provider_id or not display_name:
            raise ValueError("provider_id and display_name are required")
        now = _now()
        with self._conn() as c:
            row = c.execute("SELECT provider_id FROM providers WHERE provider_id=?", (provider_id,)).fetchone()
            if row is None:
                c.execute(
                    "INSERT INTO providers VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (provider_id, display_name, "NOT_CONNECTED", None, None, None, None, None, None, None,
                     json.dumps(list(scopes)), "{}", now),
                )
            else:
                c.execute(
                    "UPDATE providers SET display_name=?, scopes_json=?, updated_at=? WHERE provider_id=?",
                    (display_name, json.dumps(list(scopes)), now, provider_id),
                )
        return self.get(provider_id)

    def get(self, provider_id: str) -> dict[str, Any]:
        with self._conn() as c:
            row = c.execute("SELECT * FROM providers WHERE provider_id=?", (provider_id,)).fetchone()
        if row is None:
            raise KeyError(f"provider not found: {provider_id}")
        return self._row(row)

    def list(self) -> list[dict[str, Any]]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM providers ORDER BY provider_id").fetchall()
        return [self._row(r) for r in rows]

    @staticmethod
    def _row(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        item["last_test_ok"] = None if item["last_test_ok"] is None else bool(item["last_test_ok"])
        item["scopes"] = json.loads(item.pop("scopes_json"))
        item["metadata"] = json.loads(item.pop("metadata_json"))
        return item

    def record_authorized(self, provider_id: str, *, expires_in: Optional[int], scopes: Optional[str] = None) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        expires_at = None
        if expires_in is not None:
            try:
                seconds = int(expires_in)
            except (TypeError, ValueError):
                seconds = 0
            if seconds > 0:
                expires_at = (now + timedelta(seconds=seconds)).isoformat()
        metadata = self.get(provider_id)["metadata"]
        if scopes:
            metadata["granted_scope"] = str(scopes)
        with self._conn() as c:
            c.execute(
                """UPDATE providers SET status='CONNECTED', token_expires_at=?, connected_at=COALESCE(connected_at,?),
                   revoked_at=NULL, last_error=NULL, metadata_json=?, updated_at=? WHERE provider_id=?""",
                (expires_at, now.isoformat(), json.dumps(metadata, sort_keys=True), now.isoformat(), provider_id),
            )
        return self.get(provider_id)

    def record_refresh(self, provider_id: str, *, expires_in: Optional[int], scopes: Optional[str] = None) -> dict[str, Any]:
        item = self.record_authorized(provider_id, expires_in=expires_in, scopes=scopes)
        now = _now()
        with self._conn() as c:
            c.execute("UPDATE providers SET last_refresh_at=?, updated_at=? WHERE provider_id=?", (now, now, provider_id))
        return self.get(provider_id)

    def mark_revoked(self, provider_id: str, error: str) -> dict[str, Any]:
        now = _now()
        with self._conn() as c:
            c.execute(
                "UPDATE providers SET status='REVOKED', revoked_at=?, last_error=?, updated_at=? WHERE provider_id=?",
                (now, str(error)[:1000], now, provider_id),
            )
        return self.get(provider_id)

    def mark_error(self, provider_id: str, error: str) -> dict[str, Any]:
        now = _now()
        with self._conn() as c:
            c.execute(
                "UPDATE providers SET status=CASE WHEN status='NOT_CONNECTED' THEN 'ERROR' ELSE status END, last_error=?, updated_at=? WHERE provider_id=?",
                (str(error)[:1000], now, provider_id),
            )
        return self.get(provider_id)

    def record_test(self, provider_id: str, ok: bool, error: Optional[str] = None) -> dict[str, Any]:
        now = _now()
        with self._conn() as c:
            c.execute(
                "UPDATE providers SET last_test_at=?, last_test_ok=?, last_error=?, updated_at=? WHERE provider_id=?",
                (now, 1 if ok else 0, None if ok else str(error or "connection test failed")[:1000], now, provider_id),
            )
        return self.get(provider_id)

    def token_needs_refresh(self, provider_id: str, *, skew_seconds: int = 60) -> bool:
        item = self.get(provider_id)
        raw = item.get("token_expires_at")
        if not raw:
            return False
        try:
            expires = datetime.fromisoformat(str(raw))
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
        except ValueError:
            return True
        return expires <= datetime.now(timezone.utc) + timedelta(seconds=max(0, int(skew_seconds)))
