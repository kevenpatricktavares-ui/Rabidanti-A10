# Rabidanti v3.98

**Laboratory Integration Proposal Workflow**

This version turns an `APPROVED` v3.97 human laboratory review into a persistent,
immutable and auditable proposal for a future controlled Core change.

A proposal records the exact reviewed evidence snapshot, target component,
affected repository-relative files, change plan, regression test plan, rollback
plan, explicit risks and the asserted proposal author. Identical proposals are
idempotent; material changes create a new proposal and preserve the old one.

A v3.98 proposal is **non-executable**. It cannot modify repository files,
authorize Core integration, publish, spend, make payments, sign contracts or
perform other external actions. A separate authorization and controlled change
executor are required before any change can be applied.

See `ARCHITECTURE-v3.98.md` and `test_v3_98_lab_integration_proposal.py`.
