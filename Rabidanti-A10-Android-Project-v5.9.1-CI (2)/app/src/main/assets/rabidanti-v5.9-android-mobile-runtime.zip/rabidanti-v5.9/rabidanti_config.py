"""Rabidanti v4.3 — configuration and secrets boundary.

Persistent configuration is intentionally limited to a small allowlist of
non-sensitive settings. Secret material is never written by this module: it may
come from process environment or an in-memory session store only.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Optional
import json
import os
import re
import tempfile
from urllib.parse import urlparse


SECRET_MARKERS = ("secret", "token", "password", "passwd", "credential", "api_key", "apikey", "private_key", "master_key")
_SECRET_NAME = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")

def _is_loopback_model_url(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    try:
        parsed = urlparse(value)
    except Exception:
        return False
    return parsed.scheme in {"http", "https"} and (parsed.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"} and not parsed.username and not parsed.password and not parsed.query and not parsed.fragment


DEFAULT_CONFIG: dict[str, Any] = {
    "api": {"host": "127.0.0.1", "port": 8765},
    "ui": {"auto_open_browser": True},
    "runtime": {"recover_on_start": True},
    "logging": {"level": "INFO"},
    "ai": {"provider": "ollama", "base_url": "http://127.0.0.1:11434", "model": "llama3.2", "fallback_model": "", "timeout_seconds": 60},
}

_ALLOWED = {
    "api.host": lambda v: isinstance(v, str) and v in {"127.0.0.1", "::1", "localhost"},
    "api.port": lambda v: isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 65535,
    "ui.auto_open_browser": lambda v: isinstance(v, bool),
    "runtime.recover_on_start": lambda v: isinstance(v, bool),
    "logging.level": lambda v: isinstance(v, str) and v.upper() in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"},
    "ai.provider": lambda v: v == "ollama",
    "ai.base_url": _is_loopback_model_url,
    "ai.model": lambda v: isinstance(v, str) and 0 < len(v.strip()) <= 200,
    "ai.fallback_model": lambda v: isinstance(v, str) and len(v.strip()) <= 200,
    "ai.timeout_seconds": lambda v: isinstance(v, (int,float)) and not isinstance(v,bool) and 1 <= v <= 300,
}



def _looks_secret(name: str) -> bool:
    lowered = name.lower()
    return any(marker in lowered for marker in SECRET_MARKERS)


def redact_sensitive(value: Any) -> Any:
    """Return a redacted copy suitable for logs/events."""
    if isinstance(value, Mapping):
        out: dict[str, Any] = {}
        for key, item in value.items():
            out[str(key)] = "[REDACTED]" if _looks_secret(str(key)) else redact_sensitive(item)
        return out
    if isinstance(value, list):
        return [redact_sensitive(x) for x in value]
    if isinstance(value, tuple):
        return [redact_sensitive(x) for x in value]
    return value


class ConfigurationError(ValueError):
    pass


class RabidantiConfig:
    """Schema-limited, atomic JSON configuration store."""

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data = deepcopy(DEFAULT_CONFIG)
        if self.path.exists():
            self._load()
        else:
            self._persist()

    @staticmethod
    def _split(key: str) -> tuple[str, str]:
        if not isinstance(key, str) or key.count(".") != 1:
            raise ConfigurationError("configuration key must be section.name")
        section, name = key.split(".", 1)
        if _looks_secret(key):
            raise ConfigurationError("secret-like configuration keys are forbidden")
        if key not in _ALLOWED:
            raise ConfigurationError(f"unsupported configuration key: {key}")
        return section, name

    @classmethod
    def _validate(cls, key: str, value: Any) -> Any:
        cls._split(key)
        if key == "logging.level" and isinstance(value, str):
            value = value.upper()
        if not _ALLOWED[key](value):
            raise ConfigurationError(f"invalid value for {key}")
        return value

    def _load(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ConfigurationError(f"invalid configuration file: {exc}") from exc
        if not isinstance(raw, dict):
            raise ConfigurationError("configuration root must be an object")
        flattened: dict[str, Any] = {}
        for section, values in raw.items():
            if not isinstance(section, str) or not isinstance(values, dict):
                raise ConfigurationError("configuration sections must be objects")
            for name, value in values.items():
                key = f"{section}.{name}"
                flattened[key] = self._validate(key, value)
        data = deepcopy(DEFAULT_CONFIG)
        for key, value in flattened.items():
            section, name = key.split(".", 1)
            data[section][name] = value
        self._data = data

    def _persist(self) -> None:
        payload = json.dumps(self._data, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=".config-", suffix=".tmp", dir=str(self.path.parent), text=True)
        try:
            if os.name != "nt":
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
            if os.name != "nt":
                os.chmod(self.path, 0o600)
        finally:
            try:
                if os.path.exists(temp_name):
                    os.unlink(temp_name)
            except OSError:
                pass

    def as_dict(self) -> dict[str, Any]:
        return deepcopy(self._data)

    def get(self, key: str) -> Any:
        section, name = self._split(key)
        return deepcopy(self._data[section][name])

    def set(self, key: str, value: Any) -> dict[str, Any]:
        section, name = self._split(key)
        value = self._validate(key, value)
        self._data[section][name] = value
        self._persist()
        return self.as_dict()

    def update(self, changes: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(changes, Mapping) or not changes:
            raise ConfigurationError("changes must be a non-empty object")
        validated: dict[str, Any] = {}
        for key, value in changes.items():
            if not isinstance(key, str):
                raise ConfigurationError("configuration keys must be strings")
            validated[key] = self._validate(key, value)
        previous = deepcopy(self._data)
        try:
            for key, value in validated.items():
                section, name = key.split(".", 1)
                self._data[section][name] = value
            self._persist()
        except Exception:
            self._data = previous
            raise
        return self.as_dict()


class RabidantiSecrets:
    """Non-persistent secrets store backed by environment + process memory."""

    ENV_PREFIX = "RABIDANTI_SECRET_"

    def __init__(self, environ: Optional[Mapping[str, str]] = None) -> None:
        self._environ = os.environ if environ is None else environ
        self._session: dict[str, str] = {}

    @staticmethod
    def normalize_name(name: str) -> str:
        if not isinstance(name, str):
            raise ValueError("secret name must be a string")
        normalized = name.strip().upper()
        if not _SECRET_NAME.fullmatch(normalized):
            raise ValueError("secret name must match [A-Z][A-Z0-9_]{1,63}")
        return normalized

    def set_session(self, name: str, value: str) -> None:
        name = self.normalize_name(name)
        if not isinstance(value, str) or len(value) < 8:
            raise ValueError("secret value must contain at least 8 characters")
        self._session[name] = value

    def clear_session(self, name: str) -> None:
        self._session.pop(self.normalize_name(name), None)

    def get(self, name: str) -> Optional[str]:
        name = self.normalize_name(name)
        if name in self._session:
            return self._session[name]
        env_name = self.ENV_PREFIX + name
        value = self._environ.get(env_name)
        if value:
            return str(value)
        # Backwards-compatible API token source, not persisted.
        if name == "API_TOKEN":
            legacy = self._environ.get("RABIDANTI_API_TOKEN")
            if legacy:
                return str(legacy)
        return None

    def status(self, names: Optional[list[str]] = None) -> list[dict[str, Any]]:
        candidates = set(names or [])
        candidates.update(self._session)
        for key in self._environ:
            if key.startswith(self.ENV_PREFIX):
                candidates.add(key[len(self.ENV_PREFIX):])
        if self._environ.get("RABIDANTI_API_TOKEN"):
            candidates.add("API_TOKEN")
        rows = []
        for raw in sorted(candidates):
            name = self.normalize_name(raw)
            source = None
            if name in self._session:
                source = "session"
            elif self._environ.get(self.ENV_PREFIX + name):
                source = "environment"
            elif name == "API_TOKEN" and self._environ.get("RABIDANTI_API_TOKEN"):
                source = "environment_legacy"
            rows.append({"name": name, "configured": source is not None, "source": source})
        return rows

    def configured(self, name: str) -> bool:
        return self.get(name) is not None
