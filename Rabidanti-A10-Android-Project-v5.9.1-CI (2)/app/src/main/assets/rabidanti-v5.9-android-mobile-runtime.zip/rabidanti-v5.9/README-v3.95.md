# Rabidanti v3.95 — Laboratory Evidence Flow Integration

## Scope

v3.95 connects the v3.94 SQLite Evidence Memory to the existing Laboratory flow.
It records experiments, execution runs, reviewed analyses, and reproducibility
assessments with preserved authoritative IDs and typed relationships.

## Design

- New `LabEvidenceIntegration` adapter keeps the previous modules usable without
  Evidence Memory, preserving backwards compatibility.
- Deterministic node IDs (`experiment:`, `run:`, `analysis:`,
  `reproducibility:`) prevent duplicate records during repeated synchronization.
- `sync_experiment()` imports already-persisted laboratory records.
- `history()` returns evidence directly attached to a given experiment.
- Execution, result analysis, and reproducibility modules accept an optional
  `evidence_memory` and record evidence when it is supplied.
- Evidence storage remains separate from scientific validation and from human
  authorization for integration into the Core.

## Important limitations

The experiment ledger and evidence database are separate SQLite databases, so
cross-database writes are not one atomic transaction. A storage failure can
therefore leave a valid laboratory record awaiting a later `sync_experiment()`.
Evidence provenance is not independent proof of scientific truth, and a
reproducibility classification is still only a consistency assessment of the
recorded reviewed runs.
