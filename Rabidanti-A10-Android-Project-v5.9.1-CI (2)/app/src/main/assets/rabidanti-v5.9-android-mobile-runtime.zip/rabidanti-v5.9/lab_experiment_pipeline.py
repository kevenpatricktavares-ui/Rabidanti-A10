"""Rabidanti v3.91 — controlled experiment-to-execution pipeline.

Coordinates the existing experiment ledger and container executor. It records
all outcomes, never auto-integrates code, and requires per-run approval.
"""
from __future__ import annotations
from dataclasses import asdict
import uuid
from lab_container_executor import LabContainerExecutor
from lab_evidence_integration import LabEvidenceIntegration

class LabExperimentPipeline:
    def __init__(self, experiment_manager, executor=LabContainerExecutor, evidence_memory=None):
        self.manager = experiment_manager
        self.executor = executor
        self.evidence = LabEvidenceIntegration(experiment_manager, evidence_memory) if evidence_memory is not None else None

    def run(self, experiment_id, plan, probe, *, approved=False, timeout=None):
        """Run a single approved experiment and persist outcome evidence.

        If approval is missing, reject before changing experiment state. Runtime
        unavailability is recorded as a blocked outcome, not as a test failure
        or proof that the experiment ran.
        """
        exp = self.manager.get(experiment_id)
        if not approved:
            raise PermissionError("explicit per-run operator approval required")
        if exp.status != "PLANNED":
            raise ValueError("only PLANNED experiments can be launched by this pipeline")
        run_id = str(uuid.uuid4())
        self.manager.transition(experiment_id, "RUNNING", f"{run_id}:start", "Approved execution request")
        try:
            result = self.executor.execute(plan, probe, approved=True, timeout=timeout)
            payload = asdict(result) if hasattr(result, "__dataclass_fields__") else dict(result)
            status = payload.get("status", "execution_error")
            executed = payload.get("executed") is True
            record = {
                "run_id": run_id,
                "experiment_id": experiment_id,
                "status": status,
                "executed": executed,
                "return_code": payload.get("return_code"),
                "stdout": str(payload.get("stdout", ""))[:getattr(self.executor, "MAX_OUTPUT", 8000)],
                "stderr": str(payload.get("stderr", ""))[:getattr(self.executor, "MAX_OUTPUT", 8000)],
                "audit_digest": payload.get("audit_digest", ""),
                "started_at": payload.get("started_at", ""),
                "finished_at": payload.get("finished_at", ""),
            }
            self.manager.add_entry(experiment_id, f"{run_id}:result", "RESULT", status, record)
            if self.evidence is not None:
                self.evidence.record_run(experiment_id, record)
            final_status = "ANALYSIS"
            self.manager.transition(experiment_id, final_status, f"{run_id}:finish",
                                    "Execution outcome recorded; evidence awaits analysis" if executed else "Execution blocked or failed before verified run; classify during analysis")
            return record
        except Exception as exc:
            # Persist the failure where possible, but do not disguise it as a run.
            try:
                self.manager.add_entry(experiment_id, f"{run_id}:error", "RISK", str(exc)[:1000],
                                       {"run_id": run_id, "executed": False, "error_type": type(exc).__name__})
                current = self.manager.get(experiment_id).status
                if current == "RUNNING":
                    self.manager.transition(experiment_id, "ANALYSIS", f"{run_id}:error-finish", "Executor raised; inspect recorded risk")
            except Exception:
                pass
            raise
