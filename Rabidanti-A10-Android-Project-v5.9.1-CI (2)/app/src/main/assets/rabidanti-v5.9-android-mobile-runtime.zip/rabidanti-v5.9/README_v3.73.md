# Rabidanti v3.73 — Evolution Cycle Persistence & Audit

Adds a durable SQLite audit layer for the evidence-decision/controller gate.

Flow:
signals -> evidence -> proposal -> decision -> gate -> persistent audit -> controller

The store records what was decided, why, confidence score, gate outcome and timestamp.
It does not activate strategies, bypass approval, or mutate the Evolution Controller.
