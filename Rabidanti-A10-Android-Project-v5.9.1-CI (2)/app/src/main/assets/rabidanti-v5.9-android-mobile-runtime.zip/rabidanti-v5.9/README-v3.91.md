# Rabidanti v3.91 — Laboratory Experiment Pipeline

## What changed
- Connects the existing experiment ledger to the container executor.
- Requires explicit approval for every run and only launches experiments in `PLANNED` state.
- Persists structured execution results, status, timestamps, audit digest, and bounded stdout/stderr as experiment evidence.
- Records blocked/failed execution outcomes for later analysis; a blocked run is not presented as a successful experiment.
- Records raised executor errors as risk entries where possible.
- Does not auto-validate discoveries or integrate/deploy prototypes. Analysis and integration approval remain separate human-controlled steps.

## Validation
Run `python -m pytest -q`. Tests include mocked executor paths; they validate orchestration and persistence, not real container isolation. Docker/Podman execution is not claimed unless tested on a host with a reachable runtime and suitable security controls.
