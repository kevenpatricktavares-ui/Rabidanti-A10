import sqlite3
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone


@dataclass(frozen=True)
class EvolutionCycleEvent:
    event_id: str
    proposal_id: str
    event_type: str
    decision: str
    score: float
    gate: str
    reason: str
    created_at: str


class EvolutionCycleStore:
    """Durable audit store for the controlled evolution decision cycle."""

    def __init__(self, db_path=":memory:"):
        self.db = sqlite3.connect(db_path)
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_cycle_events (
                event_id TEXT PRIMARY KEY,
                proposal_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                decision TEXT NOT NULL,
                score REAL NOT NULL,
                gate TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        self.db.commit()

    def record(self, event: EvolutionCycleEvent):
        if not event.event_id or not event.proposal_id:
            raise ValueError("event_id and proposal_id are required")
        try:
            self.db.execute(
                """INSERT INTO evolution_cycle_events
                (event_id, proposal_id, event_type, decision, score, gate, reason, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (event.event_id, event.proposal_id, event.event_type,
                 event.decision, float(event.score), event.gate,
                 event.reason, event.created_at)
            )
            self.db.commit()
        except sqlite3.IntegrityError:
            raise ValueError("duplicate event_id")

    def list_events(self, proposal_id=None):
        q = """SELECT event_id, proposal_id, event_type, decision, score,
                      gate, reason, created_at
               FROM evolution_cycle_events"""
        args = ()
        if proposal_id:
            q += " WHERE proposal_id = ?"
            args = (proposal_id,)
        q += " ORDER BY created_at, event_id"
        rows = self.db.execute(q, args).fetchall()
        return [EvolutionCycleEvent(*r) for r in rows]

    def latest(self, proposal_id):
        events = self.list_events(proposal_id)
        return events[-1] if events else None

    def close(self):
        self.db.close()
