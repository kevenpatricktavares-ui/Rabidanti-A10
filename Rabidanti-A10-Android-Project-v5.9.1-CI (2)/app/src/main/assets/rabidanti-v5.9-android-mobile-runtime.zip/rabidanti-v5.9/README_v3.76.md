# Rabidanti v3.76 — Evolution Signal Hub

Provides a single typed intake for evolution-relevant signals from:
Health, Performance, Learning, Laboratory, World Awareness and Knowledge.

The hub validates domains and identifiers, tracks signal provenance by domain,
and forwards accepted signals to the existing runtime. It has no activation
authority and cannot modify the Core.
