@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 rabidanti.py --state-dir "%~dp0.rabidanti" shell
) else (
  python rabidanti.py --state-dir "%~dp0.rabidanti" shell
)
endlocal
