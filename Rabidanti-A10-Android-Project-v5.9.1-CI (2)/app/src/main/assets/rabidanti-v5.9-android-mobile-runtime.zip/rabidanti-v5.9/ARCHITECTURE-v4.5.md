# Rabidanti v4.5 — OAuth, Encrypted Credential Vault & Gmail Read-Only

## Purpose
v4.5 adds the first concrete third-party connector implementation while preserving the v4.4 permission boundary.

## Credential vault
- File: `<state-dir>/credentials.vault.json`
- Secret values are encrypted at rest with Fernet.
- Encryption key is derived with PBKDF2-HMAC-SHA256, 600,000 iterations and a random 128-bit salt.
- The master key is supplied externally through `RABIDANTI_VAULT_MASTER_KEY` or an explicit runtime unlock operation; it is never persisted in the vault.
- If the vault is locked, Rabidanti remains operational but persistent encrypted credentials are unavailable.
- Session/environment secrets remain higher priority than vault values.

This is an application-level encrypted vault, not an OS hardware-backed credential store. No claim is made that it protects secrets from a process/user already able to read Rabidanti memory or the master-key environment.

## OAuth 2.0 + PKCE
`rabidanti_oauth.py` implements Authorization Code + PKCE (S256).
Pending code verifiers and state values are kept encrypted in the vault and consumed after successful token exchange.
The Google Gmail read-only provider requests only:
`https://www.googleapis.com/auth/gmail.readonly`.

## Gmail connector
Built-in connector ID: `gmail.readonly`.
Capabilities:
- `gmail.profile`
- `gmail.messages.list`
- `gmail.messages.get`

All are READ capabilities. There is no send, modify, trash, delete, label mutation or arbitrary HTTP capability in v4.5.
The production API origin is fixed to `https://gmail.googleapis.com/gmail/v1`; tests may inject a loopback/mock transport.

The connector is registered at runtime but disabled by default. Enabling requires the existing v4.4 explicit connector-control workflow and a configured `GMAIL_ACCESS_TOKEN`.

## Validation boundary
The Gmail network implementation is tested against `httpx.MockTransport`. A live Google account/OAuth tenant is not available in the build environment, so end-to-end Google authentication is NOT claimed as live-validated.
