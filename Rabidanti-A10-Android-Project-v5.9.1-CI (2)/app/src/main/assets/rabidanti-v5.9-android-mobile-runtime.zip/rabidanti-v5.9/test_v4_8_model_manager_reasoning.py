import json
import httpx
import pytest
from rabidanti_model_gateway import LocalOllamaGateway, ModelGatewayError
from rabidanti_model_manager import ModelManager
from rabidanti_reasoning import AgentReasoningRuntime, ReasoningError
from rabidanti_prompts import CONVERSATION_PROMPT_VERSION, REASONING_PROMPT_VERSION
from rabidanti_conversation import ConversationEngine
from rabidanti_runtime import RabidantiRuntime
from rabidanti_config import RabidantiConfig


def client(handler): return httpx.Client(transport=httpx.MockTransport(handler),base_url='http://127.0.0.1:11434')

def test_model_manager_lists_installed():
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'models':[{'name':'a:latest','size':10},{'model':'b'}]})))
    assert [x['name'] for x in ModelManager(g).installed_models()]==['a:latest','b']

def test_model_manager_selects_primary():
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'models':[{'name':'a'}]})))
    s=ModelManager(g).select('a','b'); assert s.selected=='a' and not s.fallback_used

def test_model_manager_uses_fallback():
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'models':[{'name':'b'}]})))
    s=ModelManager(g).select('a','b'); assert s.selected=='b' and s.fallback_used

def test_model_manager_refuses_missing_models():
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'models':[]})))
    with pytest.raises(ModelGatewayError): ModelManager(g).select('a','b')

def test_reasoning_proposes_but_never_executes(tmp_path):
    body={'response':'posso propor','proposed_actions':[{'kind':'connector','connector_id':'gmail.readonly','capability':'gmail.profile','payload':{},'reason':'ver perfil'}]}
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'model':'m','message':{'content':json.dumps(body)}})),model='m')
    x=AgentReasoningRuntime(tmp_path/'r.db',g).reason('consulta')
    assert x['external_action_authorized'] is False and x['tool_execution_authorized'] is False
    assert x['proposed_actions'][0]['execution_authorized'] is False
    assert x['prompt_version']==REASONING_PROMPT_VERSION

def test_reasoning_persists_proposals(tmp_path):
    body={'response':'ok','proposed_actions':[{'kind':'internal_task','name':'analisar mercado','reason':'útil'}]}
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'message':{'content':json.dumps(body)}})))
    rr=AgentReasoningRuntime(tmp_path/'r.db',g); out=rr.reason('x')
    rows=rr.proposals(); assert rows[0]['reasoning_id']==out['reasoning_id'] and rows[0]['execution_authorized'] is False

def test_reasoning_rejects_non_json(tmp_path):
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'message':{'content':'execute'}})))
    with pytest.raises(ReasoningError): AgentReasoningRuntime(tmp_path/'r.db',g).reason('x')

def test_reasoning_rejects_unknown_action_kind(tmp_path):
    body={'response':'x','proposed_actions':[{'kind':'shell','command':'rm -rf /'}]}
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'message':{'content':json.dumps(body)}})))
    with pytest.raises(ReasoningError): AgentReasoningRuntime(tmp_path/'r.db',g).reason('x')

def test_reasoning_rejects_secret_like_payload(tmp_path):
    body={'response':'x','proposed_actions':[{'kind':'connector','connector_id':'gmail.readonly','capability':'gmail.profile','payload':{'token':'abc'},'reason':'x'}]}
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'message':{'content':json.dumps(body)}})))
    with pytest.raises(ReasoningError): AgentReasoningRuntime(tmp_path/'r.db',g).reason('x')

def test_conversation_exposes_prompt_version(tmp_path):
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'message':{'content':'ok'}})))
    out=ConversationEngine(tmp_path/'c.db',g).chat('oi'); assert out['prompt_version']==CONVERSATION_PROMPT_VERSION

def test_config_accepts_fallback_model(tmp_path):
    c=RabidantiConfig(tmp_path/'config.json'); c.set('ai.fallback_model','qwen3'); assert c.get('ai.fallback_model')=='qwen3'

def test_runtime_has_reasoning_database(tmp_path):
    r=RabidantiRuntime(tmp_path); r.start(); assert r.paths.reasoning_db.exists(); assert r.status()['ai']['fallback_model']==''; r.stop()

def test_api_and_ui_expose_reasoning_without_generic_execution():
    api=open('rabidanti_api.py',encoding='utf-8').read(); js=open('ui/app.js',encoding='utf-8').read(); html=open('ui/index.html',encoding='utf-8').read()
    assert '/reasoning/proposals' in api and '/reason' in api
    assert '/v1/reason' in js and 'Nenhuma ação foi executada' in js
    assert 'Planeamento / propostas' in html
    assert '/v1/connectors/invoke' not in api

def test_runtime_refresh_can_apply_fallback_without_authorizing_actions(tmp_path, monkeypatch):
    r=RabidantiRuntime(tmp_path)
    r.config.set('ai.model','missing')
    r.config.set('ai.fallback_model','fallback')
    class FakeManager:
        def __init__(self,g): self.g=g
        def select(self,requested,fallback):
            from rabidanti_model_manager import ModelSelection
            return ModelSelection('fallback',requested,True,('fallback',))
    monkeypatch.setattr('rabidanti_runtime.ModelManager', FakeManager)
    r._refresh_ai_runtime(resolve_model=True)
    assert r.model_gateway.model=='fallback'
    assert r.status()['safety']['external_action_authorized'] is False
