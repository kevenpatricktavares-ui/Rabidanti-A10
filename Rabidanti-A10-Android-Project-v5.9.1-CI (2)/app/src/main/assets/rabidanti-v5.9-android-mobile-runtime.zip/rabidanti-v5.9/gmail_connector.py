"""Rabidanti v4.5 — Gmail API read-only connector.

Production uses Google's fixed Gmail API origin. Tests may inject a loopback
base URL. No write/send/delete capability exists in this connector version.
"""
from __future__ import annotations

from typing import Any, Callable, Mapping, Optional
from urllib.parse import quote
import httpx

from rabidanti_connectors import (
    ConnectorAccess,
    ConnectorCapability,
    ConnectorContext,
    ConnectorDefinition,
)

GMAIL_API_BASE = "https://gmail.googleapis.com/gmail/v1"


def gmail_definition() -> ConnectorDefinition:
    return ConnectorDefinition(
        connector_id="gmail.readonly",
        display_name="Gmail Read-Only",
        version="1.0.0",
        required_secrets=("GMAIL_ACCESS_TOKEN",),
        rate_limit_per_minute=60,
        capabilities=(
            ConnectorCapability("gmail.profile", ConnectorAccess.READ, "Read the authenticated Gmail profile"),
            ConnectorCapability("gmail.messages.list", ConnectorAccess.READ, "List Gmail message identifiers"),
            ConnectorCapability("gmail.messages.get", ConnectorAccess.READ, "Read one Gmail message"),
        ),
    )


class GmailReadOnlyHandler:
    def __init__(
        self,
        secret_getter: Callable[[str], Optional[str]],
        *,
        api_base: str = GMAIL_API_BASE,
        client: Optional[httpx.Client] = None,
    ) -> None:
        self.secret_getter = secret_getter
        self.api_base = api_base.rstrip("/")
        self.client = client or httpx.Client(timeout=20.0, follow_redirects=False)

    def _headers(self) -> dict[str, str]:
        token = self.secret_getter("GMAIL_ACCESS_TOKEN")
        if not token:
            raise RuntimeError("GMAIL_ACCESS_TOKEN is not configured")
        return {"Authorization": f"Bearer {token}", "Accept": "application/json"}

    def _get(self, path: str, *, params: Optional[dict[str, Any]] = None) -> Any:
        response = self.client.get(self.api_base + path, headers=self._headers(), params=params)
        if response.status_code >= 400:
            raise RuntimeError(f"Gmail API request failed with HTTP {response.status_code}")
        return response.json()

    def __call__(self, capability: str, payload: Mapping[str, Any], context: ConnectorContext) -> Any:
        if capability == "gmail.profile":
            if payload:
                raise ValueError("gmail.profile accepts no payload")
            return self._get("/users/me/profile")

        if capability == "gmail.messages.list":
            allowed = {"query", "max_results", "page_token", "label_ids"}
            unknown = set(payload) - allowed
            if unknown:
                raise ValueError("unsupported payload fields: " + ", ".join(sorted(unknown)))
            max_results = int(payload.get("max_results", 25))
            if not 1 <= max_results <= 100:
                raise ValueError("max_results must be between 1 and 100")
            params: dict[str, Any] = {"maxResults": max_results}
            if payload.get("query"):
                q = str(payload["query"])
                if len(q) > 500:
                    raise ValueError("query too long")
                params["q"] = q
            if payload.get("page_token"):
                params["pageToken"] = str(payload["page_token"])
            labels = payload.get("label_ids")
            if labels is not None:
                if not isinstance(labels, list) or len(labels) > 20 or not all(isinstance(x, str) for x in labels):
                    raise ValueError("label_ids must be a list of up to 20 strings")
                params["labelIds"] = labels
            return self._get("/users/me/messages", params=params)

        if capability == "gmail.messages.get":
            allowed = {"message_id", "format"}
            unknown = set(payload) - allowed
            if unknown:
                raise ValueError("unsupported payload fields: " + ", ".join(sorted(unknown)))
            message_id = str(payload.get("message_id", "")).strip()
            if not message_id or len(message_id) > 256:
                raise ValueError("message_id is required")
            fmt = str(payload.get("format", "metadata"))
            if fmt not in {"minimal", "metadata", "full"}:
                raise ValueError("format must be minimal, metadata or full")
            return self._get(f"/users/me/messages/{quote(message_id, safe='')}", params={"format": fmt})

        raise ValueError(f"unsupported Gmail capability: {capability}")
