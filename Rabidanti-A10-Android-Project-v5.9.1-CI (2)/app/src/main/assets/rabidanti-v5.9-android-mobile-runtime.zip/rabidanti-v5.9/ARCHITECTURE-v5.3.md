# Architecture v5.3 — Update, Recovery & Production Hardening

## Recovery boundary

`rabidanti_launcher.py` abre `DesktopInstanceLease` e `RecoverySession` em conjunto. A sessão escreve um marcador de arranque e um heartbeat. Em encerramento limpo, ambos são removidos. Se o próximo arranque encontrar marcador residual, regista `UNCLEAN_SHUTDOWN_DETECTED` antes de iniciar a nova sessão.

O mecanismo é observacional: não reinicia o processo nem autoriza ações externas.

## State backups

`StateBackupManager` cria ZIPs locais em `<state>/backups/` com `BACKUP-MANIFEST.json` e SHA-256 de cada ficheiro. Ficam fora do backup artefactos de backup/update e marcadores transitórios de processo.

Restore é explícito, valida o backup, cria um backup de segurança pré-restore e só depois faz overwrite atómico dos ficheiros presentes no snapshot. Não elimina ficheiros adicionais.

## Offline updates

`OfflineUpdateManager` exige:

1. pacote ZIP local;
2. SHA-256 esperado fornecido explicitamente;
3. ZIP íntegro e sem path traversal;
4. exatamente um `VERSION`;
5. SemVer superior à versão instalada.

`stage()` cria primeiro um backup e depois copia o pacote para `<state>/updates/staged/<version>/`, gerando `update-plan.json`.

O plano contém `installation_authorized=false`, `automatic_apply=false` e `requires_external_installer=true`. `apply()` é deliberadamente bloqueado.

## State schema migration

`StateSchemaManager` introduz metadata `state-schema.json`. Migrações exigem confirmação explícita e backup prévio. Schemas futuros são recusados para impedir downgrade destrutivo por uma versão antiga do programa.
