# Rabidanti v3.29 — Core Orchestrator Integration

## Purpose
Connect the Rabidanti Core entry point to the persistent Workflow Orchestrator.

## Flow
Core Orchestrator → Persistent Workflow Orchestrator → DAG → Durable Queue → Workers

## Guarantees
- Central Core facade for workflow lifecycle.
- Workflow persistence remains owned by the v3.28 orchestrator.
- Dependency validation remains owned by WorkflowEngine.
- Durable execution remains owned by DurableWorkerQueue/workers.
- Recovery delegates to the existing durable recovery path.
- Status exposes global workflow progress without duplicating queue state.

## Deliberate limitation
This release does not claim that domain agents (Research, Product, Content,
Audiovisual, Ads, etc.) are automatically executed by Core. Those specialized
handlers still need explicit integration and real implementations.

## Validation target
Full inherited suite plus v3.29 Core integration tests.
