# Rabidanti no Android (Termux)

A integração Android é uma camada de host. O Core, Runtime, Permission Gate, Vault,
SQLite, API e Sala são os mesmos usados nas restantes plataformas.

## Requisitos

- Android com Termux.
- Python 3.10+ no Termux.
- Acesso local a `127.0.0.1`.
- Internet apenas se for necessário instalar dependências. O Rabidanti não precisa
  de Internet para arrancar o runtime local.

## Instalação recomendada

No Termux, dentro da pasta extraída do Rabidanti:

```bash
pkg update
pkg install python
chmod +x SETUP-ANDROID-TERMUX.sh START-RABIDANTI-ANDROID.sh
./SETUP-ANDROID-TERMUX.sh
```

Se `cryptography` precisar de compilação no dispositivo, instale também os
pacotes de build disponíveis na sua instalação Termux (por exemplo Rust/Clang,
OpenSSL e libffi) e repita `python -m pip install -r requirements-android.txt`.

## Diagnóstico

```bash
python rabidanti_android.py doctor
```

O diagnóstico não ativa conectores, não descarrega modelos e não altera o Core.

## Iniciar

```bash
./START-RABIDANTI-ANDROID.sh
```

A Sala fica em `http://127.0.0.1:8765/ui/`. Quando `termux-open-url` estiver
presente, o adaptador tenta abrir o navegador automaticamente. Caso contrário,
abra o endereço manualmente no browser do Android.

## Dados

Por defeito:

```text
$HOME/.local/share/rabidanti
```

Pode alterar com `RABIDANTI_STATE_DIR`.

## Modelo local

Ollama não é assumido como disponível no Android. A indisponibilidade do modelo
fica visível no diagnóstico/observabilidade e não autoriza qualquer fallback
externo automático.

## Segurança

A camada Android não altera as regras existentes: conectores continuam
desativados por defeito; ações externas continuam dependentes de aprovação; o
modelo não pode autoautorizar ferramentas; e a API continua ligada apenas ao
loopback local.
