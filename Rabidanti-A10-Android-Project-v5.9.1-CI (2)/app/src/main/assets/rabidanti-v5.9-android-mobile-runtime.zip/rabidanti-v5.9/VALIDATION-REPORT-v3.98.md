# Rabidanti v3.98 — Validation Report

## Scope

Version: `3.98.0`

Feature: **Laboratory Integration Proposal Workflow**.

This release was developed from the previously validated Rabidanti v3.97 package. The v3.97 source package was re-extracted and tested before modification.

## Input baseline

- Input package: `rabidanti-v3.97-lab-human-review.zip`
- Input package SHA-256: `0ed38c22d3c856f6ebdb126e72bb93388cffd9f7123f7fd9a3a8ebfaec3b3f1e`
- `VERSION` before changes: `3.97.0`
- Baseline test result: **472 passed, 0 failed**

## Implemented in v3.98

New module: `lab_integration_proposal.py`.

An integration proposal can only be created from a v3.97 human review whose final decision is `APPROVED`. The workflow verifies that the corresponding Evidence Memory decision node exists, is approved, belongs to the requested review and is bound to the exact evidence snapshot digest stored in the review ledger.

Each proposal persists:

- proposal ID and SHA-256 proposal digest;
- review, experiment and readiness identifiers;
- exact evidence snapshot digest;
- title, summary and target component;
- repository-relative affected files;
- ordered change plan;
- regression test plan;
- rollback plan;
- explicit risks;
- asserted creator identity and timestamp;
- explicit false authorization/scientific-validation flags.

Identical canonical proposals are idempotent. Materially different content creates a new immutable proposal. The proposal is persisted as an `ARTIFACT` node in Evidence Memory and linked to the approved human-review decision, readiness assessment and experiment.

## Safety behavior verified

- Non-approved reviews cannot produce proposals.
- Empty change, test, rollback or risk plans are rejected.
- Absolute paths, traversal paths and Windows-style affected-file paths are rejected.
- Proposal creation never sets Core integration or external-action authorization.
- `apply()` is intentionally non-executable and fails closed.
- `authorize_integration()` and `authorize_external_action()` fail closed.
- Proposal history survives workflow restart.
- A tampered evidence snapshot binding is rejected.

## Test results

New v3.98 tests: **10 passed, 0 failed**.

Full regression suite: **482 passed, 0 failed**.

Python bytecode compilation (`python -m compileall -q .`): **passed**.

The final package is additionally extracted into a clean directory and the full test suite is executed from the extracted package before release.

## Environment limitation

Neither Docker nor Podman is available in the validation environment. Therefore this release does not claim real operating-system container isolation. v3.98 does not execute integration changes, so no real Core mutation was attempted.

## Security / governance boundary

A v3.98 integration proposal is a planning and audit artifact only. Human approval of laboratory evidence is not itself authorization to change the Core. A future controlled executor must require separate explicit integration authorization and must provide backup, isolated application, regression testing, rollback and audit evidence.
