# Rabidanti v3.77 — Signal Correlation

Adds a deterministic correlation layer over evolution signals.

It combines confidence, signal magnitude and domain diversity to identify
strong multi-signal patterns. Correlations are evidence for later decision
making; this layer cannot activate, deploy, modify Core, or bypass approval.
