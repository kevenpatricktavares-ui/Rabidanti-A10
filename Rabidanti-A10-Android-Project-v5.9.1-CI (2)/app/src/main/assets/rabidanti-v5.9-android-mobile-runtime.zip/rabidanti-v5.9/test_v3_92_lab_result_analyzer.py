import pytest
from lab_experiment_manager import LabExperimentManager
from lab_result_analyzer import LabResultAnalyzer

class FakeRun:
    pass

def manager_with_result(tmp_path, executed=True):
    m = LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1", "p1", "test", "hypothesis", "method", ["criterion A", "criterion B"])
    m.transition("e1", "RUNNING", "start")
    m.add_entry("e1", "run-result", "RESULT", "completed", {"run_id":"r1", "executed":executed, "status":"completed" if executed else "blocked"})
    m.transition("e1", "ANALYSIS", "finish")
    return m

def criteria(a="PASS", b="PASS"):
    return {"criterion A":{"state":a,"evidence":"observed A"}, "criterion B":{"state":b,"evidence":"observed B"}}

def test_all_pass_transitions_to_passed_and_never_authorizes_integration(tmp_path):
    m=manager_with_result(tmp_path); r=LabResultAnalyzer(m).analyze("e1","r1",criteria(),reviewer="operator",evidence_refs=["artifact:1"])
    assert r["classification"] == "PASSED" and m.get("e1").status == "PASSED"
    assert r["integration_authorized"] is False and len(r["evidence_digest"]) == 64

def test_any_failed_criterion_fails_experiment(tmp_path):
    m=manager_with_result(tmp_path); r=LabResultAnalyzer(m).analyze("e1","r1",criteria("PASS","FAIL"),reviewer="operator")
    assert r["classification"] == "FAILED" and m.get("e1").status == "FAILED"

def test_inconclusive_keeps_analysis_open(tmp_path):
    m=manager_with_result(tmp_path); r=LabResultAnalyzer(m).analyze("e1","r1",criteria("PASS","INCONCLUSIVE"),reviewer="operator")
    assert r["classification"] == "INCONCLUSIVE" and m.get("e1").status == "ANALYSIS"

def test_blocked_run_cannot_be_marked_passed(tmp_path):
    m=manager_with_result(tmp_path, executed=False); r=LabResultAnalyzer(m).analyze("e1","r1",{},reviewer="operator")
    assert r["classification"] == "BLOCKED" and m.get("e1").status == "ANALYSIS"

def test_requires_every_criterion_and_evidence(tmp_path):
    m=manager_with_result(tmp_path); a=LabResultAnalyzer(m)
    with pytest.raises(ValueError): a.analyze("e1","r1",{"criterion A":{"state":"PASS","evidence":"ok"}},reviewer="operator")
    with pytest.raises(ValueError): a.analyze("e1","r1",criteria(),reviewer="")
    with pytest.raises(ValueError): a.analyze("e1","r1",{"criterion A":{"state":"PASS","evidence":""},"criterion B":{"state":"PASS","evidence":"ok"}},reviewer="operator")

def test_unknown_run_rejected(tmp_path):
    m=manager_with_result(tmp_path)
    with pytest.raises(ValueError): LabResultAnalyzer(m).analyze("e1","missing",criteria(),reviewer="operator")
