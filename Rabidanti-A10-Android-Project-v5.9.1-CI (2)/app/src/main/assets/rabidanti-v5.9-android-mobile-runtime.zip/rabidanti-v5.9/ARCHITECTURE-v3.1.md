# Rabidanti v3.1 — Application/API Persistence Integration

## Purpose

v3.1 connects the v3.0 security and persistence foundation to a real FastAPI application layer.

## Integrated layers

- SQLite persistence
- User accounts and password hashing
- Persistent bearer sessions with expiration and revocation
- User-owned projects
- Persistent jobs
- Persistent approval decisions
- Persistent connector registrations and permissions
- Persistent audit events
- Project-scoped authorization on project/job/approval routes
- Admin-only audit access

## Security boundaries

A valid session does not grant access to every project. Project routes resolve ownership from `owner_id` and the authenticated user.

Approval is separate from connector permissions. Sensitive connector capabilities remain declared permissions and require explicit approval when an action is actually authorized.

## Restart guarantee

The application reconstructs its repositories and session manager from the same SQLite database on startup. Projects, jobs, approvals, connectors, audit events, users and active/revoked sessions therefore do not depend on process memory.

## Important limitation

This release is an application-integration milestone, not a public-deployment security certification. Production deployment still needs rate limiting, secret/configuration hardening, CSRF strategy where applicable, TLS/reverse-proxy configuration, durable distributed workers, migration tooling, monitoring, backups and a broader adversarial security review.
