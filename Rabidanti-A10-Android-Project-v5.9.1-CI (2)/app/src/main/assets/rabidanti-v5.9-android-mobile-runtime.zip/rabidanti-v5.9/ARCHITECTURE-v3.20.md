# Rabidanti v3.20 — Resource & Capacity Intelligence

## Objective
Measure execution capacity and backlog so the system can make safe, non-destructive scheduling/resource recommendations.

## Components
- `resource_capacity.py`: `ResourceCapacityMonitor` and immutable `CapacityReport`.
- `ContinuousWorkerRunner.health()`: exposes capacity information when a monitor is configured.

## Signals
- configured capacity
- active workers/futures
- available capacity
- ready backlog
- utilization
- saturation threshold
- worker health snapshot

## Recommendations
- `IDLE_OR_READY`: no ready backlog.
- `PROCESS_BACKLOG`: backlog exists and capacity is available.
- `THROTTLE_OR_SCALE`: saturation threshold reached while backlog exists.

Recommendations are advisory. v3.20 does not autoscale, spend money, provision cloud resources, or change infrastructure automatically.

## Validation
- Full suite: 116 tests passed.
- `compileall`: passed.
