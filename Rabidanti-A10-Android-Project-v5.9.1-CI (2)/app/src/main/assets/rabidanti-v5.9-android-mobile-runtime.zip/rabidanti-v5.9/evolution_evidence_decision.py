from dataclasses import dataclass
from enum import Enum

class Decision(str, Enum):
    REJECT="reject"
    INVESTIGATE="investigate"
    EXPERIMENT="experiment"
    APPROVAL_REQUIRED="approval_required"

@dataclass(frozen=True)
class EvidenceAssessment:
    evidence_confidence: float
    expected_impact: float
    risk: float
    estimated_cost: float
    reversibility: float
    def validate(self):
        for k,v in self.__dict__.items():
            if not 0.0 <= v <= 1.0: raise ValueError(f"{k} must be between 0 and 1")

@dataclass(frozen=True)
class EvolutionDecision:
    proposal_id: str
    decision: Decision
    score: float
    rationale: str
    approval_required: bool

class EvolutionEvidenceDecisionEngine:
    def __init__(self,min_evidence=0.70):
        if not 0.0 <= min_evidence <= 1.0: raise ValueError("min_evidence must be between 0 and 1")
        self.min_evidence=min_evidence
        self._decisions={}
    def evaluate(self,proposal_id,assessment):
        if not proposal_id.strip(): raise ValueError("proposal_id is required")
        if proposal_id in self._decisions: raise ValueError("duplicate proposal_id")
        assessment.validate()
        if assessment.evidence_confidence < self.min_evidence:
            d=EvolutionDecision(proposal_id,Decision.INVESTIGATE,assessment.evidence_confidence,
                "Evidence confidence is below the evolution threshold.",False)
        else:
            score=(.30*assessment.expected_impact+.30*assessment.evidence_confidence+
                   .20*assessment.reversibility+.10*(1-assessment.risk)+
                   .10*(1-assessment.estimated_cost))
            if score < .45:
                decision=Decision.REJECT; approval=False
                rationale="Expected benefit does not justify risk, cost, or weak evidence."
            elif score < .65:
                decision=Decision.EXPERIMENT; approval=False
                rationale="Evidence supports a bounded experiment before activation."
            else:
                decision=Decision.APPROVAL_REQUIRED; approval=True
                rationale="Evidence and expected benefit justify an approval request."
            d=EvolutionDecision(proposal_id,decision,round(score,6),rationale,approval)
        self._decisions[proposal_id]=d
        return d
    def get(self,proposal_id): return self._decisions[proposal_id]
    def list_decisions(self): return list(self._decisions.values())
