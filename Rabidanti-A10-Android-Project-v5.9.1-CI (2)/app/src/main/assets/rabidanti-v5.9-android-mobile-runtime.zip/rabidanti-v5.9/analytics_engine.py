"""Rabidanti v3.42 — ads-to-analytics measurement layer.

Analytics is deliberately evidence-first: it summarizes supplied observations and
never fabricates campaign performance. Missing observations remain missing.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping


def _num(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    return n if n >= 0 else None


def _rate(numerator: float | None, denominator: float | None) -> float | None:
    if numerator is None or denominator is None or denominator <= 0:
        return None
    return numerator / denominator


@dataclass(frozen=True)
class AnalyticsBrief:
    project_id: str
    experiment_id: str
    channels: tuple[str, ...]
    variants: tuple[str, ...]
    observations: Mapping[str, Any]
    metrics: Mapping[str, Any]
    status: str = "MEASURED"
    evidence_state: str = "PARTIAL"
    limitations: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AnalyticsEngine:
    """Calculate transparent funnel/campaign metrics from observed data."""

    def summarize(
        self,
        project_id: str,
        ads: Mapping[str, Any],
        sales: Mapping[str, Any],
        observations: Mapping[str, Any] | None = None,
    ) -> AnalyticsBrief:
        if not str(project_id).strip():
            raise ValueError("project_id must not be empty")
        if not ads:
            raise ValueError("ads must not be empty")
        if not sales:
            raise ValueError("sales must not be empty")

        channels = tuple(ads.get("channels") or ())
        variants = tuple(ads.get("variants") or ())
        if not channels:
            raise ValueError("ads channels are required")

        obs = dict(observations or {})
        # Accept either flat metrics or a nested metrics object from a connector.
        source = obs.get("metrics") if isinstance(obs.get("metrics"), Mapping) else obs
        source = dict(source)

        impressions = _num(source.get("impressions"))
        clicks = _num(source.get("clicks"))
        checkout_starts = _num(source.get("checkout_start", source.get("checkout_starts")))
        purchases = _num(source.get("purchase", source.get("purchases")))
        refunds = _num(source.get("refunds"))
        spend = _num(source.get("spend"))
        revenue = _num(source.get("revenue"))

        metrics = {
            "impressions": impressions,
            "clicks": clicks,
            "checkout_starts": checkout_starts,
            "purchases": purchases,
            "refunds": refunds,
            "spend": spend,
            "revenue": revenue,
            "ctr": _rate(clicks, impressions),
            "click_to_checkout_rate": _rate(checkout_starts, clicks),
            "checkout_to_purchase_rate": _rate(purchases, checkout_starts),
            "purchase_rate": _rate(purchases, impressions),
            "refund_rate": _rate(refunds, purchases),
            "roas": _rate(revenue, spend),
        }

        supplied = [k for k, v in metrics.items() if v is not None]
        if not supplied:
            evidence_state = "NO_OBSERVED_METRICS"
            status = "WAITING_FOR_DATA"
        elif all(metrics[k] is not None for k in ("impressions", "clicks", "purchases")):
            evidence_state = "SUFFICIENT_FOR_FUNNEL"
            status = "MEASURED"
        else:
            evidence_state = "PARTIAL"
            status = "MEASURED"

        limits = (
            "Analytics uses supplied observations only; it does not claim live platform data without a connector.",
            "Missing metrics remain null rather than being estimated or fabricated.",
            "Spend, revenue and ROAS are reported only when observed values are supplied.",
        )
        return AnalyticsBrief(
            str(project_id),
            str(ads.get("experiment_id") or f"exp-{project_id}-ads-unknown"),
            channels,
            variants,
            obs,
            metrics,
            status,
            evidence_state,
            limits,
        )
