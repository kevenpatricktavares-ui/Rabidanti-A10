# Rabidanti v4.5 — Validation Report

## Release
- Version: 4.5.0
- Name: OAuth, Encrypted Credential Vault & Gmail Read-Only
- Baseline source: Rabidanti v4.4 connector framework
- Baseline ZIP SHA-256: `2267b61a225655446cf69fd3bf4e4a8e0d5a9a0e24992a0e70a06c29b09e0423`

## Baseline verification
The v4.4 package was inspected before modification. `pytest --collect-only` reported 547 tests. Because one-shot full-suite execution exceeded the tool window, regression verification was performed in balanced groups. No source modification was made before baseline inspection.

## Implemented in v4.5
1. Encrypted credential vault (`rabidanti_vault.py`)
   - Fernet authenticated encryption.
   - PBKDF2-HMAC-SHA256 key derivation with 600,000 iterations and random 16-byte salt.
   - Master key supplied externally; never persisted in the vault.
   - Atomic writes and POSIX mode 0600 where supported.
2. OAuth 2.0 Authorization Code + PKCE (`rabidanti_oauth.py`)
   - S256 challenge.
   - OAuth `state` validation.
   - Pending verifier/state kept encrypted in the vault.
   - Successful flow consumes the pending flow record.
3. Gmail read-only connector (`gmail_connector.py`)
   - `gmail.profile`
   - `gmail.messages.list`
   - `gmail.messages.get`
   - Fixed production Gmail API origin.
   - No send/modify/delete/trash/label-write capability.
4. Runtime integration
   - Gmail built-in registered but disabled by default.
   - Secret resolution order: session/environment before encrypted vault.
   - Vault and OAuth runtime helpers.
5. CLI integration
   - `vault status|set|delete`
   - `oauth gmail-start|gmail-exchange`
   - `gmail profile|list|get`
6. Dependency declaration
   - `cryptography>=46,<47`

## Security boundaries
- External connector actions remain unauthorized at runtime startup.
- Gmail connector is disabled by default.
- The master key is not stored in state files, events or status output.
- No generic arbitrary-URL connector or arbitrary command execution was added.
- Gmail v4.5 is strictly read-only.
- Application-level encrypted vault is not claimed to be equivalent to an OS/hardware-backed credential store.

## Test results
- Existing v4.4 collected tests: 547.
- New v4.5 tests: 15.
- Total v4.5 collected tests: 562.
- Final regression: 562 passed, 0 failed.
- Python `compileall`: PASS.
- Runtime/CLI smoke tests: PASS.

A historical v4.4 test assumed exactly one connector would exist after registering a demo connector. v4.5 legitimately adds the built-in Gmail connector, so the test was updated to verify the actual invariant: the demo connector is present/enabled and runtime counts match the registry.

## Live integration limitation
The build environment has no creator-authorized Google OAuth account/credentials. OAuth and Gmail HTTP behavior were therefore validated with controlled mocks (`httpx.MockTransport` / simulated token endpoint), not against a live Google account. Live Gmail OAuth/API operation remains unverified until the creator explicitly authorizes a real account.

## Container limitation
Docker/Podman availability is unchanged from earlier versions and OS-level container isolation is not claimed as validated here.
