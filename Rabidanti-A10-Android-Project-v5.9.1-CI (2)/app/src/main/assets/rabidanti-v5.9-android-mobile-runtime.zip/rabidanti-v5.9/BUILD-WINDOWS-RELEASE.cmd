@echo off
setlocal EnableExtensions
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File prepare_windows_build.ps1 -BootstrapPython
if errorlevel 1 exit /b %errorlevel%

call build_release_windows.bat
if errorlevel 1 exit /b %errorlevel%

.build-venv\Scripts\python.exe native_release_check.py
if errorlevel 1 exit /b %errorlevel%

echo.
echo Rabidanti Windows native release completed and verified.
echo See release-manifest.json and windows-release-validation.json.
endlocal
