from __future__ import annotations

import json
import os
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from rabidanti_config import ConfigurationError, RabidantiConfig, RabidantiSecrets, redact_sensitive
from rabidanti_api import RabidantiApiService
from rabidanti_runtime import RabidantiRuntime

TOKEN = "m" * 32


def _get(base: str, path: str):
    with urlopen(base + path, timeout=3) as r:
        return r.status, json.loads(r.read().decode())


def _post(base: str, path: str, body: dict, token: str | None = TOKEN):
    headers = {"Content-Type": "application/json"}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    req = Request(base + path, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urlopen(req, timeout=3) as r:
        return r.status, json.loads(r.read().decode())


def _service(tmp_path: Path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    service = RabidantiApiService(runtime, port=0, token=TOKEN)
    addr = service.start()
    return runtime, service, f"http://{addr.host}:{addr.port}"


def test_config_defaults_are_persisted_without_secret_fields(tmp_path):
    cfg = RabidantiConfig(tmp_path / "config.json")
    data = cfg.as_dict()
    assert data["api"] == {"host": "127.0.0.1", "port": 8765}
    raw = (tmp_path / "config.json").read_text(encoding="utf-8").lower()
    assert "token" not in raw and "password" not in raw and "secret" not in raw
    if os.name != "nt":
        assert (tmp_path / "config.json").stat().st_mode & 0o777 == 0o600


def test_config_update_is_validated_and_reloadable(tmp_path):
    path = tmp_path / "config.json"
    cfg = RabidantiConfig(path)
    cfg.update({"api.port": 9001, "logging.level": "warning", "ui.auto_open_browser": False})
    reloaded = RabidantiConfig(path)
    assert reloaded.get("api.port") == 9001
    assert reloaded.get("logging.level") == "WARNING"
    assert reloaded.get("ui.auto_open_browser") is False


def test_config_rejects_unknown_and_secret_like_keys_without_side_effect(tmp_path):
    cfg = RabidantiConfig(tmp_path / "config.json")
    before = cfg.as_dict()
    with pytest.raises(ConfigurationError):
        cfg.update({"api.token": "do-not-store"})
    with pytest.raises(ConfigurationError):
        cfg.update({"network.remote": True})
    assert cfg.as_dict() == before
    assert "do-not-store" not in cfg.path.read_text(encoding="utf-8")


def test_secret_store_is_environment_or_session_only(monkeypatch):
    monkeypatch.setenv("RABIDANTI_SECRET_TEST_KEY", "environment-secret")
    secrets = RabidantiSecrets()
    assert secrets.get("TEST_KEY") == "environment-secret"
    secrets.set_session("TEST_KEY", "session-secret")
    assert secrets.get("TEST_KEY") == "session-secret"
    status = secrets.status(["TEST_KEY"])[0]
    assert status == {"name": "TEST_KEY", "configured": True, "source": "session"}
    assert "session-secret" not in repr(status)
    secrets.clear_session("TEST_KEY")
    assert secrets.get("TEST_KEY") == "environment-secret"


def test_runtime_events_redact_sensitive_keys(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    try:
        runtime._event("REDACTION_TEST", {"api_token": "super-sensitive", "nested": {"password": "also-sensitive"}, "safe": "visible"})
        event = next(x for x in runtime.runtime_events() if x["event_type"] == "REDACTION_TEST")
        assert event["details"]["api_token"] == "[REDACTED]"
        assert event["details"]["nested"]["password"] == "[REDACTED]"
        assert event["details"]["safe"] == "visible"
        assert b"super-sensitive" not in runtime.paths.runtime_db.read_bytes()
    finally:
        runtime.stop()


def test_api_config_mutation_requires_auth_and_rejects_secret_keys(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        status, cfg = _get(base, "/v1/config")
        assert status == 200 and cfg["api"]["port"] == 8765
        with pytest.raises(HTTPError) as exc:
            _post(base, "/v1/config", {"changes": {"api.port": 9010}}, token=None)
        assert exc.value.code == 401
        status, updated = _post(base, "/v1/config", {"changes": {"api.port": 9010}})
        assert status == 200 and updated["api"]["port"] == 9010
        with pytest.raises(HTTPError) as exc:
            _post(base, "/v1/config", {"changes": {"api.token": "bad-secret"}})
        assert exc.value.code == 400
        assert b"bad-secret" not in runtime.paths.config_file.read_bytes()
    finally:
        service.stop(); runtime.stop()


def test_api_session_secret_never_appears_in_state_files_or_status(tmp_path):
    runtime, service, base = _service(tmp_path)
    secret = "this-is-a-session-only-secret"
    try:
        status, row = _post(base, "/v1/secrets/session", {"name": "CONNECTOR_KEY", "value": secret})
        assert status == 200
        assert row == {"name": "CONNECTOR_KEY", "configured": True, "source": "session"}
        _, listing = _get(base, "/v1/secrets")
        assert listing["items"] == [{"name": "CONNECTOR_KEY", "configured": True, "source": "session"}]
        _, status_data = _get(base, "/v1/status")
        assert secret not in json.dumps(status_data)
        assert status_data["secrets"]["configured"] == 1
    finally:
        service.stop(); runtime.stop()
    for path in (tmp_path / "state").iterdir():
        if path.is_file():
            assert secret.encode() not in path.read_bytes(), path.name


def test_api_can_use_environment_secret_as_mutation_token(tmp_path, monkeypatch):
    env_token = "z" * 32
    monkeypatch.setenv("RABIDANTI_SECRET_API_TOKEN", env_token)
    runtime = RabidantiRuntime(tmp_path / "state"); runtime.start()
    service = RabidantiApiService(runtime, port=0)
    try:
        assert service.token == env_token
    finally:
        runtime.stop()


def test_sala_exposes_configuration_without_persistent_browser_secret_storage():
    html = Path("ui/index.html").read_text(encoding="utf-8")
    js = Path("ui/app.js").read_text(encoding="utf-8")
    assert "Configuração e segredos" in html
    assert "/v1/config" in js and "/v1/secrets/session" in js
    assert "localStorage" not in js
    assert "sessionStorage" not in js
    assert "document.cookie" not in js


def test_redactor_is_recursive_and_does_not_destroy_normal_data():
    value = {"credential": "x", "normal": [{"private_key": "y", "count": 3}]}
    assert redact_sensitive(value) == {"credential": "[REDACTED]", "normal": [{"private_key": "[REDACTED]", "count": 3}]}


def test_current_version_is_at_least_4_3():
    version = Path("VERSION").read_text(encoding="utf-8").strip()
    parts = tuple(int(x) for x in version.split("."))
    assert parts >= (4, 3, 0)
