# Rabidanti v4.2 — Sala

Rabidanti v4.2 adiciona uma interface visual local à API v4.1.

## Arranque rápido

```bash
python rabidanti.py room
```

Por defeito a Sala usa `127.0.0.1:8765` e abre `http://127.0.0.1:8765/ui/` no navegador.

Para arrancar sem abrir automaticamente o navegador:

```bash
python rabidanti.py room --no-browser
```

Para definir um token fixo de mutação apenas para a sessão/processo:

```bash
set RABIDANTI_API_TOKEN=um-token-forte-com-24-ou-mais-caracteres
python rabidanti.py room
```

No Linux/macOS use `export` em vez de `set`.

Sem token fornecido, Rabidanti gera um token efémero e imprime-o no terminal. Esse token é necessário apenas para operações de escrita, como criar uma tarefa.

## Segurança
A Sala é local-only. Não exponha a porta através de reverse proxy, port forwarding ou túnel sem uma camada de segurança própria e uma revisão arquitetural explícita.
