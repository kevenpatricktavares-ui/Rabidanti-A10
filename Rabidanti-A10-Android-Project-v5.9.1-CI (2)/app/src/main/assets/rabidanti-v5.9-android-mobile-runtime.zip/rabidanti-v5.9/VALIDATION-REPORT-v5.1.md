# Rabidanti v5.1 — Relatório de Validação

## Base recebida

- Artefacto: `rabidanti-v5.0-executable-product-foundation.zip`
- SHA-256 confirmado: `eeff017fcf4cc5785a8589d228e57bdfc3eea1be9f4305d39cdd13bb7370e650`
- Versão inicial: `5.0.0`
- Baseline executada antes das alterações: **628/628 testes aprovados**
  - v4/v5: 134
  - v3: 157
  - `tests/`: 337

## Alterações v5.1

- novo `rabidanti_onboarding.py` com estado atómico e não sensível de primeiro arranque;
- `GET /v1/setup`;
- `POST /v1/setup/complete` autenticado;
- `POST /v1/vault/unlock` autenticado;
- wizard de primeiro arranque na Sala;
- entrega de token efémero à Sala através do fragmento URL, removido por `history.replaceState`;
- nenhuma utilização de `localStorage`, `sessionStorage` ou cookies para o token;
- desbloqueio do vault somente em memória da sessão;
- `master_key` acrescentado aos marcadores de redação sensível;
- correção: rotas `connectors/control` e `connectors/approve` removidas do handler GET e mantidas exclusivamente em POST autenticado;
- teste histórico v5.0 corrigido para validar SemVer >= 5.0, em vez de congelar `5.0.0`.

## Testes v5.1

Foram adicionados **12 testes específicos**, cobrindo:

- estado inicial e conclusão do onboarding;
- ausência de segredos no ficheiro de onboarding;
- rejeição de chaves de configuração não permitidas;
- redação de `master_key`;
- conclusão do setup no runtime;
- autenticação do endpoint de setup;
- unlock do vault sem persistência da chave;
- GET incapaz de mutar conectores;
- token efémero apenas no fragmento URL;
- remoção do fragmento e ausência de browser storage;
- comunicação explícita de que não há instalação/download automático.

## Regressão final da árvore de desenvolvimento

- v4/v5: **146 passed**
- v3: **157 passed**
- `tests/`: **337 passed**
- Total: **640/640 passed**
- Falhas: **0**
- `python -m compileall`: PASS
- `node --check ui/app.js`: PASS
- smoke `rabidanti.py status`: PASS (`VERSION=5.1.0`)
- smoke `rabidanti_bootstrap.py setup`: PASS

## Limitações preservadas

- este ambiente continua sem PyInstaller instalado e sem acesso externo para o instalar;
- nenhum `Rabidanti.exe` Windows nativo foi construído ou executado aqui;
- Ollama/modelo real não é instalado nem descarregado automaticamente;
- o wizard pode concluir mesmo sem Ollama, mas não declara o chat como operacional nesse caso;
- a chave-mestra do vault não é persistida; após reinício deve ser fornecida novamente ou vir de `RABIDANTI_VAULT_MASTER_KEY`;
- nenhuma configuração inicial concede autorização de ação externa, integração automática no Core ou validação científica.
