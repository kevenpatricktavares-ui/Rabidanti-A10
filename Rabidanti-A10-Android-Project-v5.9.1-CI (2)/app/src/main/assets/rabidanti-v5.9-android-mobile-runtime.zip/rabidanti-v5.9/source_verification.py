"""Rabidanti v3.54 — source verification and evidence fusion.

This layer evaluates a claim against explicitly recorded evidence. It never
turns source agreement into absolute truth; results are evidence assessments
with provenance, independence hints and transparent scoring.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
import sqlite3, threading, time, uuid
from typing import Optional, Iterable


class VerificationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    SUPPORTED = "SUPPORTED"
    CONTESTED = "CONTESTED"
    CONTRADICTED = "CONTRADICTED"
    INSUFFICIENT = "INSUFFICIENT"


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    claim_id: str
    source_id: str
    supports: bool
    strength: float
    note: str
    created_at: float
    independent_group: str


@dataclass(frozen=True)
class ClaimAssessment:
    claim_id: str
    claim: str
    status: VerificationStatus
    confidence: float
    evidence_count: int
    supporting_count: int
    contradicting_count: int
    independent_support_groups: int
    independent_contradiction_groups: int
    rationale: str
    assessed_at: float


class EvidenceFusionStore:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        if db_path != ':memory:':
            self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS verification_evidence (
            evidence_id TEXT PRIMARY KEY, claim_id TEXT NOT NULL, source_id TEXT NOT NULL,
            supports INTEGER NOT NULL, strength REAL NOT NULL, note TEXT NOT NULL,
            created_at REAL NOT NULL, independent_group TEXT NOT NULL)''')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS claim_assessments (
            claim_id TEXT PRIMARY KEY, claim TEXT NOT NULL, status TEXT NOT NULL,
            confidence REAL NOT NULL, evidence_count INTEGER NOT NULL,
            supporting_count INTEGER NOT NULL, contradicting_count INTEGER NOT NULL,
            independent_support_groups INTEGER NOT NULL,
            independent_contradiction_groups INTEGER NOT NULL,
            rationale TEXT NOT NULL, assessed_at REAL NOT NULL)''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_verification_evidence_claim ON verification_evidence(claim_id)')

    def save_evidence(self, evidence: Evidence) -> None:
        with self._lock:
            self._conn.execute(
                'INSERT OR REPLACE INTO verification_evidence VALUES(?,?,?,?,?,?,?,?)',
                (evidence.evidence_id, evidence.claim_id, evidence.source_id,
                 int(evidence.supports), evidence.strength, evidence.note,
                 evidence.created_at, evidence.independent_group),
            )

    def evidence(self, claim_id: str, limit: int = 500) -> list[Evidence]:
        with self._lock:
            rows = self._conn.execute(
                'SELECT * FROM verification_evidence WHERE claim_id=? ORDER BY created_at ASC LIMIT ?',
                (claim_id, int(limit)),
            ).fetchall()
        return [Evidence(**dict(r) | {'supports': bool(r['supports'])}) for r in rows]

    def save_assessment(self, assessment: ClaimAssessment) -> None:
        with self._lock:
            self._conn.execute(
                'INSERT OR REPLACE INTO claim_assessments VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                tuple(asdict(assessment).values()),
            )

    def assessment(self, claim_id: str) -> Optional[ClaimAssessment]:
        with self._lock:
            row = self._conn.execute('SELECT * FROM claim_assessments WHERE claim_id=?', (claim_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d['status'] = VerificationStatus(d['status'])
        return ClaimAssessment(**d)


class SourceVerification:
    """Records evidence and fuses it into a bounded claim assessment."""

    def __init__(self, store: EvidenceFusionStore):
        self.store = store

    def add_evidence(
        self, *, claim_id: str, source_id: str, supports: bool,
        strength: float = 0.5, note: str = '', independent_group: Optional[str] = None,
        evidence_id: Optional[str] = None, created_at: Optional[float] = None,
    ) -> Evidence:
        claim_id = str(claim_id).strip(); source_id = str(source_id).strip()
        if not claim_id or not source_id:
            raise ValueError('claim_id and source_id are required')
        strength = float(strength)
        if not 0.0 <= strength <= 1.0:
            raise ValueError('strength must be between 0 and 1')
        note = str(note).strip()
        group = (str(independent_group).strip() if independent_group is not None else source_id)
        if not group:
            raise ValueError('independent_group cannot be empty')
        ts = time.time() if created_at is None else float(created_at)
        if ts > time.time() + 60:
            raise ValueError('created_at cannot be materially in the future')
        evidence = Evidence(
            evidence_id=evidence_id or 'evidence-' + uuid.uuid4().hex,
            claim_id=claim_id, source_id=source_id, supports=bool(supports),
            strength=strength, note=note, created_at=ts, independent_group=group,
        )
        self.store.save_evidence(evidence)
        return evidence

    def assess(self, *, claim_id: str, claim: str, minimum_verified_sources: int = 2) -> ClaimAssessment:
        claim_id = str(claim_id).strip(); claim = str(claim).strip()
        if not claim_id or not claim:
            raise ValueError('claim_id and claim are required')
        if minimum_verified_sources < 1:
            raise ValueError('minimum_verified_sources must be positive')
        items = self.store.evidence(claim_id)
        support = [e for e in items if e.supports]
        oppose = [e for e in items if not e.supports]
        sg = {e.independent_group for e in support}
        og = {e.independent_group for e in oppose}
        support_score = sum(e.strength for e in support)
        oppose_score = sum(e.strength for e in oppose)
        total = support_score + oppose_score
        balance = 0.0 if total == 0 else abs(support_score - oppose_score) / total
        confidence = round(min(1.0, (0.35 * min(len(sg), 3) / 3) + (0.35 * balance) + (0.30 * min(total / 3.0, 1.0))), 4)

        if not items:
            status = VerificationStatus.INSUFFICIENT
            rationale = 'No evidence has been recorded for the claim.'
        elif support and oppose:
            status = VerificationStatus.CONTESTED if support_score >= oppose_score * 0.5 and oppose_score >= support_score * 0.5 else (VerificationStatus.SUPPORTED if support_score > oppose_score else VerificationStatus.CONTRADICTED)
            rationale = 'Supporting and contradicting evidence are both present.'
        elif support_score > 0:
            status = VerificationStatus.VERIFIED if len(sg) >= minimum_verified_sources and balance >= 0.5 else VerificationStatus.SUPPORTED
            rationale = 'Only supporting evidence is recorded; independence and evidence strength determine the status.'
        else:
            status = VerificationStatus.CONTRADICTED
            rationale = 'Only contradicting evidence is recorded.'

        result = ClaimAssessment(
            claim_id=claim_id, claim=claim, status=status, confidence=confidence,
            evidence_count=len(items), supporting_count=len(support),
            contradicting_count=len(oppose), independent_support_groups=len(sg),
            independent_contradiction_groups=len(og), rationale=rationale,
            assessed_at=time.time(),
        )
        self.store.save_assessment(result)
        return result
