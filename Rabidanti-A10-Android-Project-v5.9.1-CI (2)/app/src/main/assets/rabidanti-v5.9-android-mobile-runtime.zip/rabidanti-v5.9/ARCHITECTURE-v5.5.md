# Rabidanti v5.5 — Windows Native Build & Release Verification

## Objetivo

A v5.5 fecha a lacuna entre “pipeline de build preparado” e “release Windows verificável”.
Ela não fabrica um executável fora de Windows. Em vez disso, define evidências que só podem ser produzidas depois de um build nativo real.

## Fluxo de release Windows

1. `VERSION` é a única fonte de versão.
2. `rabidanti_release.py sync` gera metadata Windows e Inno Setup.
3. `rabidanti_release.py preflight` valida 21 invariantes do source tree.
4. PyInstaller gera `dist/Rabidanti.exe` em modo GUI (`console=False`).
5. `rabidanti_release.py postbuild` valida estrutura PE, arquitetura, subsystem GUI e SHA-256.
6. Inno Setup gera `installer-dist/Rabidanti-Setup-<version>.exe`.
7. `verify_windows_release.ps1` executa no Windows:
   - `product build-info` no executável construído;
   - `status` com estado novo;
   - instalação silenciosa num diretório isolado;
   - execução do binário instalado;
   - desinstalação silenciosa.
8. Só após esses passos é criado `windows-release-validation.json` com `end_to_end_windows_validated=true`.
9. `native_release_check.py` reconcilia hashes entre os artefactos, o `release-manifest.json` e a validação Windows.

## Separação de evidências

`release-manifest.json` prova apenas integridade estrutural do build nativo.

`windows-release-validation.json` prova execução de ponta a ponta numa máquina Windows.

A ausência destes ficheiros num pacote fonte é intencional e obrigatória.

## Segurança

- Nenhum update ou instalação é autoautorizado.
- Não existe build nativo “simulado”.
- O `.exe` deve usar subsystem `windows_gui`.
- O instalador continua per-user (`PrivilegesRequired=lowest`).
- SHA-256 do executável e instalador deve coincidir em todas as evidências.
- Alteração posterior de bytes invalida a release.

## CI opcional

`.github/workflows/windows-native-release.yml` descreve um runner Windows reprodutível que instala Inno Setup, executa `build_release_windows.bat`, valida as evidências e só então publica os artefactos.
