"""Rabidanti v5.x product/bootstrap foundation.

This module deliberately uses only the Python standard library so environment
checks can run before optional/runtime dependencies are available. It does not
install packages, download models, or make external changes automatically.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from importlib import metadata, util
from pathlib import Path
from typing import Any, Mapping, Optional
import json
import os
import platform
import shutil
import sys
import tempfile
import urllib.error
import urllib.request


RUNTIME_DEPENDENCIES: tuple[tuple[str, str], ...] = (
    ("fastapi", "fastapi"),
    ("uvicorn", "uvicorn"),
    ("pydantic", "pydantic"),
    ("httpx", "httpx"),
    ("cryptography", "cryptography"),
)


def default_state_dir(environ: Optional[Mapping[str, str]] = None) -> Path:
    env = os.environ if environ is None else environ
    override = env.get("RABIDANTI_STATE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    if os.name == "nt":
        base = env.get("LOCALAPPDATA") or env.get("APPDATA")
        if base:
            return (Path(base) / "Rabidanti").resolve()
    if sys.platform == "darwin":
        return (Path.home() / "Library" / "Application Support" / "Rabidanti").resolve()
    xdg = env.get("XDG_DATA_HOME")
    if xdg:
        return (Path(xdg) / "rabidanti").expanduser().resolve()
    return (Path.home() / ".local" / "share" / "rabidanti").resolve()


def _version_for(distribution: str) -> Optional[str]:
    try:
        return metadata.version(distribution)
    except metadata.PackageNotFoundError:
        return None


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".product-", suffix=".tmp", dir=str(path.parent), text=True)
    try:
        if os.name != "nt":
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
        if os.name != "nt":
            os.chmod(path, 0o600)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


@dataclass(frozen=True)
class DependencyCheck:
    import_name: str
    distribution: str
    available: bool
    version: Optional[str]


class ProductFoundation:
    """Read-only diagnostics plus explicit local-state initialization."""

    def __init__(self, state_dir: str | os.PathLike[str]) -> None:
        self.state_dir = Path(state_dir).expanduser().resolve()

    def dependencies(self) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for import_name, distribution in RUNTIME_DEPENDENCIES:
            row = DependencyCheck(
                import_name=import_name,
                distribution=distribution,
                available=util.find_spec(import_name) is not None,
                version=_version_for(distribution),
            )
            rows.append(asdict(row))
        return rows

    def ollama(self, *, probe_http: bool = True, timeout: float = 0.75) -> dict[str, Any]:
        executable = shutil.which("ollama")
        result: dict[str, Any] = {
            "executable": executable,
            "installed": executable is not None,
            "reachable": False,
            "endpoint": "http://127.0.0.1:11434/api/tags",
            "models": [],
        }
        if not probe_http:
            return result
        try:
            request = urllib.request.Request(result["endpoint"], headers={"Accept": "application/json"})
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = json.loads(response.read().decode("utf-8"))
            models = raw.get("models", []) if isinstance(raw, dict) else []
            result["reachable"] = True
            result["models"] = [
                str(item.get("name")) for item in models
                if isinstance(item, dict) and item.get("name")
            ]
        except (OSError, urllib.error.URLError, json.JSONDecodeError, TimeoutError):
            pass
        return result

    def build_info(self) -> dict[str, Any]:
        version_path = Path(__file__).resolve().with_name("VERSION")
        try:
            version = version_path.read_text(encoding="utf-8").strip()
        except OSError:
            version = "unknown"
        return {
            "program": "Rabidanti",
            "version": version,
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "platform": platform.platform(),
            "architecture": platform.machine(),
            "frozen": bool(getattr(sys, "frozen", False)),
            "state_dir": str(self.state_dir),
            "source_dir": str(Path(__file__).resolve().parent),
        }

    def doctor(self, *, probe_ollama: bool = True) -> dict[str, Any]:
        deps = self.dependencies()
        ollama = self.ollama(probe_http=probe_ollama)
        checks = [
            {"name": "python", "ok": sys.version_info >= (3, 10), "detail": platform.python_version()},
            {"name": "runtime_dependencies", "ok": all(x["available"] for x in deps), "detail": deps},
            {"name": "state_parent", "ok": self.state_dir.parent.exists(), "detail": str(self.state_dir.parent)},
            {
                "name": "ollama",
                "ok": bool(ollama["reachable"]),
                "detail": ollama,
                "optional": True,
            },
        ]
        return {
            "program": "Rabidanti",
            "product_foundation": "5.0",
            "ready_for_runtime": all(c["ok"] for c in checks if not c.get("optional")),
            "checks": checks,
            "build": self.build_info(),
            "safety": {
                "installs_automatically": False,
                "downloads_models_automatically": False,
                "external_action_authorized": False,
            },
        }

    def initialize(self) -> dict[str, Any]:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        marker = self.state_dir / "product.json"
        payload = {
            "program": "Rabidanti",
            "product_schema": 1,
            "state_dir": str(self.state_dir),
            "external_action_authorized": False,
        }
        _atomic_json(marker, payload)
        return {"initialized": True, "state_dir": str(self.state_dir), "marker": str(marker)}
