#!/usr/bin/env python3
"""Android/Termux compatibility host for Rabidanti.

The module is deliberately a thin host adapter. It does not fork or replace the
Rabidanti core, permission gates, databases, vault, API, or Sala. Android
specific behavior is limited to environment detection, paths, diagnostics and
browser launch.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from typing import Any, Mapping, Optional

from rabidanti_product import ProductFoundation


def is_termux(environ: Optional[Mapping[str, str]] = None) -> bool:
    env = os.environ if environ is None else environ
    prefix = str(env.get("PREFIX", "")).lower()
    return bool(env.get("TERMUX_VERSION")) or "com.termux" in prefix


def is_android(environ: Optional[Mapping[str, str]] = None) -> bool:
    env = os.environ if environ is None else environ
    return is_termux(env) or bool(env.get("ANDROID_ROOT")) or bool(env.get("ANDROID_DATA"))


def android_state_dir(environ: Optional[Mapping[str, str]] = None) -> Path:
    env = os.environ if environ is None else environ
    override = env.get("RABIDANTI_STATE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    home = Path(env.get("HOME") or str(Path.home())).expanduser().resolve()
    return (home / ".local" / "share" / "rabidanti").resolve()


def _loopback_bind_available() -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def browser_command(url: str, environ: Optional[Mapping[str, str]] = None) -> Optional[list[str]]:
    env = os.environ if environ is None else environ
    path = env.get("PATH")
    termux_open = shutil.which("termux-open-url", path=path)
    if termux_open:
        return [termux_open, url]
    am = shutil.which("am", path=path)
    if am:
        return [am, "start", "-a", "android.intent.action.VIEW", "-d", url]
    return None


def open_android_url(url: str, environ: Optional[Mapping[str, str]] = None) -> bool:
    command = browser_command(url, environ)
    if not command:
        return False
    try:
        subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except OSError:
        return False


def android_diagnostics(
    *,
    state_dir: str | os.PathLike[str] | None = None,
    environ: Optional[Mapping[str, str]] = None,
    probe_ollama: bool = False,
) -> dict[str, Any]:
    env = os.environ if environ is None else environ
    target = Path(state_dir).expanduser().resolve() if state_dir else android_state_dir(env)
    product = ProductFoundation(target)
    deps = product.dependencies()
    android = is_android(env)
    termux = is_termux(env)
    browser = browser_command("http://127.0.0.1:8765/ui/", env)
    checks = [
        {"name": "android_environment", "ok": android, "detail": {"termux": termux}, "required": True},
        {"name": "python", "ok": sys.version_info >= (3, 10), "detail": sys.version.split()[0], "required": True},
        {"name": "runtime_dependencies", "ok": all(d["available"] for d in deps), "detail": deps, "required": True},
        {"name": "loopback_bind", "ok": _loopback_bind_available(), "detail": "127.0.0.1", "required": True},
        {"name": "browser_launcher", "ok": browser is not None, "detail": browser[0] if browser else None, "required": False},
        {
            "name": "shared_storage",
            "ok": bool(env.get("EXTERNAL_STORAGE") or (Path.home() / "storage").exists()),
            "detail": env.get("EXTERNAL_STORAGE"),
            "required": False,
        },
    ]
    if probe_ollama:
        ollama = product.ollama(probe_http=True)
        checks.append({"name": "ollama", "ok": bool(ollama["reachable"]), "detail": ollama, "required": False})
    required_ok = all(c["ok"] for c in checks if c.get("required"))
    return {
        "program": "Rabidanti",
        "host": "android",
        "termux": termux,
        "state_dir": str(target),
        "ready": required_ok,
        "checks": checks,
        "safety": {
            "core_modified": False,
            "external_action_authorized": False,
            "automatic_connector_enable": False,
            "automatic_model_download": False,
        },
    }


def run_android(
    *,
    state_dir: str | os.PathLike[str] | None = None,
    port: int = 8765,
    no_browser: bool = False,
) -> int:
    """Run the existing Rabidanti runtime/API/Sala under an Android host adapter."""
    target = Path(state_dir).expanduser().resolve() if state_dir else android_state_dir()
    diagnostics = android_diagnostics(state_dir=target)
    if not diagnostics["ready"]:
        failed = [c["name"] for c in diagnostics["checks"] if c.get("required") and not c["ok"]]
        raise RuntimeError("Android readiness failed: " + ", ".join(failed))

    # Deferred imports keep `doctor` usable even when runtime dependencies are missing.
    from rabidanti_runtime import RabidantiRuntime
    from rabidanti_api import RabidantiApiService
    from rabidanti import room_browser_url

    ProductFoundation(target).initialize()
    runtime = RabidantiRuntime(str(target))
    runtime.start()
    service = RabidantiApiService(runtime, host="127.0.0.1", port=port)
    addr = service.start(background=True)
    base_url = f"http://{addr.host}:{addr.port}"
    setup_required = not runtime.onboarding.status().get("completed", False)
    url = room_browser_url(base_url, service.token, setup_required)

    print(json.dumps({
        "program": "Rabidanti",
        "version": runtime.version,
        "host": "android",
        "sala": base_url + "/ui/",
        "browser_opened": False if no_browser else open_android_url(url),
        "state_dir": str(target),
        "external_action_authorized": False,
    }, ensure_ascii=False, indent=2))
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        return 0
    finally:
        service.stop()
        runtime.stop()


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="rabidanti-android", description="Rabidanti Android/Termux host adapter")
    parser.add_argument("--state-dir")
    sub = parser.add_subparsers(dest="command", required=True)
    doctor = sub.add_parser("doctor")
    doctor.add_argument("--probe-ollama", action="store_true")
    run = sub.add_parser("run")
    run.add_argument("--port", type=int, default=8765)
    run.add_argument("--no-browser", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "doctor":
        print(json.dumps(android_diagnostics(state_dir=args.state_dir, probe_ollama=args.probe_ollama), ensure_ascii=False, indent=2))
        return 0
    return run_android(state_dir=args.state_dir, port=args.port, no_browser=args.no_browser)


if __name__ == "__main__":
    raise SystemExit(main())
