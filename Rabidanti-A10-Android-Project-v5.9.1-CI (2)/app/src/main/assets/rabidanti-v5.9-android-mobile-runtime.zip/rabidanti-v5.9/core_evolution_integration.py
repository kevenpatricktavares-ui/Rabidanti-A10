"""Rabidanti v3.69 — Core integration for controlled evolution.

This adapter gives Core/Orchestrator a single evolution-facing facade while
keeping EvolutionController as the authority for lifecycle transitions.
No method here bypasses explicit activation/rollback approval gates.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from backend.evolution_controller import EvolutionController, EvolutionRecord


@dataclass(frozen=True)
class EvolutionDecision:
    evolution_id: str
    strategy_key: str
    action: str
    state: str
    requires_approval: bool
    allowed: bool
    reason: str


class CoreEvolutionIntegration:
    """Core/Orchestrator facade over the controlled evolution lifecycle."""

    def __init__(self, controller: Optional[EvolutionController] = None):
        self.controller = controller or EvolutionController()

    def register_proposal(self, evolution_id: str, strategy_key: str) -> EvolutionRecord:
        return self.controller.create(evolution_id, strategy_key)

    def begin_experiment(self, evolution_id: str, experiment_id: str) -> EvolutionRecord:
        return self.controller.start_experiment(evolution_id, experiment_id)

    def prepare_promotion(self, evolution_id: str, promotion_id: str) -> EvolutionRecord:
        return self.controller.mark_promotion_pending(evolution_id, promotion_id)

    def prepare_activation(self, evolution_id: str) -> EvolutionRecord:
        return self.controller.request_activation(evolution_id)

    def activation_decision(self, evolution_id: str, new_version: str) -> EvolutionDecision:
        record = self.controller.get(evolution_id)
        if record.state.value != "ACTIVATION_PENDING":
            return EvolutionDecision(evolution_id, record.strategy_key, "activate", record.state.value,
                                     True, False, "activation requires ACTIVATION_PENDING")
        return EvolutionDecision(evolution_id, record.strategy_key, "activate", record.state.value,
                                 True, True, "explicit approval required")

    def activate(self, evolution_id: str, new_version: str, approval: bool = False) -> EvolutionRecord:
        return self.controller.activate(evolution_id, new_version, approval=approval)

    def review_health(self, evolution_id: str, health_status: str) -> EvolutionRecord:
        return self.controller.begin_health_review(evolution_id, health_status)

    def recommend_rollback(self, evolution_id: str, rollback_target: str) -> EvolutionRecord:
        return self.controller.recommend_rollback(evolution_id, rollback_target)

    def rollback(self, evolution_id: str, approval: bool = False) -> EvolutionRecord:
        return self.controller.apply_rollback(evolution_id, approval=approval)

    def reject(self, evolution_id: str) -> EvolutionRecord:
        return self.controller.reject(evolution_id)

    def status(self, evolution_id: str) -> dict:
        r = self.controller.get(evolution_id)
        return {
            "evolution_id": r.evolution_id,
            "strategy_key": r.strategy_key,
            "state": r.state.value,
            "experiment_id": r.experiment_id,
            "promotion_id": r.promotion_id,
            "active_version": r.active_version,
            "previous_version": r.previous_version,
            "rollback_target": r.rollback_target,
            "health_status": r.health_status,
        }
