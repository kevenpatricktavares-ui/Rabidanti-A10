"""Rabidanti v3.60 — Priority outcome feedback and learning.

Records what happened after an intelligence-priority decision was executed and
produces bounded evidence for future prioritization. It never changes weights,
executes work, spends money, or treats correlation as causation.
"""
from __future__ import annotations

import sqlite3
import time
import json
from dataclasses import dataclass, asdict
from typing import Iterable

from intelligence_prioritization import PriorityBand, PriorityDecision


@dataclass(frozen=True)
class PriorityOutcome:
    candidate_id: str
    band: PriorityBand
    score: float
    outcome: str
    duration_seconds: float | None = None
    attempts: int = 1
    recorded_at: float = 0.0
    components: dict[str, float] | None = None

    def validate(self) -> None:
        if not str(self.candidate_id).strip():
            raise ValueError("candidate_id is required")
        if not 0.0 <= float(self.score) <= 1.0:
            raise ValueError("score must be between 0 and 1")
        if not isinstance(self.band, PriorityBand):
            raise ValueError("band must be a PriorityBand")
        if not str(self.outcome).strip():
            raise ValueError("outcome is required")
        if self.duration_seconds is not None and float(self.duration_seconds) < 0:
            raise ValueError("duration_seconds must be >= 0")
        if int(self.attempts) < 1:
            raise ValueError("attempts must be >= 1")


@dataclass(frozen=True)
class PriorityFeedback:
    band: str
    observations: int
    completed: int
    failed: int
    success_rate: float | None
    average_duration_seconds: float | None
    average_attempts: float | None
    evidence: str

    def to_dict(self) -> dict:
        return asdict(self)


class PriorityLearningStore:
    """Small durable SQLite store for priority execution outcomes."""

    def __init__(self, db_path: str = ":memory:"):
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS priority_outcomes (
                candidate_id TEXT NOT NULL,
                band INTEGER NOT NULL,
                score REAL NOT NULL,
                outcome TEXT NOT NULL,
                duration_seconds REAL,
                attempts INTEGER NOT NULL,
                recorded_at REAL NOT NULL,
                components_json TEXT
            )"""
        )
        columns = {row[1] for row in self.conn.execute("PRAGMA table_info(priority_outcomes)").fetchall()}
        if "components_json" not in columns:
            self.conn.execute("ALTER TABLE priority_outcomes ADD COLUMN components_json TEXT")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_priority_outcomes_band ON priority_outcomes(band)")
        self.conn.commit()

    def record(self, outcome: PriorityOutcome) -> None:
        outcome.validate()
        recorded_at = float(outcome.recorded_at or time.time())
        self.conn.execute(
            "INSERT INTO priority_outcomes VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (outcome.candidate_id, int(outcome.band), float(outcome.score), outcome.outcome.upper(),
             outcome.duration_seconds, int(outcome.attempts), recorded_at, json.dumps(outcome.components or {}, sort_keys=True)),
        )
        self.conn.commit()

    def list(self) -> list[PriorityOutcome]:
        rows = self.conn.execute(
            "SELECT candidate_id, band, score, outcome, duration_seconds, attempts, recorded_at, components_json "
            "FROM priority_outcomes ORDER BY recorded_at, candidate_id"
        ).fetchall()
        return [PriorityOutcome(r[0], PriorityBand(r[1]), r[2], r[3], r[4], r[5], r[6], json.loads(r[7] or "{}")) for r in rows]

    def feedback(self) -> list[PriorityFeedback]:
        rows = self.conn.execute(
            "SELECT band, COUNT(*), SUM(CASE WHEN outcome='COMPLETED' THEN 1 ELSE 0 END), "
            "SUM(CASE WHEN outcome='FAILED' THEN 1 ELSE 0 END), "
            "AVG(CASE WHEN duration_seconds IS NOT NULL THEN duration_seconds END), AVG(attempts) "
            "FROM priority_outcomes GROUP BY band ORDER BY band DESC"
        ).fetchall()
        result = []
        for band, n, completed, failed, duration, attempts in rows:
            completed = int(completed or 0); failed = int(failed or 0)
            decisive = completed + failed
            rate = round(completed / decisive, 4) if decisive else None
            evidence = "SUFFICIENT" if decisive >= 3 else "LIMITED"
            result.append(PriorityFeedback(PriorityBand(band).name, int(n), completed, failed, rate,
                                           round(duration, 4) if duration is not None else None,
                                           round(attempts, 4) if attempts is not None else None, evidence))
        return result

    def close(self) -> None:
        self.conn.close()


class PriorityFeedbackEngine:
    """Turns stored execution outcomes into cautious, auditable feedback."""

    def __init__(self, store: PriorityLearningStore):
        self.store = store

    def record_decision_outcome(self, decision: PriorityDecision, outcome: str,
                                duration_seconds: float | None = None, attempts: int = 1,
                                recorded_at: float | None = None) -> PriorityOutcome:
        normalized = str(outcome).strip().upper()
        if normalized not in {"COMPLETED", "FAILED", "CANCELLED"}:
            raise ValueError("outcome must be COMPLETED, FAILED, or CANCELLED")
        item = PriorityOutcome(decision.candidate_id, decision.band, decision.score, normalized,
                               duration_seconds, attempts, float(recorded_at or time.time()), dict(decision.components))
        self.store.record(item)
        return item

    def assess(self) -> list[PriorityFeedback]:
        return self.store.feedback()

    def recommendations(self) -> tuple[str, ...]:
        recommendations: list[str] = []
        for feedback in self.assess():
            if feedback.evidence != "SUFFICIENT":
                continue
            if feedback.success_rate is not None and feedback.success_rate < 0.5:
                recommendations.append(
                    f"Review {feedback.band} priority signals: observed completion rate is {feedback.success_rate:.2f}."
                )
            elif feedback.success_rate is not None and feedback.success_rate >= 0.8:
                recommendations.append(
                    f"{feedback.band} priority has strong observed execution completion ({feedback.success_rate:.2f}); preserve for further observation."
                )
        if not recommendations:
            recommendations.append("Collect more execution outcomes before changing prioritization strategy.")
        return tuple(recommendations)
