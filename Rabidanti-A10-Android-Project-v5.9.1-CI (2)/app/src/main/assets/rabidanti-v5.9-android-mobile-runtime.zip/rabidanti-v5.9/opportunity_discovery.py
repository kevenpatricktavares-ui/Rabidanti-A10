"""Rabidanti v3.49 — Continuous Opportunity Discovery foundation.

Groups world-awareness signals into evidence-bounded opportunity themes. This
module detects repeated/related signals; it does not claim commercial validity.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import defaultdict
import re, uuid
from typing import Any

from world_awareness import WorldAwareness
from world_opportunity import WorldOpportunityEngine

_STOP = {"the","and","for","with","that","this","from","into","new","may","can","are","was","uma","uma","com","para","que","dos","das"}

def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-zA-ZÀ-ÿ0-9]{3,}", text.lower()) if t not in _STOP}

@dataclass(frozen=True)
class OpportunityTheme:
    theme_id: str
    topic: str
    signal_ids: tuple[str, ...]
    source_ids: tuple[str, ...]
    signal_count: int
    verified_source_count: int
    average_confidence: float
    average_freshness: float
    relatedness: float
    hypothesis: str
    evidence: tuple[dict[str, Any], ...]
    limitations: tuple[str, ...]
    status: str = "CANDIDATE_THEME"
    def to_dict(self): return asdict(self)

class OpportunityDiscoveryEngine:
    """Find recurring evidence themes without turning them into fake market facts."""
    def __init__(self, world: WorldAwareness):
        self.world = world
        self.world_engine = WorldOpportunityEngine(world)

    def discover(self, *, topic: str | None = None, limit: int = 100, min_signals: int = 2,
                 min_relatedness: float = 0.2) -> list[OpportunityTheme]:
        if not 1 <= int(limit) <= 500: raise ValueError("limit must be between 1 and 500")
        if not 1 <= int(min_signals) <= 100: raise ValueError("min_signals must be between 1 and 100")
        if not 0 <= float(min_relatedness) <= 1: raise ValueError("min_relatedness must be between 0 and 1")
        signals = self.world.store.signals(topic=topic.strip() if topic else None, limit=int(limit))
        grouped: dict[str, list[Any]] = defaultdict(list)
        for s in signals: grouped[s.topic].append(s)
        themes=[]
        for group_topic, items in sorted(grouped.items()):
            if len(items) < int(min_signals): continue
            token_sets=[_tokens(s.statement) | _tokens(s.topic) for s in items]
            pairs=[]
            for i in range(len(token_sets)):
                for j in range(i+1,len(token_sets)):
                    union=token_sets[i] | token_sets[j]
                    if union: pairs.append(len(token_sets[i]&token_sets[j])/len(union))
            relatedness=round(sum(pairs)/len(pairs),4) if pairs else 1.0
            if relatedness < float(min_relatedness): continue
            sources=[]; evidence=[]
            for s in items:
                src=self.world.store.source(s.source_id)
                if not src: continue
                sources.append(src)
                evidence.append({"world_signal_id":s.signal_id,"world_source_id":src.source_id,"statement":s.statement,"confidence":s.confidence,"freshness":s.freshness,"verified":src.verified,"publisher":src.publisher,"locator":src.locator})
            if not evidence: continue
            avg_c=round(sum(x["confidence"] for x in evidence)/len(evidence),4)
            avg_f=round(sum(x["freshness"] for x in evidence)/len(evidence),4)
            verified=len({x["world_source_id"] for x in evidence if x["verified"]})
            hypothesis=f"Repeated or related world signals around '{group_topic}' may justify investigating a solution or business opportunity in this area."
            limitations=("This is a candidate theme, not a validated market opportunity.","Signal repetition does not prove demand, willingness-to-pay, competition, feasibility or profitability.","Commercial research and controlled experimentation are required.")
            themes.append(OpportunityTheme("otheme-"+uuid.uuid4().hex,group_topic,tuple(x["world_signal_id"] for x in evidence),tuple(dict.fromkeys(x["world_source_id"] for x in evidence)),len(evidence),verified,avg_c,avg_f,relatedness,hypothesis,tuple(evidence),limitations))
        themes.sort(key=lambda x:(-x.signal_count,-x.verified_source_count,-x.average_confidence,-x.relatedness,x.topic))
        return themes
