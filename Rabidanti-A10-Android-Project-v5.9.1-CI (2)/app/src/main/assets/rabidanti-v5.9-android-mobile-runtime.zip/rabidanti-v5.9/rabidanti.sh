#!/usr/bin/env sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$SCRIPT_DIR/rabidanti.py" --state-dir "$SCRIPT_DIR/.rabidanti" shell
