from dataclasses import dataclass
import sqlite3
import pytest

from lab_evidence_memory import LabEvidenceMemory
from lab_evidence_integration import LabEvidenceIntegration
from lab_experiment_manager import LabExperimentManager
from lab_experiment_pipeline import LabExperimentPipeline
from lab_result_analyzer import LabResultAnalyzer
from lab_reproducibility import LabReproducibilityAnalyzer


@dataclass
class FakeResult:
    status: str = "completed"
    executed: bool = True
    return_code: int = 0
    stdout: str = "ok"
    stderr: str = ""
    started_at: str = "start"
    finished_at: str = "finish"
    audit_digest: str = "b" * 64


class FakeExecutor:
    MAX_OUTPUT = 8000

    @classmethod
    def execute(cls, plan, probe, *, approved=False, timeout=None):
        assert approved is True
        return FakeResult()


def make_manager(tmp_path, criteria=("criterion A",)):
    manager = LabExperimentManager(tmp_path / "lab.sqlite3")
    manager.create("e1", "p1", "evidence integration", "hypothesis", "method", list(criteria))
    return manager


def test_pipeline_records_experiment_and_run_in_persistent_evidence_memory(tmp_path):
    manager = make_manager(tmp_path)
    evidence_path = tmp_path / "evidence.sqlite3"
    memory = LabEvidenceMemory(evidence_path)
    result = LabExperimentPipeline(manager, FakeExecutor, evidence_memory=memory).run(
        "e1", {}, {}, approved=True
    )

    reopened = LabEvidenceMemory(evidence_path)
    exp = reopened.get_node("experiment:e1")
    run = reopened.get_node(f"run:{result['run_id']}")
    assert exp["metadata"]["experiment_id"] == "e1"
    assert run["metadata"]["run_id"] == result["run_id"]
    assert run["metadata"]["record_type"] == "run"
    assert any(
        link["relation"] == "EXECUTED_AS" and link["to_id"] == run["node_id"]
        for link in reopened.trace(exp["node_id"])["links"]
    )


def test_result_analysis_is_linked_to_experiment_and_run(tmp_path):
    manager = make_manager(tmp_path)
    memory = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    run = LabExperimentPipeline(manager, FakeExecutor, evidence_memory=memory).run("e1", {}, {}, approved=True)
    report = LabResultAnalyzer(manager, evidence_memory=memory).analyze(
        "e1", run["run_id"],
        {"criterion A": {"state": "PASS", "evidence": "observed"}},
        reviewer="operator", evidence_refs=["artifact:one"],
    )
    node = memory.get_node(f"analysis:{report['analysis_id']}")
    assert node["metadata"]["classification"] == "PASSED"
    assert node["metadata"]["integration_authorized"] is False
    run_trace = memory.trace(f"run:{run['run_id']}")
    assert any(link["relation"] == "ANALYZED_BY" and link["to_id"] == node["node_id"] for link in run_trace["links"])


def test_sync_is_idempotent_and_history_contains_all_record_types(tmp_path):
    manager = make_manager(tmp_path)
    # Build authoritative historical records without evidence integration.
    for rid in ("r1", "r2"):
        manager.add_entry("e1", f"{rid}:result", "RESULT", "completed", {
            "run_id": rid, "experiment_id": "e1", "executed": True, "status": "completed"
        })
        manager.add_entry("e1", f"a-{rid}:analysis", "RECOMMENDATION", "review", {
            "analysis_id": f"a-{rid}", "experiment_id": "e1", "run_id": rid,
            "classification": "PASSED", "criteria": {"criterion A": {"state": "PASS", "evidence": "ok"}},
            "integration_authorized": False,
        })
    manager.add_entry("e1", "rep-1:reproducibility", "RECOMMENDATION", "repro", {
        "reproducibility_id": "rep-1", "experiment_id": "e1", "run_ids": ["r1", "r2"],
        "classification": "CONSISTENT", "integration_authorized": False,
    })

    memory = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    bridge = LabEvidenceIntegration(manager, memory)
    first = bridge.sync_experiment("e1")
    second = bridge.sync_experiment("e1")
    assert first == second == {"experiment": 1, "runs": 2, "analyses": 2, "reproducibility": 1}

    with sqlite3.connect(memory.database) as conn:
        node_count = conn.execute("SELECT COUNT(*) FROM lab_evidence_nodes").fetchone()[0]
        link_count = conn.execute("SELECT COUNT(*) FROM lab_evidence_links").fetchone()[0]
    assert node_count == 6  # 1 experiment + 2 runs + 2 analyses + 1 reproducibility
    assert link_count == 9  # 2 exp-run + 2 exp-analysis + 2 run-analysis + 1 exp-repro + 2 repro-run

    history = bridge.history("e1")
    assert history["integration_authorized"] is False
    assert {item["relation"] for item in history["records"]} == {
        "EXECUTED_AS", "HAS_ANALYSIS", "HAS_REPRODUCIBILITY"
    }
    assert len(history["records"]) == 5


def test_reproducibility_flow_is_persisted_and_links_compared_runs(tmp_path):
    manager = make_manager(tmp_path)
    for rid in ("r1", "r2"):
        manager.add_entry("e1", f"{rid}:result", "RESULT", "completed", {"run_id": rid, "executed": True})
        manager.add_entry("e1", f"{rid}:analysis", "RECOMMENDATION", "review", {
            "analysis_id": f"a-{rid}", "run_id": rid, "classification": "PASSED",
            "criteria": {"criterion A": {"state": "PASS", "evidence": "reviewed"}},
            "integration_authorized": False,
        })
    memory = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    bridge = LabEvidenceIntegration(manager, memory)
    bridge.sync_experiment("e1")

    report = LabReproducibilityAnalyzer(manager, evidence_memory=memory).compare(
        "e1", ["r1", "r2"], reviewer="operator"
    )
    node = memory.get_node(f"reproducibility:{report['reproducibility_id']}")
    assert node["metadata"]["classification"] == "CONSISTENT"
    assert node["metadata"]["integration_authorized"] is False
    trace = memory.trace(node["node_id"])
    compared = {link["to_id"] for link in trace["links"] if link["relation"] == "COMPARES_RUN"}
    assert compared == {"run:r1", "run:r2"}


def test_analysis_sync_rejects_missing_authoritative_run(tmp_path):
    manager = make_manager(tmp_path)
    memory = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    bridge = LabEvidenceIntegration(manager, memory)
    with pytest.raises(ValueError, match="no recorded execution result"):
        bridge.record_analysis("e1", {
            "analysis_id": "a1", "run_id": "missing", "classification": "INCONCLUSIVE",
            "integration_authorized": False,
        })


def test_incompatible_existing_node_fails_closed(tmp_path):
    manager = make_manager(tmp_path)
    memory = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    memory.add_node("SOURCE", "wrong", node_id="experiment:e1")
    with pytest.raises(ValueError, match="incompatible kind"):
        LabEvidenceIntegration(manager, memory).ensure_experiment("e1")
