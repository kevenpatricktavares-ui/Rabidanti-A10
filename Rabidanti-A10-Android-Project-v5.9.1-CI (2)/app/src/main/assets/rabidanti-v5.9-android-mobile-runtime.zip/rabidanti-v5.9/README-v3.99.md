# Rabidanti v3.99

**Controlled Change Authorization & Executor**

Esta versão introduz aplicação controlada de alterações propostas pelo fluxo do Laboratório.

Principais garantias:
- change set imutável e idempotente;
- autorização humana explícita vinculada ao digest exato;
- caminhos limitados ao workspace;
- verificação de hash antes da alteração;
- backup antes da escrita;
- testes allowlisted sem shell;
- rollback automático quando a verificação falha;
- nenhuma autorização de ações externas;
- nenhuma autoautorização.

A v3.99 aproxima o Rabidanti de um runtime operacional, mas ainda não constitui o programa final. O passo seguinte deve unificar Core, tarefas, memória, Laboratório e autorização num processo executável único (v4.0 Runtime MVP).
