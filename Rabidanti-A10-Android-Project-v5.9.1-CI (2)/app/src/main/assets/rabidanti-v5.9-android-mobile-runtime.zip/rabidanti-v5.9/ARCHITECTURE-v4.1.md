# Rabidanti Architecture v4.1 — Local API & Service Layer

## Purpose

Create a stable local service boundary over the v4.0 runtime so future desktop/web interfaces and local integrations can communicate with Rabidanti without importing internal Python modules directly.

## Components

`rabidanti_api.py` provides a `ThreadingHTTPServer`-based local API using only Python's standard library. It owns no business state; all state remains in `RabidantiRuntime` and its persistent stores.

## Trust model

- Listener must bind to a loopback host.
- Read endpoints are local-only and do not mutate state.
- Mutations require a bearer token of at least 24 characters.
- Tokens are compared with constant-time comparison and are not persisted.
- Request bodies are JSON-only and capped at 64 KiB.
- No arbitrary shell or command execution endpoint exists.
- API startup grants no external-action, scientific-validation or Core-integration authority.

## Initial surface

Read: health, status, doctor, tasks, evidence, runtime events, workflows.
Mutation: create persistent task.

The deliberately small mutation surface reduces risk while establishing the service contract for the future Sala/UI.
