# Rabidanti v3.19 — Recovery Controller

## Purpose
Add a bounded, cadence-controlled automatic recovery loop above the conservative v3.18 RecoveryEngine.

## Flow
Health/Telemetry -> RecoveryEngine -> RecoveryController -> Runner

The controller does not invent recovery actions. It delegates only to the existing conservative recovery engine and rate-limits recovery cycles.

## Safety properties
- first recovery cycle is immediately eligible;
- subsequent cycles respect `interval_seconds`;
- recovery statistics are explicit;
- existing queue lease recovery remains the source of truth for abandoned work;
- stale workers with active work are not forcibly revived;
- no cloud/autoscaling/external broker is claimed.

## Integration
`ContinuousWorkerRunner` accepts an optional `RecoveryController`. When supplied, it uses the controller instead of its legacy direct recovery path and exposes `recovery_cycles` in health output.
