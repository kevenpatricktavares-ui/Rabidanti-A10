from dataclasses import dataclass
from enum import Enum


class EvidenceDecision(str, Enum):
    REJECT = "REJECT"
    INVESTIGATE = "INVESTIGATE"
    EXPERIMENT = "EXPERIMENT"
    APPROVAL_REQUIRED = "APPROVAL_REQUIRED"


@dataclass(frozen=True)
class EvidenceDecisionInput:
    fusion_score: float
    independence: float
    reversibility: float
    risk: float
    cost: float


@dataclass(frozen=True)
class EvidenceDecisionResult:
    decision: EvidenceDecision
    score: float
    rationale: str
    approval_required: bool


class EvidenceToDecisionIntegration:
    """Maps fused evidence into the existing decision vocabulary only.

    This layer has no activation, deployment, approval, or Core mutation authority.
    """

    def __init__(self, min_independence=0.30, min_evidence=0.70):
        if not 0 <= min_independence <= 1:
            raise ValueError("min_independence must be between 0 and 1")
        if not 0 <= min_evidence <= 1:
            raise ValueError("min_evidence must be between 0 and 1")
        self.min_independence = min_independence
        self.min_evidence = min_evidence

    def decide(self, assessment: EvidenceDecisionInput):
        values = (assessment.fusion_score, assessment.independence,
                  assessment.reversibility, assessment.risk, assessment.cost)
        if any(not 0 <= v <= 1 for v in values):
            raise ValueError("decision factors must be between 0 and 1")

        if assessment.independence < self.min_independence:
            return EvidenceDecisionResult(
                EvidenceDecision.INVESTIGATE, 0.0,
                "insufficient independent evidence", False)

        if assessment.fusion_score < self.min_evidence:
            return EvidenceDecisionResult(
                EvidenceDecision.INVESTIGATE, round(assessment.fusion_score, 6),
                "fused evidence below decision threshold", False)

        score = (
            .40 * assessment.fusion_score
            + .25 * assessment.reversibility
            + .15 * (1 - assessment.risk)
            + .20 * (1 - assessment.cost)
        )
        score = round(score, 6)

        if score < .45:
            decision = EvidenceDecision.REJECT
            approval = False
        elif score < .65:
            decision = EvidenceDecision.EXPERIMENT
            approval = False
        else:
            decision = EvidenceDecision.APPROVAL_REQUIRED
            approval = True

        return EvidenceDecisionResult(
            decision, score,
            "decision derived from fused evidence and bounded execution factors",
            approval,
        )

    def activate(self, *args, **kwargs):
        raise PermissionError("activation belongs to Evolution Controller")

    def approve(self, *args, **kwargs):
        raise PermissionError("approval belongs to authorized approval workflow")
