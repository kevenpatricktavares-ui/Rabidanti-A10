from __future__ import annotations

import json
from pathlib import Path
import tempfile
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from rabidanti_api import RabidantiApiService
from rabidanti_runtime import RabidantiRuntime

TOKEN = "t" * 32


def _get(base: str, path: str):
    with urlopen(base + path, timeout=3) as r:
        return r.status, json.loads(r.read().decode())


def _post(base: str, path: str, body: dict, token: str | None = TOKEN):
    headers = {"Content-Type": "application/json"}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    req = Request(base + path, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urlopen(req, timeout=3) as r:
        return r.status, json.loads(r.read().decode())


def _service(tmp_path: Path):
    runtime = RabidantiRuntime(tmp_path / "state")
    runtime.start()
    service = RabidantiApiService(runtime, port=0, token=TOKEN)
    addr = service.start()
    return runtime, service, f"http://{addr.host}:{addr.port}"


def test_rejects_non_loopback_binding(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state")
    with pytest.raises(ValueError, match="loopback"):
        RabidantiApiService(runtime, host="0.0.0.0", token=TOKEN)
    runtime.close()


def test_requires_strong_mutation_token(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state")
    with pytest.raises(ValueError, match="24"):
        RabidantiApiService(runtime, token="short")
    runtime.close()


def test_health_and_status_are_local_read_only(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        status, health = _get(base, "/health")
        assert status == 200
        assert health["program"] == "Rabidanti"
        assert health["version"] == Path("VERSION").read_text(encoding="utf-8").strip()
        status, data = _get(base, "/v1/status")
        assert status == 200
        assert data["safety"]["self_authorization"] is False
        assert data["safety"]["external_action_authorized"] is False
    finally:
        service.stop(); runtime.stop()


def test_task_mutation_requires_bearer_token(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        with pytest.raises(HTTPError) as exc:
            _post(base, "/v1/tasks", {"name": "blocked"}, token=None)
        assert exc.value.code == 401
        assert runtime.list_tasks() == []
    finally:
        service.stop(); runtime.stop()


def test_task_creation_and_persistence_through_api(tmp_path):
    state = tmp_path / "state"
    runtime = RabidantiRuntime(state); runtime.start()
    service = RabidantiApiService(runtime, port=0, token=TOKEN); addr = service.start()
    base = f"http://{addr.host}:{addr.port}"
    try:
        status, item = _post(base, "/v1/tasks", {"name": "API task", "priority": "HIGH"})
        assert status == 201
        assert item["name"] == "API task"
        assert item["priority"] == "HIGH"
        _, listed = _get(base, "/v1/tasks")
        assert [x["task_id"] for x in listed["items"]] == [item["task_id"]]
    finally:
        service.stop(); runtime.stop()
    runtime2 = RabidantiRuntime(state); runtime2.start()
    try:
        assert runtime2.list_tasks()[0]["name"] == "API task"
    finally:
        runtime2.stop()


def test_invalid_task_payload_is_rejected_without_side_effect(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        with pytest.raises(HTTPError) as exc:
            _post(base, "/v1/tasks", {"name": "x", "shell": "rm -rf /"})
        assert exc.value.code == 400
        assert runtime.list_tasks() == []
    finally:
        service.stop(); runtime.stop()


def test_arbitrary_http_methods_are_not_an_execution_surface(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        req = Request(base + "/v1/tasks", data=b"{}", method="DELETE", headers={"Authorization": f"Bearer {TOKEN}"})
        with pytest.raises(HTTPError) as exc:
            urlopen(req, timeout=3)
        assert exc.value.code == 405
    finally:
        service.stop(); runtime.stop()


def test_events_record_api_lifecycle_and_mutation(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        _post(base, "/v1/tasks", {"name": "audit me"})
        event_types = {e["event_type"] for e in runtime.runtime_events()}
        assert "LOCAL_API_STARTED" in event_types
        assert "API_TASK_ADDED" in event_types
    finally:
        service.stop()
        event_types = {e["event_type"] for e in runtime.runtime_events()}
        assert "LOCAL_API_STOPPED" in event_types
        runtime.stop()


def test_read_endpoints_validate_limits(tmp_path):
    runtime, service, base = _service(tmp_path)
    try:
        with pytest.raises(HTTPError) as exc:
            _get(base, "/v1/events?limit=not-a-number")
        assert exc.value.code == 400
        with pytest.raises(HTTPError) as exc:
            _get(base, "/v1/events?limit=1001")
        assert exc.value.code == 400
    finally:
        service.stop(); runtime.stop()


def test_generated_token_is_ephemeral_and_not_written_to_runtime_db(tmp_path):
    runtime = RabidantiRuntime(tmp_path / "state"); runtime.start()
    service = RabidantiApiService(runtime, port=0)
    token = service.token
    assert len(token) >= 24
    addr = service.start()
    service.stop(); runtime.stop()
    data = (tmp_path / "state" / "runtime.sqlite3").read_bytes()
    assert token.encode() not in data
