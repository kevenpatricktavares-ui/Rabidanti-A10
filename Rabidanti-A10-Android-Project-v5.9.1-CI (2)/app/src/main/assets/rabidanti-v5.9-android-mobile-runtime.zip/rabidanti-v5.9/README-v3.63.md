# Rabidanti v3.63

Forward Controlled Experimentation for adaptive prioritization.

Validated with the complete inherited suite plus v3.63 tests.

- Full tests: 278 passed
- Compileall: passed
- New module: `forward_experiment.py`
- New tests: `tests/test_v363_forward_experiment.py`

This release does not change production prioritization weights automatically.
