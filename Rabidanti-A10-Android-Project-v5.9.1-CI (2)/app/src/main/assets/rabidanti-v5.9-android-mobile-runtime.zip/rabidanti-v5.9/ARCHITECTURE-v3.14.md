# Rabidanti v3.14 — Worker Runner + Supervisor Integration

Integrates the v3.12 continuous durable-queue runner with the v3.13 persistent worker health registry.

## Capabilities
- stable worker identities per runner slot
- automatic worker registration and RUNNING state
- active-count heartbeat during execution
- supervisor health inspection
- stale-worker detection hook on runner ticks
- graceful STOPPED state on runner close
- durable queue execution remains the source of task state

## Scope
This is still a local/in-process execution layer using SQLite persistence. It does not claim cloud hosting, autoscaling, external brokers, multi-region failover, or production SLA.
