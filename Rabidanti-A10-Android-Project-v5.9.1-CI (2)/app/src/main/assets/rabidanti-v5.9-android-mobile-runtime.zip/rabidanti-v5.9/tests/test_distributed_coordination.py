import os
import tempfile
import time
import unittest

from distributed_coordination import DistributedCoordinator


class TestDistributedCoordination(unittest.TestCase):
    def test_only_one_worker_claims_active_lease(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "coord.db")
            a = DistributedCoordinator(db, lease_seconds=10)
            b = DistributedCoordinator(db, lease_seconds=10)
            self.assertIsNotNone(a.try_claim("t1", "worker-a"))
            self.assertIsNone(b.try_claim("t1", "worker-b"))
            a.close()
            b.close()

    def test_lease_can_be_recovered_after_expiry(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "coord.db")
            c = DistributedCoordinator(db, lease_seconds=1)
            c.try_claim("t1", "worker-a")
            time.sleep(1.1)
            self.assertEqual(c.recover_expired(), ["t1"])
            self.assertIsNotNone(c.try_claim("t1", "worker-b"))
            c.close()

    def test_heartbeat_requires_owner(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "coord.db")
            c = DistributedCoordinator(db, lease_seconds=5)
            c.try_claim("t1", "worker-a")
            with self.assertRaises(PermissionError):
                c.heartbeat("t1", "worker-b")
            lease = c.heartbeat("t1", "worker-a")
            self.assertGreater(lease.lease_until, time.time())
            c.close()

    def test_release_requires_owner(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "coord.db")
            c = DistributedCoordinator(db)
            c.try_claim("t1", "worker-a")
            with self.assertRaises(PermissionError):
                c.release("t1", "worker-b")
            c.release("t1", "worker-a")
            self.assertIsNone(c.get("t1"))
            c.close()

    def test_coordination_survives_new_coordinator_instance(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "coord.db")
            c1 = DistributedCoordinator(db)
            lease = c1.try_claim("t1", "worker-a")
            self.assertEqual(lease.attempts, 1)
            c1.close()

            c2 = DistributedCoordinator(db)
            current = c2.get("t1")
            self.assertEqual(current.worker_id, "worker-a")
            self.assertIsNone(c2.try_claim("t1", "worker-b"))
            c2.close()

    def test_attempt_count_increases_after_expiry(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "coord.db")
            c = DistributedCoordinator(db, lease_seconds=1)
            first = c.try_claim("t1", "worker-a")
            time.sleep(1.1)
            c.recover_expired()
            second = c.try_claim("t1", "worker-b")
            self.assertEqual(first.attempts, 1)
            self.assertEqual(second.attempts, 2)
            c.close()


if __name__ == "__main__":
    unittest.main()
