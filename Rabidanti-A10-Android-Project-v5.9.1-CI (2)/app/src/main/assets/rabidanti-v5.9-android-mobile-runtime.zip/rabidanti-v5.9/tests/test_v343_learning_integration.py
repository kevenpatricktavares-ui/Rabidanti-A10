from analytics_engine import AnalyticsEngine
from learning_engine import LearningEngine
from business_stage_execution import BusinessStageRegistry, register_builtin_learning, StageExecutionContext
from stage_artifact_store import StageArtifactStore

def measured():
    return AnalyticsEngine().summarize("p1", {"channels":["web"],"variants":["control","v1"],"experiment_id":"e1"}, {"funnel_events":["purchase"]}, {"metrics":{"impressions":1000,"clicks":100,"checkout_starts":40,"purchases":20,"spend":50,"revenue":150}}).to_dict()

def test_learning_generates_hypotheses_from_observed_metrics():
    b=LearningEngine().analyze("p1", measured(), {"variants":["control","v1"],"experiment_id":"e1"})
    assert b.status == "ANALYZED"
    assert b.evidence_state == "SUFFICIENT_FOR_LEARNING"
    assert b.hypotheses and b.experiments and b.learnings
    assert any(h["evidence_metric"] == "ctr" for h in b.hypotheses)

def test_learning_waits_without_data():
    a=AnalyticsEngine().summarize("p1", {"channels":["web"],"variants":["control"]}, {"funnel_events":[]}, {})
    b=LearningEngine().analyze("p1", a.to_dict())
    assert b.status == "WAITING_FOR_DATA"
    assert b.hypotheses == ()

def test_stage_learning_consumes_persistent_analytics_artifact():
    store=StageArtifactStore(":memory:")
    store.put("p1","analytics", measured())
    store.put("p1","ads", {"experiment_id":"e1","variants":["control","v1"]})
    reg=BusinessStageRegistry(store)
    register_builtin_learning(reg)
    out=reg.get("learning")(StageExecutionContext("p1","learning","analyze",{},"3.43"))
    assert out["status"] == "ANALYZED"
    assert out["experiment_id"] == "e1"
