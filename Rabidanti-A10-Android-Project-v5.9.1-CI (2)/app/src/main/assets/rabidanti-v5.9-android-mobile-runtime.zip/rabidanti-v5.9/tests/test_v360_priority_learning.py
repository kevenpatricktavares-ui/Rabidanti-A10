import tempfile
from pathlib import Path

from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate, PriorityBand
from priority_learning import PriorityFeedbackEngine, PriorityLearningStore, PriorityOutcome


def decision(cid, value=.9):
    return IntelligencePrioritizer().score(PriorityCandidate(
        cid, "lab", novelty=value, confidence=value, relevance=value,
        impact=value, urgency=value, knowledge_gap=value, investigation_cost=0.0,
    ))


def test_record_and_feedback_persist():
    d = tempfile.TemporaryDirectory()
    path = str(Path(d.name) / "db.sqlite")
    store = PriorityLearningStore(path)
    engine = PriorityFeedbackEngine(store)
    try:
        dec = decision("x")
        engine.record_decision_outcome(dec, "completed", duration_seconds=2.5, attempts=1, recorded_at=10)
        engine.record_decision_outcome(decision("y", .9), "failed", duration_seconds=1.5, attempts=2, recorded_at=11)
        store.close()
        store = PriorityLearningStore(path)
        feedback = store.feedback()
        assert feedback[0].band == "CRITICAL"
        assert feedback[0].observations == 2
        assert feedback[0].completed == 1
        assert feedback[0].failed == 1
    finally:
        store.close(); d.cleanup()


def test_outcome_validation_and_cancelled_are_supported():
    store = PriorityLearningStore()
    engine = PriorityFeedbackEngine(store)
    try:
        item = engine.record_decision_outcome(decision("c", .7), "cancelled")
        assert item.outcome == "CANCELLED"
        try:
            engine.record_decision_outcome(decision("bad"), "unknown")
            assert False
        except ValueError:
            pass
    finally:
        store.close()


def test_limited_evidence_does_not_change_strategy():
    store = PriorityLearningStore()
    engine = PriorityFeedbackEngine(store)
    try:
        engine.record_decision_outcome(decision("x"), "failed")
        assert engine.recommendations() == ("Collect more execution outcomes before changing prioritization strategy.",)
    finally:
        store.close()


def test_sufficient_success_generates_cautious_feedback():
    store = PriorityLearningStore()
    engine = PriorityFeedbackEngine(store)
    try:
        dec = decision("x")
        for i in range(3):
            engine.record_decision_outcome(dec, "completed", recorded_at=i + 1)
        feedback = engine.assess()[0]
        assert feedback.evidence == "SUFFICIENT"
        assert feedback.success_rate == 1.0
        assert "preserve" in engine.recommendations()[0]
    finally:
        store.close()


def test_priority_band_is_not_recomputed_from_outcome():
    store = PriorityLearningStore()
    engine = PriorityFeedbackEngine(store)
    try:
        dec = decision("x", .9)
        engine.record_decision_outcome(dec, "failed")
        assert store.list()[0].band == PriorityBand.CRITICAL
        assert store.list()[0].score == dec.score
    finally:
        store.close()
