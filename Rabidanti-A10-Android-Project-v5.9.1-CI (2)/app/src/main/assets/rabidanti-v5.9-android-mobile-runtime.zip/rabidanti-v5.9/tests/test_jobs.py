
from backend.jobs import JobManager, JobPriority, JobState


def test_job_lifecycle_and_approval():
    manager = JobManager()

    job = manager.create(
        project_id="p1",
        agent="ads_agent",
        stage="ads",
        priority=JobPriority.HIGH,
        requires_approval=True,
    )
    assert job.state == JobState.WAITING_APPROVAL

    manager.approve(job.id)
    assert job.state == JobState.QUEUED

    result = manager.run(job.id, lambda: {"ok": True})
    assert result.state == JobState.COMPLETED
    assert result.result["ok"] is True


def test_failed_job_moves_to_retry_then_can_complete():
    manager = JobManager()
    job = manager.create(
        project_id="p1",
        agent="worker",
        stage="render",
        max_retries=2,
    )

    calls = {"n": 0}

    def flaky():
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("temporary failure")
        return "done"

    first = manager.run(job.id, flaky)
    assert first.state == JobState.RETRY
    assert first.retries == 1

    second = manager.retry(job.id, flaky)
    assert second.state == JobState.COMPLETED
    assert second.result == "done"


def test_max_retries_ends_in_failed():
    manager = JobManager()
    job = manager.create(
        project_id="p1",
        agent="worker",
        stage="test",
        max_retries=1,
    )

    def always_fails():
        raise RuntimeError("failure")

    first = manager.run(job.id, always_fails)
    assert first.state == JobState.RETRY

    second = manager.retry(job.id, always_fails)
    assert second.state == JobState.FAILED
    assert second.retries == 1
