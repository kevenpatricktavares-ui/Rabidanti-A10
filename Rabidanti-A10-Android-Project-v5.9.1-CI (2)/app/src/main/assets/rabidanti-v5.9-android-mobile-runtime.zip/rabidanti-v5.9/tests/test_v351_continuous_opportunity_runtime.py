import tempfile
from datetime import datetime, timezone, timedelta
from world_awareness import WorldAwareness, WorldAwarenessStore
from continuous_opportunity_runtime import ContinuousOpportunityRuntime, HANDLER
from continuous_worker_runner import ContinuousWorkerRunner
from durable_worker_queue import DurableWorkerQueue
from persistent_scheduler import PersistentScheduler

def seed(world):
    a=world.ingest_source(title='A',locator='u1',publisher='P',verified=True)
    b=world.ingest_source(title='B',locator='u2',publisher='Q',verified=True)
    world.add_signal(a.source_id,topic='Automation',statement='warehouse automation demand grows',confidence=.8)
    world.add_signal(b.source_id,topic='Automation',statement='warehouse automation adoption expands',confidence=.9)

def test_scheduled_scan_flows_scheduler_queue_worker():
    with tempfile.TemporaryDirectory() as d:
        world=WorldAwareness(WorldAwarenessStore(d+'/world.db')); seed(world)
        rt=ContinuousOpportunityRuntime(d+'/runtime.db',world=world)
        runner=ContinuousWorkerRunner(DurableWorkerQueue(d+'/queue.db'),max_workers=1,poll_interval=0)
        rt.attach_runner(runner)
        task=rt.schedule_scan(run_at=datetime.now(timezone.utc)-timedelta(seconds=1))
        queued=rt.enqueue_due(); assert len(queued)==1
        runner.run(max_ticks=5)
        records=rt.records.list(); assert len(records)==1 and records[0].topic=='Automation'
        runner.close()

def test_scan_is_deduplicated_across_repeated_runs():
    with tempfile.TemporaryDirectory() as d:
        world=WorldAwareness(WorldAwarenessStore(d+'/world.db')); seed(world)
        rt=ContinuousOpportunityRuntime(d+'/runtime.db',world=world)
        assert rt.scan_once()['themes_seen']==1
        assert rt.scan_once()['themes_seen']==1
        assert len(rt.records.list())==1

def test_restart_preserves_discovery_records():
    with tempfile.TemporaryDirectory() as d:
        world=WorldAwareness(WorldAwarenessStore(d+'/world.db')); seed(world)
        rt=ContinuousOpportunityRuntime(d+'/runtime.db',world=world); rt.scan_once()
        reopened=ContinuousOpportunityRuntime(d+'/runtime.db',world=world)
        assert len(reopened.records.list())==1
