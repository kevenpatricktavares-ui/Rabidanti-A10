from backend.persona import PersonaEngine
from backend.personality import PersonalityCore
from backend.authority import AuthorityState, AuthorityMode

def test_persona():
    p = PersonaEngine().build({
        "name": "Creator", "market": "Cabo Verde", "language": "pt-CV",
        "knowledge_level": "beginner", "preferred_formats": ["video"]
    })
    assert p.market == "Cabo Verde"
    assert PersonaEngine().adaptation_guide(p)["safety"]["no_discriminatory_targeting"]

def test_personality():
    core = PersonalityCore()
    core.add_interest("ciência")
    core.add_experience("experimento concluído")
    core.update_belief("velocidade", "validar antes de escalar", 0.8, ["exp-1"])
    assert len(core.snapshot()["beliefs"]) == 1

def test_reversible_autonomy():
    state = AuthorityState()
    assert state.mode == AuthorityMode.NORMAL
    state.grant_max_autonomy()
    assert state.is_max_autonomy
    state.revoke_autonomy()
    assert state.mode == AuthorityMode.NORMAL
