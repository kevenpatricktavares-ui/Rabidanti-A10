import tempfile
from world_awareness import WorldAwareness, WorldAwarenessStore
from world_opportunity import WorldOpportunityEngine, OpportunityWorldBridge


def build(d):
    world = WorldAwareness(WorldAwarenessStore(d + "/world.db"))
    return world, WorldOpportunityEngine(world), OpportunityWorldBridge(world)


def test_signal_becomes_bounded_opportunity_hypothesis():
    with tempfile.TemporaryDirectory() as d:
        world, engine, _ = build(d)
        src = world.ingest_source(
            title="Technology source", locator="https://example.test/a",
            publisher="Example", verified=True
        )
        sig = world.add_signal(
            src.source_id, topic="AI", statement="New capability", confidence=.9
        )
        c = engine.from_signal(sig.signal_id)
        assert c.status == "HYPOTHESIS"
        assert c.topic == "AI"
        assert c.evidence[0]["world_signal_id"] == sig.signal_id
        assert c.evidence[0]["verified"] is True
        assert "validated market opportunity" in " ".join(c.limitations)


def test_topic_candidates_are_bounded():
    with tempfile.TemporaryDirectory() as d:
        world, engine, _ = build(d)
        src = world.ingest_source(title="S", locator="u", publisher="P")
        for i in range(3):
            world.add_signal(src.source_id, topic="Robotics", statement=f"S{i}", confidence=.5)
        assert len(engine.from_topic("Robotics", limit=2)) == 2
        try:
            engine.from_topic("Robotics", limit=101)
            assert False
        except ValueError:
            pass


def test_missing_signal_rejected():
    with tempfile.TemporaryDirectory() as d:
        _, engine, _ = build(d)
        try:
            engine.from_signal("missing")
            assert False
        except KeyError:
            pass


def test_candidate_preserves_world_provenance():
    with tempfile.TemporaryDirectory() as d:
        world, engine, _ = build(d)
        src = world.ingest_source(title="S", locator="u", publisher="P", verified=False)
        sig = world.add_signal(src.source_id, topic="Energy", statement="Signal", confidence=.7)
        c = engine.from_signal(sig.signal_id)
        e = c.evidence[0]
        assert e["world_source_id"] == src.source_id
        assert e["publisher"] == "P"
        assert e["locator"] == "u"


def test_bridge_creates_existing_opportunity_contract_without_fabrication():
    with tempfile.TemporaryDirectory() as d:
        world, engine, bridge = build(d)
        src = world.ingest_source(title="S", locator="u", publisher="P", verified=True)
        sig = world.add_signal(src.source_id, topic="HealthTech", statement="Signal", confidence=.8)
        c = engine.from_signal(sig.signal_id)
        brief = bridge.score_candidate("p1", "Investigate HealthTech", c)
        assert brief.source_stage == "research"
        assert brief.evidence
        assert any("validated market opportunity" in x for x in brief.limitations)


def test_empty_topic_rejected():
    with tempfile.TemporaryDirectory() as d:
        _, engine, _ = build(d)
        try:
            engine.from_topic(" ", limit=1)
            assert False
        except ValueError:
            pass
