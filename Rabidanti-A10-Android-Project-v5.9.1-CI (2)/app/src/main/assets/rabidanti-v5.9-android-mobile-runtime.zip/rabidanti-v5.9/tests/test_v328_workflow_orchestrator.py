import tempfile, os
from durable_worker_queue import DurableWorkerQueue, QueueItemState
from workflow_engine import WorkflowNode
from workflow_orchestrator import PersistentWorkflowOrchestrator, WorkflowState

def setup():
    d=tempfile.mkdtemp(); q=DurableWorkerQueue(os.path.join(d,'q.db')); o=PersistentWorkflowOrchestrator(os.path.join(d,'w.db'),q); return d,q,o

def test_create_start_progress_and_complete():
    d,q,o=setup(); r=o.create('demo',[WorkflowNode('a'),WorkflowNode('b',('a',))]); assert r.state==WorkflowState.DRAFT
    o.start(r.workflow_id); p=o.progress(r.workflow_id); assert p.total==2 and p.queued==2 and p.blocked==1
    a=q.get_by_task_id('a'); q.claim(a.item_id,'w'); q.complete(a.item_id,'w','ok'); o.refresh(r.workflow_id)
    b=q.get_by_task_id('b'); q.claim(b.item_id,'w'); q.complete(b.item_id,'w','ok')
    p=o.progress(r.workflow_id); assert p.state==WorkflowState.COMPLETED and p.percent==100

def test_persistence_after_restart():
    d,q,o=setup(); r=o.create('persist',[WorkflowNode('a'),WorkflowNode('b',('a',))]); o.start(r.workflow_id); oid=r.workflow_id; q.close(); o.close()
    q2=DurableWorkerQueue(os.path.join(d,'q.db')); o2=PersistentWorkflowOrchestrator(os.path.join(d,'w.db'),q2); rr=o2.get(oid); assert rr.task_ids==('a','b') and rr.state==WorkflowState.RUNNING

def test_recover_and_resume():
    d,q,o=setup(); r=o.create('resume',[WorkflowNode('a')]); o.start(r.workflow_id); a=q.get_by_task_id('a'); q.claim(a.item_id,'dead'); q.coordinator._conn.execute("UPDATE worker_leases SET lease_until=0 WHERE task_id=?",('a',)); q.recover_expired(); rr=o.recover_and_resume(r.workflow_id); assert rr.state==WorkflowState.RUNNING; assert q.get_by_task_id('a').state==QueueItemState.QUEUED

def test_cancel_cancels_queue_tasks():
    d,q,o=setup(); r=o.create('cancel',[WorkflowNode('a'),WorkflowNode('b')]); o.start(r.workflow_id); rr=o.cancel(r.workflow_id); assert rr.state==WorkflowState.CANCELLED; assert all(q.get_by_task_id(t).state==QueueItemState.CANCELLED for t in r.task_ids)

def test_failed_workflow():
    d,q,o=setup(); r=o.create('fail',[WorkflowNode('a')],max_attempts=1); o.start(r.workflow_id); a=q.get_by_task_id('a'); q.claim(a.item_id,'w'); q.fail(a.item_id,'w','boom'); rr=o.refresh(r.workflow_id); assert rr.state==WorkflowState.FAILED and rr.error=='boom'
