import os, tempfile
from business_pipeline import BusinessPipelineSpec, STAGES, build_business_pipeline
from core_orchestrator import CoreOrchestrator
from durable_worker_queue import DurableWorkerQueue
from workflow_orchestrator import PersistentWorkflowOrchestrator, WorkflowState


def setup():
    d = tempfile.mkdtemp()
    q = DurableWorkerQueue(os.path.join(d, "q.db"))
    w = PersistentWorkflowOrchestrator(os.path.join(d, "w.db"), q)
    return q, w, CoreOrchestrator(w)


def test_pipeline_has_canonical_stages_and_dependencies():
    nodes, payloads = build_business_pipeline(BusinessPipelineSpec("x", "p1", "make product", {"market":"CV"}))
    assert tuple(n.task_id for n in nodes) == STAGES
    assert nodes[1].dependencies == ("research",)
    assert nodes[6].dependencies == ("product", "review")
    assert nodes[-1].dependencies == ("analytics",)
    assert payloads["research"]["project_id"] == "p1"


def test_core_creates_real_business_pipeline_workflow():
    q, w, core = setup()
    r = core.create_business_pipeline(BusinessPipelineSpec("Business", "p1", "launch product", {"market":"CV"}))
    assert r.metadata["pipeline"] == "business"
    assert len(r.task_ids) == 13
    assert core.start(r.workflow_id).state == WorkflowState.RUNNING
    assert core.status(r.workflow_id)["total"] == 13


def test_pipeline_parallelism_is_exposed_by_dag():
    q, w, core = setup()
    r = core.create_business_pipeline(BusinessPipelineSpec("Business", "p1", "launch", {}))
    core.start(r.workflow_id)
    batches = w.engine.parallel_batches(r.task_ids)
    assert batches[0] == ("research",)
    assert "brand" in batches[5] and "render" in batches[5]
    assert batches[-1] == ("learning",)
