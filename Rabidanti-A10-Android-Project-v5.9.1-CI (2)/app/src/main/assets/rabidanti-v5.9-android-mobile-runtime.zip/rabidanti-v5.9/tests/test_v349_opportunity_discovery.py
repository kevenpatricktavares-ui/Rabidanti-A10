import tempfile
from world_awareness import WorldAwareness, WorldAwarenessStore
from opportunity_discovery import OpportunityDiscoveryEngine

def build(d):
    w=WorldAwareness(WorldAwarenessStore(d+"/world.db")); return w, OpportunityDiscoveryEngine(w)

def test_repeated_related_signals_form_theme():
    with tempfile.TemporaryDirectory() as d:
        w,e=build(d); s1=w.ingest_source(title='A',locator='u1',publisher='P',verified=True); s2=w.ingest_source(title='B',locator='u2',publisher='Q',verified=True)
        w.add_signal(s1.source_id,topic='Robotics',statement='robots automate warehouse tasks',confidence=.8)
        w.add_signal(s2.source_id,topic='Robotics',statement='warehouse robots improve task automation',confidence=.9)
        t=e.discover(topic='Robotics',min_signals=2)[0]
        assert t.signal_count==2 and t.verified_source_count==2 and t.relatedness>0
        assert t.status=='CANDIDATE_THEME'

def test_unrelated_signals_can_be_filtered():
    with tempfile.TemporaryDirectory() as d:
        w,e=build(d); s=w.ingest_source(title='S',locator='u',publisher='P')
        w.add_signal(s.source_id,topic='Energy',statement='solar batteries storage',confidence=.5)
        w.add_signal(s.source_id,topic='Energy',statement='marine insurance claims',confidence=.5)
        assert e.discover(topic='Energy',min_signals=2,min_relatedness=.5)==[]

def test_no_fabricated_market_claims():
    with tempfile.TemporaryDirectory() as d:
        w,e=build(d); s=w.ingest_source(title='S',locator='u',publisher='P'); w.add_signal(s.source_id,topic='AI',statement='AI signal',confidence=.7)
        w.add_signal(s.source_id,topic='AI',statement='AI signal again',confidence=.8)
        t=e.discover(topic='AI')[0]
        assert any('not a validated market opportunity' in x for x in t.limitations)

def test_bounds():
    with tempfile.TemporaryDirectory() as d:
        w,e=build(d)
        for args in ({'limit':0},{'min_signals':0},{'min_relatedness':2}):
            try: e.discover(**args); assert False
            except ValueError: pass
