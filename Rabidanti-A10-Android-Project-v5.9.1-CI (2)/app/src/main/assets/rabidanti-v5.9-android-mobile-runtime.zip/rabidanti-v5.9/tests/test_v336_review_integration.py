import tempfile
from pathlib import Path
from stage_artifact_store import StageArtifactStore
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_review

def test_review_consumes_content_artifact():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        store.put('p1', 'content', {'title':'Budget Mastery','audience':'beginners','format':'course_curriculum','outline':['a','b','c'], 'limitations':['review required']})
        reg = BusinessStageRegistry(store)
        register_builtin_review(reg)
        out = reg.get('review')(StageExecutionContext('p1','review','review budgeting',{},'3.36'))
        assert out['status'] == 'PASS'
        assert out['score'] == 100
        assert out['source_stage'] == 'content'

def test_review_blocks_missing_structure():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        store.put('p1', 'content', {'title':'Budget Mastery','audience':'beginners','format':'course_curriculum','outline':['a']})
        reg = BusinessStageRegistry(store)
        register_builtin_review(reg)
        out = reg.get('review')(StageExecutionContext('p1','review','review',{},'3.36'))
        assert out['status'] == 'BLOCKED'
        assert out['blockers']

def test_review_requires_content_artifact():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        reg = BusinessStageRegistry(store)
        register_builtin_review(reg)
        try:
            reg.get('review')(StageExecutionContext('missing','review','x',{},'3.36'))
            assert False
        except RuntimeError as e:
            assert 'content artifact missing' in str(e)
