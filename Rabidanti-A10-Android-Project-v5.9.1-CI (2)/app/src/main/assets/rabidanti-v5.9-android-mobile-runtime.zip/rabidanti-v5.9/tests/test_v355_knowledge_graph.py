import pytest
from knowledge_graph import KnowledgeGraphStore, WorldKnowledgeGraph, RelationStatus

def test_entities_and_relations_persist_and_traverse():
    s=KnowledgeGraphStore(':memory:'); g=WorldKnowledgeGraph(s)
    a=g.add_entity(name='AI', entity_type='technology')
    b=g.add_entity(name='Laboratory', entity_type='system')
    r=g.add_relation(subject_id=a.entity_id,predicate='used_by',object_id=b.entity_id,status=RelationStatus.SUPPORTED,confidence=.8,source_id='src-1',claim_id='claim-1')
    assert s.relation(r.relation_id).status is RelationStatus.SUPPORTED
    n=g.neighbors(a.entity_id)
    assert n[0]['entity']['name']=='Laboratory'
    assert n[0]['relation']['source_id']=='src-1'

def test_missing_entity_is_rejected():
    g=WorldKnowledgeGraph(KnowledgeGraphStore(':memory:'))
    a=g.add_entity(name='A',entity_type='x')
    with pytest.raises(KeyError): g.add_relation(subject_id=a.entity_id,predicate='rel',object_id='missing')

def test_confidence_is_bounded():
    s=KnowledgeGraphStore(':memory:'); g=WorldKnowledgeGraph(s)
    a=g.add_entity(name='A',entity_type='x'); b=g.add_entity(name='B',entity_type='x')
    with pytest.raises(ValueError): g.add_relation(subject_id=a.entity_id,predicate='rel',object_id=b.entity_id,confidence=1.1)

def test_relation_status_does_not_change_truth_implicitly():
    s=KnowledgeGraphStore(':memory:'); g=WorldKnowledgeGraph(s)
    a=g.add_entity(name='A',entity_type='x'); b=g.add_entity(name='B',entity_type='x')
    r=g.add_relation(subject_id=a.entity_id,predicate='related_to',object_id=b.entity_id)
    assert r.status is RelationStatus.PROPOSED and r.confidence == 0

def test_predicate_filter():
    s=KnowledgeGraphStore(':memory:'); g=WorldKnowledgeGraph(s)
    a=g.add_entity(name='A',entity_type='x'); b=g.add_entity(name='B',entity_type='x'); c=g.add_entity(name='C',entity_type='x')
    g.add_relation(subject_id=a.entity_id,predicate='uses',object_id=b.entity_id)
    g.add_relation(subject_id=a.entity_id,predicate='creates',object_id=c.entity_id)
    assert len(s.relations(a.entity_id,predicate='uses'))==1
    assert s.relations(a.entity_id,predicate='uses')[0].object_id==b.entity_id
