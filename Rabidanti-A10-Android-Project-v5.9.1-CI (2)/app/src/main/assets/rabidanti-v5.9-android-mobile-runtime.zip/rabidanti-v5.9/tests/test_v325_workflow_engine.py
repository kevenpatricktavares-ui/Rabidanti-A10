import tempfile
from pathlib import Path
import pytest
from durable_worker_queue import DurableWorkerQueue
from workflow_engine import WorkflowEngine, WorkflowNode, WorkflowCycleError

def make():
    d=tempfile.TemporaryDirectory(); q=DurableWorkerQueue(str(Path(d.name)/'db.sqlite')); return d,q

def test_validate_rejects_cycle():
    with pytest.raises(WorkflowCycleError):
        WorkflowEngine.validate([WorkflowNode('A',('B',)),WorkflowNode('B',('A',))])

def test_register_and_plan_dag():
    d,q=make()
    try:
        e=WorkflowEngine(q)
        e.register([WorkflowNode('A'),WorkflowNode('B',('A',)),WorkflowNode('C',('A',),priority=5)],
                   {'A':{'handler':'a'}})
        p=e.plan()
        assert p.ready_task_ids==('A',)
        assert set(p.blocked_task_ids)=={'B','C'}
    finally: q.close(); d.cleanup()

def test_completion_unlocks_children():
    d,q=make()
    try:
        e=WorkflowEngine(q)
        e.register([WorkflowNode('A'),WorkflowNode('B',('A',))])
        q.claim(q.get_by_task_id('A').item_id,'w'); q.complete(q.get_by_task_id('A').item_id,'w','ok')
        assert e.plan().ready_task_ids==('B',)
    finally: q.close(); d.cleanup()

def test_missing_dependency_rejected():
    d,q=make()
    try:
        with pytest.raises(ValueError): WorkflowEngine(q).register([WorkflowNode('B',('missing',))])
    finally: q.close(); d.cleanup()
