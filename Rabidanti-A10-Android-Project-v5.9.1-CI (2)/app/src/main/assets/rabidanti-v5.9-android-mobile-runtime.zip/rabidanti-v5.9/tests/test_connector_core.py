
from backend.connectors import (
    Connector,
    ConnectorPermission,
    ConnectorRegistry,
    ConnectorState,
)


def test_registry_and_connection_lifecycle():
    registry = ConnectorRegistry()
    connector = Connector(
        id="analytics-demo",
        name="Analytics Demo",
        provider="demo",
        permissions=[ConnectorPermission.READ],
    )
    registry.register(connector)

    assert registry.get("analytics-demo") is connector
    assert connector.state == ConnectorState.DISCONNECTED

    connector.connect()
    assert connector.health()["healthy"] is True
    assert connector.capabilities() == ["READ"]

    connector.disconnect()
    assert connector.health()["healthy"] is False


def test_sensitive_action_requires_approval():
    connector = Connector(
        id="ads-demo",
        name="Ads Demo",
        provider="demo",
        permissions=[ConnectorPermission.PUBLISH, ConnectorPermission.SPEND],
    )
    connector.connect()

    blocked_publish = connector.authorize(ConnectorPermission.PUBLISH)
    blocked_spend = connector.authorize(ConnectorPermission.SPEND)

    assert blocked_publish["allowed"] is False
    assert blocked_spend["allowed"] is False

    assert connector.authorize(
        ConnectorPermission.PUBLISH, approval_granted=True
    )["allowed"] is True


def test_missing_permission_and_disconnected_connector_are_blocked():
    connector = Connector(
        id="storage-demo",
        name="Storage Demo",
        provider="demo",
        permissions=[ConnectorPermission.READ],
    )

    assert connector.authorize(ConnectorPermission.DELETE)["allowed"] is False
    assert connector.authorize(ConnectorPermission.READ)["allowed"] is False

    connector.connect()
    assert connector.authorize(ConnectorPermission.READ)["allowed"] is True
