from backend.approvals.approval_center import ApprovalCenter
from backend.connectors.core import Connector, ConnectorPermission, ConnectorState
from backend.dashboard.dashboard_service import DashboardService
from backend.jobs.job_manager import JobManager, JobState


def build_service():
    jobs = JobManager()
    approvals = ApprovalCenter(jobs)
    connector = Connector(
        id="ads-1",
        name="Advertising Connector",
        provider="demo",
        permissions=[ConnectorPermission.READ, ConnectorPermission.PUBLISH],
    )
    dashboard = DashboardService(jobs, [connector], approvals)
    return jobs, approvals, connector, dashboard


def test_dashboard_aggregates_jobs_connectors_and_pending_approval():
    jobs, approvals, connector, dashboard = build_service()
    waiting = jobs.create("p1", "ads_agent", "ads", requires_approval=True)
    jobs.create("p2", "research_agent", "research")

    snapshot = dashboard.snapshot("p1")

    assert snapshot["project_id"] == "p1"
    assert snapshot["job_counts"][JobState.WAITING_APPROVAL.value] == 1
    assert snapshot["pending_approvals"][0]["id"] == waiting.id
    assert snapshot["connectors"][0]["state"] == ConnectorState.DISCONNECTED.value


def test_approval_does_not_grant_connector_permission():
    jobs, approvals, connector, dashboard = build_service()
    job = jobs.create("p1", "ads_agent", "ads", requires_approval=True)

    approvals.approve(job.id, "approved for this test")

    assert job.state == JobState.QUEUED
    assert ConnectorPermission.SPEND not in connector.permissions
    assert connector.authorize(ConnectorPermission.PUBLISH)["allowed"] is False


def test_rejection_and_project_scoping():
    jobs, approvals, connector, dashboard = build_service()
    rejected = jobs.create("p1", "ads_agent", "ads", requires_approval=True)
    other = jobs.create("p2", "ads_agent", "ads", requires_approval=True)

    approvals.reject(rejected.id, "not authorized")
    snapshot = dashboard.snapshot("p2")

    assert rejected.state == JobState.FAILED
    assert snapshot["pending_approvals"][0]["id"] == other.id
