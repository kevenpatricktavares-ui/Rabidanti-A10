
from backend.interactive.interactive_product_factory import InteractiveProductFactory


def test_calculator_with_integrations():
    f = InteractiveProductFactory()
    brief = f.build(
        "Savings Planner", "calculator", "learners",
        "Estimate a savings target.", "Produce an illustrative plan.",
        [{"name": "monthly_amount", "type": "number"},
         {"name": "months", "type": "integer"}],
        [{"name": "estimated_total", "type": "number"}],
        [{"description": "Multiply amount by months.",
          "formula": "monthly_amount * months"}],
        persona_context={"market": "general", "language": "en"},
        character_context={"name": "Rabi", "role": "teacher"},
        audiovisual_hook={"type": "demo"},
    )
    result = f.validate(brief)
    assert result["valid"] is True
    assert result["requires_human_review"] is True
    assert result["ready_for_external_publication"] is False


def test_missing_logic_is_invalid():
    f = InteractiveProductFactory()
    brief = f.build(
        "Tool", "calculator", "learners", "Problem", "Objective",
        [{"name": "x"}], [{"name": "y"}], []
    )
    result = f.validate(brief)
    assert result["valid"] is False
    assert "at least one rule/formula/logic definition is required" in result["errors"]


def test_unknown_type_is_invalid():
    f = InteractiveProductFactory()
    brief = f.build(
        "Tool", "unknown", "learners", "Problem", "Objective",
        [{"name": "x"}], [{"name": "y"}], [{"description": "transform x"}]
    )
    result = f.validate(brief)
    assert result["valid"] is False
    assert any("unsupported product_type" in e for e in result["errors"])
