import tempfile
from knowledge_graph import KnowledgeGraphStore, WorldKnowledgeGraph, RelationStatus
from knowledge_intelligence import KnowledgeIntelligenceStore, KnowledgeIntelligenceEngine
from laboratory import LaboratoryStore, LaboratoryEngine


def _graph(status=RelationStatus.VERIFIED, confidence=.9):
    g=WorldKnowledgeGraph(KnowledgeGraphStore(':memory:'))
    a=g.add_entity(name='Technology A', entity_type='technology')
    b=g.add_entity(name='System B', entity_type='system')
    r=g.add_relation(subject_id=a.entity_id,predicate='enables',object_id=b.entity_id,status=status,confidence=confidence,claim_id='c1',source_id='s1')
    return g,r


def test_verified_relationship_generates_lab_and_opportunity_hypotheses():
    g,r=_graph()
    e=KnowledgeIntelligenceEngine(g,KnowledgeIntelligenceStore(':memory:'))
    labs=e.generate_lab_investigations()
    opps=e.generate_opportunity_hypotheses()
    assert len(labs)==1 and labs[0].relation_id==r.relation_id
    assert len(opps)==1 and opps[0].kind=='OPPORTUNITY_HYPOTHESIS'
    assert 'not a validated discovery' in labs[0].limitations[0]


def test_low_confidence_relationship_is_not_promoted():
    g,_=_graph(confidence=.4)
    e=KnowledgeIntelligenceEngine(g,KnowledgeIntelligenceStore(':memory:'))
    assert e.generate_lab_investigations()==[]
    assert e.generate_opportunity_hypotheses()==[]


def test_contested_relationship_is_not_eligible():
    g,_=_graph(RelationStatus.CONTESTED,.95)
    e=KnowledgeIntelligenceEngine(g,KnowledgeIntelligenceStore(':memory:'))
    assert e.generate_lab_investigations()==[]


def test_lab_project_creation_is_persistent_and_idempotent():
    g,_=_graph()
    with tempfile.TemporaryDirectory() as d:
        labs=LaboratoryEngine(LaboratoryStore(d+'/lab.db'))
        e=KnowledgeIntelligenceEngine(g,KnowledgeIntelligenceStore(d+'/ki.db'))
        first=e.create_lab_projects(labs)
        second=e.create_lab_projects(labs)
        assert len(first)==1 and len(second)==1
        assert first[0].lab_id==second[0].lab_id
        assert labs.store.get(first[0].lab_id).status=='INVESTIGAÇÃO'


def test_generation_is_idempotent_per_relation():
    g,r=_graph()
    e=KnowledgeIntelligenceEngine(g,KnowledgeIntelligenceStore(':memory:'))
    a=e.generate_opportunity_hypotheses(); b=e.generate_opportunity_hypotheses()
    assert a[0].candidate_id==b[0].candidate_id
    assert b[0].relation_id==r.relation_id
