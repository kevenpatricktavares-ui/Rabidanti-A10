import os, tempfile, time
from observability import ObservabilityStore
from worker_supervisor import WorkerSupervisor
from health_monitor import HealthMonitor


def test_failure_rate_alert_and_persistence_event():
    fd, path = tempfile.mkstemp(); os.close(fd)
    try:
        o = ObservabilityStore(path)
        for i in range(3): o.event('job_failed', item_id=f'f{i}')
        o.event('job_completed', item_id='ok')
        m = HealthMonitor(o, failure_window=10, failure_rate_threshold=0.5)
        r = m.check_and_record()
        assert not r.healthy
        assert r.alerts[0].kind == 'HIGH_FAILURE_RATE'
        assert o.summary()['events'] == 5
        o.close()
    finally: os.unlink(path)


def test_stale_worker_alert():
    o = ObservabilityStore(':memory:')
    s = WorkerSupervisor(':memory:', stale_after=0.1)
    s.register('w1', 1); s.set_status('w1', s.get('w1').status.RUNNING)
    rec = s.get('w1')
    s._conn.execute('UPDATE workers SET last_heartbeat=? WHERE worker_id=?', (time.time()-1, 'w1'))
    r = HealthMonitor(o, s).analyze()
    assert not r.healthy
    assert any(a.kind == 'STALE_WORKERS' for a in r.alerts)
    o.close(); s.close()


def test_healthy_report_without_terminal_events():
    o = ObservabilityStore(':memory:')
    r = HealthMonitor(o).analyze()
    assert r.healthy and r.score == 100.0 and r.alerts == []
    o.close()
