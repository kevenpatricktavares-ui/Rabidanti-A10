import os
import tempfile
import unittest

from persistent_autonomous_runtime import (
    PersistentAutonomousTaskRuntime,
    PersistentTaskPriority,
    PersistentTaskState,
)


class TestPersistentAutonomousRuntime(unittest.TestCase):
    def test_task_survives_restart(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "tasks.db")
            r1 = PersistentAutonomousTaskRuntime(db)
            t = r1.add("research", priority=PersistentTaskPriority.HIGH)
            r1.close()

            r2 = PersistentAutonomousTaskRuntime(db)
            restored = r2.get(t.task_id)
            self.assertIsNotNone(restored)
            self.assertEqual(restored.name, "research")
            self.assertEqual(restored.priority, PersistentTaskPriority.HIGH)
            r2.close()

    def test_dependencies_survive_restart(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "tasks.db")
            r = PersistentAutonomousTaskRuntime(db)
            a = r.add("A")
            b = r.add("B", dependencies=[a.task_id])
            self.assertEqual([x.task_id for x in r.ready()], [a.task_id])
            r.claim(a.task_id, "w1")
            r.complete(a.task_id, "w1", {"ok": True})
            self.assertEqual([x.task_id for x in r.ready()], [b.task_id])
            r.close()

            r2 = PersistentAutonomousTaskRuntime(db)
            self.assertEqual([x.task_id for x in r2.ready()], [b.task_id])
            r2.close()

    def test_owner_and_retry_persist(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "tasks.db")
            r = PersistentAutonomousTaskRuntime(db)
            t = r.add("unstable", max_attempts=2)
            claimed = r.claim(t.task_id, "worker-1")
            self.assertEqual(claimed.attempts, 1)
            r.close()

            r2 = PersistentAutonomousTaskRuntime(db)
            current = r2.get(t.task_id)
            self.assertEqual(current.owner, "worker-1")
            self.assertEqual(current.attempts, 1)
            r2.fail(t.task_id, "worker-1", "temporary")
            self.assertEqual(r2.get(t.task_id).state, PersistentTaskState.QUEUED)
            r2.close()

    def test_restart_recovers_running_task(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "tasks.db")
            r = PersistentAutonomousTaskRuntime(db)
            t = r.add("recover-me", max_attempts=3)
            r.claim(t.task_id, "old-worker")
            r.close()

            r2 = PersistentAutonomousTaskRuntime(db)
            recovered = r2.recover_running()
            self.assertEqual(len(recovered), 1)
            current = r2.get(t.task_id)
            self.assertEqual(current.state, PersistentTaskState.QUEUED)
            self.assertIsNone(current.owner)
            self.assertEqual(current.attempts, 1)
            r2.close()

    def test_cancel_persists_and_history_exists(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "tasks.db")
            r = PersistentAutonomousTaskRuntime(db)
            t = r.add("cancel-me")
            r.cancel(t.task_id, "not needed")
            r.close()

            r2 = PersistentAutonomousTaskRuntime(db)
            self.assertEqual(r2.get(t.task_id).state, PersistentTaskState.CANCELLED)
            events = [e["event"] for e in r2.history(t.task_id)]
            self.assertIn("ADDED", events)
            self.assertIn("CANCELLED", events)
            r2.close()

    def test_priority_order_is_persistent(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "tasks.db")
            r = PersistentAutonomousTaskRuntime(db)
            low = r.add("low", priority=PersistentTaskPriority.LOW)
            high = r.add("high", priority=PersistentTaskPriority.HIGH)
            critical = r.add("critical", priority=PersistentTaskPriority.CRITICAL)
            r.close()

            r2 = PersistentAutonomousTaskRuntime(db)
            self.assertEqual(
                [x.task_id for x in r2.runnable()],
                [critical.task_id, high.task_id, low.task_id],
            )
            r2.close()


if __name__ == "__main__":
    unittest.main()
