import tempfile
from world_awareness import WorldAwareness, WorldAwarenessStore
from laboratory import LaboratoryEngine, LaboratoryStore
from laboratory_intelligence import LaboratoryIntelligenceStore, LaboratoryIntelligence
from world_lab_integration import WorldLaboratoryBridge


def build(d):
    world=WorldAwareness(WorldAwarenessStore(d+'/world.db'))
    lab=LaboratoryEngine(LaboratoryStore(d+'/lab.db'))
    intel=LaboratoryIntelligence(lab,LaboratoryIntelligenceStore(d+'/intel.db'))
    return world, lab, intel, WorldLaboratoryBridge(world,lab,intel)


def test_world_signal_creates_traceable_lab_investigation():
    with tempfile.TemporaryDirectory() as d:
        world, lab, intel, bridge=build(d)
        src=world.ingest_source(title='Tech source',locator='https://example.test/x',publisher='Example',verified=True,summary='Summary')
        sig=world.add_signal(src.source_id,topic='AI',statement='New capability signal',confidence=.9)
        p=bridge.create_investigation_from_signal(sig.signal_id)
        assert p.status=='INVESTIGAÇÃO'
        assert p.evidence[0]['world_signal_id']==sig.signal_id
        snap=bridge.snapshot(p.lab_id)
        assert snap['world_provenance'][0]['world_source_id']==src.source_id
        assert snap['world_provenance'][0]['verified'] is True


def test_topic_bridge_is_bounded():
    with tempfile.TemporaryDirectory() as d:
        world, lab, intel, bridge=build(d)
        src=world.ingest_source(title='S',locator='u',publisher='P')
        world.add_signal(src.source_id,topic='AI',statement='A',confidence=.5)
        assert len(bridge.create_investigations_from_topic('AI',limit=1))==1
        try:
            bridge.create_investigations_from_topic('AI',limit=101)
            assert False
        except ValueError:
            pass


def test_missing_world_signal_rejected():
    with tempfile.TemporaryDirectory() as d:
        world, lab, intel, bridge=build(d)
        try:
            bridge.create_investigation_from_signal('missing')
            assert False
        except KeyError:
            pass
