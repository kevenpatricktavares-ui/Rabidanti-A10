import pytest
from backend.evolution_controller import EvolutionController,EvolutionState

def test_full_cycle():
 c=EvolutionController(); r=c.create('e1','s'); c.start_experiment('e1','x'); c.mark_promotion_pending('e1','p'); c.request_activation('e1')
 with pytest.raises(PermissionError): c.activate('e1','v2')
 c.activate('e1','v2',approval=True); c.begin_health_review('e1','degraded'); c.recommend_rollback('e1','v1'); c.apply_rollback('e1',approval=True)
 assert r.state is EvolutionState.ROLLED_BACK and r.active_version=='v1' and len(r.history)>=8

def test_activation_requires_approval():
 c=EvolutionController(); c.create('e1','s'); c.start_experiment('e1','x'); c.mark_promotion_pending('e1','p'); c.request_activation('e1')
 with pytest.raises(PermissionError): c.activate('e1','v2')
 assert c.get('e1').state is EvolutionState.ACTIVATION_PENDING

def test_rollback_requires_approval_and_target():
 c=EvolutionController(); c.create('e1','s'); c.start_experiment('e1','x'); c.mark_promotion_pending('e1','p'); c.request_activation('e1'); c.activate('e1','v2',True); c.begin_health_review('e1','bad'); c.recommend_rollback('e1','v1')
 with pytest.raises(PermissionError): c.apply_rollback('e1')
 assert c.get('e1').state is EvolutionState.ROLLBACK_RECOMMENDED

def test_invalid_transition():
 c=EvolutionController(); c.create('e1','s')
 with pytest.raises(ValueError): c.begin_health_review('e1','ok')

def test_ids_and_history():
 c=EvolutionController()
 with pytest.raises(ValueError): c.create('','s')
 with pytest.raises(ValueError): c.create('e1','')
 c.create('e1','s')
 with pytest.raises(ValueError): c.create('e1','s2')
 c.start_experiment('e1','x'); assert c.get('e1').history[-1]['state']=='EXPERIMENTING'
