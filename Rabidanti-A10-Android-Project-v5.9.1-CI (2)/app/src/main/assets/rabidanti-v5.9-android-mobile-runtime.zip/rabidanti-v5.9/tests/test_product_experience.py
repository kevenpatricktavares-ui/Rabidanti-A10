
from backend.product_integration import ProductExperienceIntegrator


def test_full_specialized_product_integration():
    integrator = ProductExperienceIntegrator()
    experience = integrator.build(
        product_name="Learning Planner",
        product_type="interactive_educational_tool",
        persona={"market": "general", "language": "pt"},
        character={"name": "Rabi", "role": "teacher", "disclosure": "virtual character"},
        audiovisual={"format": "course_lesson", "scenes": [{"number": 1}]},
        interactive={
            "inputs": [{"name": "goal"}],
            "outputs": [{"name": "plan"}],
        },
    )

    result = integrator.validate(experience)

    assert result["valid"] is True
    assert "persona_adaptation" in experience.experience_flow
    assert "character_consistency" in experience.experience_flow
    assert "interactive_experience" in experience.experience_flow
    assert "audiovisual_explanation" in experience.experience_flow
    assert result["requires_human_review"] is True
    assert result["ready_for_external_publication"] is False


def test_character_without_name_fails():
    integrator = ProductExperienceIntegrator()
    experience = integrator.build(
        product_name="Tool",
        product_type="educational_tool",
        character={"role": "teacher", "disclosure": "virtual"},
    )
    result = integrator.validate(experience)

    assert result["valid"] is False
    assert "character integration requires a name" in result["errors"]


def test_empty_experience_identifies_required_fields():
    integrator = ProductExperienceIntegrator()
    experience = integrator.build("", "")
    result = integrator.validate(experience)

    assert result["valid"] is False
    assert "product_name is required" in result["errors"]
    assert "product_type is required" in result["errors"]
