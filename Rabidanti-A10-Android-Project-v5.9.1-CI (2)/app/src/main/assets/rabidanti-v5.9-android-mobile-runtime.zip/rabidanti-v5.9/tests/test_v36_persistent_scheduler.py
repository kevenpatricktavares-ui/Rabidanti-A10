
from datetime import datetime, timezone
from persistent_scheduler import PersistentScheduler, PersistentSchedulerLoop

def test_schedule_survives_new_instance(tmp_path):
    db=str(tmp_path/"scheduler.db")
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(db,lambda: now)
    s.add("daily",now,60)
    s2=PersistentScheduler(db,lambda: now)
    assert [x.task_id for x in s2.due(now)]==["daily"]

def test_restart_does_not_duplicate_after_ack(tmp_path):
    db=str(tmp_path/"scheduler.db")
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(db,lambda: now)
    s.add("once",now)
    seen=[]
    PersistentSchedulerLoop(s,lambda tid: seen.append(tid)).tick(now)
    s2=PersistentScheduler(db,lambda: now)
    PersistentSchedulerLoop(s2,lambda tid: seen.append(tid)).tick(now)
    assert seen==["once"]

def test_recurring_schedule_persists_next_run(tmp_path):
    db=str(tmp_path/"scheduler.db")
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(db,lambda: now)
    s.add("repeat",now,60)
    PersistentSchedulerLoop(s,lambda tid: tid).tick(now)
    s2=PersistentScheduler(db,lambda: now)
    assert s2.due(now)==[]
    assert len(s2.list())==1
    assert s2.list()[0].runs==1

def test_enqueue_failure_does_not_consume_schedule(tmp_path):
    db=str(tmp_path/"scheduler.db")
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(db,lambda: now)
    s.add("fragile",now)
    def fail(_): raise RuntimeError("queue unavailable")
    try:
        PersistentSchedulerLoop(s,fail).tick(now)
    except RuntimeError:
        pass
    else:
        assert False
    assert len(s.due(now))==1
