import pytest
from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate, PriorityBand


def test_score_is_deterministic_and_bounded():
    c = PriorityCandidate("a", "lab", novelty=.9, confidence=.9, relevance=.8, impact=.9, urgency=.7, knowledge_gap=.8, investigation_cost=.2)
    a = IntelligencePrioritizer().score(c)
    b = IntelligencePrioritizer().score(c)
    assert a == b
    assert 0 <= a.score <= 1
    assert a.band == PriorityBand.HIGH


def test_cost_reduces_priority():
    p = IntelligencePrioritizer()
    cheap = p.score(PriorityCandidate("cheap", "lab", .8,.8,.8,.8,.8,.8,.1))
    expensive = p.score(PriorityCandidate("expensive", "lab", .8,.8,.8,.8,.8,.8,.9))
    assert cheap.score > expensive.score


def test_rank_is_descending_with_deterministic_tie_break():
    p = IntelligencePrioritizer()
    cs = [
        PriorityCandidate("b", "opportunity", relevance=.5, confidence=.5),
        PriorityCandidate("a", "lab", relevance=.5, confidence=.5),
        PriorityCandidate("c", "lab", relevance=.9, confidence=.9),
    ]
    result = p.rank(cs)
    assert [x.candidate_id for x in result] == ["c", "a", "b"]


def test_limit_and_validation():
    p = IntelligencePrioritizer()
    cs = [PriorityCandidate(str(i), "lab") for i in range(3)]
    assert len(p.rank(cs, limit=2)) == 2
    with pytest.raises(ValueError): p.rank(cs, limit=0)
    with pytest.raises(ValueError): p.score(PriorityCandidate("x", "lab", novelty=1.1))


def test_missing_identity_rejected():
    with pytest.raises(ValueError):
        IntelligencePrioritizer().score(PriorityCandidate("", "lab"))


def test_bands():
    p = IntelligencePrioritizer()
    assert p._band(.81) == PriorityBand.CRITICAL
    assert p._band(.61) == PriorityBand.HIGH
    assert p._band(.41) == PriorityBand.MEDIUM
    assert p._band(.39) == PriorityBand.LOW
