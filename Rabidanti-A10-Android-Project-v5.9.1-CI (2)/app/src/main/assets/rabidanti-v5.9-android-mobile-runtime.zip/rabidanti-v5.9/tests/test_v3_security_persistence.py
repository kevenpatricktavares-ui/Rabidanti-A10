import time

from backend.persistence import SQLiteStore
from backend.security import SessionManager, hash_password, verify_password


def test_password_hash_is_salted_and_verifies():
    encoded = hash_password("strong-password")
    assert encoded != hash_password("strong-password")
    assert verify_password("strong-password", encoded)
    assert not verify_password("wrong-password", encoded)


def test_sessions_expire_and_revoke():
    manager = SessionManager(ttl_seconds=1)
    session = manager.create("user-1")
    assert manager.validate(session.token).user_id == "user-1"
    assert manager.revoke(session.token)
    assert manager.validate(session.token) is None

    short = SessionManager(ttl_seconds=1)
    s2 = short.create("user-2")
    short._sessions[s2.token] = type(s2)(s2.token, s2.user_id, time.time() - 1)
    assert short.validate(s2.token) is None


def test_sqlite_store_persists_and_enforces_project_foreign_key(tmp_path):
    db = tmp_path / "rabidanti.db"
    store = SQLiteStore(str(db))
    store.execute(
        "INSERT INTO projects(id, owner_id, name, created_at) VALUES (?, ?, ?, ?)",
        ("p1", "u1", "Demo", "now"),
    )
    store.execute(
        "INSERT INTO jobs(id, project_id, agent, stage, priority, state, retries, max_retries, requires_approval, approval_granted, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        ("j1", "p1", "agent", "research", "NORMAL", "QUEUED", 0, 3, 0, 0, "now", "now"),
    )
    assert store.query("SELECT id FROM jobs WHERE project_id = ?", ("p1",))[0]["id"] == "j1"

    try:
        store.execute(
            "INSERT INTO jobs(id, project_id, agent, stage, priority, state, retries, max_retries, requires_approval, approval_granted, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("j2", "missing", "agent", "research", "NORMAL", "QUEUED", 0, 3, 0, 0, "now", "now"),
        )
    except Exception:
        pass
    else:
        raise AssertionError("foreign key constraint was not enforced")
