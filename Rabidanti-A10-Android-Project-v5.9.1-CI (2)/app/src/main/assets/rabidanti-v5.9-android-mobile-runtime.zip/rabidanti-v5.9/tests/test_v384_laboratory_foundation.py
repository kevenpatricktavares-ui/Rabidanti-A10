import pytest
from laboratory_foundation import LaboratoryFoundation, LabKind, LabStage

def project(lab,rid='p1'):
    return lab.create_project(rid,'Prototype a research tool',LabKind.SOFTWARE,'Test a capability')

def test_create_and_persist(tmp_path):
    db=str(tmp_path/'lab.sqlite'); lab=LaboratoryFoundation(db); project(lab)
    assert LaboratoryFoundation(db).get('p1').stage=='PROJECT'

def test_full_lifecycle_and_audit(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab)
    for stage,event in [(LabStage.RESEARCH,'e2'),(LabStage.HYPOTHESIS,'e3'),(LabStage.EXPERIMENT,'e4'),(LabStage.PROTOTYPE,'e5'),(LabStage.VALIDATION,'e6'),(LabStage.DISCOVERY,'e7')]:
        lab.transition('p1',stage,event_id=event,note='reviewed',evidence_refs=['source:1'],confidence=.9)
    assert lab.get('p1').stage=='DISCOVERY' and lab.get('p1').confidence==.9
    assert len(lab.list_events('p1'))==7

def test_invalid_transition_blocked(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab)
    with pytest.raises(ValueError,match='invalid transition'): lab.transition('p1',LabStage.DISCOVERY,event_id='bad')

def test_duplicate_project_id_blocked(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab)
    with pytest.raises(ValueError,match='duplicate'): project(lab)

def test_duplicate_event_id_blocked(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab); lab.transition('p1',LabStage.RESEARCH,event_id='same'); project(lab,'p2')
    with pytest.raises(ValueError,match='duplicate event_id'): lab.transition('p2',LabStage.RESEARCH,event_id='same')

def test_invalid_confidence_blocked(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab)
    with pytest.raises(ValueError,match='confidence'): lab.transition('p1',LabStage.RESEARCH,event_id='e2',confidence=1.5)

def test_evidence_refs_deduplicated(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab)
    assert lab.transition('p1',LabStage.RESEARCH,event_id='e2',evidence_refs=['a','a','b']).evidence_refs==('a','b')

def test_filtering(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite')); project(lab); lab.create_project('p2','Research a market',LabKind.DIGITAL_BUSINESS,'Market hypothesis')
    assert len(lab.list_records(kind=LabKind.SOFTWARE))==1 and len(lab.list_records(stage=LabStage.PROJECT))==2

def test_missing_record_raises(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite'))
    with pytest.raises(KeyError): lab.get('missing')

def test_missing_ids_rejected(tmp_path):
    lab=LaboratoryFoundation(str(tmp_path/'lab.sqlite'))
    with pytest.raises(ValueError): lab.create_project('','Title',LabKind.AI,'Summary')
    project(lab)
    with pytest.raises(ValueError): lab.transition('p1',LabStage.RESEARCH,event_id='')
