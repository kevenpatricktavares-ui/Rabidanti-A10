import tempfile
import time
import unittest

from worker_supervisor import WorkerSupervisor, WorkerStatus


class TestWorkerSupervisor(unittest.TestCase):
    def test_register_and_heartbeat_persist(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            s = WorkerSupervisor(f.name, stale_after=10)
            s.register("w1", 2, "local")
            r = s.heartbeat("w1", active=1)
            self.assertEqual(r.status, WorkerStatus.RUNNING)
            self.assertEqual(r.capacity, 2)
            self.assertEqual(r.active, 1)
            s.close()
            s2 = WorkerSupervisor(f.name, stale_after=10)
            r2 = s2.get("w1")
            self.assertEqual(r2.worker_id, "w1")
            self.assertEqual(r2.active, 1)
            s2.close()

    def test_active_cannot_exceed_capacity(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            s = WorkerSupervisor(f.name)
            s.register("w1", 2)
            with self.assertRaises(ValueError):
                s.heartbeat("w1", active=3)
            s.close()

    def test_stale_detection(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            s = WorkerSupervisor(f.name, stale_after=1)
            s.register("w1", 1)
            old = time.time() - 5
            s._conn.execute("UPDATE workers SET last_heartbeat=? WHERE worker_id=?", (old, "w1"))
            stale = s.stale(now=time.time())
            self.assertEqual([x.worker_id for x in stale], ["w1"])
            self.assertEqual(s.get("w1").status, WorkerStatus.STALE)
            s.close()

    def test_stopped_worker_not_marked_stale(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            s = WorkerSupervisor(f.name, stale_after=1)
            s.register("w1", 1)
            s.stop("w1")
            old = time.time() - 5
            s._conn.execute("UPDATE workers SET last_heartbeat=? WHERE worker_id=?", (old, "w1"))
            self.assertEqual(s.stale(), [])
            self.assertEqual(s.get("w1").status, WorkerStatus.STOPPED)
            s.close()

    def test_invalid_values(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            s = WorkerSupervisor(f.name)
            with self.assertRaises(ValueError):
                WorkerSupervisor(f.name, stale_after=0)
            with self.assertRaises(ValueError):
                s.register("w1", 0)
            s.close()

    def test_remove(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            s = WorkerSupervisor(f.name)
            s.register("w1", 1)
            s.remove("w1")
            with self.assertRaises(KeyError):
                s.get("w1")
            s.close()


if __name__ == "__main__":
    unittest.main()
