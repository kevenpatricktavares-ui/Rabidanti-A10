import os, tempfile
from core_orchestrator import CoreOrchestrator
from durable_worker_queue import DurableWorkerQueue, QueueItemState
from workflow_engine import WorkflowNode
from workflow_orchestrator import PersistentWorkflowOrchestrator, WorkflowState


def setup():
    d = tempfile.mkdtemp()
    q = DurableWorkerQueue(os.path.join(d, "q.db"))
    w = PersistentWorkflowOrchestrator(os.path.join(d, "w.db"), q)
    return d, q, w, CoreOrchestrator(w)


def test_core_creates_and_starts_workflow():
    d, q, w, core = setup()
    r = core.create_workflow("core-demo", [WorkflowNode("a"), WorkflowNode("b", ("a",))])
    assert r.metadata["created_by"] == "rabidanti-core"
    assert core.start(r.workflow_id).state == WorkflowState.RUNNING
    s = core.status(r.workflow_id)
    assert s["total"] == 2 and s["blocked"] == 1 and s["percent"] == 0.0


def test_core_tracks_completion():
    d, q, w, core = setup()
    r = core.create_workflow("complete", [WorkflowNode("a")])
    core.start(r.workflow_id)
    item = q.get_by_task_id("a")
    q.claim(item.item_id, "worker-1")
    q.complete(item.item_id, "worker-1", {"ok": True})
    assert core.status(r.workflow_id)["state"] == "COMPLETED"
    assert core.status(r.workflow_id)["percent"] == 100.0


def test_core_recovers_after_restart():
    d, q, w, core = setup()
    r = core.create_workflow("recover", [WorkflowNode("a")])
    core.start(r.workflow_id)
    q.close(); w.close()
    q2 = DurableWorkerQueue(os.path.join(d, "q.db"))
    w2 = PersistentWorkflowOrchestrator(os.path.join(d, "w.db"), q2)
    core2 = CoreOrchestrator(w2)
    assert core2.recover(r.workflow_id).state == WorkflowState.RUNNING


def test_core_cancel_is_authoritative():
    d, q, w, core = setup()
    r = core.create_workflow("cancel", [WorkflowNode("a"), WorkflowNode("b")])
    core.start(r.workflow_id)
    assert core.cancel(r.workflow_id).state == WorkflowState.CANCELLED
    assert all(q.get_by_task_id(t).state == QueueItemState.CANCELLED for t in r.task_ids)


def test_core_exposes_workflow_list():
    d, q, w, core = setup()
    r1 = core.create_workflow("one", [WorkflowNode("one")])
    r2 = core.create_workflow("two", [WorkflowNode("two")])
    assert [r.name for r in core.list_workflows()] == ["one", "two"]
