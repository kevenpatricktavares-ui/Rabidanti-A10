import os, tempfile, time, unittest
from durable_worker_queue import DurableWorkerQueue, QueueItemState

class TestDurableWorkerQueue(unittest.TestCase):
    def test_enqueue_survives_restart(self):
        with tempfile.TemporaryDirectory() as d:
            db=os.path.join(d,"q.db")
            q=DurableWorkerQueue(db)
            x=q.enqueue({"job":"research"}, priority=5)
            q.close()
            q2=DurableWorkerQueue(db)
            y=q2.get(x.item_id)
            self.assertEqual(y.payload, {"job":"research"})
            self.assertEqual(y.state, QueueItemState.QUEUED)
            q2.close()

    def test_priority_ready_order(self):
        with tempfile.TemporaryDirectory() as d:
            q=DurableWorkerQueue(os.path.join(d,"q.db"))
            a=q.enqueue("a",priority=1)
            b=q.enqueue("b",priority=10)
            self.assertEqual([x.item_id for x in q.ready()],[b.item_id,a.item_id])
            q.close()

    def test_only_one_worker_claims(self):
        with tempfile.TemporaryDirectory() as d:
            db=os.path.join(d,"q.db")
            a=DurableWorkerQueue(db)
            b=DurableWorkerQueue(db)
            x=a.enqueue("payload")
            self.assertIsNotNone(a.claim(x.item_id,"w1"))
            self.assertIsNone(b.claim(x.item_id,"w2"))
            a.close(); b.close()

    def test_complete_requires_owner(self):
        with tempfile.TemporaryDirectory() as d:
            q=DurableWorkerQueue(os.path.join(d,"q.db"))
            x=q.enqueue("payload")
            q.claim(x.item_id,"w1")
            with self.assertRaises(PermissionError):
                q.complete(x.item_id,"w2")
            y=q.complete(x.item_id,"w1",{"ok":True})
            self.assertEqual(y.state,QueueItemState.COMPLETED)
            self.assertEqual(y.result,{"ok":True})
            q.close()

    def test_failure_requeues_then_fails(self):
        with tempfile.TemporaryDirectory() as d:
            q=DurableWorkerQueue(os.path.join(d,"q.db"))
            x=q.enqueue("payload",max_attempts=2)
            q.claim(x.item_id,"w1")
            y=q.fail(x.item_id,"w1","temporary")
            self.assertEqual(y.state,QueueItemState.QUEUED)
            q.claim(x.item_id,"w2")
            z=q.fail(x.item_id,"w2","final")
            self.assertEqual(z.state,QueueItemState.FAILED)
            q.close()

    def test_expired_worker_is_recovered(self):
        with tempfile.TemporaryDirectory() as d:
            q=DurableWorkerQueue(os.path.join(d,"q.db"),lease_seconds=1)
            x=q.enqueue("payload",max_attempts=3)
            q.claim(x.item_id,"w1")
            time.sleep(1.1)
            self.assertEqual(q.recover_expired(),[x.item_id])
            self.assertEqual(q.get(x.item_id).state,QueueItemState.QUEUED)
            q.close()

    def test_heartbeat(self):
        with tempfile.TemporaryDirectory() as d:
            q=DurableWorkerQueue(os.path.join(d,"q.db"),lease_seconds=2)
            x=q.enqueue("payload")
            q.claim(x.item_id,"w1")
            lease=q.heartbeat(x.item_id,"w1")
            self.assertGreater(lease.lease_until,time.time())
            q.close()

    def test_cancel(self):
        with tempfile.TemporaryDirectory() as d:
            q=DurableWorkerQueue(os.path.join(d,"q.db"))
            x=q.enqueue("payload")
            y=q.cancel(x.item_id,"no longer needed")
            self.assertEqual(y.state,QueueItemState.CANCELLED)
            q.close()

if __name__=="__main__":
    unittest.main()
