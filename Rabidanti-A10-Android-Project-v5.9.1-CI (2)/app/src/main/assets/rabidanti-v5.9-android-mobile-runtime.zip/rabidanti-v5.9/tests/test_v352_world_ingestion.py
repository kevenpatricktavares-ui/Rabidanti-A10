import tempfile, time
from world_awareness import WorldAwareness, WorldAwarenessStore
from world_ingestion import WorldIntelligenceIngestion

def test_normalization_and_hash_are_stable():
    w=WorldIntelligenceIngestion(WorldAwareness(WorldAwarenessStore(':memory:')))
    assert w.normalize_text('  A\n   B  ') == 'A B'
    assert w.content_hash(' A\nB ') == w.content_hash('A B')

def test_duplicate_locator_is_not_inserted_twice():
    with tempfile.TemporaryDirectory() as d:
        aw=WorldAwareness(WorldAwarenessStore(d+'/x.db')); ing=WorldIntelligenceIngestion(aw)
        a=ing.ingest(title='A',locator='u',publisher='P',content='hello')
        b=ing.ingest(title='A changed',locator='u',publisher='P',content='different')
        assert a.created and not b.created and b.duplicate_of==a.source.source_id
        assert len(aw.store.sources())==1

def test_duplicate_content_hash_is_detected_across_locators():
    aw=WorldAwareness(WorldAwarenessStore(':memory:')); ing=WorldIntelligenceIngestion(aw)
    a=ing.ingest(title='A',locator='u1',publisher='P',content='same   text')
    b=ing.ingest(title='B',locator='u2',publisher='Q',content='same text')
    assert not b.created and b.duplicate_of==a.source.source_id

def test_verified_is_preserved_not_inferred():
    aw=WorldAwareness(WorldAwarenessStore(':memory:')); ing=WorldIntelligenceIngestion(aw)
    a=ing.ingest(title='A',locator='u',publisher='P',content='x',verified=False)
    assert a.source.verified is False

def test_batch_and_future_fetch_rejected():
    aw=WorldAwareness(WorldAwarenessStore(':memory:')); ing=WorldIntelligenceIngestion(aw)
    out=ing.ingest_many([{'title':'A','locator':'u1','publisher':'P'},{'title':'B','locator':'u2','publisher':'P'}])
    assert len(out)==2
    try:
        ing.ingest(title='X',locator='u3',publisher='P',fetched_at=time.time()+1000)
        assert False
    except ValueError:
        pass
