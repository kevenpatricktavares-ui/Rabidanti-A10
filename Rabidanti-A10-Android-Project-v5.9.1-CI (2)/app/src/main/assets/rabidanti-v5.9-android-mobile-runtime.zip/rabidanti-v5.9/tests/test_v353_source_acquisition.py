import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from source_acquisition import SourceAcquirer, SourceAcquisitionError

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        body=b'<html><head><title>Test Source</title></head><body>Hello world</body></html>'
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(body)
    def log_message(self,*a): pass

def server():
    s=HTTPServer(('127.0.0.1',0),H); t=threading.Thread(target=s.serve_forever,daemon=True); t.start(); return s

def test_fetch_records_integrity_and_text():
    s=server()
    try:
        r=SourceAcquirer(timeout_seconds=2,max_bytes=10000).fetch(f'http://127.0.0.1:{s.server_port}/')
        assert r.acquisition_ok and r.status_code == 200
        assert r.title == 'Test Source' and r.text == 'Hello world'
        assert len(r.content_hash) == 64 and r.content_length > 0
    finally: s.shutdown(); s.server_close()

def test_rejects_non_http():
    try: SourceAcquirer().fetch('file:///tmp/x')
    except SourceAcquisitionError: return
    assert False

def test_missing_host_fails_without_claiming_verification():
    r=SourceAcquirer(timeout_seconds=1).fetch('http://127.0.0.1:1/nope')
    assert not r.acquisition_ok and r.error
