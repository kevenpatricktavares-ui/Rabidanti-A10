import os, tempfile
from business_pipeline import BusinessPipelineSpec, build_business_pipeline, STAGES
from business_stage_execution import BusinessStageRegistry, StageExecutionResult
from durable_worker_queue import DurableWorkerQueue, QueueItemState
from continuous_worker_runner import ContinuousWorkerRunner


def test_pipeline_payloads_have_stable_stage_handlers():
    _, payloads = build_business_pipeline(BusinessPipelineSpec("x", "p1", "launch", {}))
    assert all(payloads[s]["handler"] == f"business.stage.{s}" for s in STAGES)


def test_registry_adapts_context_to_runner():
    d = tempfile.mkdtemp(); db = os.path.join(d, "q.db")
    q = DurableWorkerQueue(db, lease_seconds=5)
    runner = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0)
    reg = BusinessStageRegistry()
    seen = []
    reg.register("research", lambda ctx: seen.append((ctx.project_id, ctx.objective)) or {"ok": True})
    reg.attach_to_runner(runner)
    item = q.enqueue({"handler":"business.stage.research", "data": {
        "project_id":"p1", "stage":"research", "objective":"find opportunity",
        "context":{"market":"CV"}, "pipeline_version":"1.0"
    }}, task_id="research")
    runner.run(max_ticks=1)
    assert q.get(item.item_id).state == QueueItemState.COMPLETED
    assert seen == [("p1", "find opportunity")]
    runner.stop()


def test_unregistered_stage_fails_explicitly():
    reg = BusinessStageRegistry()
    try:
        reg.get("research")
    except KeyError as e:
        assert "research" in str(e)
    else:
        raise AssertionError("expected missing handler")
