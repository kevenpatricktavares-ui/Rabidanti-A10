import tempfile
import time
from pathlib import Path

from capacity_intelligence import CapacityIntelligence
from continuous_worker_runner import ContinuousWorkerRunner
from durable_worker_queue import DurableWorkerQueue
from resource_capacity import ResourceCapacityMonitor


def make():
    d = tempfile.TemporaryDirectory()
    q = DurableWorkerQueue(str(Path(d.name) / "db.sqlite"), lease_seconds=10)
    ci = CapacityIntelligence(ResourceCapacityMonitor(q))
    ci.observe(2, 0, now=time.time())
    return d, q, ci


def test_runner_uses_execution_planner_priority():
    d, q, ci = make()
    try:
        q.enqueue({"handler": "capture", "data": "low"}, priority=1, task_id="low")
        q.enqueue({"handler": "capture", "data": "high"}, priority=9, task_id="high")
        seen = []
        runner = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0, capacity_intelligence=ci)
        runner.register_handler("capture", lambda data: seen.append(data))
        runner.tick()
        runner.run(max_ticks=1)
        assert seen == ["high"]
        runner.close()
    finally:
        d.cleanup()


def test_runner_planner_does_not_mutate_queue_before_claim():
    d, q, ci = make()
    try:
        item = q.enqueue({"handler": "noop", "data": 1}, priority=5, task_id="one")
        runner = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0, capacity_intelligence=ci)
        runner.register_handler("noop", lambda data: data)
        assert q.get(item.item_id).state.value == "QUEUED"
        runner.close()
    finally:
        d.cleanup()
