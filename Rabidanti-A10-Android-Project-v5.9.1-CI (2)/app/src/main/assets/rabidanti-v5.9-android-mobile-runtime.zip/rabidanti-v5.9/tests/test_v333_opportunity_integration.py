import os, tempfile
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_research, register_builtin_opportunity
from stage_artifact_store import StageArtifactStore
from durable_worker_queue import DurableWorkerQueue, QueueItemState
from continuous_worker_runner import ContinuousWorkerRunner

def test_research_output_is_persisted_and_opportunity_consumes_it():
    d=tempfile.mkdtemp(); db=os.path.join(d,'q.db')
    store=StageArtifactStore(db); reg=BusinessStageRegistry(store)
    register_builtin_research(reg); register_builtin_opportunity(reg)
    research_ctx=StageExecutionContext('p1','research','planner',{'demand_signals':['people want simpler planning'],'pain_points':['planning is hard'],'market_gaps':['few simple tools'],'evidence':[{'source':'interviews'}]},'1.0')
    research=reg.get('research')(research_ctx)
    store.put('p1','research',research)
    result=reg.get('opportunity')(StageExecutionContext('p1','opportunity','planner',{},'1.0'))
    assert result['source_stage']=='research'
    assert result['score']>0
    assert result['evidence'][0]['source']=='interviews'

def test_missing_research_fails_explicitly():
    store=StageArtifactStore(':memory:'); reg=BusinessStageRegistry(store); register_builtin_opportunity(reg)
    try: reg.get('opportunity')(StageExecutionContext('p1','opportunity','x',{},'1.0'))
    except RuntimeError as e: assert 'research artifact missing' in str(e)
    else: raise AssertionError('expected missing research failure')

def test_runner_persists_research_result_for_next_stage():
    d=tempfile.mkdtemp(); db=os.path.join(d,'q.db'); store=StageArtifactStore(db)
    q=DurableWorkerQueue(db, lease_seconds=5); runner=ContinuousWorkerRunner(q,max_workers=1,poll_interval=0)
    reg=BusinessStageRegistry(store); register_builtin_research(reg); reg.attach_to_runner(runner)
    item=q.enqueue({'handler':'business.stage.research','data':{'project_id':'p1','stage':'research','objective':'find opportunity','context':{'demand_signals':['buyers want speed']},'pipeline_version':'1.0'}},task_id='research')
    runner.run(max_ticks=1); assert q.get(item.item_id).state==QueueItemState.COMPLETED
    saved=store.get('p1','research'); assert saved and saved['project_id']=='p1'; runner.stop()
