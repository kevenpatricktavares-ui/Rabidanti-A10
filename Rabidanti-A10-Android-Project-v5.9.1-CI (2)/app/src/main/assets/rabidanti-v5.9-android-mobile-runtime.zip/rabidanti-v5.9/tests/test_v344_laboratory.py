import tempfile
from laboratory import LaboratoryStore, LaboratoryEngine

def test_lab_lifecycle_and_discovery_alert():
    with tempfile.TemporaryDirectory() as d:
        s=LaboratoryStore(d+'/lab.db'); e=LaboratoryEngine(s)
        p=e.create('Teste azul','Pode existir uma aplicação nova?','AI','Combinar X e Y pode resolver Z')
        p=e.investigate(p.lab_id,[{'source':'paper-1','verified':True}],['Sinal inicial'])
        assert p.status=='INVESTIGAÇÃO'
        p=e.record_experiment(p.lab_id,findings=['Resultado reproduzido'],tested=True,reproducible=True,novelty=True,relevance=True,confidence=.91)
        assert p.status=='DESCOBERTA'
        alerts=s.open_alerts(); assert len(alerts)==1 and alerts[0]['priority']=='MAXIMUM'
        assert s.acknowledge_alert(alerts[0]['alert_id'])
        assert not s.open_alerts()

def test_lab_does_not_promote_without_all_criteria():
    with tempfile.TemporaryDirectory() as d:
        s=LaboratoryStore(d+'/lab.db'); e=LaboratoryEngine(s)
        p=e.create('Teste','Q','tech','H')
        p=e.record_experiment(p.lab_id,findings=['r'],tested=True,reproducible=True,novelty=False,relevance=True,confidence=.8)
        assert p.status=='RESULTADO_VALIDADO'
        assert s.open_alerts()==[]

def test_persistence_survives_new_store():
    with tempfile.TemporaryDirectory() as d:
        path=d+'/lab.db'; s=LaboratoryStore(path); e=LaboratoryEngine(s)
        p=e.create('Persistente','Q','science','H'); lid=p.lab_id
        del s
        s2=LaboratoryStore(path); assert s2.get(lid).title=='Persistente'
