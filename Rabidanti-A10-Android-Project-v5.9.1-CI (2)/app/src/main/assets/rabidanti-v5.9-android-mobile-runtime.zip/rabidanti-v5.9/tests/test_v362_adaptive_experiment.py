from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate
from priority_learning import PriorityFeedbackEngine, PriorityLearningStore
from adaptive_prioritization import AdaptivePrioritizationEngine
from adaptive_experiment import AdaptiveExperimentEngine


def dec(cid, factor, high):
    vals = {"novelty": .5, "confidence": .5, "relevance": .5, "impact": .5, "urgency": .5, "knowledge_gap": .5, "investigation_cost": .0}
    vals[factor] = .9 if high else .1
    return IntelligencePrioritizer().score(PriorityCandidate(cid, "lab", **vals))


def test_shadow_evaluation_never_mutates_weights():
    store = PriorityLearningStore()
    try:
        feedback = PriorityFeedbackEngine(store)
        for i in range(3):
            feedback.record_decision_outcome(dec(f"h{i}", "impact", True), "completed")
            feedback.record_decision_outcome(dec(f"l{i}", "impact", False), "failed")
        adaptive = AdaptivePrioritizationEngine(store)
        proposal = next(p for p in adaptive.propose() if p.factor == "impact")
        result = AdaptiveExperimentEngine(store, adaptive.weights).evaluate(proposal)
        assert result.improvement > 0
        assert adaptive.weights["impact"] == .20
    finally:
        store.close()


def test_shadow_result_requires_both_outcome_groups():
    store = PriorityLearningStore()
    try:
        feedback = PriorityFeedbackEngine(store)
        for i in range(3):
            feedback.record_decision_outcome(dec(f"h{i}", "impact", True), "completed")
        adaptive = AdaptivePrioritizationEngine(store)
        proposal = adaptive.propose()
        assert proposal == ()
    finally:
        store.close()


def test_negative_shadow_change_is_not_adoption():
    store = PriorityLearningStore()
    try:
        feedback = PriorityFeedbackEngine(store)
        for i in range(3):
            feedback.record_decision_outcome(dec(f"h{i}", "urgency", True), "failed")
            feedback.record_decision_outcome(dec(f"l{i}", "urgency", False), "completed")
        adaptive = AdaptivePrioritizationEngine(store)
        proposal = next(p for p in adaptive.propose() if p.factor == "urgency")
        result = AdaptiveExperimentEngine(store, adaptive.weights).evaluate(proposal)
        assert result.recommendation == "PROMISING_SHADOW_RESULT"
        assert result.improvement > 0
    finally:
        store.close()


def test_unknown_factor_is_rejected():
    store = PriorityLearningStore()
    try:
        adaptive = AdaptiveExperimentEngine(store, {"impact": .2})
        from adaptive_prioritization import AdaptationProposal
        p = AdaptationProposal("urgency", .1, .15, .05, 6, .5, "INCREASE", "test")
        try:
            adaptive.evaluate(p)
            assert False
        except ValueError:
            pass
    finally:
        store.close()
