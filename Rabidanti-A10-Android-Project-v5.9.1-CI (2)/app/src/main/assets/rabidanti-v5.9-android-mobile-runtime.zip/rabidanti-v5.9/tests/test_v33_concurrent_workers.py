import threading,time
from concurrent_workers import ConcurrentWorkerPool

class FakeWorker:
    active=0; peak=0; lock=threading.Lock()
    def __init__(self,wid): self.wid=wid
    def process_one(self):
        with self.lock:
            FakeWorker.active+=1; FakeWorker.peak=max(FakeWorker.peak,FakeWorker.active)
        time.sleep(.04)
        with self.lock: FakeWorker.active-=1
        return type("R",(),{"job_id":self.wid})()

def test_bounded_concurrent_execution():
    FakeWorker.active=FakeWorker.peak=0
    start=time.perf_counter()
    results=ConcurrentWorkerPool(FakeWorker,3).run()
    elapsed=time.perf_counter()-start
    assert len(results)==3 and all(r.completed for r in results)
    assert 2 <= FakeWorker.peak <= 3
    assert elapsed < .11

def test_invalid_worker_count():
    try: ConcurrentWorkerPool(FakeWorker,0)
    except ValueError: return
    assert False
