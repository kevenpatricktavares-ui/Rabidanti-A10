import time
from recovery_controller import RecoveryController


class FakeEngine:
    def __init__(self):
        self.calls = []

    def recover(self, now=None):
        self.calls.append(now)
        class A:
            status = "APPLIED"
            kind = "QUEUE_LEASE_RECOVERY"
        class R:
            actions = [A()]
        return R()


def test_controller_runs_immediately_then_respects_interval():
    e = FakeEngine()
    c = RecoveryController(e, interval_seconds=10)
    assert c.run_if_due(now=100.0) is not None
    assert c.run_if_due(now=105.0) is None
    assert c.run_if_due(now=110.0) is not None
    assert len(e.calls) == 2
    assert c.stats.cycles == 2
    assert c.stats.applied_actions == 2


def test_negative_interval_rejected():
    try:
        RecoveryController(FakeEngine(), -1)
        assert False
    except ValueError:
        pass


def test_runner_can_use_recovery_controller():
    import os, tempfile
    from durable_worker_queue import DurableWorkerQueue
    from continuous_worker_runner import ContinuousWorkerRunner
    from worker_supervisor import WorkerSupervisor
    from observability import ObservabilityStore
    from health_monitor import HealthMonitor
    from recovery_engine import RecoveryEngine

    fd, path = tempfile.mkstemp(); os.close(fd)
    try:
        q = DurableWorkerQueue(path, lease_seconds=2)
        s = WorkerSupervisor(path, stale_after=30)
        o = ObservabilityStore(path)
        m = HealthMonitor(o, s)
        controller = RecoveryController(RecoveryEngine(q, m, s, o), interval_seconds=100)
        runner = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0, supervisor=s,
                                        observability=o, health_monitor=m,
                                        recovery_controller=controller)
        runner.tick()
        assert runner.recovery_cycles == 1
        assert controller.stats.cycles == 1
        runner.close(); o.close(); s.close(); q.coordinator.close(); q._conn.close()
    finally:
        try: os.unlink(path)
        except FileNotFoundError: pass
