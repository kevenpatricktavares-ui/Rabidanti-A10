from backend.audiovisual import AudiovisualFactory

def test_audiovisual_brief_and_validation():
    factory = AudiovisualFactory()
    brief = factory.build({
        "title": "Aula de demonstração",
        "format": "course_lesson",
        "audience": "criadores iniciantes",
        "objective": "ensinar uma ferramenta",
        "language": "pt-CV",
        "character_name": "Lia",
        "scenes": [
            {
                "purpose": "introdução",
                "visual_direction": "personagem em apresentação",
                "narration": "Hoje vamos aprender o conceito.",
                "duration_seconds": 12,
                "character_present": True,
            },
            {
                "purpose": "demonstração",
                "visual_direction": "captura da ferramenta",
                "narration": "Agora vamos ver como funciona.",
                "duration_seconds": 20,
            },
        ],
    })

    result = factory.validate(brief)
    assert result["has_scenes"]
    assert result["has_narration"]
    assert result["humanized_audio_direction"]
    assert result["rights_review_required"]
    assert result["human_approval_required"]
    assert result["total_duration_seconds"] == 32
    assert result["ready_for_external_publication"] is False

def test_invalid_format_is_rejected():
    try:
        AudiovisualFactory().build({
            "title": "X", "format": "unknown",
            "audience": "Y", "objective": "Z", "language": "pt"
        })
        assert False
    except ValueError as exc:
        assert "format" in str(exc)
