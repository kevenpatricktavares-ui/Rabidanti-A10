import tempfile
from pathlib import Path
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_brand, register_builtin_landing
from stage_artifact_store import StageArtifactStore

def setup(td):
    store=StageArtifactStore(str(Path(td)/'a.db'))
    store.put('p1','product',{'name':'Focus Course','product_type':'course','target_audience':'students','problem':'study planning','value_proposition':'A practical study system.'})
    store.put('p1','render',{'status':'COMPLETED','format':'pdf','output_path':str(Path(td)/'product.pdf')})
    return store

def test_brand_consumes_product_and_render():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); reg=BusinessStageRegistry(store); register_builtin_brand(reg)
        out=reg.get('brand')(StageExecutionContext('p1','brand','brand',{},'3.38'))
        assert out['name']=='Focus Course'; assert out['render_reference'].endswith('product.pdf')

def test_landing_consumes_brand_product_render():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); store.put('p1','brand',{'name':'Focus Course','promise':'A practical study system.'})
        reg=BusinessStageRegistry(store); register_builtin_landing(reg)
        out=reg.get('landing')(StageExecutionContext('p1','landing','landing',{},'3.38'))
        assert out['status']=='READY_FOR_REVIEW'; assert 'call_to_action' in out['sections']

def test_brand_requires_render():
    with tempfile.TemporaryDirectory() as td:
        store=StageArtifactStore(str(Path(td)/'a.db')); store.put('p1','product',{'name':'X'})
        reg=BusinessStageRegistry(store); register_builtin_brand(reg)
        try: reg.get('brand')(StageExecutionContext('p1','brand','x',{},'3.38')); assert False
        except RuntimeError as e: assert 'render artifact missing' in str(e)

def test_landing_requires_brand():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); reg=BusinessStageRegistry(store); register_builtin_landing(reg)
        try: reg.get('landing')(StageExecutionContext('p1','landing','x',{},'3.38')); assert False
        except RuntimeError as e: assert 'brand artifact missing' in str(e)
