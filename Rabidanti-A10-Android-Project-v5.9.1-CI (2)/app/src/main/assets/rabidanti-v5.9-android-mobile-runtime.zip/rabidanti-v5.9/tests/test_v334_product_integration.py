import tempfile
from pathlib import Path
from stage_artifact_store import StageArtifactStore
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_product


def test_product_consumes_opportunity_artifact():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        store.put('p1', 'opportunity', {'score': 82, 'gap_score': 75, 'hypotheses': ['h1'], 'evidence': [{'source':'x'}]})
        reg = BusinessStageRegistry(store)
        register_builtin_product(reg)
        out = reg.get('product')(StageExecutionContext('p1','product','learn budgeting',{},'3.34'))
        assert out['project_id'] == 'p1'
        assert out['source_stage'] == 'opportunity'
        assert out['product_type'] == 'interactive_tool'
        assert out['opportunity_score'] == 82


def test_product_requires_opportunity_artifact():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        reg = BusinessStageRegistry(store)
        register_builtin_product(reg)
        try:
            reg.get('product')(StageExecutionContext('missing','product','x',{},'3.34'))
            assert False
        except RuntimeError as e:
            assert 'opportunity artifact missing' in str(e)
