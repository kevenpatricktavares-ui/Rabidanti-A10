import tempfile
import time
from pathlib import Path

from capacity_intelligence import CapacityIntelligence
from durable_worker_queue import DurableWorkerQueue
from execution_planner import PlannedItem
from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate, PriorityBand
from priority_execution_planner import PriorityAwareExecutionPlanner
from resource_capacity import ResourceCapacityMonitor


def planner():
    d = tempfile.TemporaryDirectory()
    q = DurableWorkerQueue(str(Path(d.name) / "db.sqlite"), lease_seconds=10)
    ci = CapacityIntelligence(ResourceCapacityMonitor(q))
    ci.observe(2, 0, now=time.time())
    return d, q, PriorityAwareExecutionPlanner(ci)


def decision(cid, scoreish):
    # Keep values deterministic while making score ordering obvious.
    return IntelligencePrioritizer().score(PriorityCandidate(
        cid, "lab", novelty=scoreish, confidence=scoreish, relevance=scoreish,
        impact=scoreish, urgency=scoreish, knowledge_gap=scoreish, investigation_cost=0.0,
    ))


def test_intelligence_priority_orients_selection():
    d, q, p = planner()
    try:
        items = [PlannedItem("low", 9), PlannedItem("high", 1)]
        ds = [decision("low", .2), decision("high", .9)]
        plan = p.plan_with_decisions(items, 1, ds, now=1)
        assert plan.selected == ("high",)
        assert plan.deferred == ("low",)
        assert plan.reason == "CAPACITY_BOUND"
    finally:
        d.cleanup()


def test_missing_decision_falls_back_to_queue_priority():
    d, q, p = planner()
    try:
        items = [PlannedItem("a", 2), PlannedItem("b", 8)]
        plan = p.plan_with_decisions(items, 1, [decision("a", .9)], now=1)
        assert plan.selected == ("a",)
    finally:
        d.cleanup()


def test_dependencies_and_readiness_still_block():
    d, q, p = planner()
    try:
        items = [
            PlannedItem("blocked", 99, False, True),
            PlannedItem("dep", 99, True, False),
            PlannedItem("ready", 1, True, True),
        ]
        ds = [decision("blocked", .99), decision("dep", .99)]
        plan = p.plan_with_decisions(items, 2, ds, now=1)
        assert plan.selected == ("ready",)
        assert "blocked" in plan.deferred and "dep" in plan.deferred
    finally:
        d.cleanup()


def test_capacity_and_deterministic_tie_break():
    d, q, p = planner()
    try:
        ds = [decision("b", .8), decision("a", .8), decision("c", .8)]
        plan = p.plan_with_decisions([PlannedItem("b", 1), PlannedItem("a", 1), PlannedItem("c", 1)], 2, ds, now=1)
        assert plan.selected == ("a", "b")
    finally:
        d.cleanup()


def test_planner_cannot_override_readiness_gate():
    d, q, p = planner()
    try:
        item = q.enqueue({"handler": "noop", "data": 1}, priority=1, task_id="gated")
        plan = p.plan_with_decisions(
            [PlannedItem(item.item_id, 100, False, True)],
            1,
            [decision(item.item_id, .99)],
            now=1,
        )
        assert plan.selected == ()
        assert plan.deferred == (item.item_id,)
        # A high intelligence score cannot turn a non-ready item into executable work.
        assert q.claim(item.item_id, "worker-1") is not None
    finally:
        d.cleanup()


def test_priority_band_is_preserved_as_metadata():
    d, q, p = planner()
    try:
        d1 = decision("x", .9)
        assert d1.band == PriorityBand.CRITICAL
        plan = p.plan_with_decisions([PlannedItem("x", 0)], 1, [d1], now=1)
        assert plan.selected == ("x",)
    finally:
        d.cleanup()
