
from datetime import datetime, timezone
from persistent_scheduler import PersistentScheduler
from continuous_execution import ContinuousExecutionEngine

def test_engine_schedules_and_processes(tmp_path):
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(str(tmp_path/"db.sqlite"),lambda: now)
    s.add("job-a",now)
    submitted=[]
    processed=[]
    e=ContinuousExecutionEngine(
        s, lambda tid: submitted.append(tid),
        lambda: processed.append(True) or "drained",
        lambda: now
    )
    assert e.tick()=="drained"
    assert submitted==["job-a"]
    assert processed==[True]
    assert e.stats.scheduled==1

def test_engine_restart_does_not_duplicate_one_shot(tmp_path):
    db=str(tmp_path/"db.sqlite")
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(db,lambda: now)
    s.add("job-a",now)
    submitted=[]
    ContinuousExecutionEngine(s,lambda tid: submitted.append(tid),lambda: None,lambda: now).tick()
    s2=PersistentScheduler(db,lambda: now)
    ContinuousExecutionEngine(s2,lambda tid: submitted.append(tid),lambda: None,lambda: now).tick()
    assert submitted==["job-a"]

def test_enqueue_failure_keeps_schedule(tmp_path):
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=PersistentScheduler(str(tmp_path/"db.sqlite"),lambda: now)
    s.add("job-a",now)
    def fail(_): raise RuntimeError("queue unavailable")
    e=ContinuousExecutionEngine(s,fail,lambda: None,lambda: now)
    try:
        e.tick()
    except RuntimeError:
        pass
    else:
        assert False
    assert len(s.due(now))==1

def test_run_and_stop():
    class Fake:
        def __init__(self):
            self.n=0
        def due(self,now): return []
    f=Fake()
    e=ContinuousExecutionEngine(f,lambda _:None,lambda: "ok",lambda: datetime.now(timezone.utc))
    assert e.run(3)==["ok","ok","ok"]
    e.stop()
    assert e.run(3)==[]

def test_invalid_run_limit():
    class Fake:
        def due(self,now): return []
    e=ContinuousExecutionEngine(Fake(),lambda _:None,lambda:None)
    try:
        e.run(0)
    except ValueError:
        return
    assert False
