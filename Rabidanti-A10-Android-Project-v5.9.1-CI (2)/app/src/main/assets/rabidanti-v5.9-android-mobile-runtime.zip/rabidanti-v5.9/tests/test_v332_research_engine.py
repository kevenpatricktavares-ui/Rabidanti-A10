from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_research
from research_engine import ResearchEngine


def test_research_engine_builds_traceable_brief_without_inventing_evidence():
    brief = ResearchEngine().research(
        "p1", "create a study planner",
        {"demand_signals": ["students want simpler planning"],
         "pain_points": ["planning is difficult"],
         "market_gaps": ["few tools combine planning and feedback"],
         "evidence": [{"source": "user interviews", "count": 5}]},
    )
    assert brief.project_id == "p1"
    assert "students want simpler planning" in brief.demand_signals
    assert brief.evidence[0]["source"] == "user interviews"
    assert not brief.limitations
    assert all("verified" not in h.lower() for h in brief.hypotheses)


def test_research_engine_labels_missing_current_evidence():
    brief = ResearchEngine().research("p1", "find an opportunity", {})
    assert brief.limitations
    assert "external evidence" in brief.limitations[0]


def test_research_handler_is_real_and_returns_structured_output():
    reg = BusinessStageRegistry()
    register_builtin_research(reg)
    ctx = StageExecutionContext("p1", "research", "launch a digital product", {
        "demand_signals": ["buyers want faster results"]
    }, "1.0")
    result = reg.get("research")(ctx)
    assert result["project_id"] == "p1"
    assert result["demand_signals"] == ("buyers want faster results",)
    assert result["hypotheses"]
