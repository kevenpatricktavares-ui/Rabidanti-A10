import tempfile
from source_verification import EvidenceFusionStore, SourceVerification
from knowledge_graph import KnowledgeGraphStore, WorldKnowledgeGraph, RelationStatus
from verified_knowledge_graph import VerifiedKnowledgeGraphBridge, WorldKnowledgeGraphBridge
from world_awareness import WorldAwareness, WorldAwarenessStore


def test_verified_assessment_materializes_with_confidence_and_claim_provenance():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    v.add_evidence(claim_id='c1', source_id='s1', supports=True, strength=1, independent_group='a')
    v.add_evidence(claim_id='c1', source_id='s2', supports=True, strength=1, independent_group='b')
    assessment = v.assess(claim_id='c1', claim='A claim')
    g = WorldKnowledgeGraph(KnowledgeGraphStore(':memory:'))
    a = g.add_entity(name='A', entity_type='technology')
    b = g.add_entity(name='B', entity_type='system')
    result = VerifiedKnowledgeGraphBridge(g).materialize_assessment(
        assessment, subject_id=a.entity_id, predicate='used_by', object_id=b.entity_id)
    relation = g.store.relation(result.relation_id)
    assert result.status.name == 'VERIFIED'
    assert relation.status is RelationStatus.VERIFIED
    assert relation.claim_id == 'c1'
    assert relation.confidence == assessment.confidence


def test_contested_assessment_is_preserved_as_contested_edge():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    v.add_evidence(claim_id='c2', source_id='s1', supports=True, strength=1, independent_group='a')
    v.add_evidence(claim_id='c2', source_id='s2', supports=False, strength=1, independent_group='b')
    assessment = v.assess(claim_id='c2', claim='A contested claim')
    g = WorldKnowledgeGraph(KnowledgeGraphStore(':memory:'))
    a = g.add_entity(name='A', entity_type='x'); b = g.add_entity(name='B', entity_type='y')
    result = VerifiedKnowledgeGraphBridge(g).materialize_assessment(
        assessment, subject_id=a.entity_id, predicate='relates_to', object_id=b.entity_id)
    assert result.relation_status is RelationStatus.CONTESTED


def test_materialize_if_supported_does_not_promote_insufficient_claim():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    assessment = v.assess(claim_id='c3', claim='Unknown')
    g = WorldKnowledgeGraph(KnowledgeGraphStore(':memory:'))
    a = g.add_entity(name='A', entity_type='x'); b = g.add_entity(name='B', entity_type='y')
    assert VerifiedKnowledgeGraphBridge(g).materialize_if_supported(
        assessment, subject_id=a.entity_id, predicate='relates_to', object_id=b.entity_id) is None
    assert g.store.relations() == []


def test_world_signal_materializes_as_signal_entity_not_verified_fact():
    with tempfile.TemporaryDirectory() as d:
        world = WorldAwareness(WorldAwarenessStore(d + '/world.db'))
        source = world.ingest_source(title='Source', locator='https://example.test/a', publisher='Pub')
        signal = world.add_signal(source.source_id, topic='AI', statement='New signal', confidence=.7)
        g = WorldKnowledgeGraph(KnowledgeGraphStore(d + '/kg.db'))
        entity = WorldKnowledgeGraphBridge(world, g).materialize_signal(signal.signal_id)
        assert entity.entity_type == 'world_signal'
        assert g.store.relations() == []
