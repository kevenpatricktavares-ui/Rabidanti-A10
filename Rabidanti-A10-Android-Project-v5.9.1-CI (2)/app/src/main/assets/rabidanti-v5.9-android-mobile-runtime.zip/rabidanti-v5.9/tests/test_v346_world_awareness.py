import tempfile, time
from world_awareness import WorldAwareness, WorldAwarenessStore

def test_source_and_signal_persist():
    with tempfile.TemporaryDirectory() as d:
        path=d+'/world.db'; w=WorldAwareness(WorldAwarenessStore(path))
        s=w.ingest_source(title='Source',locator='https://example.test/a',publisher='Example',verified=True,summary='x')
        sig=w.add_signal(s.source_id,topic='AI',statement='A signal',confidence=.8)
        w2=WorldAwareness(WorldAwarenessStore(path)); snap=w2.snapshot('AI')
        assert snap['verified_source_count']==1 and len(snap['signals'])==1

def test_future_source_rejected():
    w=WorldAwareness(WorldAwarenessStore(':memory:'))
    try: w.ingest_source(title='x',locator='u',publisher='p',published_at=time.time()+1000); assert False
    except ValueError: pass

def test_signal_requires_source_and_bounds():
    w=WorldAwareness(WorldAwarenessStore(':memory:'))
    try: w.add_signal('missing',topic='x',statement='x',confidence=.5); assert False
    except KeyError: pass
    s=w.ingest_source(title='x',locator='u',publisher='p')
    try: w.add_signal(s.source_id,topic='x',statement='x',confidence=1.2); assert False
    except ValueError: pass
