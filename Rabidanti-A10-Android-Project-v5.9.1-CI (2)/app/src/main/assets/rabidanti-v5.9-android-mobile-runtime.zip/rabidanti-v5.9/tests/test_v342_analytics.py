import tempfile
from stage_artifact_store import StageArtifactStore
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_analytics


def setup(td):
    return StageArtifactStore(td + '/db.sqlite')


def seed(store):
    store.put('p1', 'sales', {'landing_title': 'Focus Course', 'events': ['landing_view', 'purchase']})
    store.put('p1', 'ads', {
        'experiment_id': 'exp-p1-ads-001',
        'channels': ['web', 'social'],
        'variants': ['control', 'value_angle', 'problem_solution'],
    })


def test_analytics_calculates_observed_funnel_metrics():
    with tempfile.TemporaryDirectory() as td:
        store = setup(td); seed(store); reg = BusinessStageRegistry(store); register_builtin_analytics(reg)
        ctx = StageExecutionContext('p1', 'analytics', 'measure', {
            'observations': {'impressions': 1000, 'clicks': 100, 'checkout_start': 20, 'purchases': 10}
        }, '3.42')
        out = reg.get('analytics')(ctx)
        assert out['status'] == 'MEASURED'
        assert out['evidence_state'] == 'SUFFICIENT_FOR_FUNNEL'
        assert out['metrics']['ctr'] == 0.1
        assert out['metrics']['checkout_to_purchase_rate'] == 0.5
        assert out['metrics']['purchase_rate'] == 0.01


def test_analytics_calculates_commercial_metrics_only_when_observed():
    with tempfile.TemporaryDirectory() as td:
        store = setup(td); seed(store); reg = BusinessStageRegistry(store); register_builtin_analytics(reg)
        out = reg.get('analytics')(StageExecutionContext('p1', 'analytics', 'measure', {
            'observations': {'spend': 25, 'revenue': 100, 'purchases': 4, 'refunds': 1}
        }, '3.42'))
        assert out['metrics']['roas'] == 4.0
        assert out['metrics']['refund_rate'] == 0.25


def test_analytics_does_not_invent_missing_data():
    with tempfile.TemporaryDirectory() as td:
        store = setup(td); seed(store); reg = BusinessStageRegistry(store); register_builtin_analytics(reg)
        out = reg.get('analytics')(StageExecutionContext('p1', 'analytics', 'measure', {}, '3.42'))
        assert out['status'] == 'WAITING_FOR_DATA'
        assert out['metrics']['ctr'] is None
        assert out['metrics']['roas'] is None


def test_analytics_requires_ads():
    with tempfile.TemporaryDirectory() as td:
        store = setup(td); store.put('p1', 'sales', {'events': ['purchase']})
        reg = BusinessStageRegistry(store); register_builtin_analytics(reg)
        try:
            reg.get('analytics')(StageExecutionContext('p1', 'analytics', 'x', {}, '3.42'))
            assert False
        except RuntimeError as e:
            assert 'ads artifact missing' in str(e)


def test_analytics_requires_sales():
    with tempfile.TemporaryDirectory() as td:
        store = setup(td); store.put('p1', 'ads', {'channels': ['web'], 'variants': ['control']})
        reg = BusinessStageRegistry(store); register_builtin_analytics(reg)
        try:
            reg.get('analytics')(StageExecutionContext('p1', 'analytics', 'x', {}, '3.42'))
            assert False
        except RuntimeError as e:
            assert 'sales artifact missing' in str(e)


def test_analytics_persists_through_registry_artifact_store():
    with tempfile.TemporaryDirectory() as td:
        store = setup(td); seed(store); reg = BusinessStageRegistry(store); register_builtin_analytics(reg)
        out = reg.get('analytics')(StageExecutionContext('p1', 'analytics', 'measure', {
            'observations': {'impressions': 500, 'clicks': 50}
        }, '3.42'))
        store.put('p1', 'analytics', out)
        saved = store.get('p1', 'analytics')
        assert saved['experiment_id'] == 'exp-p1-ads-001'
        assert saved['metrics']['ctr'] == 0.1
