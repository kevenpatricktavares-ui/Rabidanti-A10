import os, tempfile, time
from durable_worker_queue import DurableWorkerQueue, QueueItemState
from worker_supervisor import WorkerSupervisor, WorkerStatus
from observability import ObservabilityStore
from health_monitor import HealthMonitor
from recovery_engine import RecoveryEngine


def test_recovers_expired_queue_item():
    fd, path = tempfile.mkstemp(); os.close(fd)
    try:
        q = DurableWorkerQueue(path, lease_seconds=1)
        o = ObservabilityStore(path)
        s = WorkerSupervisor(path, stale_after=30)
        m = HealthMonitor(o, s)
        q.enqueue({'handler': 'x'})
        item = q.ready()[0]
        q.claim(item.item_id, 'dead-worker')
        q.coordinator._conn.execute('UPDATE worker_leases SET lease_until=? WHERE task_id=?', (time.time()-2, item.task_id))
        report = RecoveryEngine(q, m, s, o).recover()
        assert any(a.kind == 'QUEUE_LEASE_RECOVERY' and a.status == 'APPLIED' for a in report.actions)
        assert q.get(item.item_id).state == QueueItemState.QUEUED
        o.close(); s.close(); q.coordinator.close(); q._conn.close()
    finally: os.unlink(path)


def test_recovers_idle_stale_worker_but_not_active():
    o = ObservabilityStore(':memory:')
    s = WorkerSupervisor(':memory:', stale_after=1)
    q = DurableWorkerQueue(':memory:', lease_seconds=2)
    s.register('idle', 1); s.set_status('idle', WorkerStatus.RUNNING)
    s.register('busy', 1); s.heartbeat('busy', active=1)
    old = time.time() - 10
    s._conn.execute('UPDATE workers SET last_heartbeat=? WHERE worker_id IN (?,?)', (old, 'idle', 'busy'))
    r = RecoveryEngine(q, HealthMonitor(o, s), s, o).recover(now=time.time())
    assert s.get('idle').status == WorkerStatus.RUNNING
    assert any(a.target == 'busy' and a.status == 'SKIPPED' for a in r.actions)
    o.close(); s.close(); q.coordinator.close(); q._conn.close()
