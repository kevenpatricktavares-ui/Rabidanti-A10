
from autonomous_runtime import AutonomousTaskRuntime, AutonomousTask, TaskPriority, TaskState

def test_priority_and_dependencies():
    r=AutonomousTaskRuntime()
    r.add(AutonomousTask("a","research",TaskPriority.NORMAL))
    r.add(AutonomousTask("b","critical",TaskPriority.CRITICAL))
    r.add(AutonomousTask("c","depends",TaskPriority.HIGH,dependencies=["a"]))
    assert [x.task_id for x in r.runnable()]==["b","a"]
    assert r.claim("a","w1")
    r.complete("a","w1","ok")
    assert [x.task_id for x in r.runnable()]==["b","c"]

def test_single_owner_and_owner_validation():
    r=AutonomousTaskRuntime()
    r.add(AutonomousTask("a","job"))
    assert r.claim("a","worker-1")
    assert not r.claim("a","worker-2")
    try:
        r.complete("a","worker-2")
    except PermissionError:
        pass
    else:
        assert False

def test_retry_then_failure():
    r=AutonomousTaskRuntime()
    r.add(AutonomousTask("a","job",max_attempts=2))
    assert r.claim("a","w")
    r.fail("a","w","first")
    assert r.get("a").state==TaskState.QUEUED
    assert r.claim("a","w")
    r.fail("a","w","second")
    assert r.get("a").state==TaskState.FAILED
    assert r.get("a").attempts==2

def test_cancel():
    r=AutonomousTaskRuntime()
    r.add(AutonomousTask("a","job"))
    assert r.cancel("a")
    assert r.get("a").state==TaskState.CANCELLED
    assert r.runnable()==[]

def test_blocked_dependency():
    r=AutonomousTaskRuntime()
    r.add(AutonomousTask("a","parent"))
    r.add(AutonomousTask("b","child",dependencies=["a"]))
    assert [x.task_id for x in r.runnable()]==["a"]
