import os
import tempfile
import unittest

from versioned_strategy import StrategyState, VersionedStrategyStore


class TestVersionedStrategy(unittest.TestCase):
    def test_initial_and_persistence(self):
        fd, path = tempfile.mkstemp(); os.close(fd)
        try:
            store = VersionedStrategyStore(path)
            initial = store.create_initial("priority", {"impact": .2, "confidence": .3})
            store.close()
            store2 = VersionedStrategyStore(path)
            self.assertEqual(store2.active("priority").version, 1)
            self.assertEqual(initial.hash, store2.active("priority").hash)
            store2.close()
        finally:
            os.unlink(path)

    def test_approval_and_activation_version_history(self):
        store = VersionedStrategyStore()
        store.create_initial("priority", {"impact": .2, "confidence": .3})
        proposed = store.propose("priority", {"impact": .25, "confidence": .25}, "experiment promotion")
        self.assertEqual(proposed.state, StrategyState.PROPOSED)
        store.approve("priority", 2)
        active = store.activate("priority", 2)
        self.assertEqual(active.state, StrategyState.ACTIVE)
        self.assertEqual(store.get("priority", 1).state, StrategyState.ROLLED_BACK)

    def test_no_implicit_activation(self):
        store = VersionedStrategyStore()
        store.create_initial("priority", {"impact": .2})
        proposed = store.propose("priority", {"impact": .3}, "test")
        self.assertEqual(store.active("priority").version, 1)
        self.assertEqual(proposed.state, StrategyState.PROPOSED)

    def test_reject_does_not_change_active(self):
        store = VersionedStrategyStore()
        store.create_initial("priority", {"impact": .2})
        store.propose("priority", {"impact": .3}, "test")
        store.reject("priority", 2)
        self.assertEqual(store.active("priority").version, 1)
        self.assertEqual(store.get("priority", 2).state, StrategyState.REJECTED)

    def test_rollback_creates_new_auditable_active_version(self):
        store = VersionedStrategyStore()
        store.create_initial("priority", {"impact": .2})
        store.propose("priority", {"impact": .3}, "change")
        store.approve("priority", 2)
        store.activate("priority", 2)
        rollback = store.rollback("priority", 1, "performance regression")
        self.assertEqual(rollback.version, 3)
        self.assertEqual(rollback.state, StrategyState.ACTIVE)
        self.assertEqual(rollback.weights, {"impact": .2})
        self.assertEqual(store.get("priority", 2).state, StrategyState.ROLLED_BACK)
        self.assertEqual(rollback.parent_version, 2)

    def test_validation_and_invalid_transitions(self):
        store = VersionedStrategyStore()
        store.create_initial("priority", {"impact": .2})
        with self.assertRaises(ValueError):
            store.propose("priority", {"impact": .2}, "same")
        with self.assertRaises(ValueError):
            store.activate("priority", 1)
        with self.assertRaises(ValueError):
            store.rollback("priority", 1)
        with self.assertRaises(ValueError):
            store.propose("priority", {"impact": 1.5}, "bad")


if __name__ == "__main__":
    unittest.main()
