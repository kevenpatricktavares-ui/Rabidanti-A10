import tempfile
import time
from pathlib import Path

from capacity_intelligence import CapacityIntelligence
from continuous_worker_runner import ContinuousWorkerRunner
from durable_worker_queue import DurableWorkerQueue
from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate
from priority_execution_planner import PriorityAwareExecutionPlanner
from resource_capacity import ResourceCapacityMonitor


def test_runner_uses_intelligence_decisions_before_queue_priority():
    d = tempfile.TemporaryDirectory()
    try:
        q = DurableWorkerQueue(str(Path(d.name) / "db.sqlite"), lease_seconds=10)
        ci = CapacityIntelligence(ResourceCapacityMonitor(q))
        ci.observe(1, 0, now=time.time())
        planner = PriorityAwareExecutionPlanner(ci)
        low = q.enqueue({"handler": "capture", "data": "low"}, priority=9, task_id="low")
        high = q.enqueue({"handler": "capture", "data": "high"}, priority=1, task_id="high")
        p = IntelligencePrioritizer()
        decisions = [
            p.score(PriorityCandidate(low.item_id, "lab", novelty=.1, confidence=.1, relevance=.1, impact=.1, urgency=.1, knowledge_gap=.1)),
            p.score(PriorityCandidate(high.item_id, "lab", novelty=.9, confidence=.9, relevance=.9, impact=.9, urgency=.9, knowledge_gap=.9)),
        ]
        seen = []
        runner = ContinuousWorkerRunner(
            q, max_workers=1, poll_interval=0, capacity_intelligence=ci,
            execution_planner=planner,
            priority_decisions_provider=lambda items: decisions,
        )
        runner.register_handler("capture", lambda data: seen.append(data))
        runner.run(max_ticks=1)
        assert seen == ["high"]
        runner.close()
    finally:
        d.cleanup()
