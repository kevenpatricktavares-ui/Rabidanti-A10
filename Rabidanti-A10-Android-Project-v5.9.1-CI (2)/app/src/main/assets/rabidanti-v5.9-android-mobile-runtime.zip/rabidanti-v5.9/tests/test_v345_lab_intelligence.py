import tempfile
from laboratory import LaboratoryStore, LaboratoryEngine
from laboratory_intelligence import LaboratoryIntelligenceStore, LaboratoryIntelligence

def test_signal_and_hypothesis_intelligence():
    with tempfile.TemporaryDirectory() as d:
        lab=LaboratoryEngine(LaboratoryStore(d+'/lab.db'))
        p=lab.create('Blue ocean','Q','AI','H')
        intel=LaboratoryIntelligence(lab,LaboratoryIntelligenceStore(d+'/intel.db'))
        s=intel.ingest_signal(p.lab_id,'Sinal relevante',domain='AI',sources=[{'source':'a','verified':True},{'source':'b','verified':True}])
        assert s.verified_source_count==2 and s.strength>0
        a=intel.assess_hypothesis(p.lab_id,support=.9,contradiction=.05,evidence_count=2)
        assert a.status=='SUPPORTED' and a.confidence>.75

def test_rejects_signal_without_sources():
    with tempfile.TemporaryDirectory() as d:
        lab=LaboratoryEngine(LaboratoryStore(d+'/lab.db')); p=lab.create('x','q','d','h')
        intel=LaboratoryIntelligence(lab,LaboratoryIntelligenceStore(d+'/i.db'))
        try: intel.ingest_signal(p.lab_id,'x',domain='d',sources=[]); assert False
        except ValueError: pass

def test_snapshot_persists():
    with tempfile.TemporaryDirectory() as d:
        lab=LaboratoryEngine(LaboratoryStore(d+'/lab.db')); p=lab.create('x','q','d','h')
        path=d+'/i.db'; intel=LaboratoryIntelligence(lab,LaboratoryIntelligenceStore(path))
        intel.ingest_signal(p.lab_id,'signal',domain='d',sources=[{'source':'s','verified':True}])
        intel.assess_hypothesis(p.lab_id,support=.6,contradiction=.1,evidence_count=1)
        intel2=LaboratoryIntelligence(lab,LaboratoryIntelligenceStore(path)); snap=intel2.research_snapshot(p.lab_id)
        assert len(snap['signals'])==1 and len(snap['hypothesis_assessments'])==1
