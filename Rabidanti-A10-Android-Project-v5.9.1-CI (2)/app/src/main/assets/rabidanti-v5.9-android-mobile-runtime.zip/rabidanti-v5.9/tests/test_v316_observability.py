import tempfile, os
from observability import ObservabilityStore

def test_metrics_events_persist_restart():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        a=ObservabilityStore(path); a.metric('x',3); a.event('test',worker_id='w',item_id='i'); a.close()
        b=ObservabilityStore(path)
        assert b.summary()=={'metrics':1,'events':1}
        assert b.recent_metrics('x')[0].value==3
        assert b.recent_events()[0].worker_id=='w'
        b.close()
    finally: os.unlink(path)

def test_validation():
    o=ObservabilityStore(':memory:')
    for fn,args in [(o.metric,('',1)),(o.event,('',))]:
        try: fn(*args); assert False
        except ValueError: pass
    try: o.recent_metrics(limit=0); assert False
    except ValueError: pass
    o.close()
