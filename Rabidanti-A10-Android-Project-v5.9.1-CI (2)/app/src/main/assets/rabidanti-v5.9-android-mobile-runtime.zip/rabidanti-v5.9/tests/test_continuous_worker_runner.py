import tempfile
import time
import unittest

from durable_worker_queue import DurableWorkerQueue, QueueItemState
from continuous_worker_runner import ContinuousWorkerRunner


class TestContinuousWorkerRunner(unittest.TestCase):
    def test_handler_completes_item(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name, lease_seconds=2)
            item = q.enqueue({"handler": "echo", "data": "ok"})
            r = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0.001)
            r.register_handler("echo", lambda x: x)
            r.run(max_ticks=5)
            self.assertEqual(q.get(item.item_id).state, QueueItemState.COMPLETED)
            self.assertEqual(q.get(item.item_id).result, "ok")
            r.close(); q.close()

    def test_bounded_concurrency(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name, lease_seconds=2)
            for i in range(6):
                q.enqueue({"handler": "slow", "data": i})
            active = [0]
            peak = [0]
            lock = __import__("threading").Lock()
            def slow(x):
                with lock:
                    active[0] += 1; peak[0] = max(peak[0], active[0])
                time.sleep(0.015)
                with lock: active[0] -= 1
                return x
            r = ContinuousWorkerRunner(q, max_workers=2, poll_interval=0.002)
            r.register_handler("slow", slow)
            r.run(max_ticks=40)
            self.assertEqual(len([x for x in q.ready()]), 0)
            self.assertEqual(r.stats.completed, 6)
            self.assertLessEqual(peak[0], 2)
            r.close(); q.close()

    def test_missing_handler_fails_and_retries(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name, lease_seconds=2)
            item = q.enqueue({"handler": "missing", "data": 1}, max_attempts=2)
            r = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0.001)
            r.run(max_ticks=10)
            self.assertEqual(q.get(item.item_id).state, QueueItemState.FAILED)
            self.assertEqual(q.get(item.item_id).attempts, 2)
            r.close(); q.close()

    def test_stop_is_graceful(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name)
            r = ContinuousWorkerRunner(q)
            r.stop()
            self.assertTrue(r.stopped)
            r.close(); q.close()

    def test_invalid_worker_count(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name)
            with self.assertRaises(ValueError):
                ContinuousWorkerRunner(q, max_workers=0)
            q.close()


if __name__ == "__main__":
    unittest.main()
