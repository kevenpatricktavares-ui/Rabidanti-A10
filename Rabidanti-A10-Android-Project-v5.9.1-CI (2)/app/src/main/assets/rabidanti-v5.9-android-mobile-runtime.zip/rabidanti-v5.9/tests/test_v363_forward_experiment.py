import pytest
from forward_experiment import Arm, ExperimentState, ForwardExperiment, ForwardExperimentEngine, ForwardExperimentStore, ExperimentObservation

def make(store,eid="exp-1",allocation=.5):
    store.create(ForwardExperiment(eid,"impact",.2,.25,allocation)); eng=ForwardExperimentEngine(store); eng.start(eid); return eng

def arms(eng,eid,prefix):
    c=[]; t=[]
    for i in range(500):
        cid=f"{prefix}{i}"; a=eng.assign(eid,cid)
        (t if a.arm==Arm.TREATMENT else c).append(cid)
        if len(c)>=3 and len(t)>=3:return c[:3],t[:3]
    raise AssertionError("could not find both arms")

def test_deterministic_assignment_persists():
    s=ForwardExperimentStore(); e=make(s); a=e.assign("exp-1","candidate-a",1); assert e.assign("exp-1","candidate-a",2)==a

def test_assignment_requires_running():
    s=ForwardExperimentStore(); s.create(ForwardExperiment("e","impact",.2,.25));
    with pytest.raises(ValueError): ForwardExperimentEngine(s).assign("e","x")

def test_observation_arm_must_match():
    s=ForwardExperimentStore(); e=make(s); a=e.assign("exp-1","x"); wrong=Arm.CONTROL if a.arm==Arm.TREATMENT else Arm.TREATMENT
    with pytest.raises(ValueError): s.record(ExperimentObservation("exp-1","x",wrong,"COMPLETED",1))

def test_insufficient_evidence():
    s=ForwardExperimentStore(); e=make(s); c,t=arms(e,"exp-1","i")
    for cid in c[:2]+t[:2]:e.record("exp-1",cid,"COMPLETED")
    assert e.evaluate("exp-1").recommendation=="INSUFFICIENT_EVIDENCE"

def test_promising_enters_approval_gate_without_changing_weights():
    s=ForwardExperimentStore(); e=make(s); c,t=arms(e,"exp-1","p")
    for cid in c:e.record("exp-1",cid,"FAILED")
    for cid in t:e.record("exp-1",cid,"COMPLETED")
    ev=e.complete_for_review("exp-1"); assert ev.recommendation=="PROMISING_TREATMENT"; assert s.get("exp-1").state==ExperimentState.PROMOTION_PENDING
    approved=e.approve("exp-1"); assert approved.state==ExperimentState.APPROVED; assert approved.baseline_weight==.2 and approved.proposed_weight==.25

def test_negative_result_not_promoted():
    s=ForwardExperimentStore(); e=make(s); c,t=arms(e,"exp-1","n")
    for cid in c:e.record("exp-1",cid,"COMPLETED")
    for cid in t:e.record("exp-1",cid,"FAILED")
    assert e.complete_for_review("exp-1").recommendation=="REJECT_TREATMENT"; assert s.get("exp-1").state==ExperimentState.COMPLETED
