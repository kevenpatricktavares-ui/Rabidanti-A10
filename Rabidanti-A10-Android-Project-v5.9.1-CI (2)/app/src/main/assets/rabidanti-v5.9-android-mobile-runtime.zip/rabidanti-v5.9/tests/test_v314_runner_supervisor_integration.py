import tempfile
import time
import unittest

from continuous_worker_runner import ContinuousWorkerRunner
from durable_worker_queue import DurableWorkerQueue, QueueItemState
from worker_supervisor import WorkerSupervisor, WorkerStatus


class TestV314RunnerSupervisorIntegration(unittest.TestCase):
    def test_runner_registers_and_updates_workers(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name, lease_seconds=2)
            s = WorkerSupervisor(f.name, stale_after=5)
            q.enqueue({"handler": "echo", "data": "ok"})
            r = ContinuousWorkerRunner(q, max_workers=2, poll_interval=0.001, supervisor=s)
            r.register_handler("echo", lambda x: x)
            r.run(max_ticks=5)
            records = s.list()
            self.assertEqual(len(records), 2)
            self.assertTrue(all(x.status == WorkerStatus.RUNNING for x in records))
            self.assertTrue(all(x.active == 0 for x in records))
            r.close(); s.close(); q.close()

    def test_stable_worker_identity_and_health(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name, lease_seconds=2)
            s = WorkerSupervisor(f.name, stale_after=5)
            for i in range(3):
                q.enqueue({"handler": "slow", "data": i})
            r = ContinuousWorkerRunner(q, max_workers=2, poll_interval=0.001, supervisor=s)
            r.register_handler("slow", lambda x: (time.sleep(0.01), x)[1])
            r.run(max_ticks=30)
            self.assertEqual(r.stats.completed, 3)
            ids = {x.worker_id for x in s.list()}
            self.assertEqual(ids, {"runner-1", "runner-2"})
            health = r.health()
            self.assertTrue(health["supervisor"])
            self.assertEqual(health["active_futures"], 0)
            r.close(); s.close(); q.close()

    def test_close_marks_workers_stopped(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            q = DurableWorkerQueue(f.name)
            s = WorkerSupervisor(f.name)
            r = ContinuousWorkerRunner(q, max_workers=2, supervisor=s)
            r.close()
            self.assertTrue(all(x.status == WorkerStatus.STOPPED for x in s.list()))
            s.close(); q.close()


if __name__ == "__main__":
    unittest.main()
