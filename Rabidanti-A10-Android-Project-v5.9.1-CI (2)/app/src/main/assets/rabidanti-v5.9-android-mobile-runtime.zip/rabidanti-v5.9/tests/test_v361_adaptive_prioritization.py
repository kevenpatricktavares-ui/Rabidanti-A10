from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate
from priority_learning import PriorityFeedbackEngine, PriorityLearningStore
from adaptive_prioritization import AdaptivePrioritizationEngine


def dec(cid, factor, high):
    vals = {"novelty": .5, "confidence": .5, "relevance": .5, "impact": .5, "urgency": .5, "knowledge_gap": .5, "investigation_cost": .0}
    vals[factor] = .9 if high else .1
    return IntelligencePrioritizer().score(PriorityCandidate(cid, "lab", **vals))


def test_component_evidence_is_persisted():
    store = PriorityLearningStore()
    try:
        e = PriorityFeedbackEngine(store)
        d = dec("x", "impact", True)
        e.record_decision_outcome(d, "completed")
        assert store.list()[0].components["impact"] == .9
    finally:
        store.close()


def test_insufficient_evidence_produces_no_proposal():
    store = PriorityLearningStore()
    try:
        e = PriorityFeedbackEngine(store)
        e.record_decision_outcome(dec("a", "impact", True), "completed")
        e.record_decision_outcome(dec("b", "impact", False), "failed")
        assert AdaptivePrioritizationEngine(store).propose() == ()
    finally:
        store.close()


def test_strong_association_produces_bounded_proposal_without_mutation():
    store = PriorityLearningStore()
    try:
        e = PriorityFeedbackEngine(store)
        for i in range(3):
            e.record_decision_outcome(dec(f"h{i}", "impact", True), "completed")
            e.record_decision_outcome(dec(f"l{i}", "impact", False), "failed")
        engine = AdaptivePrioritizationEngine(store)
        proposals = engine.propose()
        impact = next(p for p in proposals if p.factor == "impact")
        assert impact.direction == "INCREASE"
        assert abs(impact.delta) <= .05
        assert impact.proposed_weight != impact.current_weight
        assert AdaptivePrioritizationEngine(store).weights["impact"] == .20
    finally:
        store.close()


def test_negative_association_can_propose_decrease():
    store = PriorityLearningStore()
    try:
        e = PriorityFeedbackEngine(store)
        for i in range(3):
            e.record_decision_outcome(dec(f"h{i}", "urgency", True), "failed")
            e.record_decision_outcome(dec(f"l{i}", "urgency", False), "completed")
        p = next(p for p in AdaptivePrioritizationEngine(store).propose() if p.factor == "urgency")
        assert p.direction == "DECREASE"
    finally:
        store.close()
