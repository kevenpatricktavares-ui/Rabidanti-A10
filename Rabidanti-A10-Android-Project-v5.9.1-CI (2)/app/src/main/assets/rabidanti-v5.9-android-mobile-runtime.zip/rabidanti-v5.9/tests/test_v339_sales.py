import tempfile
from stage_artifact_store import StageArtifactStore
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_sales

def setup(td): return StageArtifactStore(td + '/db.sqlite')

def test_sales_consumes_product_and_landing():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); store.put('p1','product',{'name':'Focus Course'}); store.put('p1','landing',{'title':'Focus Course','cta':'Start now'})
        reg=BusinessStageRegistry(store); register_builtin_sales(reg)
        out=reg.get('sales')(StageExecutionContext('p1','sales','sales',{},'3.39'))
        assert out['product_name']=='Focus Course'; assert out['funnel'][-1]=='purchase'; assert out['primary_cta']=='Start now'

def test_sales_requires_landing():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); store.put('p1','product',{'name':'X'})
        reg=BusinessStageRegistry(store); register_builtin_sales(reg)
        try: reg.get('sales')(StageExecutionContext('p1','sales','x',{},'3.39')); assert False
        except RuntimeError as e: assert 'landing artifact missing' in str(e)

def test_sales_does_not_claim_real_payment():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); store.put('p1','product',{'name':'X'}); store.put('p1','landing',{'title':'X'})
        reg=BusinessStageRegistry(store); register_builtin_sales(reg)
        out=reg.get('sales')(StageExecutionContext('p1','sales','x',{},'3.39'))
        assert 'No real payment' in out['limitations'][0]
