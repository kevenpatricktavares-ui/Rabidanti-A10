
from backend.jobs import JobManager, JobPriority, JobState
from backend.queue import ExecutionQueue, Worker


def test_priority_and_worker_execution():
    manager = JobManager()
    queue = ExecutionQueue(manager)
    low = manager.create("p", "a", "low", priority=JobPriority.LOW)
    high = manager.create("p", "a", "high", priority=JobPriority.HIGH)
    queue.enqueue(low); queue.enqueue(high)
    worker = Worker("worker-1", queue)
    seen = []
    first = worker.start_once({
        "high": lambda: seen.append("high") or "ok",
        "low": lambda: seen.append("low") or "ok",
    })
    assert first.stage == "high"
    assert seen == ["high"]
    assert worker.running is False


def test_retry_returns_to_queue_and_completes():
    manager = JobManager()
    queue = ExecutionQueue(manager)
    job = manager.create("p", "a", "render", max_retries=2)
    queue.enqueue(job)
    calls = {"n": 0}
    def flaky():
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("temporary")
        return "done"
    first = queue.process_one({"render": flaky})
    assert first.state == JobState.RETRY
    assert len(queue.pending()) == 1
    second = queue.process_one({"render": flaky})
    assert second.state == JobState.COMPLETED
    assert len(queue.pending()) == 0


def test_approval_job_waits_until_approved():
    manager = JobManager()
    queue = ExecutionQueue(manager)
    job = manager.create("p", "ads_agent", "publish", requires_approval=True)
    queue.enqueue(job)
    assert queue.pending() == []
    queue.approve_and_enqueue(job.id)
    assert len(queue.pending()) == 1
    assert queue.process_one({"publish": lambda: "published"}).state == JobState.COMPLETED


def test_missing_handler_fails_safely():
    manager = JobManager()
    queue = ExecutionQueue(manager)
    job = manager.create("p", "agent", "unknown")
    queue.enqueue(job)
    result = queue.process_one({})
    assert result.state == JobState.FAILED
    assert "no handler registered" in result.error
