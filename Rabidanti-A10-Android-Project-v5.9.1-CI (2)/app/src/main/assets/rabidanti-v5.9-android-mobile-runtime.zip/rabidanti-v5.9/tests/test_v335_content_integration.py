import tempfile
from pathlib import Path
from stage_artifact_store import StageArtifactStore
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_content

def test_content_consumes_product_artifact():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        store.put('p1', 'product', {'name':'Budget Mastery','product_type':'course','target_audience':'beginners','value_proposition':'learn to budget','limitations':['validation pending']})
        reg = BusinessStageRegistry(store)
        register_builtin_content(reg)
        out = reg.get('content')(StageExecutionContext('p1','content','learn budgeting',{},'3.35'))
        assert out['project_id'] == 'p1'
        assert out['source_stage'] == 'product'
        assert out['product_type'] == 'course'
        assert out['format'] == 'course_curriculum'
        assert len(out['outline']) >= 5

def test_content_requires_product_artifact():
    with tempfile.TemporaryDirectory() as td:
        store = StageArtifactStore(Path(td) / 'artifacts.db')
        reg = BusinessStageRegistry(store)
        register_builtin_content(reg)
        try:
            reg.get('content')(StageExecutionContext('missing','content','x',{},'3.35'))
            assert False
        except RuntimeError as e:
            assert 'product artifact missing' in str(e)
