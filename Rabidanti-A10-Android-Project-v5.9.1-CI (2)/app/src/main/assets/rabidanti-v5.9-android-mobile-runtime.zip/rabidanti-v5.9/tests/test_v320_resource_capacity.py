import tempfile
from pathlib import Path
import pytest
from durable_worker_queue import DurableWorkerQueue
from resource_capacity import ResourceCapacityMonitor

def make_queue(tmp):
    return DurableWorkerQueue(str(Path(tmp)/'db.sqlite'), lease_seconds=10)

def test_capacity_empty_ready():
    with tempfile.TemporaryDirectory() as d:
        q=make_queue(d); m=ResourceCapacityMonitor(q)
        r=m.analyze(4,0)
        assert r.available==4 and r.utilization==0 and r.recommendation=='IDLE_OR_READY'

def test_capacity_backlog_recommendation():
    with tempfile.TemporaryDirectory() as d:
        q=make_queue(d)
        q.enqueue({'handler':'x','data':1}, priority=1)
        m=ResourceCapacityMonitor(q)
        r=m.analyze(4,1)
        assert r.queued==1 and r.recommendation=='PROCESS_BACKLOG'

def test_capacity_saturation():
    with tempfile.TemporaryDirectory() as d:
        q=make_queue(d); q.enqueue({'handler':'x'}, priority=1)
        m=ResourceCapacityMonitor(q, saturation_threshold=.75)
        r=m.analyze(4,3)
        assert r.saturation and r.recommendation=='THROTTLE_OR_SCALE'

def test_capacity_validation():
    with tempfile.TemporaryDirectory() as d:
        q=make_queue(d); m=ResourceCapacityMonitor(q)
        with pytest.raises(ValueError): m.analyze(0,0)
        with pytest.raises(ValueError): m.analyze(2,3)
