import tempfile
import time
import unittest

from continuous_worker_runner import ContinuousWorkerRunner
from durable_worker_queue import DurableWorkerQueue
from worker_supervisor import WorkerSupervisor, WorkerStatus


class TestV315HealthRecovery(unittest.TestCase):
    def test_health_snapshot_reports_stale(self):
        with tempfile.NamedTemporaryFile(suffix='.db') as f:
            s = WorkerSupervisor(f.name, stale_after=0.01)
            s.register('w1', 1)
            time.sleep(0.02)
            health = s.health_snapshot()
            self.assertFalse(health['healthy'])
            self.assertIn('w1', health['stale_worker_ids'])
            self.assertEqual(health['counts']['STALE'], 1)
            s.close()

    def test_idle_stale_worker_can_be_recovered(self):
        with tempfile.NamedTemporaryFile(suffix='.db') as f:
            s = WorkerSupervisor(f.name, stale_after=0.01)
            s.register('w1', 1)
            time.sleep(0.02)
            s.stale()
            rec = s.recover_idle_stale('w1')
            self.assertEqual(rec.status, WorkerStatus.RUNNING)
            s.close()

    def test_active_stale_worker_is_not_revived(self):
        with tempfile.NamedTemporaryFile(suffix='.db') as f:
            s = WorkerSupervisor(f.name, stale_after=0.01)
            s.register('w1', 1)
            s.heartbeat('w1', active=1)
            time.sleep(0.02)
            s.stale()
            with self.assertRaises(RuntimeError):
                s.recover_idle_stale('w1')
            self.assertEqual(s.get('w1').status, WorkerStatus.STALE)
            s.close()

    def test_runner_health_contains_recovery(self):
        with tempfile.NamedTemporaryFile(suffix='.db') as f:
            q = DurableWorkerQueue(f.name)
            s = WorkerSupervisor(f.name, stale_after=0.01)
            r = ContinuousWorkerRunner(q, max_workers=1, poll_interval=0, supervisor=s)
            time.sleep(0.02)
            r.tick()
            health = r.health()
            self.assertTrue(health['supervisor'])
            self.assertGreaterEqual(health['recovered_workers'], 1)
            self.assertTrue(health['healthy'])
            r.close(); s.close(); q.close()


if __name__ == '__main__':
    unittest.main()
