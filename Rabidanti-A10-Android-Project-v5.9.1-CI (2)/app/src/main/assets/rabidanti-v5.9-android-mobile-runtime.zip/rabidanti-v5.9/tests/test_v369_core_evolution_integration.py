import pytest

from core_evolution_integration import CoreEvolutionIntegration


def test_full_controlled_cycle_through_core_adapter():
    core = CoreEvolutionIntegration()
    core.register_proposal("e1", "priority_strategy")
    core.begin_experiment("e1", "exp1")
    core.prepare_promotion("e1", "promo1")
    core.prepare_activation("e1")
    decision = core.activation_decision("e1", "v2")
    assert decision.allowed is True
    assert decision.requires_approval is True
    with pytest.raises(PermissionError):
        core.activate("e1", "v2")
    active = core.activate("e1", "v2", approval=True)
    assert active.active_version == "v2"
    core.review_health("e1", "DEGRADED")
    core.recommend_rollback("e1", "v1")
    with pytest.raises(PermissionError):
        core.rollback("e1")
    rolled = core.rollback("e1", approval=True)
    assert rolled.active_version == "v1"


def test_promotion_never_implicitly_activates():
    core = CoreEvolutionIntegration()
    core.register_proposal("e2", "strategy")
    core.begin_experiment("e2", "exp2")
    core.prepare_promotion("e2", "promo2")
    assert core.status("e2")["state"] == "PROMOTION_PENDING"


def test_activation_decision_blocks_wrong_state():
    core = CoreEvolutionIntegration()
    core.register_proposal("e3", "strategy")
    d = core.activation_decision("e3", "v2")
    assert d.allowed is False
    assert d.requires_approval is True


def test_history_remains_owned_by_controller():
    core = CoreEvolutionIntegration()
    r = core.register_proposal("e4", "strategy")
    core.begin_experiment("e4", "exp4")
    assert len(r.history) == 2
