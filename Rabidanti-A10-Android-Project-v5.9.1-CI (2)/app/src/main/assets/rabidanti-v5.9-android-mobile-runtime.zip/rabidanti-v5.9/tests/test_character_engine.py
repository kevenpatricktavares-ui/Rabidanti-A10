from backend.character import CharacterEngine

def test_character_creation_and_consistency():
    engine = CharacterEngine()
    character = engine.build({
        "name": "Lia",
        "role": "teacher",
        "personality": ["curious", "warm", "direct"],
        "values": ["clarity", "evidence"],
        "specialization": ["digital products"],
        "voice_style": "natural, warm and conversational",
        "visual_direction": "modern educational presenter",
        "product_knowledge": ["course curriculum"],
    })

    assert character.name == "Lia"
    assert character.role == "teacher"

    checks = engine.validate_consistency(character)
    assert checks["identity_present"]
    assert checks["personality_defined"]
    assert checks["real_person_impersonation_allowed"] is False

def test_invalid_role_is_rejected():
    try:
        CharacterEngine().build({"name": "X", "role": "unknown"})
        assert False
    except ValueError as exc:
        assert "role" in str(exc)
