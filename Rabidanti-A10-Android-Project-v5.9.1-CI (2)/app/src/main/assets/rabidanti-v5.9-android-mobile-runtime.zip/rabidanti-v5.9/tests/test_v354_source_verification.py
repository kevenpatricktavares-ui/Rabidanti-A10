import pytest
from source_verification import EvidenceFusionStore, SourceVerification, VerificationStatus


def test_no_evidence_is_insufficient():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    a = v.assess(claim_id='c1', claim='A claim')
    assert a.status is VerificationStatus.INSUFFICIENT
    assert a.confidence == 0


def test_two_independent_supporting_sources_can_verify():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    v.add_evidence(claim_id='c1', source_id='s1', supports=True, strength=1.0, independent_group='publisher-a')
    v.add_evidence(claim_id='c1', source_id='s2', supports=True, strength=1.0, independent_group='publisher-b')
    a = v.assess(claim_id='c1', claim='A claim')
    assert a.status is VerificationStatus.VERIFIED
    assert a.independent_support_groups == 2
    assert a.confidence > 0


def test_same_publisher_does_not_count_as_independent_twice():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    v.add_evidence(claim_id='c1', source_id='s1', supports=True, strength=1.0, independent_group='same')
    v.add_evidence(claim_id='c1', source_id='s2', supports=True, strength=1.0, independent_group='same')
    a = v.assess(claim_id='c1', claim='A claim')
    assert a.status is VerificationStatus.SUPPORTED
    assert a.independent_support_groups == 1


def test_conflict_is_preserved():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    v.add_evidence(claim_id='c1', source_id='s1', supports=True, strength=1.0, independent_group='a')
    v.add_evidence(claim_id='c1', source_id='s2', supports=False, strength=1.0, independent_group='b')
    a = v.assess(claim_id='c1', claim='A claim')
    assert a.status is VerificationStatus.CONTESTED
    assert a.supporting_count == 1 and a.contradicting_count == 1


def test_validation_rejects_bad_strength():
    v = SourceVerification(EvidenceFusionStore(':memory:'))
    with pytest.raises(ValueError):
        v.add_evidence(claim_id='c', source_id='s', supports=True, strength=1.2)
