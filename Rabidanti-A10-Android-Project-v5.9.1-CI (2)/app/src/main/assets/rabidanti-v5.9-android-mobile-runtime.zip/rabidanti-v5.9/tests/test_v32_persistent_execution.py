import tempfile
from pathlib import Path
from backend.persistence import SQLiteStore, ProjectRepository, JobRepository
from backend.jobs import JobPriority, JobState, PersistentJobManager
from backend.queue import PersistentExecutionQueue, PersistentWorker

def setup():
    td = tempfile.TemporaryDirectory()
    db = Path(td.name) / "test.db"
    store = SQLiteStore(str(db))
    ProjectRepository(store).create("p1", "u1", "Project")
    return td, JobRepository(store)

def test_job_survives_manager_restart():
    td, repo = setup()
    try:
        m1 = PersistentJobManager(repo)
        job = m1.create("p1", "agent", "stage", JobPriority.HIGH)
        assert repo.get(job.id)["state"] == "QUEUED"
        m2 = PersistentJobManager(repo)
        restored = m2.get(job.id)
        assert restored.project_id == "p1"
        assert restored.priority == JobPriority.HIGH
    finally: td.cleanup()

def test_running_job_recovers_after_restart():
    td, repo = setup()
    try:
        m1 = PersistentJobManager(repo)
        job = m1.create("p1", "agent", "stage")
        assert repo.claim(job.id, "dead-worker", 0)["state"] == "RUNNING"
        m2 = PersistentJobManager(repo)
        recovered = m2.get(job.id)
        assert recovered.state == JobState.RETRY
        assert recovered.retries == 1
        assert "recovered" in recovered.error
    finally: td.cleanup()

def test_approval_persists_and_blocks_until_approved():
    td, repo = setup()
    try:
        m = PersistentJobManager(repo)
        job = m.create("p1", "agent", "stage", requires_approval=True)
        q = PersistentExecutionQueue(m)
        calls = []
        first = q.process_one({"stage": lambda: calls.append(1)}, "w1")
        assert first.state == JobState.WAITING_APPROVAL and calls == []
        m2 = PersistentJobManager(repo)
        m2.approve(job.id)
        result = PersistentExecutionQueue(m2).process_one(
            {"stage": lambda: calls.append(1) or {"ok": True}}, "w1")
        assert result.state == JobState.COMPLETED and calls == [1]
    finally: td.cleanup()

def test_worker_persists_completion():
    td, repo = setup()
    try:
        m = PersistentJobManager(repo)
        job = m.create("p1", "agent", "stage")
        result = PersistentWorker("worker-a", PersistentExecutionQueue(m)).start_once(
            {"stage": lambda: "done"})
        assert result.id == job.id
        assert repo.get(job.id)["state"] == "COMPLETED"
    finally: td.cleanup()

def test_failure_requeues_until_retry_limit():
    td, repo = setup()
    try:
        m = PersistentJobManager(repo)
        job = m.create("p1", "agent", "stage", max_retries=1)
        q = PersistentExecutionQueue(m)
        def boom(): raise RuntimeError("boom")
        r1 = q.process_one({"stage": boom})
        assert r1.state == JobState.RETRY
        r2 = q.process_one({"stage": boom})
        assert r2.state == JobState.FAILED
    finally: td.cleanup()
