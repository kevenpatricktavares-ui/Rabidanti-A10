import tempfile
from pathlib import Path
from durable_worker_queue import DurableWorkerQueue
from workflow_engine import WorkflowEngine, WorkflowNode

def make():
    d=tempfile.TemporaryDirectory(); q=DurableWorkerQueue(str(Path(d.name)/'db.sqlite')); return d,q

def test_independent_branches_share_batch():
    d,q=make()
    try:
        e=WorkflowEngine(q)
        e.register([WorkflowNode('A'), WorkflowNode('B'), WorkflowNode('C',('A',)), WorkflowNode('D',('A',))])
        assert e.parallel_batches()==(('A','B'),('C','D'))
    finally:
        q.close(); d.cleanup()

def test_completed_root_allows_parallel_children():
    d,q=make()
    try:
        e=WorkflowEngine(q)
        e.register([WorkflowNode('A'),WorkflowNode('B',('A',)),WorkflowNode('C',('A',))])
        a=q.get_by_task_id('A'); q.claim(a.item_id,'w'); q.complete(a.item_id,'w','ok')
        assert e.parallel_batches()==(('B','C'),)
    finally:
        q.close(); d.cleanup()
