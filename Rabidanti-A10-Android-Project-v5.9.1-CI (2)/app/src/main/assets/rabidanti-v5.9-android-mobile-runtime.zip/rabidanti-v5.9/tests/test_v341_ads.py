import tempfile
from stage_artifact_store import StageArtifactStore
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_distribution, register_builtin_ads

def setup(td): return StageArtifactStore(td + '/db.sqlite')

def seed(store):
    store.put('p1','product',{'name':'Focus Course'})
    store.put('p1','sales',{'landing_title':'Focus Course','events':['landing_view','purchase']})

def test_distribution_builds_preparation_package():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); seed(store); reg=BusinessStageRegistry(store); register_builtin_distribution(reg)
        out=reg.get('distribution')(StageExecutionContext('p1','distribution','x',{},'3.40'))
        assert out['status']=='PREPARED'; assert 'web' in out['channels']; assert 'publication' in out['limitations'][0]

def test_ads_consumes_distribution_and_sales():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); seed(store); store.put('p1','distribution',{'channels':['web','social'],'assets':['web:x'],'sales_events':['landing_view','purchase']})
        reg=BusinessStageRegistry(store); register_builtin_ads(reg)
        out=reg.get('ads')(StageExecutionContext('p1','ads','x',{},'3.41'))
        assert out['status']=='READY_FOR_APPROVAL'; assert len(out['variants'])==3; assert out['budget']['approved'] is False

def test_ads_requires_distribution():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); seed(store); reg=BusinessStageRegistry(store); register_builtin_ads(reg)
        try: reg.get('ads')(StageExecutionContext('p1','ads','x',{},'3.41')); assert False
        except RuntimeError as e: assert 'distribution artifact missing' in str(e)

def test_ads_never_claims_spend_or_publication():
    with tempfile.TemporaryDirectory() as td:
        store=setup(td); seed(store); store.put('p1','distribution',{'channels':['web'],'assets':['web:x'],'sales_events':['purchase']})
        reg=BusinessStageRegistry(store); register_builtin_ads(reg)
        out=reg.get('ads')(StageExecutionContext('p1','ads','x',{},'3.41'))
        assert 'No ad is published or spent' in out['limitations'][0]
        assert out['budget']['amount'] is None
