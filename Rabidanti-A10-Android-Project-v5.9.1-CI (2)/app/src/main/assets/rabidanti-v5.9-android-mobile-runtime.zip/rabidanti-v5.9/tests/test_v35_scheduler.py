from datetime import datetime, timedelta, timezone
from scheduler import Scheduler, SchedulerLoop

def test_one_shot_runs_once():
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=Scheduler(lambda: now)
    s.add("once",now)
    seen=[]
    loop=SchedulerLoop(s,lambda tid: seen.append(tid))
    loop.tick(now)
    loop.tick(now)
    assert seen==["once"]
    assert s.tasks["once"].enabled is False

def test_recurring_task_reschedules():
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=Scheduler(lambda: now)
    s.add("repeat",now,interval_seconds=60)
    seen=[]
    loop=SchedulerLoop(s,lambda tid: seen.append(tid))
    loop.tick(now)
    assert seen==["repeat"]
    assert s.tasks["repeat"].run_at==now+timedelta(seconds=60)
    loop.tick(now)
    assert seen==["repeat"]

def test_cancel_prevents_execution():
    now=datetime(2026,1,1,tzinfo=timezone.utc)
    s=Scheduler(lambda: now)
    s.add("cancelled",now)
    s.cancel("cancelled")
    seen=[]
    SchedulerLoop(s,lambda tid: seen.append(tid)).tick(now)
    assert seen==[]

def test_invalid_interval_rejected():
    s=Scheduler()
    try:
        s.add("bad",datetime.now(timezone.utc),0)
    except ValueError:
        return
    assert False
