import pytest
from forward_experiment import ForwardExperiment, ForwardExperimentStore, ForwardExperimentEngine, ExperimentState
from experiment_promotion import ExperimentPromotionController, PromotionProposal


def make_promising():
    store = ForwardExperimentStore(); store.create(ForwardExperiment("e", "x", .2, .25))
    engine = ForwardExperimentEngine(store); engine.start("e")
    # Find enough deterministic assignments for both arms.
    i=0; controls=[]; treatments=[]
    while len(controls)<3 or len(treatments)<3:
        cid=f"c{i}"; i+=1; a=engine.assign("e",cid)
        (treatments if a.arm.value=="TREATMENT" else controls).append(cid)
    for cid in controls: engine.record("e",cid,"FAILED")
    for cid in treatments: engine.record("e",cid,"COMPLETED")
    return store, engine


def test_proposal_requires_promising_evidence():
    store=ForwardExperimentStore(); store.create(ForwardExperiment("e","x",.2,.25)); engine=ForwardExperimentEngine(store); engine.start("e")
    controller=ExperimentPromotionController(engine,{"x":.2})
    with pytest.raises(ValueError): controller.propose("e")


def test_propose_and_approve_are_explicit():
    store,engine=make_promising(); controller=ExperimentPromotionController(engine,{"x":.2})
    engine.complete_for_review("e")
    proposal=controller.propose("e")
    assert proposal.recommendation=="PROMISING_TREATMENT"
    # propose does not change state or weights
    assert store.get("e").state==ExperimentState.PROMOTION_PENDING
    assert controller.production_weights=={"x":.2}
    controller.approve_experiment("e")
    assert store.get("e").state==ExperimentState.APPROVED


def test_apply_requires_explicit_approval():
    store,engine=make_promising(); controller=ExperimentPromotionController(engine,{"x":.2})
    engine.complete_for_review("e"); proposal=controller.propose("e")
    with pytest.raises(PermissionError): controller.apply_explicit(proposal, explicit_approval=False)
    with pytest.raises(ValueError): controller.apply_explicit(proposal, explicit_approval=True)


def test_apply_returns_new_weights_without_mutating_controller():
    store,engine=make_promising(); controller=ExperimentPromotionController(engine,{"x":.2})
    engine.complete_for_review("e"); proposal=controller.propose("e"); controller.approve_experiment("e")
    updated=controller.apply_explicit(proposal, explicit_approval=True)
    assert updated=={"x":.25}
    assert controller.production_weights=={"x":.2}


def test_factor_must_exist_in_production():
    store,engine=make_promising(); controller=ExperimentPromotionController(engine,{"other":.2})
    engine.complete_for_review("e")
    with pytest.raises(ValueError): controller.propose("e")


def test_proposal_snapshot_mismatch_is_rejected():
    store,engine=make_promising(); controller=ExperimentPromotionController(engine,{"x":.2})
    engine.complete_for_review("e"); proposal=controller.propose("e"); controller.approve_experiment("e")
    altered=PromotionProposal("e","x",.2,.30,"PROMISING_TREATMENT",6,"tampered")
    with pytest.raises(ValueError): controller.apply_explicit(altered, explicit_approval=True)
