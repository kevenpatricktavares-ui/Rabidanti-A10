import tempfile
from pathlib import Path
from business_stage_execution import BusinessStageRegistry, StageExecutionContext, register_builtin_render
from stage_artifact_store import StageArtifactStore

def _registry(td, review_status="PASS"):
    store=StageArtifactStore(Path(td)/"a.db")
    store.put("p1","content",{"title":"Test Product","audience":"beginners","format":"ebook","outline":["One","Two","Three"]})
    store.put("p1","review",{"status":review_status,"score":100 if review_status=="PASS" else 25})
    reg=BusinessStageRegistry(store); register_builtin_render(reg, Path(td)/"out")
    return reg

def test_render_requires_review_pass():
    with tempfile.TemporaryDirectory() as td:
        reg=_registry(td,"BLOCKED")
        try: reg.get("render")(StageExecutionContext("p1","render","x",{},"3.37")); assert False
        except RuntimeError as e: assert "review status" in str(e)

def test_render_creates_real_pdf():
    with tempfile.TemporaryDirectory() as td:
        reg=_registry(td,"PASS")
        out=reg.get("render")(StageExecutionContext("p1","render","x",{},"3.37"))
        assert out["status"]=="COMPLETED"
        assert out["format"]=="pdf"
        path=Path(out["output_path"])
        assert path.exists() and path.stat().st_size>500
        assert path.read_bytes()[:4]==b"%PDF"

def test_render_requires_review_artifact():
    with tempfile.TemporaryDirectory() as td:
        store=StageArtifactStore(Path(td)/"a.db")
        store.put("p1","content",{"title":"T","outline":["a","b","c"],"audience":"x","format":"ebook"})
        reg=BusinessStageRegistry(store); register_builtin_render(reg, Path(td)/"out")
        try: reg.get("render")(StageExecutionContext("p1","render","x",{},"3.37")); assert False
        except RuntimeError as e: assert "review artifact missing" in str(e)
