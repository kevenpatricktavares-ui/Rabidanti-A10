import tempfile
from pathlib import Path
import pytest
from durable_worker_queue import DurableWorkerQueue
from continuous_worker_runner import ContinuousWorkerRunner

def make():
    d=tempfile.TemporaryDirectory(); q=DurableWorkerQueue(str(Path(d.name)/"db.sqlite"), lease_seconds=10); return d,q

def test_dependency_blocks_until_completed():
    d,q=make()
    try:
        dep=q.enqueue({"handler":"noop"}, task_id="A")
        child=q.enqueue({"handler":"noop"}, task_id="B", dependencies=["A"])
        assert q.ready()==[dep]
        assert q.get(child.item_id).dependencies==("A",)
    finally: d.cleanup()

def test_dependency_unlocks_after_completion():
    d,q=make()
    try:
        dep=q.enqueue({"handler":"noop"}, task_id="A")
        child=q.enqueue({"handler":"noop"}, task_id="B", dependencies=["A"])
        claimed=q.claim(dep.item_id,"w")
        q.complete(dep.item_id,"w","ok")
        assert [x.task_id for x in q.ready()]==["B"]
    finally: d.cleanup()

def test_missing_dependency_stays_blocked():
    d,q=make()
    try:
        child=q.enqueue({"handler":"noop"}, task_id="B", dependencies=["missing"])
        assert q.ready()==[]
    finally: d.cleanup()

def test_self_dependency_rejected():
    d,q=make()
    try:
        with pytest.raises(ValueError): q.enqueue({"handler":"noop"}, task_id="A", dependencies=["A"])
    finally: d.cleanup()

def test_dependencies_persist_restart():
    d,q=make()
    path=q.db_path
    try:
        q.enqueue({"handler":"noop"}, task_id="A")
        q.enqueue({"handler":"noop"}, task_id="B", dependencies=["A"])
        q.close()
        q2=DurableWorkerQueue(path, lease_seconds=10)
        try:
            item=next(x for x in q2._conn.execute("SELECT * FROM queue_items WHERE task_id='B'").fetchall())
            assert q2.get(item["item_id"]).dependencies==("A",)
            assert q2.ready()[0].task_id=="A"
        finally: q2.close()
    finally:
        d.cleanup()
