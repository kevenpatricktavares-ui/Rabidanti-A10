import pytest
from evidence_decision_integration import EvidenceToDecisionIntegration, EvidenceDecision
from evolution_evidence_fusion import EvidenceItem, EvolutionEvidenceFusion
from evolution_evidence_runtime import EvolutionEvidenceRuntime
from evolution_evidence_store import EvolutionEvidenceStore


def strong_fusion():
    f = EvolutionEvidenceFusion()
    f.add(EvidenceItem("e1", .95, .95, .90))
    f.add(EvidenceItem("e2", .92, .90, .85))
    return f.fuse("f1", ["e1", "e2"], pattern_score=.92)


def test_strong_evidence_is_persisted_and_requires_approval():
    store = EvolutionEvidenceStore()
    runtime = EvolutionEvidenceRuntime(EvidenceToDecisionIntegration(), store)
    result = runtime.evaluate("p1", strong_fusion(), reversibility=.90, risk=.10, cost=.10, event_id="ev1")
    assert result.decision == EvidenceDecision.APPROVAL_REQUIRED.value
    assert result.approval_required is True
    saved = store.latest("p1")
    assert saved.event_id == "ev1"
    assert saved.fusion_id == "f1"
    assert saved.approval_required is True
    assert saved.evidence_count == 2


def test_low_independence_becomes_investigate():
    f = EvolutionEvidenceFusion()
    f.add(EvidenceItem("e1", .95, .95, .10))
    f.add(EvidenceItem("e2", .90, .90, .10))
    fusion = f.fuse("f-low", ["e1", "e2"], pattern_score=.95)
    store = EvolutionEvidenceStore()
    result = EvolutionEvidenceRuntime(store=store).evaluate(
        "p-low", fusion, reversibility=.9, risk=.1, cost=.1, event_id="ev-low"
    )
    assert result.decision == EvidenceDecision.INVESTIGATE.value
    assert result.approval_required is False


def test_duplicate_event_is_rejected_without_second_record():
    store = EvolutionEvidenceStore()
    runtime = EvolutionEvidenceRuntime(store=store)
    fusion = strong_fusion()
    runtime.evaluate("p1", fusion, reversibility=.9, risk=.1, cost=.1, event_id="ev1")
    with pytest.raises(ValueError, match="duplicate event_id"):
        runtime.evaluate("p1b", fusion, reversibility=.9, risk=.1, cost=.1, event_id="ev1")
    assert len(store.list_events()) == 1


def test_invalid_factors_are_rejected():
    store = EvolutionEvidenceStore()
    runtime = EvolutionEvidenceRuntime(store=store)
    with pytest.raises(ValueError):
        runtime.evaluate("p1", strong_fusion(), reversibility=1.2, risk=.1, cost=.1, event_id="ev1")


def test_activation_and_deploy_are_not_authorized():
    runtime = EvolutionEvidenceRuntime(store=EvolutionEvidenceStore())
    with pytest.raises(PermissionError):
        runtime.activate("p1")
    with pytest.raises(PermissionError):
        runtime.deploy("p1")


def test_empty_identifiers_are_rejected():
    runtime = EvolutionEvidenceRuntime(store=EvolutionEvidenceStore())
    with pytest.raises(ValueError):
        runtime.evaluate("", strong_fusion(), reversibility=.9, risk=.1, cost=.1, event_id="e")
    with pytest.raises(ValueError):
        runtime.evaluate("p", strong_fusion(), reversibility=.9, risk=.1, cost=.1, event_id="")
