import pytest
from lab_prototype_manager import LabPrototypeManager

def setup(tmp_path):
    m=LabPrototypeManager(str(tmp_path/'lab.sqlite')); m.create('proto1','project1','Safe parser','v1 design',['artifact:a','artifact:a']); return m

def test_create_version_persists_and_deduplicates_artifacts(tmp_path):
    m=setup(tmp_path); assert m.version('proto1')['artifact_refs']==['artifact:a']
    m.create_version('proto1','v2 design',['artifact:b'])
    assert LabPrototypeManager(str(tmp_path/'lab.sqlite')).version('proto1')['version']==2

def test_acceptance_tests_gate_review(tmp_path):
    m=setup(tmp_path); m.transition('proto1','TESTING','e1')
    m.add_test('t1','proto1',1,'Parser handles empty input',['returns safe error'])
    with pytest.raises(ValueError,match='must PASS'): m.transition('proto1','READY_FOR_REVIEW','e2')
    m.record_test('t1','PASS','Returned documented validation error')
    assert m.transition('proto1','READY_FOR_REVIEW','e3').status=='READY_FOR_REVIEW'

def test_integration_requires_proposal_and_explicit_approval(tmp_path):
    m=setup(tmp_path); m.transition('proto1','TESTING','e1'); m.add_test('t1','proto1',1,'Basic test',['expected result']); m.record_test('t1','PASS','passed'); m.transition('proto1','READY_FOR_REVIEW','e2')
    m.propose_integration('pr1','proto1',1,'Benefit','Risk of regression','Rollback to previous version')
    with pytest.raises(PermissionError): m.transition('proto1','INTEGRATED','e3')
    m.decide_proposal('pr1','APPROVED')
    assert m.transition('proto1','INTEGRATED','e4',human_approved=True).status=='INTEGRATED'

def test_cannot_integrate_without_approved_proposal(tmp_path):
    m=setup(tmp_path); m.transition('proto1','TESTING','e1'); m.add_test('t1','proto1',1,'Basic test',['works']); m.record_test('t1','PASS','passed'); m.transition('proto1','READY_FOR_REVIEW','e2')
    with pytest.raises(ValueError,match='approved integration proposal'): m.transition('proto1','INTEGRATED','e3',human_approved=True)

def test_invalid_status_and_duplicates_blocked(tmp_path):
    m=setup(tmp_path)
    with pytest.raises(ValueError,match='duplicate'): m.create('proto1','p','dup','desc')
    with pytest.raises(ValueError,match='unknown status'): m.transition('proto1','MAGIC','e1')

def test_report_marks_not_integrated_by_default(tmp_path):
    m=setup(tmp_path); r=m.report('proto1'); assert not r['integration_authorized'] and len(r['versions'])==1
