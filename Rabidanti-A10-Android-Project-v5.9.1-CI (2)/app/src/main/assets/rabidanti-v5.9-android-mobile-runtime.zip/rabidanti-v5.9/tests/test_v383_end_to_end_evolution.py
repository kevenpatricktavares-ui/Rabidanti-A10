from backend.evolution_controller import EvolutionController, EvolutionState
from evolution_end_to_end import EndToEndEvolutionCycle
from evolution_evidence_runtime import EvolutionEvidenceRuntime
from evolution_evidence_store import EvolutionEvidenceStore
from evolution_evidence_fusion import EvolutionEvidenceFusion


def runtime(tmp_path):
    return EvolutionEvidenceRuntime(store=EvolutionEvidenceStore(str(tmp_path / "evidence.sqlite")))


def strong_fusion():
    f = EvolutionEvidenceFusion()
    f.add(type("I", (), {"evidence_id":"e1", "confidence":0.98, "relevance":0.98, "independence":1.0})())
    f.add(type("I", (), {"evidence_id":"e2", "confidence":0.98, "relevance":0.98, "independence":1.0})())
    return f.fuse("f1", ["e1", "e2"], pattern_score=0.98)


def test_register_persists_decision_and_does_not_auto_activate(tmp_path):
    c = EndToEndEvolutionCycle(runtime(tmp_path))
    r = c.evaluate_and_register(evolution_id="ev1", proposal_id="p1", strategy_key="priority",
                               fusion=strong_fusion(), reversibility=.95, risk=.05, cost=.05, event_id="evt1")
    assert r.decision == "APPROVAL_REQUIRED"
    assert r.controller_state == "PROPOSED"
    assert c.controller.get("ev1").state is EvolutionState.PROPOSED


def test_full_controlled_cycle(tmp_path):
    c = EndToEndEvolutionCycle(runtime(tmp_path))
    c.evaluate_and_register(evolution_id="ev2", proposal_id="p2", strategy_key="priority",
                            fusion=strong_fusion(), reversibility=.95, risk=.05, cost=.05, event_id="evt2")
    assert c.start_experiment("ev2", "exp2").state is EvolutionState.EXPERIMENTING
    assert c.promote("ev2", "promo2").state is EvolutionState.PROMOTION_PENDING
    assert c.request_activation("ev2").state is EvolutionState.ACTIVATION_PENDING
    assert c.approve_activation("ev2", "v2").state is EvolutionState.ACTIVE
    assert c.health_review("ev2", "DEGRADED").state is EvolutionState.HEALTH_REVIEW
    assert c.recommend_rollback("ev2", "v1").state is EvolutionState.ROLLBACK_RECOMMENDED
    assert c.approve_rollback("ev2").state is EvolutionState.ROLLED_BACK
    assert c.controller.get("ev2").active_version == "v1"


def test_activation_requires_controller_approval(tmp_path):
    c = EndToEndEvolutionCycle(runtime(tmp_path))
    c.evaluate_and_register(evolution_id="ev3", proposal_id="p3", strategy_key="x",
                            fusion=strong_fusion(), reversibility=.95, risk=.05, cost=.05, event_id="evt3")
    c.start_experiment("ev3", "exp3"); c.promote("ev3", "promo3"); c.request_activation("ev3")
    try:
        c.controller.activate("ev3", "v3", approval=False)
        assert False
    except PermissionError:
        pass


def test_rollback_requires_controller_approval(tmp_path):
    c = EndToEndEvolutionCycle(runtime(tmp_path))
    c.evaluate_and_register(evolution_id="ev4", proposal_id="p4", strategy_key="x",
                            fusion=strong_fusion(), reversibility=.95, risk=.05, cost=.05, event_id="evt4")
    c.start_experiment("ev4", "exp4"); c.promote("ev4", "promo4"); c.request_activation("ev4"); c.approve_activation("ev4", "v4")
    c.health_review("ev4", "DEGRADED"); c.recommend_rollback("ev4", "v3")
    try:
        c.controller.apply_rollback("ev4", approval=False)
        assert False
    except PermissionError:
        pass


def test_investigate_stays_proposed(tmp_path):
    f = EvolutionEvidenceFusion()
    f.add(type("I", (), {"evidence_id":"e1", "confidence":.4, "relevance":.4, "independence":.2})())
    f.add(type("I", (), {"evidence_id":"e2", "confidence":.4, "relevance":.4, "independence":.2})())
    fusion = f.fuse("fw", ["e1", "e2"], pattern_score=.2)
    c = EndToEndEvolutionCycle(runtime(tmp_path))
    r = c.evaluate_and_register(evolution_id="ev5", proposal_id="p5", strategy_key="x",
                                fusion=fusion, reversibility=.4, risk=.7, cost=.8, event_id="evt5")
    assert r.decision == "INVESTIGATE"
    assert r.controller_state == "PROPOSED"


def test_reject_is_terminal(tmp_path):
    f = EvolutionEvidenceFusion()
    f.add(type("I", (), {"evidence_id":"e1", "confidence":.98, "relevance":.98, "independence":1.0})())
    f.add(type("I", (), {"evidence_id":"e2", "confidence":.98, "relevance":.98, "independence":1.0})())
    fusion = f.fuse("fb", ["e1", "e2"], pattern_score=.98)
    c = EndToEndEvolutionCycle(runtime(tmp_path))
    r = c.evaluate_and_register(evolution_id="ev6", proposal_id="p6", strategy_key="x",
                                fusion=fusion, reversibility=0.0, risk=1.0, cost=1.0, event_id="evt6")
    assert r.decision == "REJECT"
    assert r.controller_state == "REJECTED"


def test_external_controller_can_be_injected(tmp_path):
    controller = EvolutionController()
    c = EndToEndEvolutionCycle(runtime(tmp_path), controller=controller)
    r = c.evaluate_and_register(evolution_id="ev7", proposal_id="p7", strategy_key="x",
                                fusion=strong_fusion(), reversibility=.95, risk=.05, cost=.05, event_id="evt7")
    assert controller.get("ev7").state is EvolutionState.PROPOSED
    assert r.evolution_id == "ev7"
