import tempfile
from pathlib import Path
import pytest
from durable_worker_queue import DurableWorkerQueue
from resource_capacity import ResourceCapacityMonitor
from capacity_intelligence import CapacityIntelligence
from execution_planner import ExecutionPlanner, PlannedItem

def make():
    d=tempfile.TemporaryDirectory(); q=DurableWorkerQueue(str(Path(d.name)/"db.sqlite"), lease_seconds=10)
    ci=CapacityIntelligence(ResourceCapacityMonitor(q)); ci.observe(3,0,now=0)
    return d, ExecutionPlanner(ci)

def test_priority_and_capacity():
    d,p=make()
    try:
        items=[PlannedItem("a",2),PlannedItem("b",9),PlannedItem("c",5),PlannedItem("d",8)]
        plan=p.plan(items,2,now=1)
        assert plan.selected==("b","d") and plan.reason=="CAPACITY_BOUND"
    finally: d.cleanup()

def test_dependencies_and_readiness():
    d,p=make()
    try:
        items=[PlannedItem("a",10,False),PlannedItem("b",8,True,False),PlannedItem("c",1)]
        plan=p.plan(items,2,now=1)
        assert plan.selected==("c",) and set(plan.deferred)=={"a","b"}
    finally: d.cleanup()

def test_zero_capacity():
    d,p=make()
    try:
        plan=p.plan([PlannedItem("a",1)],0,now=1)
        assert plan.selected==() and plan.reason=="NO_CAPACITY"
    finally: d.cleanup()

def test_invalid_capacity():
    d,p=make()
    try:
        with pytest.raises(ValueError): p.plan([], -1)
    finally: d.cleanup()

def test_plan_does_not_mutate_items():
    d,p=make()
    try:
        items=[PlannedItem("z",3),PlannedItem("a",3)]
        p.plan(items,1,now=1)
        assert [x.item_id for x in items]==["z","a"]
    finally: d.cleanup()
