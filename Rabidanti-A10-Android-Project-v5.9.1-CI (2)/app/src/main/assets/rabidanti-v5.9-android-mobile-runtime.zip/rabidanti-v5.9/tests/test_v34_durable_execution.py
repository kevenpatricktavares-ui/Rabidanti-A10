from datetime import datetime, timedelta, timezone
import pytest
from durable_execution import DurableExecutionCoordinator, DurableJob

def test_expired_lease_is_recovered():
    c=DurableExecutionCoordinator(lease_seconds=10)
    c.add(DurableJob("j1", max_attempts=3))
    j=c.claim("w1", datetime.now(timezone.utc)-timedelta(seconds=20))
    assert j and j.state=="RUNNING"
    recovered=c.recover_expired(datetime.now(timezone.utc))
    assert recovered==["j1"]
    assert c.jobs["j1"].state=="RETRY"
    assert c.jobs["j1"].worker_id is None

def test_approval_blocks_claim_until_approved():
    c=DurableExecutionCoordinator()
    c.add(DurableJob("j2", requires_approval=True))
    assert c.claim("w1") is None
    assert c.jobs["j2"].state=="WAITING_APPROVAL"
    c.approve("j2")
    assert c.claim("w1") is not None

def test_only_owner_can_complete():
    c=DurableExecutionCoordinator()
    c.add(DurableJob("j3"))
    c.claim("w1")
    with pytest.raises(PermissionError):
        c.complete("j3","w2")
    c.complete("j3","w1")
    assert c.jobs["j3"].state=="COMPLETED"

def test_retry_limit_leads_to_failed():
    c=DurableExecutionCoordinator()
    c.add(DurableJob("j4", max_attempts=1))
    c.claim("w1")
    c.fail("j4","w1","boom")
    assert c.jobs["j4"].state=="FAILED"
