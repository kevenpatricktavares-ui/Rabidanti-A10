from fastapi.testclient import TestClient

from backend.api.app import AppState


def make_client(tmp_path):
    s = AppState(str(tmp_path / "rabidanti.db"))
    import importlib
    mod = importlib.import_module("backend.api.app")
    mod.state = s
    return TestClient(mod.app), s


def register_login(client, username):
    assert client.post('/auth/register', json={'username': username, 'password':'strong-pass'}).status_code == 201
    r = client.post('/auth/login', json={'username': username, 'password':'strong-pass'})
    assert r.status_code == 200
    return r.json()['access_token']


def auth(token): return {'Authorization': f'Bearer {token}'}


def test_project_and_job_survive_application_restart(tmp_path):
    client, state = make_client(tmp_path)
    token = register_login(client, 'alice')
    r = client.post('/projects', json={'name':'Persistent Project'}, headers=auth(token)); assert r.status_code == 201
    project_id = r.json()['id']
    r = client.post(f'/projects/{project_id}/jobs', json={'agent':'research','stage':'research','requires_approval':True}, headers=auth(token)); assert r.status_code == 201
    job_id = r.json()['id']

    import importlib
    mod = importlib.import_module("backend.api.app")
    mod.state = AppState(str(tmp_path / 'rabidanti.db'))
    client = TestClient(mod.app)
    r = client.post('/auth/login', json={'username':'alice','password':'strong-pass'}); assert r.status_code == 200
    token2 = r.json()['access_token']
    assert client.get('/projects', headers=auth(token2)).json()[0]['id'] == project_id
    assert client.get(f'/projects/{project_id}/jobs/{job_id}', headers=auth(token2)).json()['state'] == 'WAITING_APPROVAL'
    assert client.post(f'/projects/{project_id}/jobs/{job_id}/approve', headers=auth(token2)).json()['state'] == 'QUEUED'


def test_cross_project_isolation(tmp_path):
    client, _ = make_client(tmp_path)
    a = register_login(client, 'alice')
    b = register_login(client, 'bruno')
    pa = client.post('/projects', json={'name':'Alice'}, headers=auth(a)).json()['id']
    pb = client.post('/projects', json={'name':'Bruno'}, headers=auth(b)).json()['id']
    assert client.get(f'/projects/{pb}', headers=auth(a)).status_code == 404
    job = client.post(f'/projects/{pb}/jobs', json={'agent':'x','stage':'x'}, headers=auth(b)).json()
    assert client.get(f'/projects/{pb}/jobs/{job["id"]}', headers=auth(a)).status_code == 404
    assert client.post(f'/projects/{pb}/jobs/{job["id"]}/approve', headers=auth(a)).status_code == 404
    assert pa != pb


def test_session_persists_and_revocation_survives_restart(tmp_path):
    client, _ = make_client(tmp_path)
    token = register_login(client, 'alice')
    assert client.get('/me', headers=auth(token)).status_code == 200
    client.post('/auth/logout', headers=auth(token))
    import importlib
    mod = importlib.import_module("backend.api.app")
    mod.state = AppState(str(tmp_path / 'rabidanti.db'))
    client = TestClient(mod.app)
    assert client.get('/me', headers=auth(token)).status_code == 401


def test_connector_permissions_survive_restart(tmp_path):
    client, _ = make_client(tmp_path)
    token = register_login(client, 'alice')
    r = client.post('/connectors', json={'id':'ads-1','name':'Ads','provider':'demo','permissions':['READ','SPEND']}, headers=auth(token))
    assert r.status_code == 201
    import importlib
    mod = importlib.import_module("backend.api.app")
    mod.state = AppState(str(tmp_path / 'rabidanti.db'))
    client = TestClient(mod.app)
    token2 = client.post('/auth/login', json={'username':'alice','password':'strong-pass'}).json()['access_token']
    rows = client.get('/connectors', headers=auth(token2)).json()
    assert rows[0]['id'] == 'ads-1'
    assert 'SPEND' in rows[0]['permissions']


def test_active_session_audit_and_approval_history_survive_restart(tmp_path):
    client, _ = make_client(tmp_path)
    token = register_login(client, 'alice')
    project = client.post('/projects', json={'name':'Audit'}, headers=auth(token)).json()
    job = client.post(f'/projects/{project["id"]}/jobs', json={'agent':'a','stage':'research','requires_approval':True}, headers=auth(token)).json()
    import importlib
    mod = importlib.import_module('backend.api.app')
    mod.state = AppState(str(tmp_path / 'rabidanti.db'))
    client = TestClient(mod.app)
    assert client.get('/me', headers=auth(token)).status_code == 200
    token2 = client.post('/auth/login', json={'username':'alice','password':'strong-pass'}).json()['access_token']
    assert client.post(f'/projects/{project["id"]}/jobs/{job["id"]}/approve', headers=auth(token2)).status_code == 200
    history = client.get('/approvals/history', headers=auth(token2)).json()
    assert history[-1]['job_id'] == job['id']
    assert history[-1]['decision'] == 'APPROVED'
    dashboard = client.get('/dashboard', headers=auth(token2)).json()
    assert dashboard['projects'][0]['id'] == project['id']


def test_non_admin_cannot_read_audit_and_admin_can(tmp_path):
    client, state = make_client(tmp_path)
    token = register_login(client, 'alice')
    assert client.get('/audit', headers=auth(token)).status_code == 403
    state.store.execute("UPDATE users SET role='admin' WHERE username='alice'")
    assert client.get('/audit', headers=auth(token)).status_code == 200
