import tempfile
from pathlib import Path

import pytest

from capacity_intelligence import CapacityIntelligence
from continuous_worker_runner import ContinuousWorkerRunner
from durable_worker_queue import DurableWorkerQueue
from experiment_execution_planner import ExperimentAwarePriorityExecutionPlanner
from forward_experiment import ForwardExperiment, ForwardExperimentEngine, ForwardExperimentStore, Arm
from intelligence_prioritization import IntelligencePrioritizer, PriorityCandidate
from resource_capacity import ResourceCapacityMonitor
from execution_planner import PlannedItem


def setup(tmp):
    q = DurableWorkerQueue(str(Path(tmp) / "db.sqlite"), lease_seconds=10)
    ci = CapacityIntelligence(ResourceCapacityMonitor(q))
    ci.observe(1, 0)
    store = ForwardExperimentStore(str(Path(tmp) / "exp.sqlite"))
    eng = ForwardExperimentEngine(store)
    store.create(ForwardExperiment("exp", "impact", .20, .80, .5))
    eng.start("exp")
    planner = ExperimentAwarePriorityExecutionPlanner(ci, eng)
    return q, ci, store, eng, planner


def decisions(ids):
    p = IntelligencePrioritizer()
    return [p.score(PriorityCandidate(i, "lab", novelty=.2, confidence=.2, relevance=.2, impact=.9, urgency=.2, knowledge_gap=.2)) for i in ids]


def test_assignment_persists_and_treatment_changes_only_experimental_score():
    with tempfile.TemporaryDirectory() as d:
        q, ci, store, eng, planner = setup(d)
        a = q.enqueue({"handler": "x", "data": 1}, priority=1, task_id="a")
        b = q.enqueue({"handler": "x", "data": 2}, priority=1, task_id="b")
        ds = decisions([a.item_id, b.item_id])
        plan = planner.plan_with_experiment([PlannedItem(a.item_id,1), PlannedItem(b.item_id,1)], 2, ds, "exp")
        assert set(plan.selected) == {a.item_id, b.item_id}
        for i in (a.item_id, b.item_id):
            assert eng.assign("exp", i) == store.assignment("exp", i)


def test_dependencies_and_capacity_remain_authoritative():
    with tempfile.TemporaryDirectory() as d:
        q, ci, store, eng, planner = setup(d)
        blocked = q.enqueue({"handler":"x"}, priority=100, task_id="blocked", dependencies=["missing"])
        ready = q.enqueue({"handler":"x"}, priority=1, task_id="ready")
        ds = decisions([blocked.item_id, ready.item_id])
        plan = planner.plan_with_experiment([
            PlannedItem(blocked.item_id,100,True,False), PlannedItem(ready.item_id,1,True,True)
        ], 1, ds, "exp")
        assert plan.selected == (ready.item_id,)


def test_runner_records_actual_outcome_not_planning():
    with tempfile.TemporaryDirectory() as d:
        q, ci, store, eng, planner = setup(d)
        item = q.enqueue({"handler":"capture","data":"ok"}, priority=1, task_id="job")
        runner = ContinuousWorkerRunner(
            q, max_workers=1, poll_interval=0, capacity_intelligence=ci,
            execution_planner=planner, priority_decisions_provider=lambda items: decisions([i.item_id for i in items]),
            experiment_engine=eng, experiment_id="exp",
        )
        seen=[]
        runner.register_handler("capture", lambda data: seen.append(data))
        runner.run(max_ticks=1)
        assert seen == ["ok"]
        obs = store.observations("exp")
        assert len(obs) == 1 and obs[0].candidate_id == item.item_id and obs[0].outcome == "COMPLETED"
        runner.close()


def test_runner_rejects_experiment_without_experiment_aware_planner():
    with tempfile.TemporaryDirectory() as d:
        q, ci, store, eng, _ = setup(d)
        from priority_execution_planner import PriorityAwareExecutionPlanner
        with pytest.raises(ValueError):
            ContinuousWorkerRunner(q, capacity_intelligence=ci, execution_planner=PriorityAwareExecutionPlanner(ci), experiment_engine=eng, experiment_id="exp")


def test_no_experiment_keeps_existing_priority_behavior():
    with tempfile.TemporaryDirectory() as d:
        q, ci, store, eng, planner = setup(d)
        a = q.enqueue({"handler":"x"}, priority=9, task_id="a")
        b = q.enqueue({"handler":"x"}, priority=1, task_id="b")
        base = planner.plan([PlannedItem(a.item_id,a.priority), PlannedItem(b.item_id,b.priority)], 1)
        assert base.selected == (a.item_id,)
