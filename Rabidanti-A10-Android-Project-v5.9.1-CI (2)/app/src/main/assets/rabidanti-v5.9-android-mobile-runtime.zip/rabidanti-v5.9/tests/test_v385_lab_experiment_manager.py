import pytest
from lab_experiment_manager import LabExperimentManager

def setup(tmp_path):
    m=LabExperimentManager(tmp_path/'lab.sqlite3')
    m.create('e1','p1','Prototype search','A local index improves retrieval','Compare ranked retrieval on fixed examples',['at least 8/10 relevant results'])
    return m

def test_create_and_persist(tmp_path):
    m=setup(tmp_path); assert m.get('e1').status=='PLANNED'
    assert LabExperimentManager(tmp_path/'lab.sqlite3').get('e1').success_criteria==('at least 8/10 relevant results',)

def test_entries_and_report(tmp_path):
    m=setup(tmp_path); m.add_entry('e1','a1','OBSERVATION','8 of 10 examples relevant',{'sample_size':10})
    m.add_entry('e1','a2','ARTIFACT','results.csv',{'uri':'artifacts/results.csv'})
    report=m.report('e1'); assert len(report['entries'])==2 and report['integration_authorized'] is False

def test_status_transitions_and_terminal_state(tmp_path):
    m=setup(tmp_path); m.transition('e1','RUNNING','ev1'); m.transition('e1','ANALYSIS','ev2'); m.transition('e1','PASSED','ev3')
    with pytest.raises(ValueError): m.transition('e1','RUNNING','ev4')

def test_invalid_data_and_duplicate_ids(tmp_path):
    m=setup(tmp_path)
    with pytest.raises(ValueError): m.create('e1','p1','duplicate','h','m',['c'])
    with pytest.raises(ValueError): m.add_entry('e1','x','UNKNOWN','text')
    with pytest.raises(ValueError): m.create('e2','p1','no criteria','h','m',[])
