import tempfile
from world_awareness import WorldAwareness, WorldAwarenessStore
from opportunity_discovery import OpportunityDiscoveryEngine
from opportunity_intelligence_loop import OpportunityLoopStore, OpportunityIntelligenceLoop

def build(d):
    w=WorldAwareness(WorldAwarenessStore(d+'/world.db'))
    s1=w.ingest_source(title='A',locator='u1',publisher='P',verified=True)
    s2=w.ingest_source(title='B',locator='u2',publisher='Q',verified=True)
    w.add_signal(s1.source_id,topic='Robotics',statement='robots automate warehouse tasks',confidence=.8)
    w.add_signal(s2.source_id,topic='Robotics',statement='warehouse robots improve task automation',confidence=.9)
    theme=OpportunityDiscoveryEngine(w).discover(topic='Robotics',min_signals=2)[0]
    return theme

def test_full_loop_is_explicit_and_bounded():
    with tempfile.TemporaryDirectory() as d:
        theme=build(d); store=OpportunityLoopStore(d+'/loop.db'); e=OpportunityIntelligenceLoop(store)
        loop=e.start('p1','Investigate warehouse automation',theme)
        assert loop.stage=='DISCOVERED'
        loop=e.research(loop.loop_id); assert loop.stage=='RESEARCHED'
        loop=e.plan_experiment(loop.loop_id,metric='pilot_interest'); assert loop.stage=='EXPERIMENT_READY'
        loop=e.record_result(loop.loop_id,{'pilot_interest':7}); assert loop.stage=='RESULT_RECORDED'
        loop=e.learn(loop.loop_id); assert loop.stage=='LEARNED'; assert loop.learning['status']=='ANALYZED'

def test_restart_persists_loop_state():
    with tempfile.TemporaryDirectory() as d:
        theme=build(d); path=d+'/loop.db'; store=OpportunityLoopStore(path); e=OpportunityIntelligenceLoop(store)
        loop=e.start('p1','Test robotics',theme); e.research(loop.loop_id)
        reopened=OpportunityLoopStore(path).get(loop.loop_id)
        assert reopened is not None and reopened.stage=='RESEARCHED'

def test_cannot_skip_evidence_stages():
    with tempfile.TemporaryDirectory() as d:
        theme=build(d); e=OpportunityIntelligenceLoop(OpportunityLoopStore(d+'/loop.db'))
        loop=e.start('p1','Test',theme)
        for fn in (lambda: e.plan_experiment(loop.loop_id), lambda: e.record_result(loop.loop_id,{'x':1}), lambda: e.learn(loop.loop_id)):
            try: fn(); assert False
            except ValueError: pass
