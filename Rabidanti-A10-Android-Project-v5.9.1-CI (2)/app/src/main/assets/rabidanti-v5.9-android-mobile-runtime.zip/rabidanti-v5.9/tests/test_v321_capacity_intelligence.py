import tempfile
from pathlib import Path
import pytest
from durable_worker_queue import DurableWorkerQueue
from resource_capacity import ResourceCapacityMonitor
from capacity_intelligence import CapacityIntelligence

def make():
    d=tempfile.TemporaryDirectory(); q=DurableWorkerQueue(str(Path(d.name)/"db.sqlite"), lease_seconds=10); return d,q

def test_history_and_rising_forecast():
    d,q=make()
    try:
        ci=CapacityIntelligence(ResourceCapacityMonitor(q), max_samples=3)
        ci.observe(4,0,now=0); q.enqueue({"handler":"x"}, priority=1); ci.observe(4,0,now=10)
        q.enqueue({"handler":"x"}, priority=1); ci.observe(4,0,now=20)
        f=ci.forecast(60, now=20)
        assert len(ci.samples)==3 and f.queue_trend_per_second>0 and f.pressure=="RISING"
    finally: d.cleanup()

def test_bounded_history():
    d,q=make()
    try:
        ci=CapacityIntelligence(ResourceCapacityMonitor(q), max_samples=2)
        for t in range(4): ci.observe(2,0,now=t)
        assert len(ci.samples)==2 and ci.samples[0].timestamp==2
    finally: d.cleanup()

def test_clear_time_and_recommendation():
    d,q=make()
    try:
        ci=CapacityIntelligence(ResourceCapacityMonitor(q))
        q.enqueue({"handler":"x"}, priority=1); q.enqueue({"handler":"x"}, priority=1)
        ci.observe(4,0,now=0); ci.observe(4,0,now=10)
        q.recover_expired()
        f=ci.forecast(10)
        assert f.estimated_clear_seconds is None or f.estimated_clear_seconds >= 0
    finally: d.cleanup()

def test_priority_plan():
    d,q=make()
    try:
        ci=CapacityIntelligence(ResourceCapacityMonitor(q))
        assert ci.priority_plan([1,9,3,7],2)==[9,7]
        with pytest.raises(ValueError): ci.priority_plan([1],-1)
    finally: d.cleanup()

def test_forecast_requires_observation():
    d,q=make()
    try:
        ci=CapacityIntelligence(ResourceCapacityMonitor(q))
        with pytest.raises(RuntimeError): ci.forecast()
        with pytest.raises(ValueError): ci.forecast(0)
    finally: d.cleanup()
