"""Rabidanti v3.93 — repeat-run consistency assessment.

Compares separately recorded, human-reviewed runs. This is a consistency check,
not scientific proof and never authorizes code integration.
"""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib, json, uuid
from lab_evidence_integration import LabEvidenceIntegration

class LabReproducibilityAnalyzer:
    def __init__(self, experiment_manager, evidence_memory=None):
        self.manager = experiment_manager
        self.evidence = LabEvidenceIntegration(experiment_manager, evidence_memory) if evidence_memory is not None else None

    def compare(self, experiment_id, run_ids, *, reviewer, minimum_runs=2):
        exp = self.manager.get(experiment_id)
        if not isinstance(reviewer, str) or not reviewer.strip():
            raise ValueError("reviewer is required")
        if not isinstance(run_ids, (list, tuple)) or len(run_ids) < minimum_runs:
            raise ValueError("at least minimum_runs distinct run IDs are required")
        if not isinstance(minimum_runs, int) or isinstance(minimum_runs, bool) or minimum_runs < 2:
            raise ValueError("minimum_runs must be an integer >= 2")
        if len(set(run_ids)) != len(run_ids) or any(not isinstance(x, str) or not x.strip() for x in run_ids):
            raise ValueError("run IDs must be non-empty and unique")
        entries = self.manager.list_entries(experiment_id)
        runs = {e["metadata"].get("run_id"): e["metadata"] for e in entries if e["entry_type"] == "RESULT"}
        reports = {}
        for rid in run_ids:
            if rid not in runs:
                raise ValueError(f"no recorded result for run {rid}")
            run = runs[rid]
            if run.get("executed") is not True:
                report = self._report(experiment_id, run_ids, reviewer, "BLOCKED", {},
                    [f"Run {rid} was not verified as executed."], False)
                self._persist(experiment_id, report)
                if self.evidence is not None:
                    self.evidence.record_reproducibility(experiment_id, report)
                return report
            analyses = [e["metadata"] for e in entries if e["entry_type"] == "RECOMMENDATION"
                        and e["metadata"].get("run_id") == rid and e["metadata"].get("classification") in {"PASSED", "FAILED", "INCONCLUSIVE", "BLOCKED"}]
            if not analyses:
                raise ValueError(f"run {rid} has no reviewed analysis report")
            reports[rid] = analyses[-1]
        states = {}
        for rid, report in reports.items():
            if report.get("classification") != "PASSED":
                state = report.get("classification", "UNKNOWN")
                classification = "DIVERGENT" if state == "FAILED" else ("BLOCKED" if state == "BLOCKED" else "INCONCLUSIVE")
                result = self._report(experiment_id, run_ids, reviewer, classification, {},
                    [f"Run {rid} classification is {state}; repeated runs are not uniformly PASSED."], False)
                self._persist(experiment_id, result)
                if self.evidence is not None:
                    self.evidence.record_reproducibility(experiment_id, result)
                return result
            criteria = report.get("criteria", {})
            if set(criteria) != set(exp.success_criteria) or any(v.get("state") != "PASS" for v in criteria.values()):
                raise ValueError(f"run {rid} report does not contain PASS for every predeclared criterion")
            states[rid] = {k: v["state"] for k, v in criteria.items()}
        signatures = {json.dumps(v, sort_keys=True, separators=(",", ":")) for v in states.values()}
        consistent = len(signatures) == 1
        result = self._report(experiment_id, run_ids, reviewer,
            "CONSISTENT" if consistent else "DIVERGENT", states,
            [] if consistent else ["Reviewed criterion outcomes differ between runs; investigate method, inputs, and environment."],
            False)
        result["minimum_runs"] = minimum_runs
        result["runs_compared"] = len(run_ids)
        self._persist(experiment_id, result)
        if self.evidence is not None:
            self.evidence.record_reproducibility(experiment_id, result)
        return result

    def _report(self, experiment_id, run_ids, reviewer, classification, states, limitations, integration_authorized):
        body = {"experiment_id": experiment_id, "run_ids": list(run_ids), "criterion_states": states,
                "classification": classification, "reviewer": reviewer.strip()}
        digest = hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return {"reproducibility_id": str(uuid.uuid4()), **body, "evidence_digest": digest,
                "limitations": list(limitations), "integration_authorized": integration_authorized,
                "created_at": datetime.now(timezone.utc).isoformat()}

    def _persist(self, experiment_id, report):
        self.manager.add_entry(experiment_id, f"{report['reproducibility_id']}:reproducibility", "RECOMMENDATION",
            f"Reproducibility assessment: {report['classification']}", report)
