(() => {
  const $ = (s) => document.querySelector(s);
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const api = async (path, opts={}) => {
    const r = await fetch(path, {cache:'no-store', ...opts});
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data?.error?.message || `HTTP ${r.status}`);
    return data;
  };
  const empty = (text) => `<p class="hint">${esc(text)}</p>`;

  const fragment = new URLSearchParams(location.hash.startsWith('#') ? location.hash.slice(1) : location.hash);
  const fragmentToken = fragment.get('token') || '';
  const setupRequested = fragment.get('setup') === '1';
  if (fragmentToken && $('#api-token')) $('#api-token').value = fragmentToken;
  if (location.hash) history.replaceState(null, '', location.pathname + location.search);

  let activeConversation=null;
  async function loadChat(){
    const m=await api('/v1/model');
    $('#model-status').innerHTML=`<article class="card"><h3>${esc(m.provider)} • ${esc(m.selected||m.model)}</h3><div class="meta">${esc(m.base_url)} • ${m.reachable?'disponível':'indisponível'}${m.fallback_used?' • fallback ativo':''}</div></article>`;
    const {items}=await api('/v1/conversations?limit=1');
    if(!activeConversation && items.length) activeConversation=items[0].conversation_id;
    if(!activeConversation){$('#chat-log').innerHTML=empty('Inicia uma conversa com o Rabidanti.');return;}
    const data=await api('/v1/conversations/'+encodeURIComponent(activeConversation));
    $('#chat-log').innerHTML=data.items.length?data.items.map(x=>`<div class="chat-msg ${esc(x.role)}"><strong>${x.role==='user'?'Tu':'Rabidanti'}</strong><p>${esc(x.content)}</p><div class="meta">${esc(x.model||'')}</div></div>`).join(''):empty('Sem mensagens.');
  }

  async function loadProposals(){
    const [{items:proposals},{items:reviews},{items:executions}]=await Promise.all([api('/v1/reasoning/proposals?limit=20'),api('/v1/reasoning/reviews?limit=50'),api('/v1/reasoning/executions?limit=50')]);
    const reviewMap=Object.fromEntries(reviews.map(x=>[x.proposal_id,x])); const execMap=Object.fromEntries(executions.map(x=>[x.proposal_id,x]));
    $('#proposal-list').innerHTML=proposals.length?proposals.map(x=>{const r=reviewMap[x.proposal_id], ex=execMap[x.proposal_id]; return `<article class="card"><h3>${esc(x.kind)} • ${esc(x.proposal_id)}</h3><pre>${esc(JSON.stringify(x,null,2))}</pre><div class="meta">revisão: ${esc(r?.decision||'PENDENTE')} • execução: ${esc(ex?.status||'NÃO EXECUTADA')}</div><div class="actions"><button class="proposal-action" data-action="approve" data-id="${esc(x.proposal_id)}">Aprovar</button><button class="proposal-action secondary" data-action="reject" data-id="${esc(x.proposal_id)}">Rejeitar</button><button class="proposal-action secondary" data-action="authorize" data-id="${esc(x.proposal_id)}">Autorizar</button><button class="proposal-action secondary" data-action="execute" data-id="${esc(x.proposal_id)}">Executar</button></div></article>`}).join(''):empty('Nenhuma proposta registada.');
  }

  async function loadSetup(){
    const status = await api('/v1/setup');
    let models = [];
    try { models = (await api('/v1/models')).items || []; } catch (_) { models = []; }
    $('#setup-models').innerHTML = models.map(x=>`<option value="${esc(x.name)}"></option>`).join('');
    if (!$('#setup-model').value) $('#setup-model').value = status.config?.ai?.model || 'llama3.2';
    if (!$('#setup-fallback').value) $('#setup-fallback').value = status.config?.ai?.fallback_model || '';
    $('#setup-auto-open').checked = status.config?.ui?.auto_open_browser !== false;
    $('#setup-log-level').value = status.config?.logging?.level || 'INFO';
    const model = status.model || {};
    $('#setup-summary').innerHTML = `
      <article class="card"><h3>${status.completed?'Configuração concluída':'Configuração inicial pendente'}</h3><div class="meta">${esc(status.completed_at || 'ainda não concluída')}</div></article>
      <article class="card"><h3>Ollama / modelo</h3><div class="meta">${model.reachable?'disponível':'indisponível'} • selecionado: ${esc(model.selected || status.config?.ai?.model || 'nenhum')}</div></article>
      <article class="card"><h3>Vault</h3><div class="meta">${status.vault?.unlocked?'desbloqueado nesta sessão':'bloqueado'} • chave-mestra persistida: não</div></article>
    `;
  }

  async function loadStatus(){
    const s=await api('/v1/status');
    $('#runtime-title').textContent=`${s.program} ${s.version}`;
    $('#runtime-state').textContent=`${s.runtime_state} • ${s.state_dir}`;
    const metrics=[['Tarefas',s.tasks.total],['Workflows',s.workflows.total],['Fila',s.queue.total],['Evidências',s.evidence.visible_total],['Conectores',s.connectors?.enabled ?? 0]];
    $('#metrics').innerHTML=metrics.map(([k,v])=>`<div class="metric"><strong>${esc(v)}</strong><span>${esc(k)}</span></div>`).join('');
  }
  async function loadHealth(){
    try{const h=await api('/health'); $('#health-label').textContent=h.healthy?'Saudável':'Atenção'; $('#health-dot').className='dot '+(h.healthy?'good':'bad');}
    catch(e){$('#health-label').textContent='Indisponível';$('#health-dot').className='dot bad';}
  }
  async function loadTasks(){
    const {items}=await api('/v1/tasks');
    if(!items.length){$('#tasks-list').innerHTML=empty('Nenhuma tarefa registada.');return;}
    $('#tasks-list').innerHTML=`<table><thead><tr><th>Tarefa</th><th>Prioridade</th><th>Estado</th><th>Tentativas</th></tr></thead><tbody>${items.map(x=>`<tr><td><strong>${esc(x.name)}</strong><div class="meta">${esc(x.task_id)}</div></td><td>${esc(x.priority)}</td><td><span class="badge">${esc(x.state)}</span></td><td>${esc(x.attempts)}/${esc(x.max_attempts)}</td></tr>`).join('')}</tbody></table>`;
  }
  const evidenceCards=(items)=>items.length?items.map(x=>`<article class="card"><h3>${esc(x.title || x.node_id)}</h3><div class="meta">${esc(x.kind)} • ${esc(x.node_id)}</div><p>${esc(x.summary || '')}</p></article>`).join(''):empty('Nenhum registo encontrado.');
  async function loadEvidence(){const {items}=await api('/v1/evidence?limit=100');$('#evidence-list').innerHTML=evidenceCards(items);}
  async function loadDecisions(){const {items}=await api('/v1/evidence?kind=DECISION&limit=100');$('#decisions-list').innerHTML=evidenceCards(items);}
  async function loadWorkflows(){const {items}=await api('/v1/workflows'); if(!items.length){$('#workflows-list').innerHTML=empty('Nenhum workflow registado.');return;} $('#workflows-list').innerHTML=`<table><thead><tr><th>Workflow</th><th>Estado</th><th>Tarefas</th></tr></thead><tbody>${items.map(x=>`<tr><td><strong>${esc(x.name)}</strong><div class="meta">${esc(x.workflow_id)}</div></td><td><span class="badge">${esc(x.state)}</span></td><td>${esc(x.task_ids.length)}</td></tr>`).join('')}</tbody></table>`;}
  async function loadEvents(){const {items}=await api('/v1/events?limit=100');$('#events-list').innerHTML=items.length?items.map(x=>`<div class="event"><strong>${esc(x.event_type)}</strong><div class="meta">${esc(x.created_at)} • ${esc(x.instance_id)}</div></div>`).join(''):empty('Nenhum evento registado.');}
  async function loadObservability(){
    const o=await api('/v1/observability');
    const badge=o.overall==='OK'?'ok':(o.overall==='WARNING'?'warn':'fail');
    const sm=o.summary||{};
    $('#ops-summary').innerHTML=[["Estado",o.overall],["Alertas",sm.alerts_total||0],["Críticos",sm.critical||0],["Avisos",sm.warning||0]].map(([k,v])=>`<div class="metric"><strong class="${k==='Estado'?badge:''}">${esc(v)}</strong><span>${esc(k)}</span></div>`).join('');
    $('#ops-alerts').innerHTML=o.alerts.length?o.alerts.map(a=>`<article class="card"><h3 class="${a.severity==='CRITICAL'?'fail':'warn'}">${esc(a.severity)} • ${esc(a.title)}</h3><div class="meta">${esc(a.code)}</div><p>${esc(a.detail)}</p></article>`).join(''):empty('Sem alertas operacionais.');
    const workers=sm.workers||{}, model=o.model||{}, rec=o.recovery||{}, self=o.product_self_test||{};
    $('#ops-components').innerHTML=`<article class="card"><h3>Workers</h3><div class="meta">${workers.healthy?'saudáveis':'atenção'} • total ${esc(workers.total||0)} • stale ${esc((workers.stale_worker_ids||[]).length)}</div></article>`+
      `<article class="card"><h3>Modelo local</h3><div class="meta">${model.reachable?'disponível':'indisponível'} • ${esc(model.selected||model.model||'nenhum')}</div></article>`+
      `<article class="card"><h3>Recovery</h3><div class="meta">heartbeat ${rec.heartbeat_stale?'stale':'normal/ausente'} • reinício automático: não</div></article>`+
      `<article class="card"><h3>Self-test</h3><div class="meta">${self.available?'disponível':'indisponível'} • execução automática: não • estado real modificado: não</div></article>`+
      `<article class="card"><h3>Conectores</h3><div class="meta">registados ${esc(sm.connectors?.registered||0)} • ativos ${esc(sm.connectors?.enabled||0)}</div></article>`+
      `<article class="card"><h3>Segurança</h3><div class="meta">somente leitura • remediação automática: não • ação externa autorizada: não</div></article>`;
    $('#ops-events').innerHTML=o.recent_events.length?o.recent_events.map(x=>`<div class="event"><strong>${esc(x.event_type)}</strong><div class="meta">${esc(x.created_at)} • ${esc(x.instance_id)}</div></div>`).join(''):empty('Nenhum evento recente.');
  }
  async function loadDoctor(){const d=await api('/v1/doctor'); $('#doctor-list').innerHTML=d.checks.map(x=>`<article class="card"><h3 class="${x.ok?'ok':'warn'}">${x.ok?'✓':'!'} ${esc(x.name)}</h3><div class="meta">${esc(x.detail)}</div></article>`).join('');}
  async function loadProviders(){
    const {items}=await api('/v1/providers');
    $('#providers-list').innerHTML=items.length?items.map(x=>`<article class="card"><h3>${esc(x.display_name)}</h3><div class="meta">${esc(x.provider_id)} • ${esc(x.status)} • conector ${x.connector_enabled?'ATIVO':'DESATIVADO'}</div><p>Access token: ${x.access_token_present?'presente':'ausente'}<br>Refresh token: ${x.refresh_token_present?'presente':'ausente'}<br>Client ID: ${x.client_id_present?'presente':'ausente'}<br>Refresh automático: ${x.automatic_refresh_ready?'pronto':'não pronto'}<br>Expira: ${esc(x.token_expires_at || 'desconhecido')}<br>Último teste: ${esc(x.last_test_at || 'nunca')} ${x.last_test_ok===null?'':(x.last_test_ok?'✓':'✗')}</p></article>`).join(''):empty('Nenhum provider registado.');
  }
  async function loadConnectors(){
    const [{items},{items:approvals},{items:invocations}]=await Promise.all([api('/v1/connectors'),api('/v1/connectors/approvals?limit=50'),api('/v1/connectors/invocations?limit=50')]);
    $('#connectors-list').innerHTML=items.length?items.map(x=>`<article class="card"><h3>${esc(x.display_name)}</h3><div class="meta">${esc(x.connector_id)} • v${esc(x.version)} • ${x.enabled?'ATIVO':'DESATIVADO'} • ${x.runtime_handler_loaded?'handler carregado':'sem handler'} • segredos ${x.secrets_ready?'prontos':'em falta'}</div><p>${x.capabilities.map(c=>`${esc(c.name)} [${esc(c.access)}${c.approval_required?' • aprovação':''}]`).join('<br>')}</p></article>`).join(''):empty('Nenhum conector registado. A v4.4 não liga contas externas automaticamente.');
    $('#connector-approvals').innerHTML=approvals.length?approvals.map(x=>`<article class="card"><h3>${esc(x.connector_id)} • ${esc(x.capability)}</h3><div class="meta">${x.consumed?'consumida':'pendente'} • ${esc(x.actor)} • ${esc(x.created_at)}</div></article>`).join(''):empty('Nenhuma aprovação registada.');
    $('#connector-invocations').innerHTML=invocations.length?invocations.map(x=>`<article class="card"><h3>${esc(x.connector_id)} • ${esc(x.capability)}</h3><div class="meta">${esc(x.outcome)} • ${esc(x.actor)} • ${esc(x.created_at)}</div></article>`).join(''):empty('Nenhuma invocação registada.');
  }
  async function loadSettings(){const c=await api('/v1/config'); const flat=Object.entries(c).flatMap(([section,vals])=>Object.entries(vals).map(([k,v])=>[`${section}.${k}`,v])); $('#config-list').innerHTML=flat.map(([k,v])=>`<article class="card"><h3>${esc(k)}</h3><div class="meta">${esc(JSON.stringify(v))}</div></article>`).join(''); const {items}=await api('/v1/secrets'); $('#secrets-list').innerHTML=items.length?items.map(x=>`<article class="card"><h3>${esc(x.name)}</h3><div class="meta">${x.configured?'configurado':'não configurado'}${x.source?' • '+esc(x.source):''}</div></article>`).join(''):empty('Nenhum segredo configurado nesta sessão/ambiente.');}
  const loaders={setup:loadSetup,chat:async()=>{await loadChat();await loadProposals();},tasks:loadTasks,evidence:loadEvidence,decisions:loadDecisions,workflows:loadWorkflows,events:loadEvents,observability:loadObservability,doctor:loadDoctor,providers:loadProviders,connectors:loadConnectors,settings:loadSettings};
  async function safe(fn){try{await fn();}catch(e){console.error(e);}}
  async function refreshAll(){await Promise.all([safe(loadStatus),safe(loadHealth),...Object.values(loaders).map(x=>safe(x))]);}

  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#'+b.dataset.tab).classList.add('active');safe(loaders[b.dataset.tab]);}));
  document.querySelectorAll('[data-refresh]').forEach(b=>b.addEventListener('click',()=>safe(loaders[b.dataset.refresh])));
  $('#refresh-all').addEventListener('click',refreshAll);
  $('#clear-token').addEventListener('click',()=>{$('#api-token').value='';});


  const setupForm=$('#setup-form'); if(setupForm) setupForm.addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#setup-message'); const token=$('#api-token').value.trim();
    if(!token){msg.textContent='O token local da sessão é necessário para concluir o setup.';msg.className='message warn';return;}
    const body={model:$('#setup-model').value.trim(),fallback_model:$('#setup-fallback').value.trim(),auto_open_browser:$('#setup-auto-open').checked,logging_level:$('#setup-log-level').value};
    const master=$('#setup-vault-key').value; if(master) body.vault_master_key=master;
    try{await api('/v1/setup/complete',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify(body)});$('#setup-vault-key').value='';msg.textContent='Configuração inicial concluída. Nenhuma ação externa foi autorizada.';msg.className='message ok';await Promise.all([loadSetup(),loadSettings(),loadStatus(),loadEvents()]);}
    catch(err){$('#setup-vault-key').value='';msg.textContent=err.message;msg.className='message fail';}
  });

  const vaultForm=$('#vault-unlock-form'); if(vaultForm) vaultForm.addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#vault-message'); const token=$('#api-token').value.trim(); const master=$('#vault-master-key').value;
    if(!token){msg.textContent='Introduza o token local para desbloquear o vault.';msg.className='message warn';return;}
    try{await api('/v1/vault/unlock',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({master_key:master})});$('#vault-master-key').value='';msg.textContent='Vault desbloqueado apenas nesta sessão.';msg.className='message ok';await Promise.all([loadSettings(),loadSetup(),loadEvents()]);}
    catch(err){$('#vault-master-key').value='';msg.textContent=err.message;msg.className='message fail';}
  });

  const reasonForm=$('#reason-form'); if(reasonForm) reasonForm.addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#reason-status'); const token=$('#api-token').value.trim(); const request=$('#reason-request').value.trim();
    if(!token){msg.textContent='Introduza o token local para gerar propostas.';msg.className='message warn';return;}
    if(!request)return; msg.textContent='A analisar…'; msg.className='message';
    try{const out=await api('/v1/reason',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({request})});
      msg.textContent='Proposta criada. Nenhuma ação foi executada.'; msg.className='message ok';
      $('#reason-output').innerHTML=`<article class="card"><h3>Resposta</h3><p>${esc(out.response)}</p><div class="meta">${out.proposed_actions.length} proposta(s) • execução autorizada: não</div></article>` + out.proposed_actions.map(x=>`<article class="card"><h3>${esc(x.kind)}</h3><pre>${esc(JSON.stringify(x,null,2))}</pre></article>`).join('');
    }catch(err){msg.textContent=err.message;msg.className='message error';}
  });

  $('#chat-form').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#chat-message-status'); const token=$('#api-token').value.trim();
    if(!token){msg.textContent='Introduza o token local na área de tarefas para usar o modelo.';msg.className='message warn';return;}
    const text=$('#chat-message').value.trim(); if(!text)return; msg.textContent='A pensar…'; msg.className='message';
    try{const out=await api('/v1/chat',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({message:text,conversation_id:activeConversation})});activeConversation=out.conversation_id;$('#chat-message').value='';msg.textContent='';await Promise.all([loadChat(),loadEvents()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';}
  });

  $('#task-form').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#task-message'); msg.textContent='';
    const token=$('#api-token').value.trim(); if(!token){msg.textContent='Introduza o token local para criar tarefas.';msg.className='message warn';return;}
    try{await api('/v1/tasks',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({name:$('#task-name').value.trim(),priority:$('#task-priority').value})}); $('#task-name').value='';msg.textContent='Tarefa adicionada.';msg.className='message ok';await Promise.all([loadTasks(),loadStatus(),loadEvents()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';}
  });

  $('#connector-control-form').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#connector-message'); const token=$('#api-token').value.trim();
    if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    try{await api('/v1/connectors/control',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({connector_id:$('#connector-id').value.trim(),enabled:$('#connector-enabled').value==='true',actor:$('#connector-actor').value.trim(),reason:$('#connector-reason').value.trim()})});msg.textContent='Estado do conector atualizado.';msg.className='message ok';await Promise.all([loadConnectors(),loadEvents(),loadStatus()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';}
  });

  $('#gmail-credentials-form').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#provider-message'); const token=$('#api-token').value.trim();
    if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    const body={client_id:$('#google-client-id').value.trim(),persist:$('#google-credential-mode').value==='vault'};
    const secret=$('#google-client-secret').value; if(secret) body.client_secret=secret;
    try{await api('/v1/providers/google-gmail/setup',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify(body)});$('#google-client-secret').value='';msg.textContent='Credenciais do provider configuradas.';msg.className='message ok';await Promise.all([loadProviders(),loadSettings(),loadEvents()]);}
    catch(err){$('#google-client-secret').value='';msg.textContent=err.message;msg.className='message fail';}
  });
  $('#gmail-oauth-start').addEventListener('click',async()=>{
    const msg=$('#oauth-result'), token=$('#api-token').value.trim(); if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    try{const out=await api('/v1/providers/google-gmail/oauth/start',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:'{}'});msg.innerHTML=`Autorização criada. <a href="${esc(out.authorization_url)}" target="_blank" rel="noopener noreferrer">Abrir Google OAuth</a>`;msg.className='message ok';}
    catch(err){msg.textContent=err.message;msg.className='message fail';}
  });
  $('#gmail-test').addEventListener('click',async()=>{
    const msg=$('#oauth-result'), token=$('#api-token').value.trim(); if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    try{const out=await api('/v1/providers/google-gmail/test',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({actor:'Sala'})});msg.textContent=`Ligação válida${out.email_address?' • '+out.email_address:''}.`;msg.className='message ok';await Promise.all([loadProviders(),loadEvents()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';await loadProviders();}
  });
  $('#gmail-refresh').addEventListener('click',async()=>{
    const msg=$('#oauth-result'), token=$('#api-token').value.trim(); if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    try{await api('/v1/providers/google-gmail/refresh',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:'{}'});msg.textContent='Token atualizado.';msg.className='message ok';await Promise.all([loadProviders(),loadEvents()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';await loadProviders();}
  });

  $('#config-form').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#config-message'); const token=$('#api-token').value.trim();
    if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    let value; try{value=JSON.parse($('#config-value').value);}catch(_){msg.textContent='O valor deve ser JSON válido.';msg.className='message fail';return;}
    try{await api('/v1/config',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({changes:{[$('#config-key').value]:value}})});msg.textContent='Configuração atualizada.';msg.className='message ok';$('#config-value').value='';await Promise.all([loadSettings(),loadEvents(),loadStatus()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';}
  });
  $('#secret-form').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=$('#secret-message'); const token=$('#api-token').value.trim();
    if(!token){msg.textContent='Introduza o token local na área de tarefas.';msg.className='message warn';return;}
    const name=$('#secret-name').value.trim(), value=$('#secret-value').value;
    try{await api('/v1/secrets/session',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({name,value})});$('#secret-value').value='';msg.textContent='Segredo definido apenas para esta sessão.';msg.className='message ok';await Promise.all([loadSettings(),loadEvents()]);}
    catch(err){msg.textContent=err.message;msg.className='message fail';}
  });
  document.addEventListener('click',async e=>{
    const b=e.target.closest('.proposal-action'); if(!b)return;
    const token=$('#api-token').value.trim(); if(!token){$('#reason-status').textContent='Introduza o token local para rever ou executar propostas.';$('#reason-status').className='message warn';return;}
    const id=b.dataset.id, action=b.dataset.action; const actor='Sala';
    try{
      if(action==='approve'||action==='reject') await api('/v1/reasoning/review',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({proposal_id:id,decision:action==='approve'?'APPROVED':'REJECTED',actor,reason:'Decisão explícita na Sala'})});
      else if(action==='authorize') await api('/v1/reasoning/authorize',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({proposal_id:id,actor,reason:'Autorização explícita na Sala'})});
      else if(action==='execute') await api('/v1/reasoning/execute',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`},body:JSON.stringify({proposal_id:id,actor})});
      $('#reason-status').textContent='Operação registada.'; $('#reason-status').className='message ok'; await Promise.all([loadProposals(),loadTasks(),loadEvents(),loadStatus()]);
    }catch(err){$('#reason-status').textContent=err.message;$('#reason-status').className='message fail';}
  });

  if(setupRequested){
    const setupTab=document.querySelector('.tab[data-tab="setup"]');
    if(setupTab) setupTab.click();
  }
  refreshAll();
})();
