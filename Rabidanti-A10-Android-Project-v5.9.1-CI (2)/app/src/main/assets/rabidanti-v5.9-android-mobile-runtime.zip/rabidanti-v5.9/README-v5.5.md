# Rabidanti v5.5

**Windows Native Build & Release Verification**

A v5.5 prepara a primeira release nativa Windows de forma auditável.

## Estado desta distribuição

- Runtime fonte: validado.
- Pipeline PyInstaller/Inno Setup: preparado e testado por invariantes.
- Validador Windows end-to-end: implementado.
- Workflow Windows reproduzível: incluído.
- `Rabidanti.exe` real: não incluído neste pacote fonte.
- `Setup.exe` real: não incluído neste pacote fonte.

## Build no Windows

Num Windows com Python 3.13, Internet para instalar dependências e Inno Setup 6:

```bat
build_release_windows.bat
```

O build só é considerado uma release nativa validada quando existem simultaneamente:

- `dist\Rabidanti.exe`
- `installer-dist\Rabidanti-Setup-5.5.0.exe`
- `release-manifest.json`
- `windows-release-validation.json`

Depois:

```bat
python native_release_check.py
```

deve devolver `native_release_verified: true`.

## Testes desta versão

691 testes aprovados no ambiente de desenvolvimento desta release candidate fonte.

A execução nativa Windows continua deliberadamente pendente até o pipeline ser executado num Windows real.
