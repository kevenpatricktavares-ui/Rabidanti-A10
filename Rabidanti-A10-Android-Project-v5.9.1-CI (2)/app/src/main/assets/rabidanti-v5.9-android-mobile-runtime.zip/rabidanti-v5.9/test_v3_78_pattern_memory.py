from evolution_pattern_memory import EvolutionPatternMemory


def test_records_and_orders_history():
    m=EvolutionPatternMemory()
    m.record("o1","c1",.6,"2026-01-01T00:00:00+00:00")
    m.record("o2","c1",.8,"2026-01-02T00:00:00+00:00")
    assert [x.observation_id for x in m.observations("c1")]==["o1","o2"]


def test_rising_trend():
    m=EvolutionPatternMemory()
    m.record("a","c",.5,"2026-01-01T00:00:00+00:00")
    m.record("b","c",.8,"2026-01-02T00:00:00+00:00")
    assert m.trend("c").trend=="RISING"


def test_falling_and_stable():
    m=EvolutionPatternMemory()
    m.record("a","f",.8,"2026-01-01T00:00:00+00:00")
    m.record("b","f",.4,"2026-01-02T00:00:00+00:00")
    assert m.trend("f").trend=="FALLING"
    m.record("c","s",.5,"2026-01-01T00:00:00+00:00")
    m.record("d","s",.5,"2026-01-02T00:00:00+00:00")
    assert m.trend("s").trend=="STABLE"


def test_repeated_and_missing():
    m=EvolutionPatternMemory()
    assert not m.repeated("x")
    m.record("a","x",.7,"2026-01-01T00:00:00+00:00")
    assert not m.repeated("x")
    m.record("b","x",.7,"2026-01-02T00:00:00+00:00")
    assert m.repeated("x")


def test_validation():
    m=EvolutionPatternMemory()
    try:
        m.record("","c",.5)
        assert False
    except ValueError: pass
    try:
        m.record("a","c",1.2)
        assert False
    except ValueError: pass
    m.record("a","c",.5,"2026-01-01T00:00:00+00:00")
    try:
        m.record("a","c",.5,"2026-01-02T00:00:00+00:00")
        assert False
    except ValueError: pass


def test_bounded_memory():
    m=EvolutionPatternMemory(max_observations=2)
    for i in range(3):
        m.record(str(i),"c",.5,f"2026-01-0{i+1}T00:00:00+00:00")
    assert len(m._items)==2


def test_average_strength():
    m=EvolutionPatternMemory()
    m.record("a","c",.4,"2026-01-01T00:00:00+00:00")
    m.record("b","c",.8,"2026-01-02T00:00:00+00:00")
    assert m.trend("c").average_strength==.6
