"""Rabidanti v3.65 — controlled experiment promotion governance.

Turns a forward experiment into an explicit, auditable promotion proposal.
Promotion never happens merely because an experiment looks promising. The
controller requires sufficient evidence, the experiment's PROMOTION_PENDING
state, and explicit approval. Production weights are immutable until an
explicit caller applies the returned proposal through its own configuration
boundary.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Mapping

from forward_experiment import ExperimentState, ForwardExperimentEngine


@dataclass(frozen=True)
class PromotionProposal:
    experiment_id: str
    factor: str
    baseline_weight: float
    proposed_weight: float
    recommendation: str
    evidence_count: int
    rationale: str

    def to_dict(self) -> dict:
        return asdict(self)


class ExperimentPromotionController:
    """Govern promotion from a forward experiment without mutating production."""

    def __init__(self, engine: ForwardExperimentEngine, production_weights: Mapping[str, float]):
        if not production_weights:
            raise ValueError("production_weights are required")
        self.engine = engine
        self.production_weights = dict(production_weights)
        if any(not isinstance(k, str) or not k for k in self.production_weights):
            raise ValueError("weight names must be non-empty strings")
        if any(not -1.0 <= float(v) <= 1.0 for v in self.production_weights.values()):
            raise ValueError("production weights must be between -1 and 1")

    def propose(self, experiment_id: str) -> PromotionProposal:
        experiment = self.engine.store.get(experiment_id)
        if experiment.state != ExperimentState.RUNNING and experiment.state != ExperimentState.COMPLETED and experiment.state != ExperimentState.PROMOTION_PENDING:
            raise ValueError("experiment is not eligible for promotion review")
        evaluation = self.engine.evaluate(experiment_id)
        if evaluation.recommendation != "PROMISING_TREATMENT":
            raise ValueError("experiment does not have a promising treatment result")
        if experiment.factor not in self.production_weights:
            raise ValueError("experiment factor is not in production weights")
        return PromotionProposal(
            experiment_id=experiment_id,
            factor=experiment.factor,
            baseline_weight=float(experiment.baseline_weight),
            proposed_weight=float(experiment.proposed_weight),
            recommendation=evaluation.recommendation,
            evidence_count=evaluation.control_count + evaluation.treatment_count,
            rationale=(
                "Promotion proposal prepared from forward experimental evidence. "
                "It is not a production change until explicitly approved and applied."
            ),
        )

    def approve_experiment(self, experiment_id: str) -> PromotionProposal:
        """Explicitly approve the experiment's promotion state, never its production weights."""
        proposal = self.propose(experiment_id)
        current = self.engine.store.get(experiment_id)
        if current.state == ExperimentState.COMPLETED:
            self.engine.store.transition(experiment_id, ExperimentState.PROMOTION_PENDING)
        self.engine.approve(experiment_id)
        return proposal

    def apply_explicit(self, proposal: PromotionProposal, *, explicit_approval: bool) -> dict[str, float]:
        """Return a new weight set only after explicit caller approval.

        The controller never mutates its stored production configuration.
        The returned mapping must be persisted by the caller through the
        application's normal configuration/versioning boundary.
        """
        if not explicit_approval:
            raise PermissionError("explicit approval is required to apply a promotion")
        experiment = self.engine.store.get(proposal.experiment_id)
        if experiment.state != ExperimentState.APPROVED:
            raise ValueError("experiment must be APPROVED before applying promotion")
        if proposal.factor not in self.production_weights:
            raise ValueError("proposal factor is not in production weights")
        if float(proposal.baseline_weight) != float(experiment.baseline_weight) or float(proposal.proposed_weight) != float(experiment.proposed_weight):
            raise ValueError("promotion proposal no longer matches the experiment")
        result = dict(self.production_weights)
        result[proposal.factor] = float(proposal.proposed_weight)
        return result
