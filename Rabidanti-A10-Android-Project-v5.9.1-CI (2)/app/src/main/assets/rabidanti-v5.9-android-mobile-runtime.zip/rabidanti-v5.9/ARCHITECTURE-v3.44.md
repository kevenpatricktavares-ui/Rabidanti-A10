# Rabidanti v3.44 — Laboratory Foundation

Adds the first persistent Laboratory module.

## Scope
- Research/technology exploration records.
- Evidence and findings with provenance fields preserved as supplied.
- Lifecycle: IDEIA → INVESTIGAÇÃO → EXPERIMENTO → RESULTADO_VALIDADO → DESCOBERTA.
- Discovery requires all four explicit criteria: novelty, relevance, tested, reproducible.
- Maximum-priority persistent discovery alerts.
- Alerts remain open until explicitly acknowledged.
- SQLite persistence and restart recovery through the Lab store.

## Safety of conclusions
A hypothesis is not a discovery. The module never infers novelty, causality, reproducibility, or scientific validity from missing evidence. External exploitation, publication, patents, spending, or Core changes are not performed by this foundation.

## Not yet implemented
World Awareness ingestion, scientific web/database connectors, automated literature/patent search, autonomous experimentation hardware, patent filing, cloud deployment, or automatic Core modification.
