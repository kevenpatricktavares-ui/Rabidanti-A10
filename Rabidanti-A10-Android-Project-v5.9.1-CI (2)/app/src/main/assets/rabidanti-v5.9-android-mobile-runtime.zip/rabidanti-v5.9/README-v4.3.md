# Rabidanti v4.3 — Configuration & Secrets Layer

Rabidanti v4.3 introduces an explicit boundary between persistent non-secret configuration and secret material.

## Persistent configuration

The runtime creates `<state-dir>/config.json` automatically. Only the following keys are accepted:

- `api.host` — loopback only (`127.0.0.1`, `::1`, `localhost`)
- `api.port` — integer 0–65535
- `ui.auto_open_browser` — boolean
- `runtime.recover_on_start` — boolean
- `logging.level` — `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`

Unknown keys and secret-looking keys such as `token`, `password`, `api_key`, `credential`, or `private_key` are rejected. Writes are atomic. On POSIX systems the file is set to mode `0600`.

CLI:

```bash
python rabidanti.py config show
python rabidanti.py config set api.port 9000
python rabidanti.py config set ui.auto_open_browser false
```

## Secrets

v4.3 deliberately does **not** write secret values to disk. Secrets can be provided from:

1. environment variables named `RABIDANTI_SECRET_<NAME>`;
2. the backwards-compatible `RABIDANTI_API_TOKEN` for `API_TOKEN`;
3. an in-memory session secret, set through the authenticated local API, Sala, or interactive CLI prompt.

Examples:

```bash
export RABIDANTI_SECRET_API_TOKEN='...'
export RABIDANTI_SECRET_OPENAI_API_KEY='...'
python rabidanti.py secret status
python rabidanti.py secret set OPENAI_API_KEY
```

`secret set` prompts without accepting the secret as a command-line argument, reducing shell-history exposure.

## Sala and API

Read-only endpoints:

- `GET /v1/config`
- `GET /v1/secrets` — returns names/source/status only, never values

Authenticated mutations:

- `POST /v1/config` with `{"changes":{"api.port":9000}}`
- `POST /v1/secrets/session` with `{"name":"CONNECTOR_KEY","value":"..."}`
- clearing a session secret uses `{"name":"CONNECTOR_KEY","clear":true}`

The Sala now contains a **Configuração** tab for the same operations. Mutation authentication remains the local bearer token.

## Redaction

Runtime events recursively redact values under secret-like keys before writing audit records. This is a defence-in-depth boundary; connector code must still avoid putting secrets into ordinary free-form strings.

## Important limitations

- v4.3 has no persistent OS credential vault integration yet.
- Environment variables can be observable to sufficiently privileged processes on the same machine.
- Session secrets disappear when the Rabidanti process terminates.
- No external connector is enabled merely by configuring a secret.
- Secret presence does not authorize an external action.
