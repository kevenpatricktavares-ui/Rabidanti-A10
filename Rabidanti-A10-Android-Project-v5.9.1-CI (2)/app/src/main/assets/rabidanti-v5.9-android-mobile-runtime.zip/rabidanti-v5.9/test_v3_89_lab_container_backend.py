import json, pytest
from lab_container_backend import LabContainerBackend

def test_probe_is_read_only_and_auditable():
    p=LabContainerBackend.probe()
    assert p.digest and p.assessed_at and isinstance(p.available,bool)
    assert json.loads(LabContainerBackend.report(p))["daemon_reachable"] == p.daemon_reachable

def test_probe_timeout_validated():
    with pytest.raises(ValueError): LabContainerBackend.probe(30)

def test_plan_requires_digest_pinned_image():
    with pytest.raises(ValueError): LabContainerBackend.build_plan("python:latest","python","/tmp/lab")

def test_plan_defaults_to_no_network_and_drops_privileges():
    p=LabContainerBackend.build_plan("python@sha256:"+"a"*64,"/usr/bin/python","/tmp/lab")
    assert "--network=none" in p["runtime_args"]
    assert "--cap-drop=ALL" in p["runtime_args"]
    assert p["execution_performed"] is False

def test_plan_rejects_unbounded_limits():
    with pytest.raises(ValueError): LabContainerBackend.build_plan("x@sha256:"+"b"*64,"run","/tmp/lab",pids=9999)
