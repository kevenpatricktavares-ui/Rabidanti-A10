from __future__ import annotations

import json
import os
from pathlib import Path
import stat
import subprocess
import sys

import pytest

import rabidanti_android as android


def test_version_is_5_9():
    assert Path("VERSION").read_text(encoding="utf-8").strip() == "5.9.0"


def test_termux_detection_by_version():
    assert android.is_termux({"TERMUX_VERSION": "0.118", "PREFIX": "/x"}) is True
    assert android.is_android({"TERMUX_VERSION": "0.118", "PREFIX": "/x"}) is True


def test_termux_detection_by_prefix():
    env = {"PREFIX": "/data/data/com.termux/files/usr"}
    assert android.is_termux(env) is True
    assert android.is_android(env) is True


def test_android_detection_by_android_root():
    assert android.is_android({"ANDROID_ROOT": "/system"}) is True
    assert android.is_android({}) is False


def test_android_state_dir_honors_override(tmp_path):
    target = tmp_path / "state"
    got = android.android_state_dir({"RABIDANTI_STATE_DIR": str(target), "HOME": str(tmp_path)})
    assert got == target.resolve()


def test_android_state_dir_default_is_inside_home(tmp_path):
    got = android.android_state_dir({"HOME": str(tmp_path)})
    assert got == (tmp_path / ".local" / "share" / "rabidanti").resolve()


def test_browser_command_prefers_termux_open_url(tmp_path):
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    exe = bin_dir / "termux-open-url"
    exe.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    exe.chmod(exe.stat().st_mode | stat.S_IXUSR)
    cmd = android.browser_command("http://127.0.0.1:8765/ui/", {"PATH": str(bin_dir)})
    assert cmd == [str(exe), "http://127.0.0.1:8765/ui/"]


def test_browser_command_falls_back_to_android_am(tmp_path):
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    exe = bin_dir / "am"
    exe.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    exe.chmod(exe.stat().st_mode | stat.S_IXUSR)
    cmd = android.browser_command("http://127.0.0.1:8765/ui/", {"PATH": str(bin_dir)})
    assert cmd[0] == str(exe)
    assert cmd[-1] == "http://127.0.0.1:8765/ui/"
    assert "android.intent.action.VIEW" in cmd


def test_android_diagnostics_are_read_only_and_no_external_authority(tmp_path, monkeypatch):
    monkeypatch.setattr(android, "_loopback_bind_available", lambda: True)
    monkeypatch.setattr(android, "browser_command", lambda url, environ=None: ["termux-open-url", url])
    env = {
        "TERMUX_VERSION": "0.118",
        "PREFIX": "/data/data/com.termux/files/usr",
        "HOME": str(tmp_path),
    }
    result = android.android_diagnostics(state_dir=tmp_path / "state", environ=env, probe_ollama=False)
    assert result["host"] == "android"
    assert result["termux"] is True
    assert result["safety"] == {
        "core_modified": False,
        "external_action_authorized": False,
        "automatic_connector_enable": False,
        "automatic_model_download": False,
    }
    assert not (tmp_path / "state").exists()


def test_android_doctor_does_not_probe_ollama_by_default(tmp_path, monkeypatch):
    called = {"value": False}
    def fail_probe(*args, **kwargs):
        called["value"] = True
        raise AssertionError("ollama should not be probed")
    monkeypatch.setattr("rabidanti_product.ProductFoundation.ollama", fail_probe)
    monkeypatch.setattr(android, "_loopback_bind_available", lambda: True)
    env = {"TERMUX_VERSION": "1", "PREFIX": "/data/data/com.termux/files/usr", "HOME": str(tmp_path)}
    android.android_diagnostics(state_dir=tmp_path / "state", environ=env)
    assert called["value"] is False


def test_android_scripts_are_present_executable_and_keep_loopback_only():
    start = Path("START-RABIDANTI-ANDROID.sh")
    setup = Path("SETUP-ANDROID-TERMUX.sh")
    assert start.is_file() and os.access(start, os.X_OK)
    assert setup.is_file() and os.access(setup, os.X_OK)
    start_text = start.read_text(encoding="utf-8")
    assert "rabidanti_android.py" in start_text
    assert "0.0.0.0" not in start_text
    assert "curl" not in start_text.lower()
    assert "wget" not in start_text.lower()


def test_android_docs_explicitly_preserve_core_and_permissions():
    text = Path("ANDROID-TERMUX.md").read_text(encoding="utf-8")
    assert "Core" in text
    assert "Permission Gate" in text
    assert "127.0.0.1" in text
    assert "Ollama" in text


def test_shell_scripts_have_valid_bash_syntax():
    bash = shutil_which = __import__("shutil").which("bash")
    if not bash:
        pytest.skip("bash unavailable")
    for script in ("START-RABIDANTI-ANDROID.sh", "SETUP-ANDROID-TERMUX.sh"):
        subprocess.run([bash, "-n", script], check=True)

def test_android_requirements_avoid_uvicorn_standard_native_extras():
    text = Path("requirements-android.txt").read_text(encoding="utf-8")
    assert "uvicorn[standard]" not in text
    assert "uvicorn>=" in text
    for name in ("fastapi", "pydantic", "httpx", "cryptography"):
        assert name in text
