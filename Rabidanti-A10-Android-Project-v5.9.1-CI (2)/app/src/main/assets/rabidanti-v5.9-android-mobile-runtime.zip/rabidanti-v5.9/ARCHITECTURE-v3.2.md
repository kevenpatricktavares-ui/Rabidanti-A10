# Rabidanti v3.2 — Persistent Jobs & Workers

- Durable JobManager backed by SQLite.
- Jobs survive API/process restart.
- Worker identity and execution leases.
- RUNNING jobs are recovered after interruption.
- Retry/FAILED recovery follows max_retries.
- Approval state persists and remains enforced.
- Priority-aware persistent queue and worker primitives.
- API AppState uses PersistentJobManager.

Scope boundary: this is a persistent in-process foundation. Distributed queues,
remote workers, scheduling and autoscaling remain later milestones.
