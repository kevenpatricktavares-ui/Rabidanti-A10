# Rabidanti v5.6 - Windows Native Build Handoff

This source package is prepared for a reproducible Windows x64 native build. It is **not** evidence that a Windows executable has already been built.

## One-command path

From a Windows x64 machine with Python Launcher available:

```bat
BUILD-WINDOWS-RELEASE.cmd
```

The command creates an isolated `.build-venv`, installs the pinned development/build dependencies, verifies the toolchain, builds `Rabidanti.exe`, invokes Inno Setup 6, installs/runs/uninstalls the result in an isolated test directory, and then reconciles release hashes.

## Required external tool

Inno Setup 6 (`ISCC.exe`) must be installed before the native installer can be built. The preparation script refuses to continue if it is missing.

## Evidence required for a valid native release

A publishable Windows build must contain all of:

- `dist/Rabidanti.exe`
- `installer-dist/Rabidanti-Setup-<VERSION>.exe`
- `release-manifest.json`
- `windows-release-validation.json`

Then this command must pass:

```bat
.build-venv\Scripts\python.exe native_release_check.py
```

Absence of these files means the native release has **not** been validated.
