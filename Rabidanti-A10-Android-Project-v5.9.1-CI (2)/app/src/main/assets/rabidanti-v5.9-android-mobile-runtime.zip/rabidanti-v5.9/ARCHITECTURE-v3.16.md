# Rabidanti v3.16 — Observability & Telemetry

Adds a SQLite-backed observability foundation for durable metrics and execution events. The continuous worker runner can emit job lifecycle events and aggregate runner counters. Health snapshots include observability counts when configured.

This is local/persistent observability, not a hosted monitoring service, distributed tracing system, or external alerting platform.
