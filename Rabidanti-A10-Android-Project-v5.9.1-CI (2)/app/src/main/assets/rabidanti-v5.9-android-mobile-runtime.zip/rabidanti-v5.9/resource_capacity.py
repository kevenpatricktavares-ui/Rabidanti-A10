"""Rabidanti v3.20 — Resource and capacity intelligence."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional
import time

from durable_worker_queue import DurableWorkerQueue
from worker_supervisor import WorkerSupervisor

@dataclass(frozen=True)
class CapacityReport:
    capacity: int
    active: int
    available: int
    queued: int
    utilization: float
    saturation: bool
    recommendation: str
    worker_health: dict[str, Any]
    timestamp: float

class ResourceCapacityMonitor:
    """Observe execution capacity and make non-destructive scheduling recommendations."""
    def __init__(self, queue: DurableWorkerQueue, supervisor: Optional[WorkerSupervisor] = None,
                 saturation_threshold: float = 0.9):
        if not 0 < saturation_threshold <= 1:
            raise ValueError("saturation_threshold must be between 0 and 1")
        self.queue = queue
        self.supervisor = supervisor
        self.saturation_threshold = float(saturation_threshold)

    def analyze(self, capacity: int, active: int, now: Optional[float] = None) -> CapacityReport:
        if capacity < 1:
            raise ValueError("capacity must be >= 1")
        if active < 0 or active > capacity:
            raise ValueError("active must be between 0 and capacity")
        now = time.time() if now is None else float(now)
        queued = len(self.queue.ready())
        utilization = active / capacity
        saturation = utilization >= self.saturation_threshold
        if saturation and queued:
            recommendation = "THROTTLE_OR_SCALE"
        elif queued:
            recommendation = "PROCESS_BACKLOG"
        else:
            recommendation = "IDLE_OR_READY"
        worker_health = self.supervisor.health_snapshot(now=now) if self.supervisor else {"available": False}
        return CapacityReport(capacity, active, capacity-active, queued, utilization,
                              saturation, recommendation, worker_health, now)
