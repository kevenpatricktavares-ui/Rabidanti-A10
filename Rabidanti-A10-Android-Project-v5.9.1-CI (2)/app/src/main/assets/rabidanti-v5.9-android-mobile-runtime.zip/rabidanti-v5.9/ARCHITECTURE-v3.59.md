# Rabidanti v3.59 — Priority → Execution Planning Integration

v3.59 connects the Intelligence Prioritization Engine to execution planning.

Flow:
`Intelligence Prioritizer → Priority-Aware Execution Planner → Capacity/Readiness/Dependencies → Durable Queue claim → Worker`

Rules:
- Intelligence priority orients selection; it is not truth, feasibility, profitability, or an execution permission.
- Missing intelligence decisions fall back to the existing durable queue priority.
- Readiness and dependencies remain hard planning constraints.
- Capacity remains a hard limit.
- Approval requirements cannot be bypassed by a high intelligence score.
- The durable queue `claim()` remains the final execution confirmation.
- Planning is deterministic and non-mutating.
- No publishing, spending, external actions, or Core changes are performed by this integration.
