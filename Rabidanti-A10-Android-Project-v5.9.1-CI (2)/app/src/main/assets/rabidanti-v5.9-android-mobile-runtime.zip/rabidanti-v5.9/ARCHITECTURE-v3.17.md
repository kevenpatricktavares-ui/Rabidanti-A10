# Rabidanti v3.17 — Health Monitoring & Conservative Anomaly Detection

## Added
- `HealthMonitor` interprets persisted telemetry and worker health.
- Detects configurable recent job failure-rate anomalies.
- Detects stale workers through `WorkerSupervisor`.
- Produces `HealthReport` with health state, score, alerts and evidence.
- `check_and_record()` records health alerts and health metrics.
- Runner can expose an optional health-monitor section in `health()`.

## Safety / scope
- Monitoring is observational and conservative: it does not delete work, spend money, publish externally, or change core architecture.
- Worker recovery remains owned by the existing Supervisor/Runner logic.
- This is still an in-process/local foundation; it does not claim cloud monitoring, autoscaling, external alerting, multi-region failover, or 24/7 availability by itself.

## Validation
- Full inherited + new suite: 107 tests passed.
