# Rabidanti Architecture v4.0 — Unified Local Runtime MVP

## Runtime assembly

`RabidantiRuntime` is now the local control plane. It initializes and exposes the validated components without bypassing their permission boundaries.

### Persistent runtime surfaces

- Durable Worker Queue
- Persistent Workflow Orchestrator + CoreOrchestrator facade
- Persistent Autonomous Task Runtime
- Persistent Scheduler
- Worker Supervisor
- Laboratory Experiment Manager
- Evidence Memory + integration layer
- Evidence Readiness Gate
- Human Review Workflow
- Integration Proposal Workflow
- Controlled Change Executor
- Runtime event audit database

Each surface uses persistent SQLite-backed state under one selected runtime directory.

## Lifecycle

Startup:

1. Resolve/create state directory.
2. Initialize durable stores.
3. Optionally recover stale RUNNING autonomous tasks.
4. Recover expired durable queue leases.
5. Record `RUNTIME_STARTED` event.
6. Expose status/diagnostic/command surfaces.

Shutdown records `RUNTIME_STOPPED` and closes components with long-lived SQLite connections.

## Safety invariants

Starting the program does not imply authorization to:

- integrate a proposal into the Core;
- self-authorize a controlled change;
- publish externally;
- spend or transfer funds;
- delete external data;
- treat evidence as scientific validation.

The v3.96–v3.99 governance chain remains intact inside the runtime.

## Executability boundary

v4.0 can be executed as a local Python program and used interactively. A standalone OS package, desktop GUI and external connectors are later milestones and must be validated independently.
