"""Rabidanti v3.43 — evidence-driven learning from analytics."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping


def _num(v: Any) -> float | None:
    if v is None or isinstance(v, bool): return None
    try: n=float(v)
    except (TypeError, ValueError): return None
    return n if n >= 0 else None

@dataclass(frozen=True)
class LearningBrief:
    project_id: str
    experiment_id: str
    status: str
    observation: Mapping[str, Any]
    hypotheses: tuple[Mapping[str, Any], ...]
    experiments: tuple[Mapping[str, Any], ...]
    results: Mapping[str, Any]
    learnings: tuple[str, ...]
    next_actions: tuple[str, ...]
    evidence_state: str
    limitations: tuple[str, ...]
    def to_dict(self) -> dict[str, Any]: return asdict(self)

class LearningEngine:
    """Turn measured analytics into explicit hypotheses and testable next steps.

    It never treats a missing metric or an untested hypothesis as a fact.
    """
    def analyze(self, project_id: str, analytics: Mapping[str, Any], ads: Mapping[str, Any] | None = None) -> LearningBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not analytics: raise ValueError("analytics must not be empty")
        metrics = dict(analytics.get("metrics") or {})
        experiment_id = str(analytics.get("experiment_id") or (ads or {}).get("experiment_id") or f"exp-{project_id}-unknown")
        status = str(analytics.get("status") or "WAITING_FOR_DATA")
        if status == "WAITING_FOR_DATA" or not any(v is not None for v in metrics.values()):
            return LearningBrief(str(project_id), experiment_id, "WAITING_FOR_DATA", {}, (), (), {}, (), (), "NO_OBSERVED_DATA",
                ("Learning requires observed analytics; no conclusion was inferred.",))

        obs = {k:v for k,v in metrics.items() if v is not None}
        hypotheses=[]; experiments=[]; learnings=[]; next_actions=[]
        ctr=_num(metrics.get("ctr")); c2c=_num(metrics.get("click_to_checkout_rate")); c2p=_num(metrics.get("checkout_to_purchase_rate")); roas=_num(metrics.get("roas")); refund=_num(metrics.get("refund_rate"))
        variants=tuple((ads or {}).get("variants") or ())
        if ctr is not None:
            hypotheses.append({"id":"h_ctr","statement":"Creative/message changes may materially affect click-through rate.","evidence_metric":"ctr","observed_value":ctr})
            experiments.append({"id":"exp_ctr","type":"creative_variant_test","metric":"ctr","variants":variants or ("control","variant_a")})
            learnings.append(f"Observed CTR = {ctr:.4f}; this is a measurement, not a causal conclusion.")
            next_actions.append("Compare creative variants using CTR with sufficient observations before selecting a winner.")
        if c2c is not None:
            hypotheses.append({"id":"h_checkout","statement":"Landing or offer alignment may affect click-to-checkout conversion.","evidence_metric":"click_to_checkout_rate","observed_value":c2c})
            experiments.append({"id":"exp_checkout","type":"landing_or_offer_test","metric":"click_to_checkout_rate"})
            learnings.append(f"Observed click-to-checkout rate = {c2c:.4f}.")
            next_actions.append("Test one landing/offer variable while holding other major variables stable.")
        if c2p is not None:
            hypotheses.append({"id":"h_purchase","statement":"Checkout friction or offer clarity may affect purchase conversion.","evidence_metric":"checkout_to_purchase_rate","observed_value":c2p})
            experiments.append({"id":"exp_purchase","type":"checkout_or_offer_test","metric":"checkout_to_purchase_rate"})
            learnings.append(f"Observed checkout-to-purchase rate = {c2p:.4f}.")
            next_actions.append("Investigate checkout completion before increasing traffic spend.")
        if roas is not None:
            hypotheses.append({"id":"h_economics","statement":"Campaign economics should be evaluated against observed revenue and spend.","evidence_metric":"roas","observed_value":roas})
            learnings.append(f"Observed ROAS = {roas:.4f}.")
            next_actions.append("Use observed spend and revenue to decide whether another controlled campaign test is justified.")
        if refund is not None:
            hypotheses.append({"id":"h_refund","statement":"Product/offer expectations may influence refund rate.","evidence_metric":"refund_rate","observed_value":refund})
            learnings.append(f"Observed refund rate = {refund:.4f}.")
            next_actions.append("Review refund reasons before scaling the offer.")
        evidence = "SUFFICIENT_FOR_LEARNING" if len(hypotheses) else "PARTIAL"
        return LearningBrief(str(project_id), experiment_id, "ANALYZED", obs, tuple(hypotheses), tuple(experiments), obs,
            tuple(learnings), tuple(dict.fromkeys(next_actions)), evidence,
            ("Observations do not establish causality; controlled experiments and adequate sample sizes are required.",
             "No platform performance is assumed unless supplied through a verified data source."))
