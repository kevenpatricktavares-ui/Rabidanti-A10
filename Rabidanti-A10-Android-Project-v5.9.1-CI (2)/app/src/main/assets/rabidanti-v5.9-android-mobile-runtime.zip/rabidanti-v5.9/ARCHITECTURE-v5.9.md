# Rabidanti v5.9 — Android Compatibility & Mobile Runtime

## Objective

Run the existing Rabidanti product on Android through Termux without forking or
rewriting the Core. Android is treated as an additional host adapter around the
same runtime, local API, Sala, databases, vault, permission gates and audit
model used elsewhere.

## Host boundary

`rabidanti_android.py` is the platform adapter. Its responsibilities are limited
to:

- Android/Termux environment detection;
- mobile state-directory selection;
- dependency and loopback readiness diagnostics;
- launching the existing runtime/API/Sala;
- opening the loopback Sala with `termux-open-url` or Android `am` when present.

It does not alter Core behavior, grant permissions, enable connectors or choose
an external model provider automatically.

## Android state

Default state location:

`$HOME/.local/share/rabidanti`

`RABIDANTI_STATE_DIR` remains the explicit override.

## Network boundary

The Android adapter binds only to `127.0.0.1`. The Sala and API remain local to
the device. No Android-specific code binds to `0.0.0.0`.

## Dependencies

`requirements-android.txt` mirrors the runtime packages but deliberately uses
plain `uvicorn` rather than `uvicorn[standard]` to avoid optional native extras
that add friction on Termux.

## Model behavior

Ollama is optional and is not assumed to exist on Android. If no compatible
model endpoint is available, the existing diagnostics/observability layer shows
the limitation. The Android adapter does not silently route prompts to an
external model.

## Safety invariants

- `external_action_authorized = false` by default.
- no connector is auto-enabled;
- no model is auto-downloaded;
- no critical action bypasses the Permission Gate;
- diagnostics are read-only and do not create persistent state;
- Android support remains a host layer, not a separate Rabidanti fork.
