# Rabidanti v3.63 — Forward Controlled Experimentation

## Objective
Move adaptive prioritization from retrospective shadow evaluation to a bounded forward experiment layer.

## Flow
Adaptive proposal → experiment definition → deterministic control/treatment assignment → real execution outcome → descriptive comparison → promotion gate.

## Guarantees
- Production prioritization weights are never changed by the experiment engine.
- Assignments are deterministic for `(experiment_id, candidate_id)` and persisted.
- Outcomes must match the persisted assignment arm.
- Dependencies, approvals, capacity and durable queue claims remain outside and authoritative.
- Minimum evidence is required before comparison.
- Results are descriptive and do not establish causality.
- A promising result enters `PROMOTION_PENDING`; explicit approval is required.
- Approval only changes experiment state; it does not mutate production weights.

## States
`PROPOSED → RUNNING → COMPLETED → PROMOTION_PENDING → APPROVED`

Rejected paths are explicit and terminal.

## Scope boundary
v3.63 provides the forward experiment registry/assignment/evaluation primitive. It does not yet automatically wire experiment assignment into every production job or automatically apply approved weights. That integration must remain a separate, tested step.
