from evolution_evidence_fusion import EvidenceItem, EvolutionEvidenceFusion

def build():
    f=EvolutionEvidenceFusion()
    f.add(EvidenceItem("a",.9,.9,.9)); f.add(EvidenceItem("b",.8,.9,.8)); return f

def test_strong_fusion():
    x=build().fuse("f1",["a","b"],.9)
    assert x.status=="STRONG_FUSED_EVIDENCE" and x.fused_score>=.75

def test_moderate_fusion():
    f=EvolutionEvidenceFusion()
    f.add(EvidenceItem("a",.7,.7,.7)); f.add(EvidenceItem("b",.7,.6,.7))
    x=f.fuse("f",["a","b"],.6); assert x.status=="MODERATE_FUSED_EVIDENCE"

def test_low_independence():
    f=EvolutionEvidenceFusion(min_independence=.5)
    f.add(EvidenceItem("a",.95,.95,.1)); f.add(EvidenceItem("b",.95,.95,.1))
    assert f.fuse("f",["a","b"],.95).status=="LOW_INDEPENDENCE"

def test_unknown_duplicate_blocked():
    f=build()
    for ids in (["a","z"],["a","a"]):
        try: f.fuse("x",ids,.5); assert False
        except ValueError: pass

def test_invalid_values():
    f=EvolutionEvidenceFusion()
    try: f.add(EvidenceItem("x",1.1,.5,.5)); assert False
    except ValueError: pass
    f.add(EvidenceItem("x",.5,.5,.5))
    try: f.fuse("f",["x"],1.2); assert False
    except ValueError: pass

def test_no_execution_authority():
    f=EvolutionEvidenceFusion()
    assert not hasattr(f,"activate") and not hasattr(f,"deploy") and not hasattr(f,"approve")
