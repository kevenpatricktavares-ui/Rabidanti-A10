# Rabidanti v3.0 — Security & Persistence Foundation

This release hardens the v2.9 control layer without changing the core product pipeline.

## Added
- Transactional SQLite store with WAL and foreign-key enforcement.
- Persistent schemas for projects, jobs, connectors, approvals and audit events.
- Indexed project/job/audit lookups.
- PBKDF2-SHA256 password hashing with unique salts.
- Constant-time password verification.
- Expiring bearer-session foundation with explicit revocation.
- No secrets, passwords or session tokens are written to audit metadata by this layer.

## Security rules
- Persistence does not bypass project isolation.
- Approval remains separate from connector permission.
- PUBLISH, DELETE and SPEND remain sensitive operations requiring explicit approval.
- Session validation rejects expired or revoked tokens.
- This is a foundation, not a public-deployment security certification.

## Next
- Wire repositories into the FastAPI application and authenticated project routes.
- Add complete cross-project, privilege-escalation and rate-limit tests.
- Add durable workers/queue storage and migration tooling.
