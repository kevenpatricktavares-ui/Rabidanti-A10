# Rabidanti v3.33 — Opportunity Engine Integration

Research output is persisted as a durable business-stage artifact. The Opportunity Engine consumes that artifact and produces a traceable OpportunityBrief. Scores are deterministic heuristics, not market forecasts. Missing evidence is reported as a limitation.

Flow: Research Engine -> StageArtifactStore -> Opportunity Engine -> durable workflow result.
