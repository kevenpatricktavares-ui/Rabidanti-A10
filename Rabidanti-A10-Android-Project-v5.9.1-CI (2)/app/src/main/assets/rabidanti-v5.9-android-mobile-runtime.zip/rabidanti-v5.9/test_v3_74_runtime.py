from evolution_runtime import EvolutionRuntime
from evolution_cycle_store import EvolutionCycleStore
from evolution_cycle_audit import EvolutionCycleAudit
from evolution_decision_controller_bridge import EvolutionDecisionControllerBridge
from evolution_evidence_decision import EvolutionEvidenceDecisionEngine, EvidenceAssessment


class Controller:
    def __init__(self): self.calls=[]
    def request_activation(self,pid):
        self.calls.append(pid)
        return "requested"


def assessment(**kw):
    d=dict(evidence_confidence=.9, expected_impact=.8, risk=.2,
           estimated_cost=.2, reversibility=.9)
    d.update(kw)
    return EvidenceAssessment(**d)


def runtime():
    c=Controller()
    bridge=EvolutionDecisionControllerBridge(
        c, EvolutionEvidenceDecisionEngine()
    )
    store=EvolutionCycleStore()
    return EvolutionRuntime(bridge, EvolutionCycleAudit(store)), store, c


def test_runtime_persists_allowed_decision():
    r,s,_=runtime()
    out=r.evaluate("p1",assessment(),"evt1")
    assert out.gate=="allowed"
    assert s.latest("p1").event_id=="evt1"


def test_runtime_persists_blocked_decision():
    r,s,_=runtime()
    out=r.evaluate("p2",assessment(evidence_confidence=.4),"evt2")
    assert out.gate=="blocked"
    assert s.latest("p2").gate=="blocked"


def test_runtime_does_not_activate():
    r,_,c=runtime()
    r.evaluate("p3",assessment(),"evt3")
    assert c.calls==[]


def test_activation_requires_approval():
    r,_,_=runtime()
    try:
        r.request_activation("p4",assessment())
        assert False
    except PermissionError:
        assert True


def test_approved_activation_is_delegated():
    r,_,c=runtime()
    assert r.request_activation("p5",assessment(),approval=True)=="requested"
    assert c.calls==["p5"]
