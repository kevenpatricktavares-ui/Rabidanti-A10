from dataclasses import dataclass

@dataclass(frozen=True)
class PatternAssessment:
    correlation_id: str
    observations: int
    average_strength: float
    latest_strength: float
    persistence: float
    trend_factor: float
    evidence_score: float
    status: str

class EvolutionPatternAssessment:
    def __init__(self, min_observations=2):
        if min_observations < 1:
            raise ValueError("min_observations must be positive")
        self.min_observations = min_observations

    def assess(self, trend):
        if trend is None:
            raise ValueError("trend is required")
        if trend.observations < self.min_observations:
            return PatternAssessment(
                trend.correlation_id, trend.observations,
                trend.average_strength, trend.latest_strength,
                0.0, 0.0, 0.0, "INSUFFICIENT_HISTORY"
            )
        factors = {"RISING":1.0, "STABLE":.75, "FALLING":.35}
        if trend.trend not in factors:
            return PatternAssessment(
                trend.correlation_id, trend.observations,
                trend.average_strength, trend.latest_strength,
                min(1.0, trend.observations/5.0), 0.0, 0.0,
                "WEAK_EVIDENCE"
            )
        persistence = min(1.0, trend.observations / 5.0)
        trend_factor = factors[trend.trend]
        score = round(
            trend.average_strength*.40 + trend.latest_strength*.25 +
            persistence*.20 + trend_factor*.15, 6
        )
        status = "STRONG_EVIDENCE" if score >= .75 else "MODERATE_EVIDENCE" if score >= .55 else "WEAK_EVIDENCE"
        return PatternAssessment(
            trend.correlation_id, trend.observations,
            trend.average_strength, trend.latest_strength,
            round(persistence,6), trend_factor, score, status
        )
