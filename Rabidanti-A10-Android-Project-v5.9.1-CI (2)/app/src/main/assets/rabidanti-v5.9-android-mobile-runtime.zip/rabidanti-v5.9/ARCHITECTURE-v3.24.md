# Rabidanti v3.24 — Durable Job Dependencies

The durable worker queue now supports explicit task dependencies. A queued item becomes eligible only when every declared dependency task_id exists and is COMPLETED. Dependencies persist across restart. Self-dependencies are rejected. Missing dependencies remain blocked rather than executing incorrectly. The Execution Planner consumes only queue-ready work, so dependency gating is enforced before planning/claiming.

This is an in-process SQLite foundation; it does not claim distributed DAG scheduling, external brokers, cloud orchestration, or autoscaling.
