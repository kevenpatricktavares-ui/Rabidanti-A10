# Rabidanti v3.22 — Execution Planning

Adds a capacity-aware, non-mutating execution planning layer.

## Flow
Capacity Intelligence → eligible work → priority/dependency ordering → bounded execution plan → runner/queue.

## Guarantees
- Plans never mutate queue state.
- Only ready items with satisfied dependencies are eligible.
- Higher priority wins; item id provides deterministic tie-breaking.
- Available capacity strictly bounds selected work.
- No autoscaling, spending, publishing, destructive action, or arbitrary code execution.
- Forecast information is advisory only.
