# Rabidanti v3.8 — Autonomous Task Runtime

v3.8 introduces a task-level autonomy layer above Jobs/Workers.

Capabilities:
- task lifecycle and states
- priority ordering
- dependency gating
- worker ownership
- retry/failure limits
- cancellation
- result/error history in task objects

The runtime does not execute arbitrary code itself. Actual work remains
delegated to the existing Job/Queue/Worker layers.

This release is an in-process foundation. Task persistence, distributed
coordination, cloud deployment, resource budgets and production monitoring
remain future stages.
