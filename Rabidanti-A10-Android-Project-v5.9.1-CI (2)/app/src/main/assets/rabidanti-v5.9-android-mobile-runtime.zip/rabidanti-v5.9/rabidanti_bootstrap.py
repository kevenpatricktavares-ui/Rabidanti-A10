#!/usr/bin/env python3
"""Dependency-light Rabidanti product bootstrap utility."""
from __future__ import annotations

import argparse
import json
from rabidanti_product import ProductFoundation, default_state_dir


def emit(value) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, default=str))


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="rabidanti-bootstrap")
    p.add_argument("--state-dir", default=str(default_state_dir()))
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    sub.add_parser("setup")
    sub.add_parser("build-info")
    args = p.parse_args(argv)
    product = ProductFoundation(args.state_dir)
    if args.command == "doctor":
        emit(product.doctor())
    elif args.command == "setup":
        emit(product.initialize())
    else:
        emit(product.build_info())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
