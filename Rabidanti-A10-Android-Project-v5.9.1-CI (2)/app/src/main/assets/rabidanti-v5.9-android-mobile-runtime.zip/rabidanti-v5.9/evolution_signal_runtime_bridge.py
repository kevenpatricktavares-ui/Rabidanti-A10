from dataclasses import dataclass
from evolution_runtime import EvolutionRuntime


@dataclass(frozen=True)
class SignalRuntimeInput:
    signal_id: str
    proposal_id: str
    assessment: object
    event_id: str


class EvolutionSignalRuntimeBridge:
    """Feeds validated signal-derived assessments into the evolution runtime.

    This bridge performs no activation and does not modify source signals.
    """

    def __init__(self, runtime: EvolutionRuntime):
        self.runtime = runtime
        self._seen = set()

    def process(self, item: SignalRuntimeInput):
        if not item.signal_id or not item.proposal_id or not item.event_id:
            raise ValueError("signal_id, proposal_id and event_id are required")
        if item.signal_id in self._seen:
            raise ValueError("duplicate signal_id")
        self._seen.add(item.signal_id)
        return self.runtime.evaluate(
            item.proposal_id, item.assessment, item.event_id
        )
