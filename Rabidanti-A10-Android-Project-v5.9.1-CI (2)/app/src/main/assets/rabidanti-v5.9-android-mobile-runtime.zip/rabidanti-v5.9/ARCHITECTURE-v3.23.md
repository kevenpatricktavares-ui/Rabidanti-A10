# Rabidanti v3.23 — Execution Planner Integration

The ContinuousWorkerRunner now uses the v3.22 ExecutionPlanner when CapacityIntelligence is available.
The planner remains non-mutating: it produces a bounded deterministic selection, then the runner performs normal durable queue claims.
If no planner/intelligence is supplied, the runner retains the previous queue-ready behavior.
The integration records execution-plan creation in observability and does not perform autoscaling or spending.
