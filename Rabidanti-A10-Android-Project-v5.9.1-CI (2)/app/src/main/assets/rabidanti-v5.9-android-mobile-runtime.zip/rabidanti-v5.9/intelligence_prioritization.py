"""Rabidanti v3.58 — bounded Intelligence Prioritization Engine.

Ranks investigation/opportunity candidates using only supplied signals. The
engine never invents market facts or decides to execute work; it produces a
transparent, deterministic priority score and preserves the component scores.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import IntEnum
from typing import Iterable


class PriorityBand(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass(frozen=True)
class PriorityCandidate:
    candidate_id: str
    kind: str
    novelty: float = 0.0
    confidence: float = 0.0
    relevance: float = 0.0
    impact: float = 0.0
    urgency: float = 0.0
    knowledge_gap: float = 0.0
    investigation_cost: float = 0.0

    def validate(self) -> None:
        if not str(self.candidate_id).strip():
            raise ValueError("candidate_id is required")
        if not str(self.kind).strip():
            raise ValueError("kind is required")
        for name in ("novelty", "confidence", "relevance", "impact", "urgency", "knowledge_gap", "investigation_cost"):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")


@dataclass(frozen=True)
class PriorityDecision:
    candidate_id: str
    kind: str
    score: float
    band: PriorityBand
    components: dict[str, float]
    rationale: tuple[str, ...]

    def to_dict(self) -> dict:
        data = asdict(self)
        data["band"] = self.band.name
        return data


class IntelligencePrioritizer:
    """Deterministic, explainable ranking; no external facts are inferred."""

    WEIGHTS = {
        "novelty": 0.15,
        "confidence": 0.20,
        "relevance": 0.20,
        "impact": 0.20,
        "urgency": 0.10,
        "knowledge_gap": 0.10,
        "investigation_cost": -0.05,
    }

    def score(self, candidate: PriorityCandidate) -> PriorityDecision:
        candidate.validate()
        components = {name: round(float(getattr(candidate, name)), 4) for name in self.WEIGHTS}
        raw = sum(components[name] * weight for name, weight in self.WEIGHTS.items())
        score = round(max(0.0, min(1.0, raw)), 4)
        band = self._band(score)
        rationale = self._rationale(components, band)
        return PriorityDecision(candidate.candidate_id, candidate.kind, score, band, components, rationale)

    def rank(self, candidates: Iterable[PriorityCandidate], *, limit: int | None = None) -> list[PriorityDecision]:
        decisions = [self.score(c) for c in candidates]
        decisions.sort(key=lambda d: (-d.score, -int(d.band), d.candidate_id))
        if limit is not None:
            if int(limit) < 1:
                raise ValueError("limit must be at least 1")
            decisions = decisions[:int(limit)]
        return decisions

    @staticmethod
    def _band(score: float) -> PriorityBand:
        if score >= 0.80:
            return PriorityBand.CRITICAL
        if score >= 0.60:
            return PriorityBand.HIGH
        if score >= 0.40:
            return PriorityBand.MEDIUM
        return PriorityBand.LOW

    @staticmethod
    def _rationale(c: dict[str, float], band: PriorityBand) -> tuple[str, ...]:
        reasons = [f"Priority band: {band.name}."]
        strongest = sorted(((v, k) for k, v in c.items() if k != "investigation_cost"), reverse=True)[:2]
        for value, name in strongest:
            if value >= 0.70:
                reasons.append(f"High {name.replace('_', ' ')} signal ({value:.2f}).")
        if c["investigation_cost"] >= 0.70:
            reasons.append("High investigation cost reduces priority.")
        if not any(value >= 0.70 for value, _ in strongest) and c["investigation_cost"] < 0.70:
            reasons.append("No individual priority factor dominates the decision.")
        return tuple(reasons)
