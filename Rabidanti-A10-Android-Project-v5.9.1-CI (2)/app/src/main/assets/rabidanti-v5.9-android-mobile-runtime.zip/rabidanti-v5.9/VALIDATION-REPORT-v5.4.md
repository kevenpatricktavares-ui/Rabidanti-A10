# Rabidanti v5.4 — Validation Report

## Result

**Source release candidate: PASS**

**Native Windows EXE/installer: NOT BUILT / NOT VALIDATED in this environment**

## Baseline

Input: Rabidanti v5.3 source package, previously validated with 664 tests.

## Defect corrected

The v5.3 Windows metadata contained an inconsistency: `FileVersion` and `ProductVersion` strings were 5.3.0 while `FixedFileInfo.filevers/prodvers` were still 5.2.0. v5.4 removes manual duplication by generating Windows metadata and Inno Setup version fields from the single `VERSION` file.

## New release controls

- `rabidanti_release.py sync`: generates native version metadata from `VERSION`.
- `rabidanti_release.py preflight`: cross-checks VERSION, PyInstaller spec, installer metadata, icon and release scripts.
- `rabidanti_release.py postbuild`: validates real PE headers and SHA-256 before writing `release-manifest.json`.
- `build_release_windows.bat`: requires real PyInstaller EXE plus real Inno Setup installer before a full native release manifest is produced.
- Source packages intentionally contain no `release-manifest.json`; native validation cannot be implied from source tests.

## Test results

- v5.x: 61 passed
- v4.x: 121 passed
- v3.x: 157 passed
- historical `tests/`: 337 passed
- **Total: 676 passed, 0 failed**
- `compileall`: PASS
- release preflight: PASS (16 checks)

## Environment limitation

This Linux validation environment has neither a PyInstaller executable nor Inno Setup `ISCC.exe`. No `Rabidanti.exe` or Windows Setup executable was fabricated or marked as validated. The release candidate includes the deterministic build/validation pipeline and a Windows end-to-end checklist for the next stage.

## Security

No new authority was granted to models, connectors, updates or the Core. Native release tooling only validates packaging artifacts and hashes.
