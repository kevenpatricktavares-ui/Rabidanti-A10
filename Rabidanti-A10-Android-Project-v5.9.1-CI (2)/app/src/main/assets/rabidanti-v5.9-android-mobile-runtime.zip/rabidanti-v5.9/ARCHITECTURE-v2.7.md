# Rabidanti v2.7 — Job & Execution Foundation

## Purpose
Introduce a clear operational execution model.

Agent = intelligence
Job = operational task
Connector = external capability
Approval = authorization

## States
QUEUED, RUNNING, COMPLETED, FAILED, RETRY, WAITING_APPROVAL.

## Guarantees
- approval-required jobs cannot execute before approval;
- failures become RETRY while retry budget remains;
- exhausted retry budget becomes FAILED;
- every job belongs to a project;
- results/errors and timestamps are retained in the job object.

## Current boundary
This version is an in-process execution foundation. Durable persistence,
queue infrastructure, worker processes and distributed execution are next.
