#!/usr/bin/env python3
"""Cross-platform inspection of Windows-native release evidence.

This does not execute Windows artifacts. It verifies that a Windows run produced
consistent build and end-to-end validation evidence for the current VERSION.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

class NativeEvidenceError(RuntimeError):
    pass

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def validate(root: Path) -> dict:
    version=(root/'VERSION').read_text(encoding='utf-8').strip()
    manifest_path=root/'release-manifest.json'
    windows_path=root/'windows-release-validation.json'
    if not manifest_path.exists():
        raise NativeEvidenceError('release-manifest.json is missing')
    if not windows_path.exists():
        raise NativeEvidenceError('windows-release-validation.json is missing')
    manifest=json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    windows=json.loads(windows_path.read_text(encoding='utf-8-sig'))
    if manifest.get('version') != version or windows.get('version') != version:
        raise NativeEvidenceError('release evidence version mismatch')
    if manifest.get('native_build_validated') is not True:
        raise NativeEvidenceError('native build is not validated')
    if windows.get('end_to_end_windows_validated') is not True:
        raise NativeEvidenceError('Windows end-to-end validation did not pass')
    exe=root/'dist'/'Rabidanti.exe'
    setup=root/'installer-dist'/f'Rabidanti-Setup-{version}.exe'
    if not exe.exists() or not setup.exists():
        raise NativeEvidenceError('native artifacts are missing')
    expected_exe=manifest['artifacts']['executable']['sha256']
    expected_setup=manifest['artifacts']['installer']['sha256']
    if sha256(exe) != expected_exe or sha256(setup) != expected_setup:
        raise NativeEvidenceError('native artifact hash mismatch against release manifest')
    if windows.get('executable_sha256') != expected_exe or windows.get('installer_sha256') != expected_setup:
        raise NativeEvidenceError('Windows validation hashes do not match release manifest')
    return {'ok': True, 'version': version, 'native_release_verified': True, 'checks': len(windows.get('checks',{}))}

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--root', default='.')
    a=p.parse_args(argv)
    try:
        result=validate(Path(a.root).resolve())
    except (NativeEvidenceError, KeyError, json.JSONDecodeError) as e:
        print(json.dumps({'ok':False,'error':str(e)}, indent=2))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
