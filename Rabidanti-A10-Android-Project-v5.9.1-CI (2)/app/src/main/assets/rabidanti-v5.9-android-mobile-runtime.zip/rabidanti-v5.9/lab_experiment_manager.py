"""Rabidanti v3.85 — structured experiment and prototype management.

Stores plans, success criteria, observations, artifacts and human-reviewed reports.
This module records experiments; it does not execute arbitrary code or auto-integrate changes.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
import json, sqlite3

@dataclass(frozen=True)
class Experiment:
    experiment_id: str
    project_id: str
    title: str
    hypothesis: str
    method: str
    success_criteria: tuple[str, ...]
    status: str
    created_at: str
    updated_at: str

class LabExperimentManager:
    STATUSES = {"PLANNED", "RUNNING", "ANALYSIS", "PASSED", "FAILED", "CANCELLED"}
    TRANSITIONS = {
        "PLANNED": {"RUNNING", "CANCELLED"},
        "RUNNING": {"ANALYSIS", "CANCELLED"},
        "ANALYSIS": {"PASSED", "FAILED", "RUNNING", "CANCELLED"},
        "PASSED": set(), "FAILED": set(), "CANCELLED": set(),
    }
    def __init__(self, database="rabidanti_laboratory.sqlite3"):
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as c:
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("CREATE TABLE IF NOT EXISTS lab_experiments(experiment_id TEXT PRIMARY KEY,project_id TEXT NOT NULL,title TEXT NOT NULL,hypothesis TEXT NOT NULL,method TEXT NOT NULL,success_criteria TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS lab_experiment_entries(entry_id TEXT PRIMARY KEY,experiment_id TEXT NOT NULL,entry_type TEXT NOT NULL,content TEXT NOT NULL,metadata TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(experiment_id) REFERENCES lab_experiments(experiment_id))")
            c.execute("CREATE TABLE IF NOT EXISTS lab_experiment_events(event_id TEXT PRIMARY KEY,experiment_id TEXT NOT NULL,from_status TEXT,to_status TEXT NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(experiment_id) REFERENCES lab_experiments(experiment_id))")
    def _connect(self):
        c=sqlite3.connect(self.database); c.row_factory=sqlite3.Row; return c
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def _record(r):
        return Experiment(r['experiment_id'],r['project_id'],r['title'],r['hypothesis'],r['method'],tuple(json.loads(r['success_criteria'])),r['status'],r['created_at'],r['updated_at'])
    def create(self, experiment_id, project_id, title, hypothesis, method, success_criteria):
        fields=(experiment_id,project_id,title,hypothesis,method)
        if any(not isinstance(x,str) or not x.strip() for x in fields): raise ValueError('experiment_id, project_id, title, hypothesis and method are required')
        if not isinstance(success_criteria,(list,tuple)) or not success_criteria or any(not isinstance(x,str) or not x.strip() for x in success_criteria): raise ValueError('at least one non-empty success criterion is required')
        now=self._now()
        with self._connect() as c:
            try: c.execute('INSERT INTO lab_experiments VALUES(?,?,?,?,?,?,?,?,?)',(experiment_id.strip(),project_id.strip(),title.strip(),hypothesis.strip(),method.strip(),json.dumps(list(dict.fromkeys(x.strip() for x in success_criteria))), 'PLANNED',now,now))
            except sqlite3.IntegrityError as e: raise ValueError('duplicate experiment_id') from e
        return self.get(experiment_id)
    def get(self, experiment_id):
        with self._connect() as c: r=c.execute('SELECT * FROM lab_experiments WHERE experiment_id=?',(experiment_id,)).fetchone()
        if r is None: raise KeyError(experiment_id)
        return self._record(r)
    def add_entry(self, experiment_id, entry_id, entry_type, content, metadata=None):
        if entry_type not in {'OBSERVATION','ARTIFACT','RESULT','RISK','RECOMMENDATION'}: raise ValueError('unsupported entry_type')
        if any(not isinstance(x,str) or not x.strip() for x in (entry_id,content)): raise ValueError('entry_id and content are required')
        if metadata is not None and not isinstance(metadata,dict): raise ValueError('metadata must be a dictionary')
        self.get(experiment_id); now=self._now()
        with self._connect() as c:
            try: c.execute('INSERT INTO lab_experiment_entries VALUES(?,?,?,?,?,?)',(entry_id,experiment_id,entry_type,content.strip(),json.dumps(metadata or {},sort_keys=True),now))
            except sqlite3.IntegrityError as e: raise ValueError('duplicate entry_id') from e
        return self.list_entries(experiment_id)[-1]
    def list_entries(self, experiment_id, entry_type=None):
        self.get(experiment_id)
        with self._connect() as c:
            if entry_type is None: rows=c.execute('SELECT * FROM lab_experiment_entries WHERE experiment_id=? ORDER BY created_at,entry_id',(experiment_id,)).fetchall()
            else: rows=c.execute('SELECT * FROM lab_experiment_entries WHERE experiment_id=? AND entry_type=? ORDER BY created_at,entry_id',(experiment_id,entry_type)).fetchall()
        return [dict(r, metadata=json.loads(r['metadata'])) for r in rows]
    def transition(self, experiment_id, to_status, event_id, note=''):
        if not isinstance(event_id,str) or not event_id.strip(): raise ValueError('event_id is required')
        if to_status not in self.STATUSES: raise ValueError('unknown status')
        now=self._now()
        with self._connect() as c:
            r=c.execute('SELECT * FROM lab_experiments WHERE experiment_id=?',(experiment_id,)).fetchone()
            if r is None: raise KeyError(experiment_id)
            current=r['status']
            if to_status not in self.TRANSITIONS[current]: raise ValueError(f'invalid transition: {current} -> {to_status}')
            try: c.execute('INSERT INTO lab_experiment_events VALUES(?,?,?,?,?,?)',(event_id,experiment_id,current,to_status,(note or '').strip(),now))
            except sqlite3.IntegrityError as e: raise ValueError('duplicate event_id') from e
            c.execute('UPDATE lab_experiments SET status=?,updated_at=? WHERE experiment_id=?',(to_status,now,experiment_id))
        return self.get(experiment_id)
    def report(self, experiment_id):
        exp=self.get(experiment_id); entries=self.list_entries(experiment_id)
        return {'experiment':exp.__dict__,'entries':entries,'criteria':list(exp.success_criteria),'status':exp.status,'integration_authorized':False,'note':'This report records evidence; integration requires separate human approval.'}
