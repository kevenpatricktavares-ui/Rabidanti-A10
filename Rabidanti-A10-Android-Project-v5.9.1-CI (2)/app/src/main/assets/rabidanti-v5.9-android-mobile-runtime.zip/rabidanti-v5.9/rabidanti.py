#!/usr/bin/env python3
"""Rabidanti v4.0 command-line entry point."""
from __future__ import annotations

import argparse
import json
import shlex
import sys
import os
import webbrowser
import getpass
from pathlib import Path
from urllib.parse import urlencode

from rabidanti_runtime import RabidantiRuntime
from rabidanti_api import RabidantiApiService
from rabidanti_product import ProductFoundation, default_state_dir
from rabidanti_recovery import StateBackupManager, RecoverySession, OfflineUpdateManager, StateSchemaManager
from rabidanti_selftest import ProductSelfTest


def emit(value) -> None:
    payload = json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n"
    output_file = os.environ.get("RABIDANTI_OUTPUT_FILE")
    if output_file:
        path = Path(output_file).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(payload, encoding="utf-8")
        return
    if sys.stdout is not None:
        sys.stdout.write(payload)
        sys.stdout.flush()


def room_browser_url(base_url: str, token: str, setup_required: bool) -> str:
    """Build a loopback Sala URL carrying only ephemeral data in the fragment."""
    return base_url.rstrip("/") + "/ui/#" + urlencode({
        "token": token,
        "setup": "1" if setup_required else "0",
    })


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="rabidanti", description="Rabidanti local personal AI runtime")
    p.add_argument("--state-dir", default=".rabidanti", help="persistent runtime state directory")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("status", help="show runtime status")
    sub.add_parser("doctor", help="run local diagnostics")
    sub.add_parser("observe", help="show read-only operational observability snapshot")
    sub.add_parser("events", help="show recent runtime events")
    sub.add_parser("shell", help="start interactive Rabidanti shell")
    product = sub.add_parser("product", help="inspect or initialize the product environment")
    product_sub = product.add_subparsers(dest="product_command", required=True)
    product_sub.add_parser("doctor", help="check Python, dependencies, state path and optional Ollama")
    product_sub.add_parser("setup", help="initialize the persistent product state directory")
    product_sub.add_parser("build-info", help="show product/build environment information")
    product_sub.add_parser("self-test", help="run an isolated, non-destructive product readiness test")
    product_sub.add_parser("recovery-status", help="show crash/liveness recovery status")
    product_sub.add_parser("backup-list", help="list local state backups")
    backup_create = product_sub.add_parser("backup-create", help="create a local state backup")
    backup_create.add_argument("--reason", required=True)
    backup_restore = product_sub.add_parser("backup-restore", help="explicitly restore a local backup overlay")
    backup_restore.add_argument("backup")
    backup_restore.add_argument("--confirm", action="store_true")
    update_inspect = product_sub.add_parser("update-inspect", help="verify an offline update package")
    update_inspect.add_argument("package")
    update_inspect.add_argument("--sha256", required=True)
    update_stage = product_sub.add_parser("update-stage", help="backup state and stage a verified offline update")
    update_stage.add_argument("package")
    update_stage.add_argument("--sha256", required=True)
    update_stage.add_argument("--actor", required=True)
    update_stage.add_argument("--reason", required=True)
    product_sub.add_parser("update-list", help="show staged offline update plans")
    product_sub.add_parser("migration-status", help="show persistent-state schema status")
    migration = product_sub.add_parser("migrate-state", help="explicitly migrate persistent-state schema")
    migration.add_argument("--confirm", action="store_true")
    chat = sub.add_parser("chat", help="send one message to the local AI model")
    chat.add_argument("message")
    chat.add_argument("--conversation-id")
    model = sub.add_parser("model", help="inspect local model availability")
    model.add_argument("action", choices=["status", "list"])
    reason = sub.add_parser("reason", help="ask the planning layer for non-executing proposals")
    reason.add_argument("request")
    reason.add_argument("--context")
    rp = sub.add_parser("proposals", help="show stored reasoning proposals")
    rp.add_argument("--limit", type=int, default=100)
    prv = sub.add_parser("proposal-review", help="approve or reject a reasoning proposal")
    prv.add_argument("proposal_id")
    prv.add_argument("decision", choices=["APPROVED", "REJECTED"])
    prv.add_argument("--actor", required=True)
    prv.add_argument("--reason", required=True)
    pau = sub.add_parser("proposal-authorize", help="authorize an approved proposal for one controlled execution")
    pau.add_argument("proposal_id")
    pau.add_argument("--actor", required=True)
    pau.add_argument("--reason", required=True)
    pex = sub.add_parser("proposal-execute", help="execute a reviewed and separately authorized proposal")
    pex.add_argument("proposal_id")
    pex.add_argument("--actor", required=True)
    prs = sub.add_parser("proposal-reviews", help="show proposal human reviews")
    prs.add_argument("--limit", type=int, default=100)
    pes = sub.add_parser("proposal-executions", help="show proposal execution ledger")
    pes.add_argument("--limit", type=int, default=100)

    serve = sub.add_parser("serve", help="run loopback-only local API service")
    serve.add_argument("--host", default="127.0.0.1", help="loopback host only")
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--api-token", help="mutation bearer token; defaults to RABIDANTI_API_TOKEN or a generated ephemeral token")

    room = sub.add_parser("room", help="open the local Rabidanti Sala interface")
    room.add_argument("--host", default="127.0.0.1", help="loopback host only")
    room.add_argument("--port", type=int, default=8765)
    room.add_argument("--api-token", help="mutation bearer token; defaults to RABIDANTI_API_TOKEN or a generated ephemeral token")
    room.add_argument("--no-browser", action="store_true", help="start the Sala without opening a browser")

    task = sub.add_parser("task", help="manage persistent tasks")
    tsub = task.add_subparsers(dest="task_command", required=True)
    ta = tsub.add_parser("add")
    ta.add_argument("name")
    ta.add_argument("--priority", choices=["LOW", "NORMAL", "HIGH", "CRITICAL"], default="NORMAL")
    ta.add_argument("--max-attempts", type=int, default=3)
    tl = tsub.add_parser("list")
    tl.add_argument("--state", choices=["QUEUED", "RUNNING", "WAITING", "COMPLETED", "FAILED", "CANCELLED"])

    ev = sub.add_parser("evidence", help="search evidence memory")
    ev.add_argument("--kind", choices=["SOURCE", "EXPERIMENT", "RUN", "ARTIFACT", "ANALYSIS", "DECISION"])
    ev.add_argument("--text")
    ev.add_argument("--limit", type=int, default=100)

    wf = sub.add_parser("workflow", help="show durable workflows")
    wf.add_argument("action", choices=["list"])

    cfg = sub.add_parser("config", help="show or update non-secret configuration")
    cfg_sub = cfg.add_subparsers(dest="config_command", required=True)
    cfg_sub.add_parser("show")
    cfg_set = cfg_sub.add_parser("set")
    cfg_set.add_argument("key")
    cfg_set.add_argument("value", help="JSON value, e.g. true, 9000, \"INFO\"")


    con = sub.add_parser("connector", help="inspect and control registered connectors")
    con_sub = con.add_subparsers(dest="connector_command", required=True)
    con_sub.add_parser("list")
    con_toggle = con_sub.add_parser("set")
    con_toggle.add_argument("connector_id")
    con_toggle.add_argument("state", choices=["on", "off"])
    con_toggle.add_argument("--actor", required=True)
    con_toggle.add_argument("--reason", required=True)


    vault = sub.add_parser("vault", help="manage encrypted persistent credentials")
    vault_sub = vault.add_subparsers(dest="vault_command", required=True)
    vault_sub.add_parser("status")
    vault_set = vault_sub.add_parser("set")
    vault_set.add_argument("name")
    vault_del = vault_sub.add_parser("delete")
    vault_del.add_argument("name")

    oauth = sub.add_parser("oauth", help="OAuth flows for supported providers")
    oauth_sub = oauth.add_subparsers(dest="oauth_command", required=True)
    oauth_start = oauth_sub.add_parser("gmail-start")
    oauth_start.add_argument("--client-id")
    oauth_start.add_argument("--redirect-uri", default="http://127.0.0.1:8765/oauth/callback")
    oauth_exchange = oauth_sub.add_parser("gmail-exchange")
    oauth_exchange.add_argument("--flow-id", required=True)
    oauth_exchange.add_argument("--state", required=True)
    oauth_exchange.add_argument("--code", required=True)
    oauth_exchange.add_argument("--client-id")


    provider = sub.add_parser("provider", help="inspect and manage external provider connections")
    provider_sub = provider.add_subparsers(dest="provider_command", required=True)
    provider_sub.add_parser("list")
    gmail_setup = provider_sub.add_parser("gmail-setup")
    gmail_setup.add_argument("--client-id", required=True)
    gmail_setup.add_argument("--persist", action="store_true")
    gmail_setup.add_argument("--with-client-secret", action="store_true")
    provider_sub.add_parser("gmail-refresh")
    gmail_test = provider_sub.add_parser("gmail-test")
    gmail_test.add_argument("--actor", default="local-cli")

    gmail = sub.add_parser("gmail", help="use the built-in Gmail read-only connector")
    gmail_sub = gmail.add_subparsers(dest="gmail_command", required=True)
    gmail_sub.add_parser("profile")
    gmail_list = gmail_sub.add_parser("list")
    gmail_list.add_argument("--query")
    gmail_list.add_argument("--max-results", type=int, default=25)
    gmail_get = gmail_sub.add_parser("get")
    gmail_get.add_argument("message_id")
    gmail_get.add_argument("--format", choices=["minimal", "metadata", "full"], default="metadata")

    sec = sub.add_parser("secret", help="manage non-persistent session secrets")
    sec_sub = sec.add_subparsers(dest="secret_command", required=True)
    sec_sub.add_parser("status")
    sec_set = sec_sub.add_parser("set")
    sec_set.add_argument("name")
    sec_clear = sec_sub.add_parser("clear")
    sec_clear.add_argument("name")
    return p


def shell(runtime: RabidantiRuntime) -> int:
    print(f"Rabidanti {runtime.version} — local runtime shell")
    print("Commands: status, doctor, task add <name>, task list, evidence [text], events, help, exit")
    while True:
        try:
            raw = input("rabidanti> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not raw:
            continue
        parts = shlex.split(raw)
        cmd = parts[0].lower()
        if cmd in {"exit", "quit"}:
            return 0
        if cmd == "help":
            print("status | doctor | task add <name> | task list | evidence [text] | events | exit")
        elif cmd == "status":
            emit(runtime.status())
        elif cmd == "doctor":
            emit(runtime.doctor())
        elif cmd == "events":
            emit(runtime.runtime_events())
        elif cmd == "task" and len(parts) >= 2 and parts[1] == "list":
            emit(runtime.list_tasks())
        elif cmd == "task" and len(parts) >= 3 and parts[1] == "add":
            emit(runtime.add_task(" ".join(parts[2:])))
        elif cmd == "evidence":
            emit(runtime.search_evidence(text=" ".join(parts[1:]) or None))
        else:
            print("Unknown command. Type 'help'.")


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "product":
        product = ProductFoundation(args.state_dir)
        version = Path(__file__).with_name("VERSION").read_text(encoding="utf-8").strip()
        backups = StateBackupManager(args.state_dir)
        updates = OfflineUpdateManager(args.state_dir, current_version=version)
        schema = StateSchemaManager(args.state_dir, app_version=version)
        if args.product_command == "doctor":
            emit(product.doctor())
        elif args.product_command == "setup":
            emit(product.initialize())
        elif args.product_command == "build-info":
            emit(product.build_info())
        elif args.product_command == "self-test":
            emit(ProductSelfTest(Path(args.state_dir).parent).run())
        elif args.product_command == "recovery-status":
            emit(RecoverySession.status(args.state_dir))
        elif args.product_command == "backup-list":
            emit(backups.list())
        elif args.product_command == "backup-create":
            emit(backups.create(reason=args.reason, version=version))
        elif args.product_command == "backup-restore":
            emit(backups.restore(args.backup, confirm=args.confirm, current_version=version))
        elif args.product_command == "update-inspect":
            emit(updates.inspect(args.package, expected_sha256=args.sha256))
        elif args.product_command == "update-stage":
            emit(updates.stage(args.package, expected_sha256=args.sha256, actor=args.actor, reason=args.reason))
        elif args.product_command == "update-list":
            emit(updates.staged())
        elif args.product_command == "migration-status":
            emit(schema.status())
        else:
            emit(schema.migrate(confirm=args.confirm))
        return 0

    runtime = RabidantiRuntime(args.state_dir)
    runtime.start()
    try:
        if args.command == "status":
            emit(runtime.status())
        elif args.command == "doctor":
            emit(runtime.doctor())
        elif args.command == "observe":
            emit(runtime.observability_snapshot())
        elif args.command == "events":
            emit(runtime.runtime_events())
        elif args.command == "chat":
            emit(runtime.chat(args.message, args.conversation_id))
        elif args.command == "model":
            emit(runtime.model_status() if args.action == "status" else runtime.list_models())
        elif args.command == "reason":
            emit(runtime.reason(args.request, args.context))
        elif args.command == "proposals":
            emit(runtime.reasoning_proposals(args.limit))
        elif args.command == "proposal-review":
            emit(runtime.review_reasoning_proposal(args.proposal_id, decision=args.decision, actor=args.actor, reason=args.reason))
        elif args.command == "proposal-authorize":
            emit(runtime.authorize_reasoning_proposal(args.proposal_id, actor=args.actor, reason=args.reason))
        elif args.command == "proposal-execute":
            emit(runtime.execute_reasoning_proposal(args.proposal_id, actor=args.actor))
        elif args.command == "proposal-reviews":
            emit(runtime.proposal_reviews(args.limit))
        elif args.command == "proposal-executions":
            emit(runtime.proposal_executions(args.limit))
        elif args.command == "task":
            if args.task_command == "add":
                emit(runtime.add_task(args.name, priority=args.priority, max_attempts=args.max_attempts))
            else:
                emit(runtime.list_tasks(args.state))
        elif args.command == "evidence":
            emit(runtime.search_evidence(kind=args.kind, text=args.text, limit=args.limit))
        elif args.command == "config":
            if args.config_command == "show":
                emit(runtime.get_config())
            else:
                try:
                    value = json.loads(args.value)
                except json.JSONDecodeError as exc:
                    raise SystemExit(f"invalid JSON value: {exc}")
                emit(runtime.update_config({args.key: value}))
        elif args.command == "secret":
            if args.secret_command == "status":
                emit(runtime.secret_status())
            elif args.secret_command == "set":
                value = getpass.getpass(f"Secret {args.name}: ")
                emit(runtime.set_session_secret(args.name, value))
            else:
                emit(runtime.clear_session_secret(args.name))
        elif args.command == "connector":
            if args.connector_command == "list":
                emit(runtime.list_connectors())
            else:
                emit(runtime.set_connector_enabled(
                    args.connector_id, args.state == "on", actor=args.actor, reason=args.reason
                ))
        elif args.command == "provider":
            if args.provider_command == "list":
                emit(runtime.provider_status())
            elif args.provider_command == "gmail-setup":
                client_secret = getpass.getpass("Google client secret (optional): ") if args.with_client_secret else None
                emit(runtime.configure_google_gmail_credentials(
                    client_id=args.client_id, client_secret=client_secret or None, persist=args.persist
                ))
            elif args.provider_command == "gmail-refresh":
                emit(runtime.refresh_google_gmail())
            else:
                emit(runtime.test_google_gmail_connection(actor=args.actor))
        elif args.command == "vault":
            if args.vault_command == "status":
                emit(runtime.vault_status())
            elif args.vault_command == "set":
                value = getpass.getpass(f"Vault credential {args.name}: ")
                emit(runtime.vault_set(args.name, value))
            else:
                emit(runtime.vault_delete(args.name))
        elif args.command == "oauth":
            if args.oauth_command == "gmail-start":
                emit(runtime.oauth_google_gmail_start(client_id=args.client_id, redirect_uri=args.redirect_uri))
            else:
                emit(runtime.oauth_google_gmail_exchange(
                    flow_id=args.flow_id, state=args.state, code=args.code, client_id=args.client_id,
                    client_secret=runtime.get_secret("GOOGLE_CLIENT_SECRET"),
                ))
        elif args.command == "gmail":
            if args.gmail_command == "profile":
                emit(runtime.invoke_connector("gmail.readonly", "gmail.profile", {}, actor="local-cli"))
            elif args.gmail_command == "list":
                payload = {"max_results": args.max_results}
                if args.query:
                    payload["query"] = args.query
                emit(runtime.invoke_connector("gmail.readonly", "gmail.messages.list", payload, actor="local-cli"))
            else:
                emit(runtime.invoke_connector(
                    "gmail.readonly", "gmail.messages.get",
                    {"message_id": args.message_id, "format": args.format}, actor="local-cli"
                ))
        elif args.command == "workflow":
            emit([
                {
                    "workflow_id": w.workflow_id,
                    "name": w.name,
                    "state": w.state.value,
                    "task_ids": list(w.task_ids),
                    "error": w.error,
                    "metadata": w.metadata,
                }
                for w in runtime.core.list_workflows()
            ])
        elif args.command == "shell":
            return shell(runtime)
        elif args.command in {"serve", "room"}:
            token = args.api_token or runtime.secrets.get("API_TOKEN")
            service = RabidantiApiService(runtime, host=args.host, port=args.port, token=token)
            if token is None:
                print(f"Rabidanti local API mutation token: {service.token}", file=sys.stderr)
            addr = service.start(background=True)
            base_url = f"http://{addr.host}:{addr.port}"
            if args.command == "room":
                ProductFoundation(args.state_dir).initialize()
                room_url = base_url + "/ui/"
                setup_required = not runtime.onboarding.status().get("completed", False)
                browser_url = room_browser_url(base_url, service.token, setup_required)
                print(f"Rabidanti {runtime.version} Sala: {room_url}", file=sys.stderr)
                if token is None:
                    print("O token efémero foi entregue à Sala apenas no fragmento local e não é persistido pelo navegador.", file=sys.stderr)
                if not args.no_browser and runtime.config.get("ui.auto_open_browser"):
                    webbrowser.open(browser_url)
            else:
                print(f"Rabidanti {runtime.version} local API: {base_url}", file=sys.stderr)
            try:
                while True:
                    import time
                    time.sleep(3600)
            except KeyboardInterrupt:
                service.stop()
                return 0
        return 0
    finally:
        runtime.stop()


if __name__ == "__main__":
    raise SystemExit(main())
