param(
    [Parameter(Mandatory=$true)][string]$Exe,
    [Parameter(Mandatory=$true)][string]$Installer,
    [Parameter(Mandatory=$false)][string]$Output = "windows-release-validation.json"
)
$ErrorActionPreference = "Stop"

if (-not $IsWindows -and $env:OS -ne "Windows_NT") {
    throw "Windows native verification must run on Windows."
}

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Version = (Get-Content (Join-Path $Root "VERSION") -Raw).Trim()
$ExePath = (Resolve-Path $Exe).Path
$InstallerPath = (Resolve-Path $Installer).Path
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("rabidanti-native-verify-" + [guid]::NewGuid().ToString("N"))
$InstallDir = Join-Path $TempRoot "install"
$StateDir = Join-Path $TempRoot "state"
New-Item -ItemType Directory -Force -Path $TempRoot,$InstallDir,$StateDir | Out-Null

$checks = [ordered]@{}
try {
    # 1) Built executable can run without Python being invoked directly.
    $buildInfoFile = Join-Path $TempRoot "build-info.json"
    $env:RABIDANTI_OUTPUT_FILE = $buildInfoFile
    $proc = Start-Process -FilePath $ExePath -ArgumentList @("product","build-info") -PassThru -Wait
    Remove-Item Env:RABIDANTI_OUTPUT_FILE -ErrorAction SilentlyContinue
    if ($proc.ExitCode -ne 0) { throw "Rabidanti.exe build-info failed with exit code $($proc.ExitCode)" }
    if (-not (Test-Path $buildInfoFile)) { throw "Rabidanti.exe did not produce build-info evidence" }
    $buildInfo = Get-Content $buildInfoFile -Raw | ConvertFrom-Json
    if ($buildInfo.version -ne $Version) { throw "Rabidanti.exe reports version $($buildInfo.version), expected $Version" }
    $checks["built_exe_build_info"] = "PASS"

    # 2) Source-independent status command with a fresh state directory.
    $statusFile = Join-Path $TempRoot "status.json"
    $env:RABIDANTI_OUTPUT_FILE = $statusFile
    $proc = Start-Process -FilePath $ExePath -ArgumentList @("--state-dir",$StateDir,"status") -PassThru -Wait
    Remove-Item Env:RABIDANTI_OUTPUT_FILE -ErrorAction SilentlyContinue
    if ($proc.ExitCode -ne 0) { throw "Rabidanti.exe status failed with exit code $($proc.ExitCode)" }
    if (-not (Test-Path $statusFile)) { throw "Rabidanti.exe did not produce status evidence" }
    $status = Get-Content $statusFile -Raw | ConvertFrom-Json
    if ($status.version -ne $Version) { throw "status reports version $($status.version), expected $Version" }
    $checks["built_exe_fresh_state"] = "PASS"

    # 3) Silent per-user install into an isolated directory.
    $installerArgs = @("/VERYSILENT","/SUPPRESSMSGBOXES","/NORESTART","/SP-",("/DIR=" + $InstallDir))
    $proc = Start-Process -FilePath $InstallerPath -ArgumentList $installerArgs -PassThru -Wait
    if ($proc.ExitCode -ne 0) { throw "installer failed with exit code $($proc.ExitCode)" }
    $InstalledExe = Join-Path $InstallDir "Rabidanti.exe"
    if (-not (Test-Path $InstalledExe)) { throw "installed Rabidanti.exe not found" }
    $checks["silent_install"] = "PASS"

    # 4) Installed executable is actually runnable and reports the expected version.
    $installedInfoFile = Join-Path $TempRoot "installed-build-info.json"
    $env:RABIDANTI_OUTPUT_FILE = $installedInfoFile
    $proc = Start-Process -FilePath $InstalledExe -ArgumentList @("product","build-info") -PassThru -Wait
    Remove-Item Env:RABIDANTI_OUTPUT_FILE -ErrorAction SilentlyContinue
    if ($proc.ExitCode -ne 0) { throw "installed Rabidanti.exe failed with exit code $($proc.ExitCode)" }
    if (-not (Test-Path $installedInfoFile)) { throw "installed Rabidanti.exe did not produce build-info evidence" }
    $installedInfo = Get-Content $installedInfoFile -Raw | ConvertFrom-Json
    if ($installedInfo.version -ne $Version) { throw "installed executable version mismatch" }
    $checks["installed_exe_build_info"] = "PASS"

    # 5) Silent uninstall must remove the executable.
    $Uninstaller = Join-Path $InstallDir "unins000.exe"
    if (-not (Test-Path $Uninstaller)) { throw "Inno Setup uninstaller not found" }
    $proc = Start-Process -FilePath $Uninstaller -ArgumentList @("/VERYSILENT","/SUPPRESSMSGBOXES","/NORESTART") -PassThru -Wait
    if ($proc.ExitCode -ne 0) { throw "uninstaller failed with exit code $($proc.ExitCode)" }
    Start-Sleep -Milliseconds 500
    if (Test-Path $InstalledExe) { throw "Rabidanti.exe still exists after uninstall" }
    $checks["silent_uninstall"] = "PASS"

    $result = [ordered]@{
        schema = 1
        product = "Rabidanti"
        version = $Version
        platform = [System.Environment]::OSVersion.VersionString
        end_to_end_windows_validated = $true
        checks = $checks
        executable_sha256 = (Get-FileHash -Algorithm SHA256 $ExePath).Hash.ToLowerInvariant()
        installer_sha256 = (Get-FileHash -Algorithm SHA256 $InstallerPath).Hash.ToLowerInvariant()
    }
    $result | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 (Join-Path $Root $Output)
    Write-Host "Windows native release validation passed."
    exit 0
}
catch {
    $checks["failure"] = $_.Exception.Message
    $result = [ordered]@{
        schema = 1
        product = "Rabidanti"
        version = $Version
        end_to_end_windows_validated = $false
        checks = $checks
    }
    $result | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 (Join-Path $Root $Output)
    Write-Error $_
    exit 1
}
finally {
    if (Test-Path $TempRoot) { Remove-Item -Recurse -Force $TempRoot -ErrorAction SilentlyContinue }
}
