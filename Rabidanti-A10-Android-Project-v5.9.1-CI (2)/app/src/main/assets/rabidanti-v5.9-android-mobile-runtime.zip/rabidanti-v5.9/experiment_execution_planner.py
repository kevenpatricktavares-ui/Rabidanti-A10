"""Rabidanti v3.64 — forward experiment aware execution planning.

Experiments are advisory. Dependencies, readiness, capacity, approvals and the
 durable queue claim remain authoritative.
"""
from __future__ import annotations

from typing import Iterable, Mapping

from execution_planner import ExecutionPlan, PlannedItem
from intelligence_prioritization import PriorityDecision
from priority_execution_planner import PriorityAwareExecutionPlanner, PriorityPlannedItem
from forward_experiment import Arm, ForwardExperimentEngine


class ExperimentAwarePriorityExecutionPlanner(PriorityAwareExecutionPlanner):
    """Apply a running experiment only to eligible priority ordering.

    CONTROL uses the baseline weight; TREATMENT uses the proposed weight for the
    experiment's selected factor. No global production weights are mutated.
    """

    def __init__(self, capacity, experiment_engine: ForwardExperimentEngine):
        super().__init__(capacity)
        self.experiment_engine = experiment_engine
        self._assignments: dict[tuple[str, str], Arm] = {}

    def plan_with_experiment(
        self,
        items: Iterable[PlannedItem],
        available_slots: int,
        decisions: Mapping[str, PriorityDecision] | Iterable[PriorityDecision],
        experiment_id: str,
        now: float | None = None,
    ) -> ExecutionPlan:
        if isinstance(decisions, Mapping):
            by_id = dict(decisions)
        else:
            by_id = {d.candidate_id: d for d in decisions}
        experiment = self.experiment_engine.store.get(experiment_id)
        if experiment.state.value != "RUNNING":
            raise ValueError("experiment must be RUNNING for execution planning")

        enriched: list[PriorityPlannedItem] = []
        for item in items:
            decision = by_id.get(item.item_id)
            if decision is None:
                enriched.append(PriorityPlannedItem(item.item_id, item.priority, item.ready, item.dependencies_satisfied))
                continue
            assignment = self.experiment_engine.assign(experiment_id, item.item_id, now=now)
            self._assignments[(experiment_id, item.item_id)] = assignment.arm
            score = float(decision.score)
            if assignment.arm == Arm.TREATMENT:
                factor_value = float(decision.components.get(experiment.factor, 0.0))
                score = max(0.0, min(1.0, score + factor_value * (experiment.proposed_weight - experiment.baseline_weight)))
            enriched.append(PriorityPlannedItem(
                item.item_id, item.priority, item.ready, item.dependencies_satisfied,
                round(score, 6), int(decision.band),
            ))
        return self._plan_priority(enriched, available_slots, now=now)

    def assignment_for(self, experiment_id: str, candidate_id: str):
        return self.experiment_engine.store.assignment(experiment_id, candidate_id)
