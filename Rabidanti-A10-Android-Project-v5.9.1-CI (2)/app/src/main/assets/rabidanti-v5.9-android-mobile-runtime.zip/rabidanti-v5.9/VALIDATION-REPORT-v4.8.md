# Validation Report — Rabidanti v4.8

## Baseline
Input package: Rabidanti v4.7 (`VERSION=4.7.0`).
Input SHA-256: `50b1fe7ea9d2fe2e192d63aefb92b7e56383f789e1518d82b422f0b26ba09c9f`.
Historical package report records 589/589 passing tests.

## Changes
- local Ollama model discovery;
- primary/fallback model selection;
- versioned conversation/reasoning prompts;
- persistent reasoning proposal ledger;
- strict proposal schema with secret-like payload rejection;
- no execution path from reasoning output;
- runtime/API/CLI/Sala integration.

## Regression
Final source-tree validation was executed in three deterministic groups:
- v4.x tests: 109 passed;
- v3.x root tests: 157 passed;
- historical `tests/` suite with `PYTHONPATH=.`: 337 passed.

Total: **603 passed / 0 failed**.

`python -m compileall -q .`: PASS.

## Environment limitation
No live Ollama daemon was available in the build environment. Ollama HTTP behavior, model discovery, chat and reasoning parsing are tested with `httpx.MockTransport`. Therefore live local-model inference is not claimed as validated.
