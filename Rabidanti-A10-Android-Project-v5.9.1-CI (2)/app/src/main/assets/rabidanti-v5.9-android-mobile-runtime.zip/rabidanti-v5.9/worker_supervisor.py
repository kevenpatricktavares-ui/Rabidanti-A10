"""Rabidanti v3.13 — Worker Supervisor & Health.

SQLite-backed worker registry and health primitives for continuous operation.
Tracks worker identity, capacity, status, heartbeat and timestamps. Stale
workers can be detected safely; this module does not claim cloud orchestration
or autoscaling.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class WorkerStatus(str, Enum):
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    DRAINING = "DRAINING"
    STOPPED = "STOPPED"
    STALE = "STALE"


@dataclass
class WorkerRecord:
    worker_id: str
    status: WorkerStatus
    capacity: int
    active: int
    last_heartbeat: float
    started_at: float
    updated_at: float
    metadata: str = ""


class WorkerSupervisor:
    """Persistent worker registry shared by runner processes."""

    def __init__(self, db_path: str, stale_after: float = 30.0):
        if stale_after <= 0:
            raise ValueError("stale_after must be > 0")
        self.db_path = db_path
        self.stale_after = float(stale_after)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        if db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")
            self._conn.execute("PRAGMA synchronous = NORMAL")
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS workers (
                worker_id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                capacity INTEGER NOT NULL,
                active INTEGER NOT NULL DEFAULT 0,
                last_heartbeat REAL NOT NULL,
                started_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                metadata TEXT NOT NULL DEFAULT ''
            )"""
        )
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_workers_heartbeat ON workers(last_heartbeat)")

    def register(self, worker_id: str, capacity: int, metadata: str = "") -> WorkerRecord:
        if not worker_id:
            raise ValueError("worker_id is required")
        if capacity < 1:
            raise ValueError("capacity must be >= 1")
        now = time.time()
        with self._lock:
            self._conn.execute(
                """INSERT INTO workers(worker_id,status,capacity,active,last_heartbeat,started_at,updated_at,metadata)
                   VALUES(?,?,?,?,?,?,?,?)
                   ON CONFLICT(worker_id) DO UPDATE SET
                     status=excluded.status, capacity=excluded.capacity, active=0,
                     last_heartbeat=excluded.last_heartbeat, started_at=excluded.started_at,
                     updated_at=excluded.updated_at, metadata=excluded.metadata""",
                (worker_id, WorkerStatus.STARTING.value, int(capacity), 0, now, now, now, metadata),
            )
            return self.get(worker_id)

    def set_status(self, worker_id: str, status: WorkerStatus) -> WorkerRecord:
        with self._lock:
            self._require(worker_id)
            now = time.time()
            self._conn.execute("UPDATE workers SET status=?, updated_at=? WHERE worker_id=?", (status.value, now, worker_id))
            return self.get(worker_id)

    def heartbeat(self, worker_id: str, active: Optional[int] = None) -> WorkerRecord:
        with self._lock:
            row = self._require(worker_id)
            if active is not None and (active < 0 or active > int(row["capacity"])):
                raise ValueError("active must be between 0 and capacity")
            now = time.time()
            value = int(row["active"]) if active is None else int(active)
            self._conn.execute(
                "UPDATE workers SET status=?, active=?, last_heartbeat=?, updated_at=? WHERE worker_id=?",
                (WorkerStatus.RUNNING.value, value, now, now, worker_id),
            )
            return self.get(worker_id)

    def set_active(self, worker_id: str, active: int) -> WorkerRecord:
        return self.heartbeat(worker_id, active=active)

    def stop(self, worker_id: str) -> WorkerRecord:
        return self.set_status(worker_id, WorkerStatus.STOPPED)

    def stale(self, now: Optional[float] = None) -> list[WorkerRecord]:
        now = time.time() if now is None else float(now)
        cutoff = now - self.stale_after
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM workers WHERE status NOT IN (?,?) AND last_heartbeat<=?",
                (WorkerStatus.STOPPED.value, WorkerStatus.STALE.value, cutoff),
            ).fetchall()
            if rows:
                self._conn.executemany(
                    "UPDATE workers SET status=?, updated_at=? WHERE worker_id=?",
                    [(WorkerStatus.STALE.value, now, r["worker_id"]) for r in rows],
                )
            return [self._row(r, override_status=WorkerStatus.STALE) for r in rows]


    def health_snapshot(self, now: Optional[float] = None) -> dict:
        """Return a compact health view and classify stale workers."""
        stale = self.stale(now=now)
        records = self.list()
        counts = {status.value: 0 for status in WorkerStatus}
        for record in records:
            counts[record.status.value] += 1
        return {
            "healthy": counts[WorkerStatus.STALE.value] == 0,
            "total": len(records),
            "counts": counts,
            "stale_worker_ids": [r.worker_id for r in stale],
            "workers": [r.__dict__.copy() for r in records],
        }

    def recover_idle_stale(self, worker_id: str) -> WorkerRecord:
        """Re-register a stale worker only when it reports no active work.

        This is deliberately conservative: active stale workers are not
        silently revived because their underlying execution may still exist.
        Queue lease recovery remains responsible for abandoned work.
        """
        with self._lock:
            record = self.get(worker_id)
            if record.status != WorkerStatus.STALE:
                return record
            if record.active != 0:
                raise RuntimeError(f"worker {worker_id} has active work")
            now = time.time()
            self._conn.execute(
                "UPDATE workers SET status=?, last_heartbeat=?, updated_at=? WHERE worker_id=?",
                (WorkerStatus.RUNNING.value, now, now, worker_id),
            )
            return self.get(worker_id)

    def list(self, include_stale: bool = True) -> list[WorkerRecord]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM workers ORDER BY started_at ASC").fetchall()
        records = [self._row(r) for r in rows]
        return records if include_stale else [r for r in records if r.status != WorkerStatus.STALE]

    def get(self, worker_id: str) -> WorkerRecord:
        with self._lock:
            row = self._conn.execute("SELECT * FROM workers WHERE worker_id=?", (worker_id,)).fetchone()
        if row is None:
            raise KeyError(worker_id)
        return self._row(row)

    def remove(self, worker_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM workers WHERE worker_id=?", (worker_id,))

    def _require(self, worker_id: str):
        row = self._conn.execute("SELECT * FROM workers WHERE worker_id=?", (worker_id,)).fetchone()
        if row is None:
            raise KeyError(worker_id)
        return row

    @staticmethod
    def _row(row, override_status=None) -> WorkerRecord:
        return WorkerRecord(
            worker_id=row["worker_id"],
            status=override_status or WorkerStatus(row["status"]),
            capacity=int(row["capacity"]),
            active=int(row["active"]),
            last_heartbeat=float(row["last_heartbeat"]),
            started_at=float(row["started_at"]),
            updated_at=float(row["updated_at"]),
            metadata=row["metadata"] or "",
        )

    def close(self) -> None:
        with self._lock:
            self._conn.close()
