from datetime import datetime, timezone
from evolution_cycle_store import EvolutionCycleEvent


class EvolutionCycleAudit:
    """Records decision-gate outcomes without changing controller state."""

    def __init__(self, store):
        self.store = store

    def record_assessment(self, gate_decision, event_id):
        event = EvolutionCycleEvent(
            event_id=event_id,
            proposal_id=gate_decision.proposal_id,
            event_type="DECISION_ASSESSED",
            decision=gate_decision.decision,
            score=gate_decision.score,
            gate=gate_decision.gate.value,
            reason=gate_decision.reason,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self.store.record(event)
        return event
