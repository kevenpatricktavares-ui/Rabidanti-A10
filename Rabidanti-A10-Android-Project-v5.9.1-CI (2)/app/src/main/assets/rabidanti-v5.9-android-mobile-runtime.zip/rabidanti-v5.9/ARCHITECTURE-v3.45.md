# Rabidanti v3.45 — Laboratory Research Intelligence

Adds an evidence-first intelligence layer above the v3.44 Laboratory foundation.
It records research signals with source provenance, assesses hypotheses using explicit support/contradiction/evidence inputs, persists both, and produces a research snapshot.

## Non-claims
This version does not browse the public web, verify sources externally, claim scientific novelty, or automatically exploit opportunities. External connectors and World Awareness remain future integrations.
