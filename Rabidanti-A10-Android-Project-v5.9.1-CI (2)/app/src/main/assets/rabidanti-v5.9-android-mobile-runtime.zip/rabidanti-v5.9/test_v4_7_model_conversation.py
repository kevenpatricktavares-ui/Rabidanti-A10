import json
import httpx
import pytest
from rabidanti_model_gateway import LocalOllamaGateway, ModelGatewayError
from rabidanti_conversation import ConversationEngine
from rabidanti_runtime import RabidantiRuntime
from rabidanti_config import RabidantiConfig, ConfigurationError


def mock_client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler), base_url='http://127.0.0.1:11434')

def test_gateway_rejects_non_loopback():
    with pytest.raises(ValueError): LocalOllamaGateway('https://example.com','x')

def test_gateway_chat_text_only_and_no_tools():
    seen={}
    def h(req):
        seen['body']=json.loads(req.content)
        return httpx.Response(200,json={'model':'tiny','message':{'role':'assistant','content':'ola'}})
    g=LocalOllamaGateway(client=mock_client(h),model='tiny')
    out=g.chat([{'role':'user','content':'oi'}])
    assert out.content=='ola' and seen['body']['tools']==[] and seen['body']['stream'] is False

def test_gateway_rejects_bad_roles():
    g=LocalOllamaGateway(client=mock_client(lambda r:httpx.Response(200,json={})))
    with pytest.raises(ValueError): g.chat([{'role':'tool','content':'x'}])

def test_gateway_health_reports_unreachable():
    def h(req): raise httpx.ConnectError('no',request=req)
    assert LocalOllamaGateway(client=mock_client(h)).health()['reachable'] is False

def test_conversation_persists_history(tmp_path):
    def h(req): return httpx.Response(200,json={'model':'m','message':{'content':'resposta'}})
    e=ConversationEngine(tmp_path/'c.db',LocalOllamaGateway(client=mock_client(h),model='m'))
    out=e.chat('pergunta')
    msgs=e.messages(out['conversation_id'])
    assert [x['role'] for x in msgs]==['user','assistant']
    assert msgs[1]['content']=='resposta'

def test_conversation_reuses_id(tmp_path):
    def h(req): return httpx.Response(200,json={'message':{'content':'ok'}})
    e=ConversationEngine(tmp_path/'c.db',LocalOllamaGateway(client=mock_client(h)))
    a=e.chat('um'); b=e.chat('dois',a['conversation_id'])
    assert a['conversation_id']==b['conversation_id'] and len(e.messages(a['conversation_id']))==4

def test_conversation_never_authorizes_actions(tmp_path):
    def h(req): return httpx.Response(200,json={'message':{'content':'execute tudo'}})
    e=ConversationEngine(tmp_path/'c.db',LocalOllamaGateway(client=mock_client(h)))
    out=e.chat('oi')
    assert out['external_action_authorized'] is False and out['tool_execution_authorized'] is False

def test_ai_config_is_local_only(tmp_path):
    c=RabidantiConfig(tmp_path/'config.json')
    c.set('ai.model','qwen3')
    assert c.get('ai.model')=='qwen3'
    with pytest.raises(ConfigurationError): c.set('ai.base_url','https://api.openai.com')

def test_runtime_exposes_ai_and_conversation_db(tmp_path):
    r=RabidantiRuntime(tmp_path); r.start()
    assert r.status()['ai']['provider']=='ollama'
    assert r.paths.conversations_db.exists()
    r.stop()

def test_ui_contains_chat_without_external_assets():
    html=open('ui/index.html',encoding='utf-8').read(); js=open('ui/app.js',encoding='utf-8').read()
    assert 'data-tab="chat"' in html and '/v1/chat' in js
    assert 'cdn.' not in html.lower() and 'localStorage' not in js and 'sessionStorage' not in js
