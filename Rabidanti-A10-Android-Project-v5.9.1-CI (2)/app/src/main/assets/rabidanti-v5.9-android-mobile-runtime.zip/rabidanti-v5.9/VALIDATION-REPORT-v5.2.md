# Rabidanti v5.2 — Validation Report

## Baseline
- Input: Rabidanti v5.1
- Input SHA-256: `d3f32667d8d025368e404da70720805c53fb25117713c9ad4dca5dd96343194e`
- Baseline regression: **640/640 passed** (146 v4/v5 + 157 v3 + 337 historical).

## v5.2 changes
- Single-instance desktop lease with stale-lock recovery.
- Graceful SIGTERM cleanup for desktop launcher.
- Visible startup-error path for windowed builds.
- PyInstaller windowed spec (`console=False`) with icon and Windows version metadata.
- Source Windows launcher uses `pythonw.exe`.
- Hardened build script that tests/compiles/builds/smoke-tests the binary.
- Inno Setup per-user installer definition and build script.

## Tests
- New v5.2 tests: **10/10 passed**.
- v4/v5 regression: **156/156 passed**.
- v3 regression: **157/157 passed**.
- historical `tests/`: **337/337 passed**.
- Total development-tree regression: **650/650 passed**.
- `python -m compileall -q .`: PASS.
- Desktop smoke test: first instance started; second instance refused with exit code 2; SIGTERM released the lock: PASS.

## Native build limitation
`pyinstaller` and Inno Setup (`ISCC.exe`) are not installed in this environment. A native Windows `Rabidanti.exe` and installer are therefore **not claimed as built or validated**. The build definitions are present and regression-tested as source artifacts.

## Security status
- No new automatic external authority.
- No automatic Core integration.
- Installer is configured per-user (`PrivilegesRequired=lowest`).
- Desktop lock contains only PID/token/timestamp; no user secret or connector credential.
