"""Rabidanti v3.28 — persistent workflow orchestration and resume."""
from __future__ import annotations
import json, sqlite3, threading, time, uuid
from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Optional
from workflow_engine import WorkflowEngine, WorkflowNode
from durable_worker_queue import DurableWorkerQueue, QueueItemState

class WorkflowState(str, Enum):
    DRAFT = "DRAFT"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"
    CANCELLED = "CANCELLED"

@dataclass(frozen=True)
class WorkflowRecord:
    workflow_id: str
    name: str
    state: WorkflowState
    task_ids: tuple[str, ...]
    error: Optional[str]
    created_at: float
    updated_at: float
    started_at: Optional[float]
    completed_at: Optional[float]
    metadata: dict

@dataclass(frozen=True)
class WorkflowProgress:
    workflow_id: str
    state: WorkflowState
    total: int
    queued: int
    running: int
    completed: int
    failed: int
    cancelled: int
    blocked: int
    percent: float
    error: Optional[str]

class PersistentWorkflowOrchestrator:
    def __init__(self, db_path: str, queue: DurableWorkerQueue):
        self.db_path = db_path
        self.queue = queue
        self.engine = WorkflowEngine(queue)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        if db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("""CREATE TABLE IF NOT EXISTS workflows (
            workflow_id TEXT PRIMARY KEY, name TEXT NOT NULL, state TEXT NOT NULL,
            error TEXT, created_at REAL NOT NULL, updated_at REAL NOT NULL,
            started_at REAL, completed_at REAL, metadata_json TEXT NOT NULL DEFAULT '{}'
        )""")
        self._conn.execute("""CREATE TABLE IF NOT EXISTS workflow_tasks (
            workflow_id TEXT NOT NULL, task_id TEXT NOT NULL, position INTEGER NOT NULL,
            PRIMARY KEY(workflow_id, task_id),
            FOREIGN KEY(workflow_id) REFERENCES workflows(workflow_id) ON DELETE CASCADE
        )""")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_workflow_tasks_task ON workflow_tasks(task_id)")

    @staticmethod
    def _metadata(v):
        return json.dumps(v or {}, ensure_ascii=False, default=str)

    def _record(self, row) -> WorkflowRecord:
        tasks = self._conn.execute(
            "SELECT task_id FROM workflow_tasks WHERE workflow_id=? ORDER BY position", (row["workflow_id"],)
        ).fetchall()
        return WorkflowRecord(row["workflow_id"], row["name"], WorkflowState(row["state"]),
            tuple(r["task_id"] for r in tasks), row["error"], float(row["created_at"]), float(row["updated_at"]),
            None if row["started_at"] is None else float(row["started_at"]),
            None if row["completed_at"] is None else float(row["completed_at"]),
            json.loads(row["metadata_json"] or "{}"))

    def create(self, name: str, nodes: Iterable[WorkflowNode], payloads: Optional[dict[str, object]] = None,
               max_attempts: int = 3, workflow_id: Optional[str] = None, metadata: Optional[dict] = None) -> WorkflowRecord:
        if not name.strip(): raise ValueError("workflow name must not be empty")
        items = self.engine.validate(nodes)
        if not items: raise ValueError("workflow must contain at least one task")
        ids = tuple(n.task_id for n in items)
        for task_id in ids:
            if self.queue.get_by_task_id(task_id) is not None: raise ValueError(f"task already exists: {task_id}")
        wid = workflow_id or str(uuid.uuid4()); now = time.time(); payloads = payloads or {}
        created = []
        try:
            for n in items:
                self.queue.enqueue(payloads.get(n.task_id, {}), priority=n.priority, max_attempts=max_attempts,
                                   task_id=n.task_id, dependencies=n.dependencies)
                created.append(n.task_id)
            with self._lock:
                self._conn.execute("BEGIN")
                self._conn.execute("INSERT INTO workflows(workflow_id,name,state,error,created_at,updated_at,started_at,completed_at,metadata_json) VALUES(?,?,?,?,?,?,?,?,?)",
                    (wid,name,WorkflowState.DRAFT.value,None,now,now,None,None,self._metadata(metadata)))
                self._conn.executemany("INSERT INTO workflow_tasks(workflow_id,task_id,position) VALUES(?,?,?)",
                    [(wid,t,i) for i,t in enumerate(ids)])
                self._conn.execute("COMMIT")
        except Exception:
            try: self._conn.execute("ROLLBACK")
            except sqlite3.OperationalError: pass
            for task_id in created:
                item = self.queue.get_by_task_id(task_id)
                if item and item.state in (QueueItemState.QUEUED, QueueItemState.RUNNING):
                    try: self.queue.cancel(item.item_id, "workflow creation rollback")
                    except Exception: pass
            raise
        return self.get(wid)

    def get(self, workflow_id: str) -> WorkflowRecord:
        row = self._conn.execute("SELECT * FROM workflows WHERE workflow_id=?", (workflow_id,)).fetchone()
        if row is None: raise KeyError(workflow_id)
        return self._record(row)

    def list(self) -> list[WorkflowRecord]:
        rows = self._conn.execute("SELECT * FROM workflows ORDER BY created_at ASC").fetchall()
        return [self._record(r) for r in rows]

    def start(self, workflow_id: str) -> WorkflowRecord:
        with self._lock:
            rec = self.get(workflow_id)
            if rec.state == WorkflowState.CANCELLED: raise ValueError("cancelled workflow cannot start")
            if rec.state == WorkflowState.COMPLETED: return rec
            now=time.time()
            self._conn.execute("UPDATE workflows SET state=?, started_at=COALESCE(started_at,?), updated_at=?, error=NULL WHERE workflow_id=?",
                (WorkflowState.RUNNING.value,now,now,workflow_id))
        return self.refresh(workflow_id)

    def refresh(self, workflow_id: str) -> WorkflowRecord:
        rec = self.get(workflow_id)
        if rec.state == WorkflowState.CANCELLED: return rec
        items = [self.queue.get_by_task_id(t) for t in rec.task_ids]
        if any(x is None for x in items):
            raise RuntimeError("workflow references missing queue task")
        states = [x.state for x in items]
        now=time.time(); new_state=rec.state; error=rec.error; completed_at=rec.completed_at
        if all(s == QueueItemState.COMPLETED for s in states):
            new_state=WorkflowState.COMPLETED; completed_at=completed_at or now; error=None
        elif any(s == QueueItemState.FAILED for s in states):
            new_state=WorkflowState.FAILED; error=next(x.error for x in items if x.state == QueueItemState.FAILED)
        elif rec.state == WorkflowState.RUNNING:
            # QUEUED tasks may simply be waiting on DAG dependencies; that is normal execution.
            new_state=WorkflowState.RUNNING
        elif rec.state == WorkflowState.DRAFT:
            new_state=WorkflowState.DRAFT
        elif rec.state == WorkflowState.RUNNING:
            new_state=WorkflowState.RUNNING
        with self._lock:
            self._conn.execute("UPDATE workflows SET state=?, error=?, updated_at=?, completed_at=? WHERE workflow_id=?",
                (new_state.value,error,now,completed_at,workflow_id))
        return self.get(workflow_id)

    def progress(self, workflow_id: str) -> WorkflowProgress:
        rec=self.refresh(workflow_id)
        items=[self.queue.get_by_task_id(t) for t in rec.task_ids]
        total=len(items); counts={s:0 for s in QueueItemState}
        for item in items: counts[item.state]+=1
        ready_ids={x.task_id for x in self.queue.ready() if x.task_id in rec.task_ids}
        blocked=sum(1 for item in items if item.state == QueueItemState.QUEUED and item.task_id not in ready_ids)
        percent=(counts[QueueItemState.COMPLETED]/total*100.0) if total else 100.0
        return WorkflowProgress(rec.workflow_id,rec.state,total,counts[QueueItemState.QUEUED],counts[QueueItemState.RUNNING],
            counts[QueueItemState.COMPLETED],counts[QueueItemState.FAILED],counts[QueueItemState.CANCELLED],blocked,percent,rec.error)

    def cancel(self, workflow_id: str, reason: str="workflow cancelled") -> WorkflowRecord:
        rec=self.get(workflow_id)
        if rec.state in (WorkflowState.COMPLETED, WorkflowState.CANCELLED): return rec
        for task_id in rec.task_ids:
            item=self.queue.get_by_task_id(task_id)
            if item and item.state in (QueueItemState.QUEUED, QueueItemState.RUNNING):
                self.queue.cancel(item.item_id, reason)
        now=time.time()
        self._conn.execute("UPDATE workflows SET state=?,error=?,updated_at=?,completed_at=? WHERE workflow_id=?",
            (WorkflowState.CANCELLED,reason,now,now,workflow_id))
        return self.get(workflow_id)

    def recover_and_resume(self, workflow_id: str) -> WorkflowRecord:
        rec=self.get(workflow_id)
        if rec.state == WorkflowState.CANCELLED: return rec
        self.queue.recover_expired()
        return self.start(workflow_id) if rec.state in (WorkflowState.DRAFT, WorkflowState.BLOCKED) else self.refresh(workflow_id)

    def close(self):
        self._conn.close()
