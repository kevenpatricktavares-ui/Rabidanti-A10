# Rabidanti v2.9 — Dashboard + Connection Center + Approval Center

## Goal
Create a central control surface over the execution and connector foundations without bypassing their safety boundaries.

## Components
- `backend/dashboard/dashboard_service.py`: read-only aggregation of jobs, connectors and approvals.
- `backend/approvals/approval_center.py`: explicit approve/reject workflow for jobs.

## Rules
1. Dashboard aggregation is read-only.
2. Approval is explicit and auditable in the Approval Center history.
3. Approval does not add connector permissions.
4. Connector authorization still checks declared permissions, sensitive-action approval and connection state.
5. Project filtering applies to jobs and pending approvals.
6. No external provider access is claimed by this release.

## Next
Security hardening, durable persistence, E2E testing, deployment and observability remain before Release Candidate.
