# Rabidanti v3.85 — Laboratory Experiment & Prototype Manager

Builds on v3.84's persistent Laboratory project workflow. Adds structured experiment plans (hypothesis, method, success criteria), durable observations/artifact/result/risk/recommendation entries, controlled status transitions, audit events, and a report object that explicitly marks integration as not authorized.

## Lifecycle
`PLANNED → RUNNING → ANALYSIS → PASSED | FAILED`; analysis may return to running for another iteration. Cancellation is available before a terminal outcome. Terminal statuses cannot be reopened silently.

## Safety and scope
This is a persistent management layer, not an autonomous code execution sandbox. Artifact entries store references/metadata; they do not execute or upload files. Passing an experiment does not change Rabidanti Core or deploy a prototype. Integration requires a separate explicit human approval. Use a dedicated isolated environment for any future execution runner.

## Run tests
`pytest -q`
