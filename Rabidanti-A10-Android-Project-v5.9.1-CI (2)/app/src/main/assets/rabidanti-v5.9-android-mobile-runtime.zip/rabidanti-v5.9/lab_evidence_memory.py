"""Rabidanti v3.94 — traceable laboratory evidence memory.

Stores links between sources, experiments, runs, artifacts, analyses, and decisions.
This is a provenance index, not a truth oracle or an authorization mechanism.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, sqlite3, uuid

class LabEvidenceMemory:
    KINDS = {"SOURCE", "EXPERIMENT", "RUN", "ARTIFACT", "ANALYSIS", "DECISION"}
    def __init__(self, database="rabidanti_evidence_memory.sqlite3"):
        self.database = str(database)
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS lab_evidence_nodes(
                node_id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL,
                description TEXT NOT NULL, uri TEXT, content_digest TEXT,
                metadata TEXT NOT NULL, created_at TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS lab_evidence_links(
                link_id TEXT PRIMARY KEY, from_id TEXT NOT NULL, relation TEXT NOT NULL,
                to_id TEXT NOT NULL, note TEXT NOT NULL, created_at TEXT NOT NULL,
                UNIQUE(from_id, relation, to_id),
                FOREIGN KEY(from_id) REFERENCES lab_evidence_nodes(node_id),
                FOREIGN KEY(to_id) REFERENCES lab_evidence_nodes(node_id))""")
    def _connect(self):
        c = sqlite3.connect(self.database)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c
    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def digest_content(content):
        if not isinstance(content, (str, bytes)):
            raise ValueError("content must be text or bytes")
        raw = content.encode("utf-8") if isinstance(content, str) else content
        return hashlib.sha256(raw).hexdigest()
    def add_node(self, kind, title, description="", *, node_id=None, uri=None,
                 content=None, metadata=None):
        if kind not in self.KINDS:
            raise ValueError("unsupported evidence node kind")
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title is required")
        if not isinstance(description, str):
            raise ValueError("description must be text")
        if uri is not None and (not isinstance(uri, str) or not uri.strip()):
            raise ValueError("uri must be a non-empty string when supplied")
        if metadata is not None and not isinstance(metadata, dict):
            raise ValueError("metadata must be a dictionary")
        nid = node_id or str(uuid.uuid4())
        if not isinstance(nid, str) or not nid.strip():
            raise ValueError("node_id must be a non-empty string")
        digest = None if content is None else self.digest_content(content)
        now = self._now()
        with self._connect() as c:
            try:
                c.execute("INSERT INTO lab_evidence_nodes VALUES(?,?,?,?,?,?,?,?)",
                    (nid, kind, title.strip(), description.strip(), uri, digest,
                     json.dumps(metadata or {}, sort_keys=True, separators=(",", ":")), now))
            except sqlite3.IntegrityError as e:
                raise ValueError("duplicate evidence node id") from e
        return self.get_node(nid)
    def link(self, from_id, relation, to_id, *, note=""):
        if not isinstance(relation, str) or not relation.strip():
            raise ValueError("relation is required")
        if not isinstance(note, str):
            raise ValueError("note must be text")
        self.get_node(from_id); self.get_node(to_id)
        lid = str(uuid.uuid4()); now = self._now()
        with self._connect() as c:
            try:
                c.execute("INSERT INTO lab_evidence_links VALUES(?,?,?,?,?,?)",
                          (lid, from_id, relation.strip(), to_id, note.strip(), now))
            except sqlite3.IntegrityError as e:
                raise ValueError("duplicate evidence link") from e
        return {"link_id": lid, "from_id": from_id, "relation": relation.strip(),
                "to_id": to_id, "note": note.strip(), "created_at": now}
    def get_node(self, node_id):
        with self._connect() as c:
            row = c.execute("SELECT * FROM lab_evidence_nodes WHERE node_id=?", (node_id,)).fetchone()
        if row is None:
            raise KeyError(node_id)
        item = dict(row); item["metadata"] = json.loads(item["metadata"])
        return item
    def trace(self, node_id):
        """Return node and directly connected evidence, with stable ordering."""
        node = self.get_node(node_id)
        with self._connect() as c:
            rows = c.execute("""SELECT l.*, n.kind AS other_kind, n.title AS other_title,
                n.description AS other_description, n.uri AS other_uri,
                n.content_digest AS other_digest, n.metadata AS other_metadata
                FROM lab_evidence_links l
                JOIN lab_evidence_nodes n ON n.node_id =
                    CASE WHEN l.from_id=? THEN l.to_id ELSE l.from_id END
                WHERE l.from_id=? OR l.to_id=? ORDER BY l.created_at, l.link_id""",
                (node_id, node_id, node_id)).fetchall()
        links = []
        for row in rows:
            x = dict(row); x["other_metadata"] = json.loads(x["other_metadata"])
            links.append(x)
        body = {"node": node, "links": links}
        canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
        return {**body, "trace_digest": hashlib.sha256(canonical.encode()).hexdigest(),
                "limitation": "Traceability records provenance; it does not independently verify source truth."}
    def search(self, *, kind=None, text_query=None, limit=100):
        if kind is not None and kind not in self.KINDS:
            raise ValueError("unsupported evidence node kind")
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 1000:
            raise ValueError("limit must be an integer between 1 and 1000")
        q = "SELECT * FROM lab_evidence_nodes"; clauses=[]; args=[]
        if kind:
            clauses.append("kind=?"); args.append(kind)
        if text_query:
            if not isinstance(text_query, str) or not text_query.strip():
                raise ValueError("text_query must be non-empty text")
            clauses.append("(title LIKE ? OR description LIKE ?)"); args += [f"%{text_query.strip()}%", f"%{text_query.strip()}%"]
        if clauses: q += " WHERE " + " AND ".join(clauses)
        q += " ORDER BY created_at,node_id LIMIT ?"; args.append(limit)
        with self._connect() as c: rows = c.execute(q, args).fetchall()
        out=[]
        for row in rows:
            item=dict(row); item["metadata"]=json.loads(item["metadata"]); out.append(item)
        return out
