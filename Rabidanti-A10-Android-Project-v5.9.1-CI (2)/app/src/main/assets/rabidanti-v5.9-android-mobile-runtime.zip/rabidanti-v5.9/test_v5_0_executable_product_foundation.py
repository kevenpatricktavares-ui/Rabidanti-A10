from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from rabidanti_launcher import launcher_args
from rabidanti_product import ProductFoundation, default_state_dir

ROOT = Path(__file__).resolve().parent


def test_version_is_at_least_5_0():
    parts = tuple(int(x) for x in (ROOT / "VERSION").read_text().strip().split("."))
    assert parts >= (5, 0, 0)


def test_default_state_dir_honors_explicit_environment_override(tmp_path):
    target = tmp_path / "state"
    assert default_state_dir({"RABIDANTI_STATE_DIR": str(target)}) == target.resolve()


def test_launcher_defaults_to_room_and_platform_state(monkeypatch, tmp_path):
    monkeypatch.setenv("RABIDANTI_STATE_DIR", str(tmp_path / "product-state"))
    args = launcher_args([])
    assert args[-1] == "room"
    assert args[:2] == ["--state-dir", str((tmp_path / "product-state").resolve())]


def test_launcher_preserves_explicit_cli_arguments():
    assert launcher_args(["--state-dir", "x", "status"]) == ["--state-dir", "x", "status"]


def test_product_initialize_creates_non_secret_marker_with_restricted_permissions(tmp_path):
    product = ProductFoundation(tmp_path / "state")
    result = product.initialize()
    marker = Path(result["marker"])
    data = json.loads(marker.read_text())
    assert data["program"] == "Rabidanti"
    assert data["external_action_authorized"] is False
    lowered = marker.read_text().lower()
    assert "password" not in lowered
    assert "token" not in lowered
    if os.name != "nt":
        assert marker.stat().st_mode & 0o777 == 0o600


def test_product_doctor_has_no_automatic_install_or_download_authority(tmp_path):
    result = ProductFoundation(tmp_path / "state").doctor(probe_ollama=False)
    assert result["safety"] == {
        "installs_automatically": False,
        "downloads_models_automatically": False,
        "external_action_authorized": False,
    }
    assert any(c["name"] == "runtime_dependencies" for c in result["checks"])


def test_ollama_non_network_probe_is_safe_and_structured(tmp_path):
    result = ProductFoundation(tmp_path).ollama(probe_http=False)
    assert result["reachable"] is False
    assert result["endpoint"].startswith("http://127.0.0.1:")
    assert isinstance(result["installed"], bool)


def test_bootstrap_cli_setup_works_as_independent_entrypoint(tmp_path):
    proc = subprocess.run(
        [sys.executable, str(ROOT / "rabidanti_bootstrap.py"), "--state-dir", str(tmp_path / "state"), "setup"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    data = json.loads(proc.stdout)
    assert data["initialized"] is True
    assert Path(data["marker"]).is_file()


def test_bootstrap_cli_doctor_returns_product_environment(tmp_path):
    proc = subprocess.run(
        [sys.executable, str(ROOT / "rabidanti_bootstrap.py"), "--state-dir", str(tmp_path / "state"), "doctor"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    data = json.loads(proc.stdout)
    assert data["program"] == "Rabidanti"
    assert data["product_foundation"] == "5.0"


def test_pyinstaller_spec_includes_ui_and_version_and_launcher():
    text = (ROOT / "Rabidanti.spec").read_text()
    assert '"rabidanti_launcher.py"' in text
    assert '("ui", "ui")' in text
    assert '("VERSION", ".")' in text
    assert 'name="Rabidanti"' in text


def test_product_start_and_build_scripts_are_present():
    for name in ["START-RABIDANTI.bat", "START-RABIDANTI.sh", "build_windows.bat", "build_linux.sh"]:
        assert (ROOT / name).is_file(), name


def test_build_info_does_not_claim_frozen_binary_when_running_source(tmp_path):
    info = ProductFoundation(tmp_path).build_info()
    assert info["program"] == "Rabidanti"
    assert isinstance(info["frozen"], bool)
    assert info["state_dir"] == str(tmp_path.resolve())


def test_product_cli_setup_does_not_initialize_runtime_databases(tmp_path):
    from rabidanti import main
    state = tmp_path / "state"
    assert main(["--state-dir", str(state), "product", "setup"]) == 0
    assert (state / "product.json").is_file()
    assert not (state / "runtime.sqlite3").exists()
    assert not (state / "tasks.sqlite3").exists()
