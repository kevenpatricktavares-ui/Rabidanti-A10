"""Rabidanti v3.51 — Continuous Opportunity Runtime.

Connects the persistent scheduler, durable worker queue and opportunity discovery
engine. It continuously processes already-ingested world signals; it does not
fetch the web itself and does not claim an opportunity is commercially valid.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, sqlite3, threading, time, uuid
from datetime import datetime, timezone, timedelta
from typing import Any, Optional

from opportunity_discovery import OpportunityDiscoveryEngine, OpportunityTheme
from persistent_scheduler import PersistentScheduler
from durable_worker_queue import DurableWorkerQueue
from continuous_worker_runner import ContinuousWorkerRunner
from world_awareness import WorldAwareness, WorldAwarenessStore

HANDLER = "opportunity.discovery.scan"

@dataclass(frozen=True)
class DiscoveryRecord:
    record_id: str
    fingerprint: str
    theme_id: str
    topic: str
    signal_ids: tuple[str, ...]
    discovered_at: float
    status: str = "CANDIDATE_THEME"
    def to_dict(self): return asdict(self)

class DiscoveryRecordStore:
    def __init__(self, db_path: str):
        self.db_path=db_path; self._lock=threading.RLock()
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory=sqlite3.Row
        if db_path != ':memory:':
            self._conn.execute('PRAGMA journal_mode=WAL')
            self._conn.execute('PRAGMA synchronous=NORMAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS discovery_records(
            record_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE,
            theme_id TEXT NOT NULL, topic TEXT NOT NULL, signal_ids_json TEXT NOT NULL,
            discovered_at REAL NOT NULL, status TEXT NOT NULL)''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_discovery_topic ON discovery_records(topic)')
    def add_if_new(self, theme: OpportunityTheme) -> tuple[DiscoveryRecord,bool]:
        ids=tuple(sorted(theme.signal_ids))
        fp=hashlib.sha256((theme.topic+'|'+','.join(ids)).encode()).hexdigest()
        with self._lock:
            row=self._conn.execute('SELECT * FROM discovery_records WHERE fingerprint=?',(fp,)).fetchone()
            if row:
                return self._row(row),False
            now=time.time(); rec=DiscoveryRecord('odr-'+uuid.uuid4().hex,fp,theme.theme_id,theme.topic,ids,now)
            self._conn.execute('INSERT INTO discovery_records VALUES(?,?,?,?,?,?,?)',
                (rec.record_id,rec.fingerprint,rec.theme_id,rec.topic,json.dumps(ids),now,rec.status))
            return rec,True
    def list(self, topic: str|None=None):
        with self._lock:
            if topic:
                rows=self._conn.execute('SELECT * FROM discovery_records WHERE topic=? ORDER BY discovered_at DESC',(topic,)).fetchall()
            else: rows=self._conn.execute('SELECT * FROM discovery_records ORDER BY discovered_at DESC').fetchall()
        return [self._row(r) for r in rows]
    @staticmethod
    def _row(r): return DiscoveryRecord(r['record_id'],r['fingerprint'],r['theme_id'],r['topic'],tuple(json.loads(r['signal_ids_json'])),r['discovered_at'],r['status'])

class ContinuousOpportunityRuntime:
    """Schedule and execute evidence-bounded discovery scans."""
    def __init__(self, db_path: str, *, world: WorldAwareness|None=None,
                 scheduler: PersistentScheduler|None=None, queue: DurableWorkerQueue|None=None):
        self.db_path=db_path
        self.world=world or WorldAwareness(WorldAwarenessStore(db_path))
        self.scheduler=scheduler or PersistentScheduler(db_path)
        self.queue=queue or DurableWorkerQueue(db_path)
        self.records=DiscoveryRecordStore(db_path)
        self.discovery=OpportunityDiscoveryEngine(self.world)
        self._runner: ContinuousWorkerRunner|None=None
        self._lock=threading.RLock()

    def attach_runner(self, runner: ContinuousWorkerRunner) -> None:
        self._runner=runner
        # The runtime must enqueue into the exact durable queue consumed by the runner.
        self.queue=runner.queue
        runner.register_handler(HANDLER,self._handle_scan)

    def schedule_scan(self, *, run_at: datetime|None=None, interval_seconds: int|None=None,
                      topic: str|None=None, min_signals: int=2, min_relatedness: float=.2,
                      priority: int=5) -> str:
        if run_at is None: run_at=datetime.now(timezone.utc)
        if run_at.tzinfo is None: raise ValueError('run_at must be timezone-aware')
        if interval_seconds is not None and interval_seconds < 1: raise ValueError('interval_seconds must be >= 1')
        task_id='opportunity-scan-'+uuid.uuid4().hex
        self.scheduler.add(task_id,run_at,interval_seconds)
        return task_id

    def enqueue_due(self, now: datetime|None=None) -> list[str]:
        due=self.scheduler.due(now)
        queued=[]
        for task in due:
            payload={'handler':HANDLER,'data':{'topic':None,'min_signals':2,'min_relatedness':.2}}
            item=self.queue.enqueue(payload,priority=5,task_id='opportunity-scan-job-'+task.task_id)
            self.scheduler.acknowledge(task.task_id,now)
            queued.append(item.item_id)
        return queued

    def scan_once(self, *, topic: str|None=None, min_signals: int=2, min_relatedness: float=.2, limit: int=100) -> dict[str,Any]:
        themes=self.discovery.discover(topic=topic,limit=limit,min_signals=min_signals,min_relatedness=min_relatedness)
        new=[]
        for theme in themes:
            rec,created=self.records.add_if_new(theme)
            if created: new.append(rec.to_dict())
        return {'themes_seen':len(themes),'new_themes':new,'status':'COMPLETED'}

    def _handle_scan(self, data: Any):
        data=data or {}
        return self.scan_once(topic=data.get('topic'),min_signals=int(data.get('min_signals',2)),min_relatedness=float(data.get('min_relatedness',.2)),limit=int(data.get('limit',100)))
