import json
import subprocess
import sys
from pathlib import Path

import pytest

from rabidanti_runtime import RabidantiRuntime

CURRENT_VERSION = Path(__file__).with_name("VERSION").read_text(encoding="utf-8").strip()


def test_runtime_initializes_all_control_surfaces(tmp_path):
    r = RabidantiRuntime(tmp_path / "state")
    try:
        assert r.version == CURRENT_VERSION
        assert r.core is not None
        assert r.lab is not None
        assert r.evidence is not None
        assert r.human_reviews is not None
        assert r.integration_proposals is not None
        assert r.change_executor is not None
    finally:
        r.close()


def test_start_is_idempotent_and_status_is_structured(tmp_path):
    r = RabidantiRuntime(tmp_path / "state")
    try:
        first = r.start()
        second = r.start()
        assert first["version"] == CURRENT_VERSION
        assert second["runtime_state"] == "RUNNING"
        assert second["safety"]["self_authorization"] is False
        assert second["safety"]["external_action_authorized"] is False
    finally:
        r.stop()


def test_task_persists_across_runtime_restart(tmp_path):
    state = tmp_path / "state"
    r1 = RabidantiRuntime(state)
    r1.start()
    task = r1.add_task("persist me", priority="HIGH", task_id="task-persist")
    r1.stop()
    assert task["state"] == "QUEUED"

    r2 = RabidantiRuntime(state)
    try:
        r2.start()
        items = r2.list_tasks()
        assert [x["task_id"] for x in items] == ["task-persist"]
        assert items[0]["priority"] == "HIGH"
    finally:
        r2.stop()


def test_start_recovers_running_autonomous_tasks(tmp_path):
    state = tmp_path / "state"
    r1 = RabidantiRuntime(state)
    r1.start(recover=False)
    r1.add_task("recover me", task_id="recover-task")
    r1.tasks.claim("recover-task", "worker-a")
    r1.stop()

    r2 = RabidantiRuntime(state)
    try:
        r2.start(recover=True)
        task = r2.tasks.get("recover-task")
        assert task.state.value == "QUEUED"
        assert task.owner is None
    finally:
        r2.stop()


def test_status_reports_task_counts(tmp_path):
    r = RabidantiRuntime(tmp_path / "state")
    try:
        r.start()
        r.add_task("one", task_id="one")
        r.add_task("two", task_id="two")
        status = r.status()
        assert status["tasks"]["total"] == 2
        assert status["tasks"]["counts"]["QUEUED"] == 2
    finally:
        r.stop()


def test_evidence_is_available_through_unified_runtime(tmp_path):
    r = RabidantiRuntime(tmp_path / "state")
    try:
        r.start()
        r.evidence.add_node("SOURCE", "Runtime source", content="abc", node_id="source-1")
        found = r.search_evidence(kind="SOURCE", text="Runtime")
        assert len(found) == 1
        assert found[0]["node_id"] == "source-1"
    finally:
        r.stop()


def test_runtime_events_are_persistent_and_auditable(tmp_path):
    state = tmp_path / "state"
    r1 = RabidantiRuntime(state)
    r1.start()
    r1.add_task("event task", task_id="evt-task")
    r1.stop()

    r2 = RabidantiRuntime(state)
    try:
        events = r2.runtime_events()
        types = {event["event_type"] for event in events}
        assert {"RUNTIME_STARTED", "TASK_ADDED", "RUNTIME_STOPPED"}.issubset(types)
        assert all(event["version"] == CURRENT_VERSION for event in events)
    finally:
        r2.close()


def test_doctor_does_not_pretend_container_isolation_exists(tmp_path, monkeypatch):
    r = RabidantiRuntime(tmp_path / "state")
    try:
        monkeypatch.setattr("rabidanti_runtime.shutil.which", lambda name: None)
        report = r.doctor()
        by_name = {item["name"]: item for item in report["checks"]}
        assert report["healthy"] is True
        assert by_name["container_runtime"]["ok"] is False
        assert "not validated" in by_name["container_runtime"]["detail"]
    finally:
        r.close()


def test_unified_runtime_keeps_change_executor_non_self_authorizing(tmp_path):
    r = RabidantiRuntime(tmp_path / "state")
    try:
        with pytest.raises(PermissionError):
            r.change_executor.self_authorize("anything")
        with pytest.raises(PermissionError):
            r.change_executor.authorize_external_action("anything")
    finally:
        r.close()


def test_cli_status_executes_as_real_program(tmp_path):
    state = tmp_path / "cli-state"
    proc = subprocess.run(
        [sys.executable, "rabidanti.py", "--state-dir", str(state), "status"],
        cwd=Path(__file__).parent,
        text=True,
        capture_output=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    body = json.loads(proc.stdout)
    assert body["program"] == "Rabidanti"
    assert body["version"] == CURRENT_VERSION
    assert body["runtime_state"] == "RUNNING"


def test_cli_task_add_then_list_persists(tmp_path):
    state = tmp_path / "cli-state"
    add = subprocess.run(
        [sys.executable, "rabidanti.py", "--state-dir", str(state), "task", "add", "CLI Task", "--priority", "CRITICAL"],
        cwd=Path(__file__).parent,
        text=True, capture_output=True, check=False,
    )
    assert add.returncode == 0, add.stderr
    created = json.loads(add.stdout)
    assert created["priority"] == "CRITICAL"

    listed = subprocess.run(
        [sys.executable, "rabidanti.py", "--state-dir", str(state), "task", "list"],
        cwd=Path(__file__).parent,
        text=True, capture_output=True, check=False,
    )
    assert listed.returncode == 0, listed.stderr
    items = json.loads(listed.stdout)
    assert len(items) == 1
    assert items[0]["name"] == "CLI Task"


def test_shell_can_start_and_exit_cleanly(tmp_path):
    state = tmp_path / "shell-state"
    proc = subprocess.run(
        [sys.executable, "rabidanti.py", "--state-dir", str(state), "shell"],
        cwd=Path(__file__).parent,
        input="status\nexit\n",
        text=True,
        capture_output=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    assert f"Rabidanti {CURRENT_VERSION}" in proc.stdout
    assert '"runtime_state": "RUNNING"' in proc.stdout
