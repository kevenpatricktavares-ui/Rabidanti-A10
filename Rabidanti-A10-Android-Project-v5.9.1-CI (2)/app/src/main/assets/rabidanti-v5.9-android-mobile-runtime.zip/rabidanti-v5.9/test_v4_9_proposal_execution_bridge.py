import json
import httpx
import pytest

from rabidanti_model_gateway import LocalOllamaGateway
from rabidanti_reasoning import AgentReasoningRuntime
from rabidanti_connectors import ConnectorAccess, ConnectorCapability, ConnectorDefinition, ConnectorRegistry
from rabidanti_proposal_bridge import ProposalExecutionBridge, ProposalReviewRequired, ProposalRejected, ProposalBridgeError


def client(handler):
    return httpx.Client(transport=httpx.MockTransport(handler), base_url='http://127.0.0.1:11434')

def make_reasoning(tmp_path, action):
    body={'response':'ok','proposed_actions':[action]}
    g=LocalOllamaGateway(client=client(lambda r:httpx.Response(200,json={'model':'m','message':{'content':json.dumps(body)}})),model='m')
    rr=AgentReasoningRuntime(tmp_path/'reasoning.sqlite3',g)
    out=rr.reason('x')
    return rr,out['proposed_actions'][0]

def connector_def():
    return ConnectorDefinition(
        connector_id='demo.connector', display_name='Demo', version='1',
        capabilities=(
            ConnectorCapability('items.read',ConnectorAccess.READ),
            ConnectorCapability('items.write',ConnectorAccess.WRITE),
        )
    )

def test_proposal_cannot_execute_before_review(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'analisar','reason':'necessário'})
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,ConnectorRegistry(tmp_path/'c.db'),lambda name:{'task_id':'t1','name':name})
    with pytest.raises(ProposalReviewRequired): bridge.execute(p['proposal_id'],actor='owner')

def test_rejected_proposal_cannot_be_authorized_or_executed(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'analisar','reason':'necessário'})
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,ConnectorRegistry(tmp_path/'c.db'),lambda name:{'task_id':'t1'})
    bridge.review(p['proposal_id'],decision='REJECTED',actor='owner',reason='não agora')
    with pytest.raises(ProposalRejected): bridge.authorize(p['proposal_id'],actor='owner',reason='x')

def test_review_is_final_and_immutable(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'analisar','reason':'necessário'})
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,ConnectorRegistry(tmp_path/'c.db'),lambda name:{'task_id':'t1'})
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    with pytest.raises(ProposalBridgeError,match='already has'): bridge.review(p['proposal_id'],decision='REJECTED',actor='owner',reason='change')

def test_internal_task_requires_separate_authorization(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'analisar mercado','reason':'necessário'})
    made=[]
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,ConnectorRegistry(tmp_path/'c.db'),lambda name:(made.append(name) or {'task_id':'t1','name':name}))
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    with pytest.raises(ProposalBridgeError,match='authorization'): bridge.execute(p['proposal_id'],actor='owner')
    # Internal tasks don't need connector permission approval, but do need explicit bridge authorization.
    auth=bridge.authorize(p['proposal_id'],actor='owner',reason='go')
    assert auth['connector_approval_id'] is None

def test_internal_task_can_execute_after_explicit_authorization_record(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'analisar mercado','reason':'necessário'})
    made=[]
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,ConnectorRegistry(tmp_path/'c.db'),lambda name:(made.append(name) or {'task_id':'t1','name':name}))
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    bridge.authorize(p['proposal_id'],actor='owner',reason='execute internal task')
    out=bridge.execute(p['proposal_id'],actor='owner')
    assert out['status']=='SUCCEEDED' and made==['analisar mercado']
    with pytest.raises(ProposalBridgeError,match='already been executed'): bridge.execute(p['proposal_id'],actor='owner')

def test_read_connector_still_requires_review_and_authorization_step(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'connector','connector_id':'demo.connector','capability':'items.read','payload':{'q':'x'},'reason':'consulta'})
    calls=[]; reg=ConnectorRegistry(tmp_path/'c.db'); reg.register(connector_def(),lambda cap,payload,ctx:(calls.append((cap,payload,ctx.actor)) or {'ok':True})); reg.set_enabled('demo.connector',True,actor='owner',reason='test')
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,reg,lambda name:{})
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    auth=bridge.authorize(p['proposal_id'],actor='owner',reason='execute read')
    assert auth['connector_approval_id'] is None
    out=bridge.execute(p['proposal_id'],actor='owner')
    assert out['status']=='SUCCEEDED' and calls[0][0]=='items.read'

def test_write_connector_requires_permission_gate_one_time_approval(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'connector','connector_id':'demo.connector','capability':'items.write','payload':{'id':7},'reason':'alterar'})
    calls=[]; reg=ConnectorRegistry(tmp_path/'c.db'); reg.register(connector_def(),lambda cap,payload,ctx:(calls.append(payload) or {'ok':True})); reg.set_enabled('demo.connector',True,actor='owner',reason='test')
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,reg,lambda name:{})
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    auth=bridge.authorize(p['proposal_id'],actor='owner',reason='permit exact write')
    assert auth['connector_approval_id'].startswith('approval-')
    out=bridge.execute(p['proposal_id'],actor='owner')
    assert out['status']=='SUCCEEDED' and reg.approvals()[0]['consumed'] is True

def test_get_proposal_returns_exact_digest(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'x','reason':'y'})
    got=rr.get_proposal(p['proposal_id']); assert got['proposal_digest']==p['proposal_digest'] and got['execution_authorized'] is False

def test_execution_ledger_persists_result_digest_not_authority(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'internal_task','name':'x','reason':'y'})
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,ConnectorRegistry(tmp_path/'c.db'),lambda name:{'task_id':'t1'})
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    bridge.authorize(p['proposal_id'],actor='owner',reason='go')
    bridge.execute(p['proposal_id'],actor='owner')
    row=bridge.executions()[0]
    assert row['status']=='SUCCEEDED' and row['result_digest'] and 'execution_authorized' not in row


def test_failed_connector_attempt_requires_fresh_authorization_then_can_retry(tmp_path):
    rr,p=make_reasoning(tmp_path,{'kind':'connector','connector_id':'demo.connector','capability':'items.write','payload':{'id':9},'reason':'alterar'})
    attempts={'n':0}
    def flaky(cap,payload,ctx):
        attempts['n']+=1
        if attempts['n']==1: raise RuntimeError('temporary')
        return {'ok':True}
    reg=ConnectorRegistry(tmp_path/'c.db'); reg.register(connector_def(),flaky); reg.set_enabled('demo.connector',True,actor='owner',reason='test')
    bridge=ProposalExecutionBridge(tmp_path/'bridge.db',rr,reg,lambda name:{})
    bridge.review(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    bridge.authorize(p['proposal_id'],actor='owner',reason='attempt 1')
    with pytest.raises(RuntimeError): bridge.execute(p['proposal_id'],actor='owner')
    with pytest.raises(ProposalBridgeError,match='authorization'): bridge.execute(p['proposal_id'],actor='owner')
    bridge.authorize(p['proposal_id'],actor='owner',reason='retry approved')
    out=bridge.execute(p['proposal_id'],actor='owner')
    assert out['status']=='SUCCEEDED' and attempts['n']==2

import urllib.request, urllib.error
from rabidanti_runtime import RabidantiRuntime
from rabidanti_api import RabidantiApiService


def _req(url, *, method='GET', token=None, body=None):
    headers={}; data=None
    if body is not None:
        data=json.dumps(body).encode(); headers['Content-Type']='application/json'
    if token: headers['Authorization']=f'Bearer {token}'
    req=urllib.request.Request(url,method=method,headers=headers,data=data)
    try:
        with urllib.request.urlopen(req,timeout=5) as resp: return resp.status,json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc: return exc.code,json.loads(exc.read().decode())


def test_runtime_wires_bridge_and_internal_task_execution(tmp_path):
    r=RabidantiRuntime(tmp_path/'state'); r.start()
    body={'response':'ok','proposed_actions':[{'kind':'internal_task','name':'follow up','reason':'needed'}]}
    r.reasoning.gateway=LocalOllamaGateway(client=client(lambda req:httpx.Response(200,json={'message':{'content':json.dumps(body)}})))
    p=r.reasoning.reason('x')['proposed_actions'][0]
    r.review_reasoning_proposal(p['proposal_id'],decision='APPROVED',actor='owner',reason='ok')
    r.authorize_reasoning_proposal(p['proposal_id'],actor='owner',reason='execute')
    out=r.execute_reasoning_proposal(p['proposal_id'],actor='owner')
    assert out['status']=='SUCCEEDED'
    assert any(t['name']=='follow up' for t in r.list_tasks())
    assert r.proposal_reviews()[0]['proposal_id']==p['proposal_id']
    assert r.proposal_executions()[0]['status']=='SUCCEEDED'
    r.stop()


def test_api_exposes_controlled_proposal_flow_with_token(tmp_path):
    r=RabidantiRuntime(tmp_path/'state'); r.start()
    body={'response':'ok','proposed_actions':[{'kind':'internal_task','name':'api task','reason':'needed'}]}
    r.reasoning.gateway=LocalOllamaGateway(client=client(lambda req:httpx.Response(200,json={'message':{'content':json.dumps(body)}})))
    p=r.reasoning.reason('x')['proposed_actions'][0]
    token='strong-local-token-for-v49-tests-123456'
    svc=RabidantiApiService(r,port=0,token=token); addr=svc.start(background=True); base=f'http://{addr.host}:{addr.port}'
    try:
        code,_=_req(base+'/v1/reasoning/review',method='POST',body={'proposal_id':p['proposal_id'],'decision':'APPROVED','actor':'owner','reason':'ok'})
        assert code==401
        code,rev=_req(base+'/v1/reasoning/review',method='POST',token=token,body={'proposal_id':p['proposal_id'],'decision':'APPROVED','actor':'owner','reason':'ok'})
        assert code==201 and rev['decision']=='APPROVED'
        code,auth=_req(base+'/v1/reasoning/authorize',method='POST',token=token,body={'proposal_id':p['proposal_id'],'actor':'owner','reason':'go'})
        assert code==201 and auth['authorization_id'].startswith('proposal-auth-')
        code,out=_req(base+'/v1/reasoning/execute',method='POST',token=token,body={'proposal_id':p['proposal_id'],'actor':'owner'})
        assert code==200 and out['status']=='SUCCEEDED'
        code,rows=_req(base+'/v1/reasoning/executions'); assert code==200 and rows['items'][0]['status']=='SUCCEEDED'
    finally:
        svc.stop(); r.stop()
