"""Rabidanti v3.87: bounded isolated command runner for controlled lab checks.

This is a resource-limited subprocess runner, not a hardened security sandbox.
Only explicitly allowed executables are accepted; no shell is used; each run gets
its own temporary working directory and bounded output/time. Do not use for
untrusted code on a sensitive host; use OS/container isolation for that.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, subprocess, tempfile, time

@dataclass(frozen=True)
class RunResult:
    run_id: str
    command: tuple[str, ...]
    status: str
    return_code: int | None
    stdout: str
    stderr: str
    duration_seconds: float
    workspace: str
    started_at: str
    finished_at: str
    output_truncated: bool
    digest: str

class IsolatedLabRunner:
    """Run allowlisted commands in a fresh temporary directory with limits."""
    ALLOWED = {"python", "python3", "pytest", "git", "node", "npm"}
    def __init__(self, root="lab_runs", timeout_seconds=10, output_limit=12000, max_timeout_seconds=60):
        if not isinstance(timeout_seconds, int) or timeout_seconds < 1 or timeout_seconds > max_timeout_seconds:
            raise ValueError("timeout_seconds outside allowed range")
        if not isinstance(output_limit, int) or not 256 <= output_limit <= 100000:
            raise ValueError("output_limit outside allowed range")
        self.root = Path(root).resolve(); self.root.mkdir(parents=True, exist_ok=True)
        self.timeout_seconds=timeout_seconds; self.output_limit=output_limit; self.max_timeout_seconds=max_timeout_seconds

    def run(self, run_id, command, files=None, timeout_seconds=None, env=None):
        if not isinstance(run_id,str) or not run_id.strip(): raise ValueError("run_id required")
        if not isinstance(command,(list,tuple)) or not command or any(not isinstance(x,str) or not x for x in command):
            raise ValueError("command must be a non-empty list of strings")
        exe=Path(command[0]).name
        if exe not in self.ALLOWED: raise PermissionError("executable is not allowlisted")
        timeout=self.timeout_seconds if timeout_seconds is None else timeout_seconds
        if not isinstance(timeout,int) or timeout < 1 or timeout > self.max_timeout_seconds: raise ValueError("timeout outside allowed range")
        if files is None: files={}
        if not isinstance(files,dict): raise ValueError("files must be a mapping of relative paths to text")
        started=datetime.now(timezone.utc).isoformat(); t0=time.monotonic()
        # Each invocation gets a unique workspace; reject traversal and symlinks by creating files ourselves.
        work=Path(tempfile.mkdtemp(prefix="run-",dir=self.root)).resolve()
        for rel, content in files.items():
            if not isinstance(rel,str) or not rel or Path(rel).is_absolute() or ".." in Path(rel).parts:
                shutil.rmtree(work,ignore_errors=True); raise ValueError("unsafe relative artifact path")
            if not isinstance(content,str):
                shutil.rmtree(work,ignore_errors=True); raise ValueError("artifact contents must be text")
            dest=(work/rel).resolve()
            if work not in dest.parents:
                shutil.rmtree(work,ignore_errors=True); raise ValueError("artifact path escapes workspace")
            dest.parent.mkdir(parents=True,exist_ok=True); dest.write_text(content,encoding="utf-8")
        clean_env={"PATH":os.environ.get("PATH",""),"PYTHONIOENCODING":"utf-8","PYTHONDONTWRITEBYTECODE":"1"}
        if env:
            if not isinstance(env,dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in env.items()):
                shutil.rmtree(work,ignore_errors=True); raise ValueError("env must map strings to strings")
            # Environment is intentionally restricted to caller-provided non-secret values.
            clean_env.update(env)
        status="ERROR"; rc=None; stdout=""; stderr=""
        try:
            p=subprocess.run(list(command),cwd=work,env=clean_env,shell=False,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=timeout,check=False)
            rc=p.returncode; stdout=p.stdout; stderr=p.stderr; status="PASSED" if rc==0 else "FAILED"
        except subprocess.TimeoutExpired as e:
            status="TIMED_OUT"; stdout=e.stdout or ""; stderr=e.stderr or ""
            if isinstance(stdout,bytes): stdout=stdout.decode("utf-8","replace")
            if isinstance(stderr,bytes): stderr=stderr.decode("utf-8","replace")
        except OSError as e:
            stderr=f"runner error: {type(e).__name__}: {e}"
        duration=round(time.monotonic()-t0,4); finished=datetime.now(timezone.utc).isoformat()
        combined=stdout+"\n--- STDERR ---\n"+stderr; truncated=len(combined)>self.output_limit
        if truncated: combined=combined[:self.output_limit]; stdout,_,stderr=combined.partition("\n--- STDERR ---\n")
        payload={"run_id":run_id,"command":list(command),"status":status,"return_code":rc,"stdout":stdout,"stderr":stderr,"duration_seconds":duration,"workspace":str(work),"started_at":started,"finished_at":finished,"output_truncated":truncated}
        payload["digest"]=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
        return RunResult(run_id,tuple(command),status,rc,stdout,stderr,duration,str(work),started,finished,truncated,payload["digest"])

    @staticmethod
    def to_json(result): return json.dumps(asdict(result),indent=2,ensure_ascii=False)
