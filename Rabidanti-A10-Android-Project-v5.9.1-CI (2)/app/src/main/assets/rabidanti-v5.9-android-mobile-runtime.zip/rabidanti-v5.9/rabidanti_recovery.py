"""Rabidanti v5.3 — offline update, backup and crash-recovery foundation.

Only local, explicit operations are implemented here. This module never downloads
updates, never replaces the running program, and never authorizes installation.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Optional
import hashlib
import json
import os
import shutil
import tempfile
import threading
import time
import uuid
import zipfile


class RecoveryError(RuntimeError):
    pass


class UpdateValidationError(RecoveryError):
    pass


def _now() -> float:
    return time.time()


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".rabidanti-recovery-", suffix=".tmp", dir=str(path.parent), text=True)
    try:
        if os.name != "nt":
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        if os.name != "nt":
            os.chmod(path, 0o600)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_zip_name(name: str) -> bool:
    p = PurePosixPath(name.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        return False
    # Windows drive-like prefixes are not valid package members either.
    return not (p.parts and ":" in p.parts[0])


def _semver_tuple(value: str) -> tuple[int, int, int]:
    parts = value.strip().split(".")
    if len(parts) != 3 or any(not x.isdigit() for x in parts):
        raise UpdateValidationError(f"invalid semantic version: {value!r}")
    return tuple(int(x) for x in parts)  # type: ignore[return-value]


class StateBackupManager:
    """Create validated local snapshots of persistent state.

    Backups deliberately exclude backup/update artifacts and transient process
    markers. Restore is explicit and overlays only files present in the backup;
    it never silently deletes unrelated/newer state files.
    """

    EXCLUDED_TOP_LEVEL = {"backups", "updates"}
    EXCLUDED_FILES = {"desktop-instance.lock", "recovery-session.json", "liveness.json"}

    def __init__(self, state_dir: str | os.PathLike[str]) -> None:
        self.state_dir = Path(state_dir).expanduser().resolve()
        self.backup_dir = self.state_dir / "backups"

    def _state_files(self) -> list[Path]:
        if not self.state_dir.exists():
            return []
        files: list[Path] = []
        for path in sorted(self.state_dir.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(self.state_dir)
            if rel.parts and rel.parts[0] in self.EXCLUDED_TOP_LEVEL:
                continue
            if rel.name in self.EXCLUDED_FILES:
                continue
            files.append(path)
        return files

    def create(self, *, reason: str, version: str) -> dict[str, Any]:
        if not isinstance(reason, str) or not reason.strip():
            raise RecoveryError("backup reason is required")
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        backup_id = f"backup-{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
        final = self.backup_dir / f"{backup_id}.zip"
        temp = self.backup_dir / f".{backup_id}.tmp"
        entries: list[dict[str, Any]] = []
        files = self._state_files()
        for path in files:
            rel = path.relative_to(self.state_dir).as_posix()
            entries.append({"path": rel, "sha256": sha256_file(path), "size": path.stat().st_size})
        manifest = {
            "format": "rabidanti-state-backup-v1",
            "backup_id": backup_id,
            "created_at": _now(),
            "version": version,
            "reason": reason.strip(),
            "files": entries,
            "destructive_restore": False,
        }
        try:
            with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                zf.writestr("BACKUP-MANIFEST.json", json.dumps(manifest, sort_keys=True, ensure_ascii=False, indent=2))
                for path in files:
                    zf.write(path, f"state/{path.relative_to(self.state_dir).as_posix()}")
            with zipfile.ZipFile(temp, "r") as zf:
                bad = zf.testzip()
                if bad:
                    raise RecoveryError(f"backup integrity check failed: {bad}")
            os.replace(temp, final)
        finally:
            if temp.exists():
                temp.unlink()
        return {**manifest, "path": str(final), "sha256": sha256_file(final)}

    def list(self) -> list[dict[str, Any]]:
        if not self.backup_dir.exists():
            return []
        rows: list[dict[str, Any]] = []
        for path in sorted(self.backup_dir.glob("backup-*.zip"), reverse=True):
            try:
                with zipfile.ZipFile(path) as zf:
                    manifest = json.loads(zf.read("BACKUP-MANIFEST.json"))
                rows.append({**manifest, "path": str(path), "sha256": sha256_file(path)})
            except Exception:
                rows.append({"path": str(path), "valid": False})
        return rows

    def validate(self, backup: str | os.PathLike[str]) -> dict[str, Any]:
        path = Path(backup).expanduser().resolve()
        if not path.is_file():
            raise RecoveryError("backup file does not exist")
        with zipfile.ZipFile(path, "r") as zf:
            if zf.testzip():
                raise RecoveryError("backup ZIP failed integrity check")
            names = zf.namelist()
            if any(not _safe_zip_name(n) for n in names):
                raise RecoveryError("unsafe path in backup")
            try:
                manifest = json.loads(zf.read("BACKUP-MANIFEST.json"))
            except Exception as exc:
                raise RecoveryError("backup manifest is missing or invalid") from exc
            if manifest.get("format") != "rabidanti-state-backup-v1":
                raise RecoveryError("unsupported backup format")
            for entry in manifest.get("files", []):
                rel = str(entry.get("path") or "")
                member = f"state/{rel}"
                if member not in names:
                    raise RecoveryError(f"backup member missing: {rel}")
                actual = hashlib.sha256(zf.read(member)).hexdigest()
                if actual != entry.get("sha256"):
                    raise RecoveryError(f"backup hash mismatch: {rel}")
        return {**manifest, "path": str(path), "sha256": sha256_file(path), "valid": True}

    def restore(self, backup: str | os.PathLike[str], *, confirm: bool, current_version: str) -> dict[str, Any]:
        if confirm is not True:
            raise RecoveryError("restore requires explicit confirmation")
        manifest = self.validate(backup)
        safety = self.create(reason="automatic pre-restore safety backup", version=current_version)
        path = Path(backup).expanduser().resolve()
        restored: list[str] = []
        with zipfile.ZipFile(path, "r") as zf:
            for entry in manifest.get("files", []):
                rel = str(entry["path"])
                target = (self.state_dir / rel).resolve()
                try:
                    target.relative_to(self.state_dir)
                except ValueError as exc:
                    raise RecoveryError("backup path escapes state directory") from exc
                target.parent.mkdir(parents=True, exist_ok=True)
                data = zf.read(f"state/{rel}")
                fd, tmp = tempfile.mkstemp(prefix=".restore-", dir=str(target.parent))
                try:
                    with os.fdopen(fd, "wb") as handle:
                        handle.write(data)
                        handle.flush()
                        os.fsync(handle.fileno())
                    os.replace(tmp, target)
                finally:
                    if os.path.exists(tmp):
                        os.unlink(tmp)
                restored.append(rel)
        return {
            "restored": True,
            "overlay_restore": True,
            "restored_files": restored,
            "source_backup": str(path),
            "safety_backup": safety["path"],
            "note": "Files not present in the backup were not deleted.",
        }


@dataclass
class RecoverySession:
    state_dir: Path
    version: str
    heartbeat_interval: float = 5.0

    def __post_init__(self) -> None:
        self.state_dir = Path(self.state_dir).expanduser().resolve()
        self.marker = self.state_dir / "recovery-session.json"
        self.history = self.state_dir / "recovery-history.jsonl"
        self.heartbeat = self.state_dir / "liveness.json"
        self.session_id: Optional[str] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.recovered_previous_crash = False

    def _append_history(self, payload: dict[str, Any]) -> None:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        line = json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n"
        with self.history.open("a", encoding="utf-8") as handle:
            handle.write(line)
            handle.flush()
            os.fsync(handle.fileno())

    def _archive_unclean_if_present(self) -> None:
        if not self.marker.exists():
            return
        try:
            previous = json.loads(self.marker.read_text(encoding="utf-8"))
        except Exception:
            previous = {"invalid_marker": True}
        previous.update({"event": "UNCLEAN_SHUTDOWN_DETECTED", "detected_at": _now()})
        self._append_history(previous)
        self.recovered_previous_crash = True

    def _write_heartbeat(self) -> None:
        if not self.session_id:
            return
        _atomic_json(self.heartbeat, {
            "session_id": self.session_id,
            "pid": os.getpid(),
            "version": self.version,
            "updated_at": _now(),
        })

    def _beat(self) -> None:
        while not self._stop.wait(self.heartbeat_interval):
            try:
                self._write_heartbeat()
            except Exception:
                # Liveness telemetry must never crash the product.
                pass

    def start(self) -> dict[str, Any]:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self._archive_unclean_if_present()
        self.session_id = f"session-{uuid.uuid4().hex}"
        payload = {
            "session_id": self.session_id,
            "pid": os.getpid(),
            "version": self.version,
            "started_at": _now(),
            "clean_shutdown": False,
        }
        _atomic_json(self.marker, payload)
        self._write_heartbeat()
        self._stop.clear()
        self._thread = threading.Thread(target=self._beat, name="rabidanti-liveness", daemon=True)
        self._thread.start()
        self._append_history({**payload, "event": "SESSION_STARTED", "recovered_previous_crash": self.recovered_previous_crash})
        return payload

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=max(1.0, self.heartbeat_interval + 0.5))
        if self.session_id:
            self._append_history({
                "event": "CLEAN_SHUTDOWN",
                "session_id": self.session_id,
                "pid": os.getpid(),
                "version": self.version,
                "stopped_at": _now(),
                "clean_shutdown": True,
            })
        try:
            current = json.loads(self.marker.read_text(encoding="utf-8")) if self.marker.exists() else {}
            if current.get("session_id") == self.session_id:
                self.marker.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            beat = json.loads(self.heartbeat.read_text(encoding="utf-8")) if self.heartbeat.exists() else {}
            if beat.get("session_id") == self.session_id:
                self.heartbeat.unlink(missing_ok=True)
        except Exception:
            pass
        self.session_id = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.stop()
        return False

    @staticmethod
    def status(state_dir: str | os.PathLike[str], *, stale_after: float = 30.0) -> dict[str, Any]:
        root = Path(state_dir).expanduser().resolve()
        marker = root / "recovery-session.json"
        heartbeat = root / "liveness.json"
        active = None
        beat = None
        try:
            active = json.loads(marker.read_text(encoding="utf-8")) if marker.exists() else None
        except Exception:
            active = {"invalid": True}
        try:
            beat = json.loads(heartbeat.read_text(encoding="utf-8")) if heartbeat.exists() else None
        except Exception:
            beat = {"invalid": True}
        age = None
        stale = False
        if isinstance(beat, dict) and isinstance(beat.get("updated_at"), (int, float)):
            age = max(0.0, _now() - float(beat["updated_at"]))
            stale = age > stale_after
        return {
            "active_session": active,
            "heartbeat": beat,
            "heartbeat_age_seconds": age,
            "heartbeat_stale": stale,
            "automatic_restart": False,
            "external_action_authorized": False,
        }


class OfflineUpdateManager:
    """Validate and stage offline release ZIPs. Never applies them automatically."""

    def __init__(self, state_dir: str | os.PathLike[str], *, current_version: str) -> None:
        self.state_dir = Path(state_dir).expanduser().resolve()
        self.current_version = current_version
        self.updates_dir = self.state_dir / "updates"
        self.backups = StateBackupManager(self.state_dir)

    def inspect(self, package: str | os.PathLike[str], *, expected_sha256: str) -> dict[str, Any]:
        path = Path(package).expanduser().resolve()
        if not path.is_file():
            raise UpdateValidationError("update package does not exist")
        expected = expected_sha256.strip().lower()
        if len(expected) != 64 or any(ch not in "0123456789abcdef" for ch in expected):
            raise UpdateValidationError("expected SHA-256 must be 64 hexadecimal characters")
        actual = sha256_file(path)
        if actual != expected:
            raise UpdateValidationError("update package SHA-256 mismatch")
        try:
            with zipfile.ZipFile(path, "r") as zf:
                if zf.testzip():
                    raise UpdateValidationError("update ZIP failed integrity check")
                names = zf.namelist()
                if any(not _safe_zip_name(n) for n in names):
                    raise UpdateValidationError("unsafe path found in update ZIP")
                version_members = [n for n in names if PurePosixPath(n).name == "VERSION"]
                if len(version_members) != 1:
                    raise UpdateValidationError("update package must contain exactly one VERSION file")
                target = zf.read(version_members[0]).decode("utf-8").strip()
        except zipfile.BadZipFile as exc:
            raise UpdateValidationError("update package is not a valid ZIP") from exc
        current_t = _semver_tuple(self.current_version)
        target_t = _semver_tuple(target)
        if target_t <= current_t:
            raise UpdateValidationError("update version must be newer than the current version")
        root = PurePosixPath(version_members[0]).parent.as_posix()
        return {
            "valid": True,
            "package": str(path),
            "sha256": actual,
            "current_version": self.current_version,
            "target_version": target,
            "package_root": root,
            "installation_authorized": False,
            "automatic_apply": False,
        }

    def stage(self, package: str | os.PathLike[str], *, expected_sha256: str, actor: str, reason: str) -> dict[str, Any]:
        if not actor.strip() or not reason.strip():
            raise UpdateValidationError("actor and reason are required")
        inspected = self.inspect(package, expected_sha256=expected_sha256)
        backup = self.backups.create(reason=f"pre-update backup: {reason.strip()}", version=self.current_version)
        target_dir = self.updates_dir / "staged" / inspected["target_version"]
        target_dir.mkdir(parents=True, exist_ok=True)
        staged = target_dir / "package.zip"
        shutil.copy2(inspected["package"], staged)
        if sha256_file(staged) != inspected["sha256"]:
            raise UpdateValidationError("staged package hash changed after copy")
        plan = {
            "format": "rabidanti-offline-update-plan-v1",
            "created_at": _now(),
            "actor": actor.strip(),
            "reason": reason.strip(),
            "current_version": self.current_version,
            "target_version": inspected["target_version"],
            "package": str(staged),
            "package_sha256": inspected["sha256"],
            "backup": backup["path"],
            "backup_sha256": backup["sha256"],
            "installation_authorized": False,
            "automatic_apply": False,
            "requires_external_installer": True,
        }
        _atomic_json(target_dir / "update-plan.json", plan)
        return plan

    def staged(self) -> list[dict[str, Any]]:
        root = self.updates_dir / "staged"
        if not root.exists():
            return []
        rows: list[dict[str, Any]] = []
        for plan in sorted(root.glob("*/update-plan.json"), reverse=True):
            try:
                rows.append(json.loads(plan.read_text(encoding="utf-8")))
            except Exception:
                rows.append({"plan": str(plan), "valid": False})
        return rows

    def apply(self, *_args, **_kwargs):
        raise RecoveryError(
            "in-process self-update is intentionally disabled; use a validated external installer"
        )

class StateSchemaManager:
    """Version the persistent-state layout without silently mutating user data."""

    SUPPORTED_SCHEMA = 1

    def __init__(self, state_dir: str | os.PathLike[str], *, app_version: str) -> None:
        self.state_dir = Path(state_dir).expanduser().resolve()
        self.path = self.state_dir / "state-schema.json"
        self.app_version = app_version
        self.backups = StateBackupManager(self.state_dir)

    def current(self) -> int:
        if not self.path.exists():
            return 0
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            value = int(raw.get("schema_version", 0))
        except Exception as exc:
            raise RecoveryError("invalid state schema metadata") from exc
        if value < 0:
            raise RecoveryError("invalid negative state schema")
        return value

    def status(self) -> dict[str, Any]:
        current = self.current()
        return {
            "current_schema": current,
            "supported_schema": self.SUPPORTED_SCHEMA,
            "migration_required": current < self.SUPPORTED_SCHEMA,
            "future_schema": current > self.SUPPORTED_SCHEMA,
            "automatic_migration": False,
        }

    def migrate(self, *, confirm: bool) -> dict[str, Any]:
        if confirm is not True:
            raise RecoveryError("state migration requires explicit confirmation")
        current = self.current()
        if current > self.SUPPORTED_SCHEMA:
            raise RecoveryError("state schema is newer than this Rabidanti version")
        if current == self.SUPPORTED_SCHEMA:
            return {**self.status(), "changed": False, "backup": None}
        backup = self.backups.create(reason=f"pre-migration schema {current}->{self.SUPPORTED_SCHEMA}", version=self.app_version)
        payload = {
            "format": "rabidanti-state-schema-v1",
            "schema_version": self.SUPPORTED_SCHEMA,
            "migrated_from": current,
            "app_version": self.app_version,
            "migrated_at": _now(),
            "backup": backup["path"],
            "rollback_requires_explicit_restore": True,
        }
        _atomic_json(self.path, payload)
        return {**payload, "changed": True}
