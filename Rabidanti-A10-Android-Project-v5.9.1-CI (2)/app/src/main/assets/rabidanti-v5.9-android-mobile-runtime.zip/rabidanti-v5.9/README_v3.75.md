# Rabidanti v3.75 — Signal → Evolution Runtime Bridge

Connects signal-derived assessments to the Evolution Runtime.

Flow:
signal -> proposal/assessment -> runtime -> decision -> gate -> audit

The bridge validates identifiers and prevents duplicate signal processing.
It cannot activate strategies or modify the Core.
