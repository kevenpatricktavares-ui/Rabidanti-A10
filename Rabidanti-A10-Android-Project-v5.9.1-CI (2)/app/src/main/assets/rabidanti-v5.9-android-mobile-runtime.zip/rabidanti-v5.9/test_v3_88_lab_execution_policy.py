import pytest
from lab_execution_policy import LabExecutionPolicy

def test_unknown_profile_rejected():
    with pytest.raises(ValueError): LabExecutionPolicy.assess("anything")

def test_untrusted_profile_fails_closed_without_controls():
    a = LabExecutionPolicy.assess("untrusted_code")
    assert not a.safe_for_untrusted_code
    assert "network_isolation" in a.missing_controls
    with pytest.raises(PermissionError): LabExecutionPolicy.require_profile("untrusted_code")

def test_trusted_profile_assessment_is_explicit():
    a = LabExecutionPolicy.assess("trusted_smoke")
    assert a.profile == "trusted_smoke"
    assert a.digest and a.assessed_at

def test_complete_declared_controls_pass_policy_gate():
    controls = LabExecutionPolicy.PROFILES["untrusted_code"]
    a = LabExecutionPolicy.assess("untrusted_code", controls)
    assert a.safe_for_untrusted_code and not a.missing_controls

def test_json_report_contains_security_boundary():
    import json
    a = LabExecutionPolicy.assess()
    assert json.loads(LabExecutionPolicy.to_json(a))["profile"] == "trusted_smoke"

def test_invalid_control_names_rejected():
    with pytest.raises(ValueError): LabExecutionPolicy.assess(declared_controls=[None])
