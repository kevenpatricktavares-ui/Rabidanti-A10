"""Rabidanti v3.47 — World Awareness to Laboratory integration.

Turns persisted world signals into traceable laboratory investigations. No
external fetching is performed here; provenance from World Awareness is kept
with every laboratory evidence record.
"""
from __future__ import annotations
from typing import Any

from world_awareness import WorldAwareness
from laboratory import LaboratoryEngine
from laboratory_intelligence import LaboratoryIntelligence


class WorldLaboratoryBridge:
    def __init__(self, world: WorldAwareness, laboratory: LaboratoryEngine,
                 intelligence: LaboratoryIntelligence):
        self.world = world
        self.laboratory = laboratory
        self.intelligence = intelligence

    def create_investigation_from_signal(self, signal_id: str, *,
                                         title: str | None = None,
                                         hypothesis: str | None = None):
        signals = self.world.store.signals(limit=10000)
        signal = next((s for s in signals if s.signal_id == signal_id), None)
        if signal is None:
            raise KeyError(f'world signal not found: {signal_id}')
        source = self.world.store.source(signal.source_id)
        if source is None:
            raise KeyError(f'world source not found: {signal.source_id}')

        lab_title = title.strip() if title and title.strip() else f'Investigation: {signal.topic}'
        lab_hypothesis = (hypothesis.strip() if hypothesis and hypothesis.strip()
                          else f'The signal may represent a meaningful development in {signal.topic}.')
        project = self.laboratory.create(
            lab_title, signal.statement, signal.topic, lab_hypothesis
        )
        evidence = [{
            'source': source.publisher,
            'kind': source.kind,
            'locator': source.locator,
            'summary': source.summary,
            'verified': source.verified,
            'world_signal_id': signal.signal_id,
            'world_source_id': source.source_id,
            'confidence': signal.confidence,
            'freshness': signal.freshness,
        }]
        project = self.laboratory.investigate(project.lab_id, evidence=evidence,
                                               findings=[signal.statement])
        self.intelligence.ingest_signal(
            project.lab_id, signal.statement, domain=signal.topic,
            sources=[evidence[0]]
        )
        return project

    def create_investigations_from_topic(self, topic: str, *, limit: int = 10) -> list:
        if not topic or not topic.strip():
            raise ValueError('topic is required')
        if limit < 1 or limit > 100:
            raise ValueError('limit must be between 1 and 100')
        signals = self.world.store.signals(topic.strip(), limit)
        return [self.create_investigation_from_signal(s.signal_id) for s in signals]

    def snapshot(self, lab_id: str) -> dict[str, Any]:
        snap = self.intelligence.research_snapshot(lab_id)
        world_refs = []
        for item in snap['signals']:
            # Intelligence signals preserve source references in their count only;
            # the laboratory project's evidence carries the authoritative provenance.
            pass
        project = self.laboratory.store.get(lab_id)
        if project is None:
            raise KeyError(f'lab project not found: {lab_id}')
        for evidence in project.evidence:
            if evidence.get('world_signal_id') or evidence.get('world_source_id'):
                world_refs.append({
                    'world_signal_id': evidence.get('world_signal_id'),
                    'world_source_id': evidence.get('world_source_id'),
                    'verified': bool(evidence.get('verified')),
                    'confidence': evidence.get('confidence'),
                    'freshness': evidence.get('freshness'),
                })
        snap['world_provenance'] = world_refs
        return snap
