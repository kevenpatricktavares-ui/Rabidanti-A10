# Rabidanti v3.78 — Evolution Pattern Memory

Adds bounded temporal memory for signal correlations. Repeated observations
can be classified as rising, falling, stable, or lacking sufficient history.

This layer records evidence and trends only. It cannot activate strategies,
deploy changes, modify Core, or bypass approval.
