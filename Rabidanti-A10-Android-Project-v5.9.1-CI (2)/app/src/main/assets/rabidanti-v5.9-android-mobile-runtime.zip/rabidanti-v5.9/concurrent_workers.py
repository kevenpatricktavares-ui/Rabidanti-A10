from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass

@dataclass
class PoolResult:
    worker_id: str
    job_id: str | None
    completed: bool
    error: str | None = None

class ConcurrentWorkerPool:
    def __init__(self, worker_factory, worker_count=1):
        if int(worker_count) < 1:
            raise ValueError("worker_count must be >= 1")
        self.worker_factory=worker_factory
        self.worker_count=int(worker_count)

    def run(self, worker_ids=None):
        ids=list(worker_ids) if worker_ids is not None else [
            f"worker-{i+1}" for i in range(self.worker_count)
        ]
        ids=ids[:self.worker_count]
        def execute(wid):
            try:
                result=self.worker_factory(wid).process_one()
                return PoolResult(wid,getattr(result,"job_id",None),True)
            except Exception as exc:
                return PoolResult(wid,None,False,str(exc))
        with ThreadPoolExecutor(max_workers=self.worker_count) as pool:
            futures=[pool.submit(execute,wid) for wid in ids]
            return [f.result() for f in as_completed(futures)]
