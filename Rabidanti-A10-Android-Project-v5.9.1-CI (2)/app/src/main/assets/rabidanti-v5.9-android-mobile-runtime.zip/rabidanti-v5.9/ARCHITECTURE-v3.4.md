# Rabidanti v3.4 — Durable Execution & Lease Recovery

v3.4 adds the execution-coordination primitives required for long-running
workers: exclusive claims, time-bounded leases, crash/timeout recovery,
approval gating, ownership checks, and retry limits.

The existing SQLite persistence remains the durable source of truth in the
v3.x application. This release does not claim a distributed external queue,
autoscaling, or cloud deployment.
