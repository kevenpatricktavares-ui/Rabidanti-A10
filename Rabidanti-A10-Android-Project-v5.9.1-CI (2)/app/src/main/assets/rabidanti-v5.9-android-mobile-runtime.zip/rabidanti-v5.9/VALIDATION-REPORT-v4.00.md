# Rabidanti v4.0 Validation Report

## Scope

Version: `4.0.0` — Unified Local Runtime MVP.

Baseline input: Rabidanti v3.99 Controlled Change Executor.

Baseline ZIP SHA-256:
`55f396c6b1f365357987a232a25b4c87bda146e9311a7634f3cc6ee99f062e12`

## Baseline verification

Before v4.0 changes, the received v3.99 package was extracted and tested.

Result: **494 passed / 0 failed**.

## Implemented in v4.0

- `RabidantiRuntime` unified local lifecycle.
- One selected persistent state directory for queue, workflows, tasks, scheduler, workers, laboratory, evidence, reviews, proposals, controlled changes and runtime audit events.
- Startup recovery of persisted RUNNING autonomous tasks and expired queue leases.
- Unified runtime status snapshot.
- Local diagnostic (`doctor`) with SQLite/state/Python checks and explicit container-runtime limitation reporting.
- Persistent runtime audit events.
- CLI entry point `rabidanti.py`.
- Interactive shell.
- Persistent task add/list through the executable CLI.
- Evidence search through the unified runtime.
- Windows and POSIX launch helpers.
- Existing v3.96–v3.99 governance and authorization boundaries remain in force.

## New tests

12 new v4.0 runtime tests cover:

- subsystem initialization;
- lifecycle idempotence;
- task persistence across restart;
- startup recovery;
- status aggregation;
- evidence access;
- persistent audit events;
- honest Docker/Podman diagnostic;
- blocked self-authorization/external authorization;
- real CLI status execution;
- CLI task persistence;
- interactive shell start/exit.

Specific v4.0 tests: **12 passed / 0 failed**.

## Full regression

Full suite after implementation: **506 passed / 0 failed**.

`python -m compileall -q .`: **PASS**.

## Environment limitation

Neither Docker nor Podman is available in the validation environment. Therefore OS-level container isolation is **not validated** here. The program reports this limitation rather than treating it as a runtime failure.

## Product status

v4.0 is a **functional local Python Runtime MVP**. It is not yet the final standalone product. A desktop UI, local service/API, packaged Windows executable, real external connectors/credentials and validated remote 24/7 operation remain future milestones.

## Distributed-package verification

The final ZIP was integrity-tested, extracted into a clean directory and the full suite was executed from the extracted package.

Result from extracted package: **506 passed / 0 failed**.

The executable CLI was also started from the extracted package and returned `program=Rabidanti`, `version=4.0.0`, `runtime_state=RUNNING` with safety flags disabled by default.
