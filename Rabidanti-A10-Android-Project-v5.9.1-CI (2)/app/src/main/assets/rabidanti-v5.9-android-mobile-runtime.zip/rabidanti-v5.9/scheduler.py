from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Callable, Dict, Optional

@dataclass(order=True)
class ScheduledTask:
    run_at: datetime
    task_id: str = field(compare=False)
    interval_seconds: Optional[int] = field(default=None, compare=False)
    enabled: bool = field(default=True, compare=False)
    runs: int = field(default=0, compare=False)

class Scheduler:
    def __init__(self, clock: Callable[[], datetime] | None = None):
        self.clock=clock or (lambda: datetime.now(timezone.utc))
        self.tasks: Dict[str,ScheduledTask]={}
        self.lock=Lock()

    def add(self, task_id, run_at, interval_seconds=None):
        if interval_seconds is not None and interval_seconds < 1:
            raise ValueError("interval_seconds must be >= 1")
        with self.lock:
            if task_id in self.tasks:
                raise ValueError("task already exists")
            self.tasks[task_id]=ScheduledTask(run_at,task_id,interval_seconds)

    def cancel(self, task_id):
        with self.lock:
            self.tasks[task_id].enabled=False

    def due(self, now=None):
        now=now or self.clock()
        with self.lock:
            return [t for t in self.tasks.values() if t.enabled and t.run_at <= now]

    def acknowledge(self, task_id, now=None):
        now=now or self.clock()
        with self.lock:
            t=self.tasks[task_id]
            t.runs += 1
            if t.interval_seconds is None:
                t.enabled=False
            else:
                t.run_at=now+timedelta(seconds=t.interval_seconds)

class SchedulerLoop:
    def __init__(self, scheduler, enqueue: Callable[[str], object]):
        self.scheduler=scheduler
        self.enqueue=enqueue

    def tick(self, now=None):
        due=list(self.scheduler.due(now))
        queued=[]
        for task in due:
            queued.append(self.enqueue(task.task_id))
            self.scheduler.acknowledge(task.task_id, now)
        return queued
