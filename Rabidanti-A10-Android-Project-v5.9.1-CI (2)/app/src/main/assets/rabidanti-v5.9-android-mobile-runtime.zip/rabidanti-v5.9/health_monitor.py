"""Rabidanti v3.17 — Health monitoring and conservative anomaly detection."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional
import time

from observability import ObservabilityStore
from worker_supervisor import WorkerSupervisor


@dataclass(frozen=True)
class HealthAlert:
    kind: str
    severity: str
    message: str
    timestamp: float
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class HealthReport:
    healthy: bool
    score: float
    alerts: list[HealthAlert]
    metrics: dict[str, float]
    worker_health: dict[str, Any]


class HealthMonitor:
    """Interpret persisted telemetry without taking destructive actions."""

    def __init__(self, observability: ObservabilityStore, supervisor: Optional[WorkerSupervisor] = None,
                 failure_window: int = 20, failure_rate_threshold: float = 0.5,
                 stale_is_critical: bool = True):
        if failure_window < 1:
            raise ValueError("failure_window must be >= 1")
        if not 0 <= failure_rate_threshold <= 1:
            raise ValueError("failure_rate_threshold must be between 0 and 1")
        self.observability = observability
        self.supervisor = supervisor
        self.failure_window = int(failure_window)
        self.failure_rate_threshold = float(failure_rate_threshold)
        self.stale_is_critical = bool(stale_is_critical)

    def analyze(self, now: Optional[float] = None) -> HealthReport:
        now = time.time() if now is None else float(now)
        alerts: list[HealthAlert] = []
        events = self.observability.recent_events(limit=self.failure_window)
        failed = sum(1 for e in events if e.kind == "job_failed")
        completed = sum(1 for e in events if e.kind == "job_completed")
        terminal = failed + completed
        failure_rate = (failed / terminal) if terminal else 0.0
        metrics = {"recent_failed": float(failed), "recent_completed": float(completed),
                   "recent_terminal": float(terminal), "recent_failure_rate": failure_rate}

        if terminal and failure_rate >= self.failure_rate_threshold:
            alerts.append(HealthAlert("HIGH_FAILURE_RATE", "CRITICAL" if failure_rate >= 0.75 else "WARNING",
                                      "Recent job failure rate is above the configured threshold.", now,
                                      {"failure_rate": failure_rate, "threshold": self.failure_rate_threshold,
                                       "window": self.failure_window}))

        worker_health: dict[str, Any] = {"available": False}
        if self.supervisor is not None:
            worker_health = self.supervisor.health_snapshot(now=now)
            stale = worker_health.get("stale_worker_ids", [])
            if stale:
                alerts.append(HealthAlert("STALE_WORKERS", "CRITICAL" if self.stale_is_critical else "WARNING",
                                          "One or more workers are stale.", now, {"worker_ids": stale}))

        score = 100.0
        for alert in alerts:
            score -= 45.0 if alert.severity == "CRITICAL" else 20.0
        score = max(0.0, min(100.0, score))
        return HealthReport(not alerts, score, alerts, metrics, worker_health)

    def check_and_record(self, now: Optional[float] = None) -> HealthReport:
        report = self.analyze(now=now)
        for alert in report.alerts:
            self.observability.event("health_alert", detail=f"{alert.kind}:{alert.severity}:{alert.message}")
        self.observability.metric("health.score", report.score)
        self.observability.metric("health.alert_count", len(report.alerts))
        return report
