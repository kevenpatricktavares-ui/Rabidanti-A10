# Rabidanti v5.8 — Observability & Diagnostics Architecture

## Goal

Provide one operational picture of Rabidanti without creating a second control plane or granting new authority.

## Data flow

```text
Runtime state / Doctor / Workers / Queue / Recovery / Model / Providers / Connectors / Events
                                      |
                                      v
                         OperationalObservability
                                      |
                           read-only normalized snapshot
                           /                    \
                     CLI `observe`       GET /v1/observability
                                                |
                                                v
                                           Sala / Operações
```

## Source of truth

The observability layer does not duplicate operational state. It reads existing runtime stores and APIs and normalizes them for display.

## Alert model

Each alert contains:

- `severity`: `WARNING` or `CRITICAL`;
- stable `code`;
- human-readable title;
- detail.

The overall state is the maximum severity present. No alert has an embedded executable remediation instruction.

## Read-only guarantee

The v5.8 layer has no connector invocation path, no Permission Gate approval path, no task creation path, and no Core integration path. It exposes only a GET API endpoint plus a read-only CLI command.

Existing worker health classification may mark workers stale through the pre-existing WorkerSupervisor health mechanism; v5.8 itself adds no remediation or execution behavior.

## Product self-test

The dashboard advertises that the v5.7 isolated product self-test is available, but does not run it automatically. The existing CLI remains:

```bash
python rabidanti.py --state-dir .rabidanti product self-test
```

## External connectivity

Observability does not prove Gmail/OAuth or Ollama connectivity. When such providers are unavailable, the dashboard reports that condition rather than masking it.
