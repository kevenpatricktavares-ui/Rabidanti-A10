# Rabidanti v2.6 — Connector Core

## Purpose
Provide a universal boundary between Rabidanti intelligence and external systems.

## Connector contract
id, name, provider, state, permissions, connect, disconnect, health,
capabilities, authorize.

## Permissions
READ, CREATE, UPDATE, PUBLISH, DELETE, SPEND.

## Security rule
PUBLISH, DELETE and SPEND always require explicit approval at the authorization
boundary. A connector being connected never implies permission to perform them.

## Separation of concerns
Agent = intelligence
Connector = external capability
Approval = authorization
Audit = accountability

## Current limitation
This release contains the connector framework and demo lifecycle only. It does
not claim access to any real external provider.
