# Rabidanti v3.69 — Core Evolution Integration

Integrates the v3.68 Evolution Controller with a Core/Orchestrator-facing adapter.

## Guarantees
- Core can register evolution proposals and advance controlled lifecycle stages.
- Experiments and promotions remain explicit lifecycle stages.
- Activation remains blocked unless the record is `ACTIVATION_PENDING` and explicit approval is supplied.
- Rollback remains blocked unless the record is `ROLLBACK_RECOMMENDED` and explicit approval is supplied.
- Promotion never implicitly activates a strategy.
- Lifecycle history remains owned by `EvolutionController`.
- This integration does not deploy code, alter production weights, bypass queue ownership, or perform unbounded self-modification.

## Validation
`pytest -q` validates the inherited v3.68 suite plus v3.69 Core integration tests.
