"""Rabidanti v3.44 — Laboratory foundation.

Persistent, evidence-first scientific/technological exploration.  The Lab never
promotes an idea to a discovery merely because it sounds novel: discovery
requires explicit novelty, relevance, testing and reproducibility/validation.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping, Optional
import json, sqlite3, threading, time, uuid

STATES = ("IDEIA", "INVESTIGAÇÃO", "EXPERIMENTO", "RESULTADO_VALIDADO", "DESCOBERTA")
ALERT_PRIORITY = "MAXIMUM"

@dataclass(frozen=True)
class Evidence:
    source: str
    kind: str = "unknown"
    locator: str = ""
    summary: str = ""
    verified: bool = False
    def to_dict(self): return asdict(self)

@dataclass(frozen=True)
class LabProject:
    lab_id: str
    title: str
    question: str
    domain: str
    status: str
    hypothesis: str
    evidence: tuple[Mapping[str, Any], ...]
    findings: tuple[str, ...]
    novelty: Optional[bool]
    relevance: Optional[bool]
    tested: bool
    reproducible: bool
    confidence: Optional[float]
    limitations: tuple[str, ...]
    created_at: float
    updated_at: float
    def to_dict(self): return asdict(self)

class LaboratoryStore:
    def __init__(self, db_path: str):
        self.db_path=db_path; self._lock=threading.RLock()
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory=sqlite3.Row
        if db_path != ':memory:': self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS lab_projects (
            lab_id TEXT PRIMARY KEY, title TEXT NOT NULL, question TEXT NOT NULL,
            domain TEXT NOT NULL, status TEXT NOT NULL, hypothesis TEXT NOT NULL,
            evidence_json TEXT NOT NULL, findings_json TEXT NOT NULL,
            novelty INTEGER, relevance INTEGER, tested INTEGER NOT NULL,
            reproducible INTEGER NOT NULL, confidence REAL, limitations_json TEXT NOT NULL,
            created_at REAL NOT NULL, updated_at REAL NOT NULL)''')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS lab_alerts (
            alert_id TEXT PRIMARY KEY, lab_id TEXT NOT NULL, priority TEXT NOT NULL,
            acknowledged INTEGER NOT NULL DEFAULT 0, payload_json TEXT NOT NULL,
            created_at REAL NOT NULL, acknowledged_at REAL)''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_lab_alerts_open ON lab_alerts(acknowledged, created_at)')

    def save(self, p: LabProject) -> None:
        with self._lock:
            self._conn.execute('''INSERT INTO lab_projects VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(lab_id) DO UPDATE SET title=excluded.title,question=excluded.question,
            domain=excluded.domain,status=excluded.status,hypothesis=excluded.hypothesis,
            evidence_json=excluded.evidence_json,findings_json=excluded.findings_json,
            novelty=excluded.novelty,relevance=excluded.relevance,tested=excluded.tested,
            reproducible=excluded.reproducible,confidence=excluded.confidence,
            limitations_json=excluded.limitations_json,updated_at=excluded.updated_at''',
            (p.lab_id,p.title,p.question,p.domain,p.status,p.hypothesis,json.dumps(list(p.evidence),ensure_ascii=False),
             json.dumps(list(p.findings),ensure_ascii=False),None if p.novelty is None else int(p.novelty),
             None if p.relevance is None else int(p.relevance),int(p.tested),int(p.reproducible),p.confidence,
             json.dumps(list(p.limitations),ensure_ascii=False),p.created_at,p.updated_at))

    def get(self, lab_id: str) -> Optional[LabProject]:
        with self._lock: r=self._conn.execute('SELECT * FROM lab_projects WHERE lab_id=?',(lab_id,)).fetchone()
        if not r: return None
        return self._row(r)

    def list(self) -> list[LabProject]:
        with self._lock: rows=self._conn.execute('SELECT * FROM lab_projects ORDER BY updated_at DESC').fetchall()
        return [self._row(r) for r in rows]

    def alert(self, lab_id: str, payload: Mapping[str, Any]) -> str:
        aid='alert-'+uuid.uuid4().hex
        with self._lock: self._conn.execute('INSERT INTO lab_alerts VALUES(?,?,?,?,?,?,?)',(aid,lab_id,ALERT_PRIORITY,0,json.dumps(dict(payload),ensure_ascii=False),time.time(),None))
        return aid

    def open_alerts(self) -> list[dict[str,Any]]:
        with self._lock: rows=self._conn.execute('SELECT * FROM lab_alerts WHERE acknowledged=0 ORDER BY created_at').fetchall()
        return [dict(r) | {'payload':json.loads(r['payload_json'])} for r in rows]

    def acknowledge_alert(self, alert_id: str) -> bool:
        with self._lock:
            cur=self._conn.execute('UPDATE lab_alerts SET acknowledged=1,acknowledged_at=? WHERE alert_id=? AND acknowledged=0',(time.time(),alert_id))
        return cur.rowcount==1

    @staticmethod
    def _row(r):
        return LabProject(r['lab_id'],r['title'],r['question'],r['domain'],r['status'],r['hypothesis'],
            tuple(json.loads(r['evidence_json'])),tuple(json.loads(r['findings_json'])),
            None if r['novelty'] is None else bool(r['novelty']),None if r['relevance'] is None else bool(r['relevance']),
            bool(r['tested']),bool(r['reproducible']),r['confidence'],tuple(json.loads(r['limitations_json'])),r['created_at'],r['updated_at'])

class LaboratoryEngine:
    def __init__(self, store: LaboratoryStore): self.store=store

    def create(self, title: str, question: str, domain: str, hypothesis: str, lab_id: str|None=None) -> LabProject:
        if not all(str(x).strip() for x in (title,question,domain,hypothesis)): raise ValueError('title, question, domain and hypothesis are required')
        now=time.time(); lid=lab_id or 'lab-'+uuid.uuid4().hex
        p=LabProject(lid,title.strip(),question.strip(),domain.strip(),'IDEIA',hypothesis.strip(),(),(),None,None,False,False,None,('No validated evidence yet.',),now,now)
        self.store.save(p); return p

    def investigate(self, lab_id: str, evidence: list[Mapping[str,Any]]|None=None, findings: list[str]|None=None) -> LabProject:
        p=self._require(lab_id); ev=tuple(dict(x) for x in (evidence or p.evidence)); fd=tuple(str(x) for x in (findings or p.findings) if str(x).strip())
        status='INVESTIGAÇÃO' if not p.tested else p.status
        updated=LabProject(p.lab_id,p.title,p.question,p.domain,status,p.hypothesis,ev,fd,p.novelty,p.relevance,p.tested,p.reproducible,p.confidence,p.limitations,p.created_at,time.time())
        self.store.save(updated); return updated

    def record_experiment(self, lab_id: str, *, findings: list[str], tested: bool, reproducible: bool,
                          novelty: bool|None=None, relevance: bool|None=None, confidence: float|None=None,
                          limitations: list[str]|None=None) -> LabProject:
        p=self._require(lab_id)
        if confidence is not None and not 0 <= float(confidence) <= 1: raise ValueError('confidence must be between 0 and 1')
        if not tested and reproducible: raise ValueError('reproducible cannot be true when tested is false')
        status='RESULTADO_VALIDADO' if (tested and reproducible) else ('EXPERIMENTO' if tested else 'INVESTIGAÇÃO')
        valid = bool(tested and reproducible and novelty is True and relevance is True)
        lim=tuple(str(x) for x in (limitations or p.limitations) if str(x).strip())
        if not valid and 'Discovery criteria not satisfied.' not in lim: lim=lim+('Discovery criteria not satisfied.',)
        now=time.time(); q=LabProject(p.lab_id,p.title,p.question,p.domain,status,p.hypothesis,p.evidence,tuple(findings),novelty,relevance,tested,reproducible,confidence,lim,p.created_at,now)
        self.store.save(q)
        if valid:
            discovery=LabProject(q.lab_id,q.title,q.question,q.domain,'DESCOBERTA',q.hypothesis,q.evidence,q.findings,q.novelty,q.relevance,q.tested,q.reproducible,q.confidence,q.limitations,q.created_at,now)
            self.store.save(discovery)
            self.store.alert(q.lab_id, {'type':'ALERTA_DE_DESCOBERTA','lab_id':q.lab_id,'title':q.title,'evidence':list(q.evidence),'findings':list(q.findings),'confidence':q.confidence,'implications':'Requires human review before external exploitation or core integration.'})
            return discovery
        return q

    def _require(self, lab_id):
        p=self.store.get(lab_id)
        if p is None: raise KeyError(f'lab project not found: {lab_id}')
        return p
