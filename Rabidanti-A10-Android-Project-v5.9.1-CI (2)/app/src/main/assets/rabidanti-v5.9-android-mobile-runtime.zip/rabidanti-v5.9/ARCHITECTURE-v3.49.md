# Rabidanti v3.49 — Opportunity Discovery

World Awareness signals are grouped into evidence-bounded opportunity themes.

Flow:
World Awareness → signal grouping → relatedness → opportunity theme → research/experiment.

The engine only detects repeated/related evidence. It does not infer demand,
willingness-to-pay, competition, feasibility, profitability or validated discovery.
Those require separate research and experimental evidence.
