# Rabidanti v3.98 — Laboratory Integration Proposal Workflow

## Purpose
v3.98 converts a creator-approved laboratory review into a formal integration
proposal without granting execution authority.

## Flow
Experiment → Evidence Memory → Readiness → Human Review `APPROVED` → **Integration Proposal**

## Proposal contract
A proposal is accepted only when it is bound to the exact persisted `APPROVED`
human-review decision and evidence snapshot. It must include:

- title and summary;
- target component;
- repository-relative affected files;
- ordered change plan;
- test/regression plan;
- rollback plan;
- explicit risks;
- asserted creator/author identity.

The canonical proposal body is SHA-256 hashed. Repeating identical content is
idempotent; changing material content creates a new immutable proposal record.
The proposal is also stored as an `ARTIFACT` node in Evidence Memory and linked
to its human-review decision, readiness assessment and experiment.

## Safety boundary
`integration_authorized`, `external_action_authorized`, and
`scientifically_validated` remain false. Paths with absolute locations,
traversal (`..`) or Windows-style separators are rejected. v3.98 has no method
that applies file changes; `apply()` and authorization methods fail closed.

A future controlled executor must independently require explicit integration
authorization, backup/rollback preparation and successful tests before any Core
change can be accepted.
