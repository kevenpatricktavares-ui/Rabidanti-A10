import pytest
from lab_experiment_manager import LabExperimentManager
from lab_result_analyzer import LabResultAnalyzer
from lab_reproducibility import LabReproducibilityAnalyzer

def setup_runs(tmp_path, second_state="PASS", second_executed=True):
    m=LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1","p1","repeat test","hypothesis","method",["criterion A"])
    for rid, state, executed in [("r1","PASS",True),("r2",second_state,second_executed)]:
        m.add_entry("e1",f"{rid}:result","RESULT","completed",{"run_id":rid,"executed":executed})
        m.add_entry("e1",f"{rid}:analysis","RECOMMENDATION","review",{
            "run_id":rid,"classification":"PASSED" if state=="PASS" and executed else ("FAILED" if state=="FAIL" else "BLOCKED"),
            "criteria":{"criterion A":{"state":state,"evidence":"reviewed evidence"}}})
    return m

def test_two_passed_runs_are_consistent_without_integration(tmp_path):
    m=setup_runs(tmp_path); r=LabReproducibilityAnalyzer(m).compare("e1",["r1","r2"],reviewer="operator")
    assert r["classification"]=="CONSISTENT" and r["runs_compared"]==2
    assert r["integration_authorized"] is False and len(r["evidence_digest"])==64

def test_different_criterion_outcomes_are_divergent(tmp_path):
    m=setup_runs(tmp_path, second_state="FAIL")
    # A failed run is not accepted as an all-passed replication set.
    r=LabReproducibilityAnalyzer(m).compare("e1",["r1","r2"],reviewer="operator")
    assert r["classification"]=="DIVERGENT"

def test_unverified_run_blocks_comparison(tmp_path):
    m=setup_runs(tmp_path, second_executed=False)
    r=LabReproducibilityAnalyzer(m).compare("e1",["r1","r2"],reviewer="operator")
    assert r["classification"]=="BLOCKED"

def test_requires_distinct_runs_and_reviewed_reports(tmp_path):
    m=setup_runs(tmp_path); a=LabReproducibilityAnalyzer(m)
    with pytest.raises(ValueError): a.compare("e1",["r1","r1"],reviewer="operator")
    with pytest.raises(ValueError): a.compare("e1",["r1"],reviewer="operator")
    with pytest.raises(ValueError): a.compare("e1",["r1","missing"],reviewer="operator")
    with pytest.raises(ValueError): a.compare("e1",["r1","r2"],reviewer=" ")
