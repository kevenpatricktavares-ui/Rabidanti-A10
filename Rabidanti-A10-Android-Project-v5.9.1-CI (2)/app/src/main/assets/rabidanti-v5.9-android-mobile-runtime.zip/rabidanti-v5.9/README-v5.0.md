# Rabidanti v5.0 — Executable Product Foundation

A v5.0 transforma o runtime v4.9 numa fundação de produto distribuível, sem alterar as fronteiras de autorização do Core.

## Arranque do utilizador

Windows:

```text
START-RABIDANTI.bat
```

Linux/macOS:

```sh
./START-RABIDANTI.sh
```

Launcher Python explícito:

```sh
python rabidanti_launcher.py
```

Sem argumentos, o launcher usa um diretório persistente de dados por utilizador e abre a Sala local.

## Bootstrap sem runtime

```sh
python rabidanti_bootstrap.py doctor
python rabidanti_bootstrap.py setup
python rabidanti_bootstrap.py build-info
```

O bootstrap usa somente a biblioteca padrão e não instala pacotes nem descarrega modelos automaticamente.

## Empacotamento

- `Rabidanti.spec` — especificação PyInstaller;
- `build_windows.bat` — build Windows;
- `build_linux.sh` — build Linux;
- `requirements.txt` — dependências de runtime;
- `requirements-dev.txt` — testes/build.

A geração de um executável nativo continua dependente do PyInstaller estar disponível na máquina de build. A v5.0 não declara um `.exe` Windows validado neste ambiente.

## Segurança

O arranque do produto não concede `external_action_authorized`, não ativa conectores externos e não permite autoautorização. O modelo continua limitado ao fluxo de propostas/revisão/autorização/Permission Gate implementado até v4.9.
