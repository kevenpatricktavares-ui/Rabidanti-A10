@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist "windows-build-handoff.json" (
  echo windows-build-handoff.json missing. Run prepare_windows_build.ps1 first.
  exit /b 3
)

call build_windows.bat || exit /b 1

set "ISCC="
where iscc >nul 2>nul && set "ISCC=iscc"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC (
  echo Inno Setup 6 compiler ^(ISCC.exe^) was not found.
  echo EXE was built, but installer release was NOT validated.
  exit /b 2
)

"%ISCC%" installer_windows.iss || exit /b 1
for /f "usebackq delims=" %%V in ("VERSION") do set "RABIDANTI_VERSION=%%V"
set "SETUP=installer-dist\Rabidanti-Setup-%RABIDANTI_VERSION%.exe"
if not exist "%SETUP%" (echo Installer missing: %SETUP%& exit /b 1)
python rabidanti_release.py postbuild --exe "dist\Rabidanti.exe" --installer "%SETUP%" || exit /b 1
if not exist "release-manifest.json" (echo release-manifest.json missing.& exit /b 1)

powershell -NoProfile -ExecutionPolicy Bypass -File verify_windows_release.ps1 -Exe "dist\Rabidanti.exe" -Installer "%SETUP%" || exit /b 1
if not exist "windows-release-validation.json" (echo windows-release-validation.json missing.& exit /b 1)

echo Native release built and validated end-to-end on Windows.
echo EXE: dist\Rabidanti.exe
echo SETUP: %SETUP%
echo MANIFEST: release-manifest.json
echo WINDOWS VALIDATION: windows-release-validation.json
endlocal
