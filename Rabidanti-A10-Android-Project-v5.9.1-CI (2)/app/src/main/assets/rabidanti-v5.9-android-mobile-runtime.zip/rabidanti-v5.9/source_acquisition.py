"""Rabidanti v3.53 — controlled external source acquisition.

Fetches public HTTP(S) sources with bounded size/time, records acquisition
metadata and content integrity. Successful acquisition is NOT factual
verification; callers must keep those concepts separate.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from html.parser import HTMLParser
import re, time, urllib.request
from typing import Optional

@dataclass(frozen=True)
class AcquiredSource:
    url: str
    status_code: int
    content_type: str
    fetched_at: float
    content_hash: str
    content_length: int
    title: str
    text: str
    acquisition_ok: bool
    error: Optional[str] = None

class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.title_parts=[]; self.in_title=False
    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'title': self.in_title=True
    def handle_endtag(self, tag):
        if tag.lower() == 'title': self.in_title=False
    def handle_data(self, data):
        if self.in_title:
            self.title_parts.append(data)
            return
        if data.strip(): self.parts.append(data)
    @property
    def title(self): return re.sub(r'\s+', ' ', ' '.join(self.title_parts)).strip()
    @property
    def text(self): return re.sub(r'\s+', ' ', ' '.join(self.parts)).strip()

class SourceAcquisitionError(ValueError): pass

class SourceAcquirer:
    def __init__(self, *, timeout_seconds=10.0, max_bytes=2_000_000, user_agent='Rabidanti-WorldAwareness/3.53'):
        if not 0.1 <= float(timeout_seconds) <= 60: raise ValueError('timeout_seconds out of bounds')
        if not 1024 <= int(max_bytes) <= 20_000_000: raise ValueError('max_bytes out of bounds')
        self.timeout_seconds=float(timeout_seconds); self.max_bytes=int(max_bytes); self.user_agent=user_agent
    def fetch(self, url: str) -> AcquiredSource:
        if not isinstance(url,str) or not url.strip(): raise SourceAcquisitionError('url is required')
        url=url.strip()
        if not url.lower().startswith(('http://','https://')): raise SourceAcquisitionError('only http and https URLs are supported')
        started=time.time()
        req=urllib.request.Request(url, headers={'User-Agent':self.user_agent, 'Accept':'text/html,application/json,text/plain;q=0.9,*/*;q=0.1'})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                status=int(getattr(resp,'status',200)); ctype=resp.headers.get_content_type()
                length=resp.headers.get('Content-Length')
                if length and int(length) > self.max_bytes: raise SourceAcquisitionError('response exceeds max_bytes')
                chunks=[]; total=0
                while True:
                    chunk=resp.read(min(65536, self.max_bytes-total+1))
                    if not chunk: break
                    total += len(chunk)
                    if total > self.max_bytes: raise SourceAcquisitionError('response exceeds max_bytes')
                    chunks.append(chunk)
                raw=b''.join(chunks)
                charset=resp.headers.get_content_charset() or 'utf-8'
                text=raw.decode(charset, errors='replace')
                title=''
                if 'html' in ctype:
                    p=_HTMLText(); p.feed(text); title=p.title; text=p.text
                return AcquiredSource(url,status,ctype,time.time(),sha256(raw).hexdigest(),len(raw),title,text,200 <= status < 400,None)
        except SourceAcquisitionError:
            raise
        except Exception as exc:
            return AcquiredSource(url,0,'',time.time(),'',0,'','',False,f'{type(exc).__name__}: {exc}')
