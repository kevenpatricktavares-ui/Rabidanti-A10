# Rabidanti v2.8 — Queue + Workers

Agent -> Job -> Queue -> Worker -> Handler -> Result.

Priority order: CRITICAL > HIGH > NORMAL > LOW.
WAITING_APPROVAL jobs do not enter the executable queue.
RETRY returns a failed job to the queue within its retry budget.
Unknown handlers fail safely.

Current scope: in-process foundation. Durable queues, worker pools,
process isolation and production deployment remain future infrastructure.
