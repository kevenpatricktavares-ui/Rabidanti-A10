# Rabidanti v5.8 — Observability & Diagnostics Dashboard

v5.8 adds a read-only operational observability layer that consolidates signals already present in the runtime into one human-facing view.

## What is new

- New read-only runtime snapshot: `RabidantiRuntime.observability_snapshot()`.
- New local API endpoint: `GET /v1/observability`.
- New CLI command: `python rabidanti.py --state-dir .rabidanti observe`.
- New **Operações** tab in Sala.
- Severity classification: `OK`, `WARNING`, `CRITICAL`.
- Aggregated visibility over:
  - runtime doctor checks;
  - tasks and durable queue failures;
  - worker health/stale heartbeats;
  - desktop recovery/liveness state;
  - local model availability;
  - provider state;
  - connector enablement, handler and secret readiness;
  - recent runtime audit events;
  - integrated product self-test availability.

## Safety boundary

The observability layer is deliberately read-only. It does not:

- repair or restart workers automatically;
- enable/disable connectors;
- unlock the vault;
- refresh OAuth tokens;
- execute reasoning proposals;
- modify the Core;
- authorize external actions.

The snapshot always declares:

```json
{
  "read_only": true,
  "automatic_remediation": false,
  "external_action_authorized": false,
  "self_authorization": false
}
```

## Severity policy

Examples of `CRITICAL` signals:

- required `doctor` check failed;
- stale worker detected;
- desktop heartbeat is stale;
- enabled connector has no runtime handler.

Examples of `WARNING` signals:

- Docker/Podman unavailable;
- failed task or queue item exists;
- local model unavailable;
- provider revoked/expired/error;
- enabled connector is missing required secrets.

Warnings do not automatically trigger remediation.

## Validation

The v5.8 development tree collects 724 tests and passes all 724. The final package is re-extracted and validated separately before release.
