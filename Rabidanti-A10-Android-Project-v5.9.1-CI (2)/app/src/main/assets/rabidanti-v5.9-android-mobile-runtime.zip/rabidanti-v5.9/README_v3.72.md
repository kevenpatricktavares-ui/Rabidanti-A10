# Rabidanti v3.72 — Evolution Decision → Controller Integration

Integrates the v3.71 evidence decision layer with the Evolution Controller.

Flow:
signals -> evidence -> proposal -> decision -> gate -> controller approval -> activation

The decision engine can block activation. When eligible, the adapter delegates to
the controller instead of reproducing its state machine.

Explicit approval remains mandatory for activation.
