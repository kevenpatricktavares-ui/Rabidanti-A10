# Rabidanti v3.66 — Versioned Strategy & Rollback

## Objective
Create a durable configuration boundary for strategy evolution: proposed changes are immutable, approval is explicit, activation creates a version, and rollback preserves history.

## Flow
`Experiment/Analysis → Promotion Proposal → PROPOSED → APPROVED → ACTIVE → Monitor → Rollback if needed`

## Guarantees
- No implicit activation.
- Active strategy remains unchanged until explicit approval and activation.
- Every activation has a version and parent version.
- Previous active versions are retained as history.
- Rollback creates a new active version rather than deleting history.
- SQLite persistence survives process restart.
- Weight values are bounded to [-1, 1].
- Rejected or proposed versions cannot become active without the required transition.

## Boundary
This module stores and governs strategy configuration. It does not decide whether a change is scientifically valid, profitable, safe, or legally appropriate. Upstream evidence/experiment engines remain responsible for those assessments, and the application remains responsible for creator approval and deployment policy.
