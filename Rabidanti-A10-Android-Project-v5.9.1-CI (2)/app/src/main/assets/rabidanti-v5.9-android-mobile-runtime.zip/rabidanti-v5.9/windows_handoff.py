#!/usr/bin/env python3
"""Release handoff checks for a reproducible Rabidanti Windows build.

This module never claims a native release has been built. It only validates that
source inputs and the declared Windows toolchain contract are coherent, and can
write a handoff report describing what a Windows builder must execute.
"""
from __future__ import annotations
import argparse, json, platform, re, shutil, subprocess, sys
from pathlib import Path

SEMVER2_RE = re.compile(r"^(\d+)\.(\d+)(?:\.(\d+))?.*$")

class HandoffError(RuntimeError):
    pass

def _version_tuple(value: str) -> tuple[int, int, int]:
    m = SEMVER2_RE.match(value.strip())
    if not m:
        raise HandoffError(f"cannot parse version: {value!r}")
    return tuple(int(x or 0) for x in m.groups())

def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise HandoffError(f"invalid JSON file {path.name}: {exc}") from exc

def _command_version(command: list[str]) -> str | None:
    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    text = (proc.stdout or proc.stderr or "").strip()
    return text.splitlines()[0] if text else None

def inspect(root: Path) -> dict:
    root = root.resolve()
    contract = _read_json(root / "windows-toolchain.json")
    version = (root / "VERSION").read_text(encoding="utf-8").strip()
    required = [
        "Rabidanti.spec", "build_windows.bat", "build_release_windows.bat",
        "verify_windows_release.ps1", "native_release_check.py",
        "installer_windows.iss", "requirements-dev.txt", "windows-toolchain.json",
        ".github/workflows/windows-native-release.yml",
    ]
    missing = [name for name in required if not (root / name).exists()]
    if missing:
        raise HandoffError("missing release inputs: " + ", ".join(missing))
    if contract.get("schema") != 1 or contract.get("architecture") != "x64":
        raise HandoffError("unsupported windows-toolchain.json contract")
    req = (root / "requirements-dev.txt").read_text(encoding="utf-8").lower()
    if "pyinstaller" not in req:
        raise HandoffError("requirements-dev.txt must pin PyInstaller")
    if (root / "release-manifest.json").exists() or (root / "windows-release-validation.json").exists():
        raise HandoffError("source handoff must not contain fabricated native release evidence")

    python_now = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    result = {
        "schema": 1,
        "product": "Rabidanti",
        "version": version,
        "purpose": "windows-native-build-handoff",
        "source_tree_ready": True,
        "native_release_validated": False,
        "host": {
            "system": platform.system(),
            "machine": platform.machine(),
            "python": python_now,
        },
        "toolchain_contract": contract,
        "required_steps": [
            "Run on Windows x64",
            "Run prepare_windows_build.ps1 -BootstrapPython",
            "Install Inno Setup 6 if toolchain check reports it missing",
            "Run BUILD-WINDOWS-RELEASE.cmd",
            "Require release-manifest.json and windows-release-validation.json",
            "Run python native_release_check.py before publishing artifacts",
        ],
    }
    return result

def inspect_windows_toolchain(root: Path) -> dict:
    root = root.resolve()
    base = inspect(root)
    contract = base["toolchain_contract"]
    is_windows = platform.system().lower() == "windows"
    python_ver = (sys.version_info.major, sys.version_info.minor, sys.version_info.micro)
    py_min = _version_tuple(contract["python"]["min"])
    py_max = _version_tuple(contract["python"]["max_exclusive"])
    python_ok = py_min <= python_ver < py_max

    pyinstaller_raw = _command_version([sys.executable, "-m", "PyInstaller", "--version"])
    pyinstaller_ok = False
    if pyinstaller_raw:
        try:
            v = _version_tuple(pyinstaller_raw)
            pyinstaller_ok = _version_tuple(contract["pyinstaller"]["min"]) <= v < _version_tuple(contract["pyinstaller"]["max_exclusive"])
        except HandoffError:
            pass

    iscc = shutil.which("iscc") or shutil.which("ISCC.exe")
    checks = {
        "windows_host": is_windows,
        "python_supported": python_ok,
        "pyinstaller_available": pyinstaller_ok,
        "inno_setup_available": bool(iscc),
    }
    base["toolchain_checks"] = checks
    base["toolchain_ready"] = all(checks.values())
    base["native_release_validated"] = False
    return base

def write_report(root: Path, output: Path, *, toolchain: bool = False) -> dict:
    result = inspect_windows_toolchain(root) if toolchain else inspect(root)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return result

def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Rabidanti Windows native-build handoff checker")
    p.add_argument("--root", default=".")
    p.add_argument("--output")
    p.add_argument("--toolchain", action="store_true")
    a = p.parse_args(argv)
    root = Path(a.root)
    try:
        result = inspect_windows_toolchain(root) if a.toolchain else inspect(root)
        if a.output:
            Path(a.output).write_text(json.dumps(result, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    except (HandoffError, OSError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if (not a.toolchain or result.get("toolchain_ready")) else 3

if __name__ == "__main__":
    raise SystemExit(main())
