# Rabidanti v3.84 — Laboratory Foundation

Introduces a persistent, auditable R&D workflow for the approved Laboratory wing.

Domains: science, technology, AI, software, defensive cybersecurity, digital business, product research, and internal Rabidanti improvement.

Lifecycle: PROJECT → RESEARCH → HYPOTHESIS → EXPERIMENT → PROTOTYPE → VALIDATION → DISCOVERY. Validation can return to research when evidence is insufficient. Active stages can be rejected; DISCOVERY and REJECTED are terminal in this version.

SQLite persistence survives restarts. Stage transitions create audit events; evidence references, confidence, result and timestamps are retained. Duplicate IDs, invalid transitions and invalid confidence values are rejected.

Boundary: this is a workflow foundation, not yet an autonomous research agent. It does not fetch the web, execute arbitrary code, deploy software, automatically declare scientific discoveries, or modify Rabidanti Core.
