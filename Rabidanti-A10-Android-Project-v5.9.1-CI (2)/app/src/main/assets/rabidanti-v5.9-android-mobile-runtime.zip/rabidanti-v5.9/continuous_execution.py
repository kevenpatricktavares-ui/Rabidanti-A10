
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import Event, Lock
from typing import Callable, Optional

@dataclass
class ExecutionStats:
    ticks: int = 0
    scheduled: int = 0
    completed: int = 0
    failed: int = 0
    recovered: int = 0

class ContinuousExecutionEngine:
    """Coordinates scheduler ticks and bounded queue/worker execution.

    The engine is intentionally transport-agnostic: enqueue() submits work to
    the existing Job/Queue layer, while process() drains available work.
    """

    def __init__(
        self,
        scheduler,
        enqueue: Callable[[str], object],
        process: Callable[[], object],
        clock: Optional[Callable[[], datetime]] = None,
    ):
        self.scheduler = scheduler
        self.enqueue = enqueue
        self.process = process
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.stats = ExecutionStats()
        self._stop = Event()
        self._lock = Lock()

    def tick(self):
        now = self.clock()
        with self._lock:
            self.stats.ticks += 1

        due = list(self.scheduler.due(now))
        for task in due:
            # Only consume the schedule after successful enqueue.
            self.enqueue(task.task_id)
            self.scheduler.acknowledge(task.task_id, now)
            with self._lock:
                self.stats.scheduled += 1

        result = self.process()
        return result

    def run(self, max_ticks=1):
        if max_ticks < 1:
            raise ValueError("max_ticks must be >= 1")
        results=[]
        for _ in range(max_ticks):
            if self._stop.is_set():
                break
            results.append(self.tick())
        return results

    def stop(self):
        self._stop.set()

    @property
    def stopped(self):
        return self._stop.is_set()
