# Rabidanti v5.6

Rabidanti v5.6 is the Windows Native Release Handoff & Reproducible Build Pack.

On a Windows x64 build machine, the intended operator path is:

```bat
BUILD-WINDOWS-RELEASE.cmd
```

The source package itself is not a validated native Windows release. Native validation requires real `Rabidanti.exe` and installer artifacts plus the two evidence files generated and checked on Windows.

See `WINDOWS-BUILD-HANDOFF.md` and `ARCHITECTURE-v5.6.md`.
