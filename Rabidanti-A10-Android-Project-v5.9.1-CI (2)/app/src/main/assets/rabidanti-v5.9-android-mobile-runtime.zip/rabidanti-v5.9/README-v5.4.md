# Rabidanti v5.4 — Windows Build Validation & Installer Release Candidate

v5.4 hardens the native Windows release pipeline. It fixes stale binary version metadata found in v5.3 and makes `VERSION` the single source of truth for PyInstaller metadata and the Inno Setup installer.

New release tooling (`rabidanti_release.py`) provides metadata synchronization, source preflight validation, PE structural validation and SHA-256 release manifests generated only from real built artifacts. `build_release_windows.bat` requires both a real PyInstaller EXE and a real Inno Setup installer before producing `release-manifest.json`.

This source package does **not** include `release-manifest.json`, `Rabidanti.exe`, or a Setup EXE, because those native artifacts have not been built in the current Linux environment. See `WINDOWS-RELEASE-CHECKLIST.md` for the required Windows validation procedure.
