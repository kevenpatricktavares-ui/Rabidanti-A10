"""Rabidanti v3.30 — canonical business pipeline workflow definition."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional
from workflow_engine import WorkflowNode

PIPELINE_VERSION = "1.0"
STAGES = (
    "research", "opportunity", "product", "content", "review", "render",
    "brand", "landing", "sales", "distribution", "ads", "analytics", "learning",
)

# Lower-level domain agents are intentionally represented by stable stage contracts.
# Their concrete implementations can be connected without changing workflow topology.
DEPENDENCIES = {
    "research": (),
    "opportunity": ("research",),
    "product": ("opportunity",),
    "content": ("product",),
    "review": ("content",),
    "render": ("review",),
    "brand": ("product", "review"),
    "landing": ("render", "brand"),
    "sales": ("landing",),
    "distribution": ("sales",),
    "ads": ("distribution",),
    "analytics": ("ads",),
    "learning": ("analytics",),
}

@dataclass(frozen=True)
class BusinessPipelineSpec:
    name: str
    project_id: str
    objective: str
    context: dict[str, Any]
    max_attempts: int = 3
    metadata: Optional[dict[str, Any]] = None


def build_business_pipeline(spec: BusinessPipelineSpec) -> tuple[tuple[WorkflowNode, ...], dict[str, object]]:
    if not spec.project_id.strip():
        raise ValueError("project_id must not be empty")
    if not spec.objective.strip():
        raise ValueError("objective must not be empty")
    if spec.max_attempts < 1:
        raise ValueError("max_attempts must be >= 1")

    nodes = tuple(
        WorkflowNode(task_id=stage, dependencies=tuple(DEPENDENCIES[stage]), priority=100 - i)
        for i, stage in enumerate(STAGES)
    )
    payloads = {
        stage: {
            "pipeline": "business",
            "pipeline_version": PIPELINE_VERSION,
            "project_id": spec.project_id,
            "stage": stage,
            "objective": spec.objective,
            "context": dict(spec.context),
            "handler": f"business.stage.{stage}",
        }
        for stage in STAGES
    }
    return nodes, payloads
