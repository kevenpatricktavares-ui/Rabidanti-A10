# Rabidanti v3.88 — Laboratory Execution Policy

Adds an explicit policy assessment layer for lab execution profiles. It separates **declared controls** from host capabilities, produces a timestamped SHA-256 assessment record, and fails closed when `untrusted_code` is requested without every required control being declared.

Required controls for untrusted code: CPU limit, memory limit, process limit, network isolation, non-root identity, disposable filesystem, timeout, output cap, executable allowlist, temporary workspace, and restricted environment.

**Important:** declaring controls is not proof that the operating system enforces them. This version does not create containers, namespaces, a VM, or network isolation. `safe_for_untrusted_code` means only that the supplied policy declaration is complete; deployments must independently verify enforcement. Do not run untrusted code on a sensitive host based on this assessment alone.

The v3.87 runner is retained. Run `pytest -q` from the project root.
