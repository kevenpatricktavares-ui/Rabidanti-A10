# Rabidanti v3.15 — Worker Health & Conservative Recovery

Builds on v3.14 by adding a health snapshot and conservative stale-worker recovery.

## Capabilities
- health snapshot with status counts and stale worker IDs
- stale detection on runner ticks
- automatic recovery of stale worker slots only when active=0
- active stale workers are not silently revived
- durable queue lease recovery remains responsible for abandoned work
- runner health reports recovered workers

## Safety of recovery
Recovery never assumes that a stale worker is dead while it reports active work.
This avoids duplicate execution. Work abandoned by a genuinely dead worker is
recovered by the durable queue after its lease expires.

## Scope
Still a local/in-process execution foundation using SQLite. It does not claim
cloud hosting, autoscaling, external brokers, multi-region failover, or SLA.
