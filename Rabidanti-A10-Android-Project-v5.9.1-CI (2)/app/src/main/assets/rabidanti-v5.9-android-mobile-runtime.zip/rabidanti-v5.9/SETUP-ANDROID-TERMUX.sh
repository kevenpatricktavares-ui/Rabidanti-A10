#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

if [ -z "${TERMUX_VERSION:-}" ] && [[ "${PREFIX:-}" != *com.termux* ]]; then
  echo "Este instalador deve ser executado dentro do Termux." >&2
  exit 2
fi

if ! command -v python >/dev/null 2>&1; then
  echo "Python não encontrado. Execute: pkg install python" >&2
  exit 3
fi

python - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Rabidanti requer Python 3.10 ou superior")
print("Python:", sys.version.split()[0])
PY

if [ "${RABIDANTI_ANDROID_SKIP_PIP:-0}" != "1" ]; then
  python -m pip install --upgrade pip
  python -m pip install -r requirements-android.txt
fi

STATE_DIR="${RABIDANTI_STATE_DIR:-$HOME/.local/share/rabidanti}"
python rabidanti_bootstrap.py --state-dir "$STATE_DIR" setup
python rabidanti_android.py --state-dir "$STATE_DIR" doctor

echo
echo "Rabidanti preparado. Para iniciar:"
echo "  ./START-RABIDANTI-ANDROID.sh"
