"""Rabidanti v4.1 — loopback-only local HTTP API service.

The API is deliberately conservative:
- binds only to loopback addresses;
- exposes read-only status endpoints without authentication because they are
  local-only;
- requires a bearer token for every mutation;
- never exposes arbitrary shell/command execution;
- never grants external-action or Core-integration authority.
"""
from __future__ import annotations

from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import ipaddress
import json
import secrets
import threading
from typing import Any, Optional
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from rabidanti_runtime import RabidantiRuntime
from rabidanti_connectors import ConnectorNotFound, ConnectorPermissionError, ConnectorRateLimitError
from rabidanti_oauth import OAuthError
from rabidanti_vault import VaultError
from rabidanti_proposal_bridge import ProposalBridgeError, ProposalReviewRequired, ProposalRejected, ProposalIntegrityError


API_VERSION = "v1"
MAX_BODY_BYTES = 64 * 1024
UI_ROOT = Path(__file__).with_name("ui")


def _is_loopback_host(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


@dataclass(frozen=True)
class ApiAddress:
    host: str
    port: int


class RabidantiApiService:
    """Threaded, loopback-only HTTP control surface for RabidantiRuntime."""

    def __init__(
        self,
        runtime: RabidantiRuntime,
        *,
        host: str = "127.0.0.1",
        port: int = 8765,
        token: Optional[str] = None,
    ) -> None:
        if not _is_loopback_host(host):
            raise ValueError("Rabidanti API may bind only to a loopback host")
        if not isinstance(port, int) or not 0 <= port <= 65535:
            raise ValueError("port must be between 0 and 65535")
        self.runtime = runtime
        self.host = host
        self.port = port
        self.token = token or runtime.secrets.get("API_TOKEN") or secrets.token_urlsafe(32)
        if len(self.token) < 24:
            raise ValueError("API token must be at least 24 characters")
        self._server: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    @property
    def address(self) -> ApiAddress:
        if self._server is None:
            return ApiAddress(self.host, self.port)
        host, port = self._server.server_address[:2]
        return ApiAddress(str(host), int(port))

    def _handler_class(self):
        service = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "RabidantiLocalAPI/5.1"
            sys_version = ""

            def log_message(self, format: str, *args: Any) -> None:
                # Avoid leaking request headers/tokens to stderr by default.
                return

            def _json(self, status: int, payload: Any) -> None:
                raw = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self._security_headers()
                self.end_headers()
                self.wfile.write(raw)

            def _html(self, status: int, html: str) -> None:
                raw = html.encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self._security_headers()
                self.end_headers()
                self.wfile.write(raw)

            def _security_headers(self) -> None:
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header(
                    "Content-Security-Policy",
                    "default-src 'self'; script-src 'self'; style-src 'self'; "
                    "connect-src 'self'; img-src 'self' data:; object-src 'none'; "
                    "base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
                )

            def _asset(self, name: str, content_type: str) -> None:
                path = UI_ROOT / name
                try:
                    raw = path.read_bytes()
                except OSError:
                    self._error(HTTPStatus.NOT_FOUND, "UI_ASSET_MISSING", "UI asset not found")
                    return
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(raw)))
                self._security_headers()
                self.end_headers()
                self.wfile.write(raw)

            def _error(self, status: int, code: str, message: str) -> None:
                self._json(status, {"error": {"code": code, "message": message}})

            def _authorized_mutation(self) -> bool:
                header = self.headers.get("Authorization", "")
                prefix = "Bearer "
                supplied = header[len(prefix):] if header.startswith(prefix) else ""
                if not supplied or not hmac.compare_digest(supplied, service.token):
                    self._error(HTTPStatus.UNAUTHORIZED, "UNAUTHORIZED", "valid bearer token required")
                    return False
                return True

            def _read_json_body(self) -> Optional[dict[str, Any]]:
                content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if content_type != "application/json":
                    self._error(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "CONTENT_TYPE", "application/json required")
                    return None
                raw_len = self.headers.get("Content-Length")
                try:
                    length = int(raw_len or "0")
                except ValueError:
                    self._error(HTTPStatus.BAD_REQUEST, "CONTENT_LENGTH", "invalid Content-Length")
                    return None
                if length <= 0:
                    self._error(HTTPStatus.BAD_REQUEST, "EMPTY_BODY", "JSON body required")
                    return None
                if length > MAX_BODY_BYTES:
                    self._error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "BODY_TOO_LARGE", "request body too large")
                    return None
                try:
                    value = json.loads(self.rfile.read(length).decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    self._error(HTTPStatus.BAD_REQUEST, "INVALID_JSON", "invalid JSON body")
                    return None
                if not isinstance(value, dict):
                    self._error(HTTPStatus.BAD_REQUEST, "INVALID_BODY", "JSON object required")
                    return None
                return value

            def do_GET(self) -> None:
                parsed = urlparse(self.path)
                path = parsed.path.rstrip("/") or "/"
                query = parse_qs(parsed.query, keep_blank_values=False)
                try:
                    if parsed.path == "/":
                        self.send_response(HTTPStatus.FOUND)
                        self.send_header("Location", "/ui/")
                        self._security_headers()
                        self.end_headers()
                    elif parsed.path in {"/ui", "/ui/"}:
                        self._asset("index.html", "text/html; charset=utf-8")
                    elif path == "/ui/app.js":
                        self._asset("app.js", "text/javascript; charset=utf-8")
                    elif path == "/ui/style.css":
                        self._asset("style.css", "text/css; charset=utf-8")
                    elif path == "/oauth/callback":
                        code = query.get("code", [None])[0]
                        state = query.get("state", [None])[0]
                        error = query.get("error", [None])[0]
                        if error:
                            self._html(HTTPStatus.BAD_REQUEST, "<!doctype html><meta charset='utf-8'><title>Rabidanti OAuth</title><h1>Autorização não concluída</h1><p>O fornecedor devolveu um erro. Pode fechar esta janela e regressar à Sala.</p>")
                        elif not code or not state:
                            self._html(HTTPStatus.BAD_REQUEST, "<!doctype html><meta charset='utf-8'><title>Rabidanti OAuth</title><h1>Callback inválido</h1><p>Faltam parâmetros OAuth.</p>")
                        else:
                            service.runtime.oauth_google_gmail_complete_callback(state=state, code=code)
                            self._html(HTTPStatus.OK, "<!doctype html><meta charset='utf-8'><title>Rabidanti OAuth</title><h1>Gmail ligado ao Rabidanti</h1><p>A autorização foi concluída. Pode fechar esta janela e regressar à Sala.</p>")
                    elif path == "/health":
                        self._json(HTTPStatus.OK, {
                            "program": "Rabidanti",
                            "version": service.runtime.version,
                            "api_version": API_VERSION,
                            "healthy": service.runtime.doctor()["healthy"],
                        })
                    elif path == f"/{API_VERSION}/status":
                        self._json(HTTPStatus.OK, service.runtime.status())
                    elif path == f"/{API_VERSION}/doctor":
                        self._json(HTTPStatus.OK, service.runtime.doctor())
                    elif path == f"/{API_VERSION}/observability":
                        self._json(HTTPStatus.OK, service.runtime.observability_snapshot())
                    elif path == f"/{API_VERSION}/config":
                        self._json(HTTPStatus.OK, service.runtime.get_config())
                    elif path == f"/{API_VERSION}/setup":
                        self._json(HTTPStatus.OK, service.runtime.onboarding_status())
                    elif path == f"/{API_VERSION}/secrets":
                        self._json(HTTPStatus.OK, {"items": service.runtime.secret_status()})
                    elif path == f"/{API_VERSION}/tasks":
                        state = query.get("state", [None])[0]
                        self._json(HTTPStatus.OK, {"items": service.runtime.list_tasks(state)})
                    elif path == f"/{API_VERSION}/evidence":
                        kind = query.get("kind", [None])[0]
                        text = query.get("text", [None])[0]
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.search_evidence(kind=kind, text=text, limit=limit)})
                    elif path == f"/{API_VERSION}/events":
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.runtime_events(limit)})
                    elif path == f"/{API_VERSION}/model":
                        self._json(HTTPStatus.OK, service.runtime.model_status())
                    elif path == f"/{API_VERSION}/models":
                        self._json(HTTPStatus.OK, service.runtime.list_models())
                    elif path == f"/{API_VERSION}/reasoning/proposals":
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.reasoning_proposals(limit)})
                    elif path == f"/{API_VERSION}/reasoning/reviews":
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.proposal_reviews(limit)})
                    elif path == f"/{API_VERSION}/reasoning/executions":
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.proposal_executions(limit)})
                    elif path == f"/{API_VERSION}/conversations":
                        try:
                            limit = int(query.get("limit", ["50"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.list_conversations(limit)})
                    elif path.startswith(f"/{API_VERSION}/conversations/"):
                        conversation_id = path.split("/")[-1]
                        self._json(HTTPStatus.OK, {"items": service.runtime.conversation_messages(conversation_id)})
                    elif path == f"/{API_VERSION}/providers":
                        self._json(HTTPStatus.OK, {"items": service.runtime.provider_status()})
                    elif path == f"/{API_VERSION}/connectors":
                        self._json(HTTPStatus.OK, {"items": service.runtime.list_connectors()})
                    elif path == f"/{API_VERSION}/connectors/approvals":
                        connector_id = query.get("connector_id", [None])[0]
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.connector_approvals(connector_id, limit)})
                    elif path == f"/{API_VERSION}/connectors/invocations":
                        connector_id = query.get("connector_id", [None])[0]
                        try:
                            limit = int(query.get("limit", ["100"])[0])
                        except ValueError:
                            raise ValueError("limit must be an integer")
                        self._json(HTTPStatus.OK, {"items": service.runtime.connector_invocations(connector_id, limit)})
                    elif path == f"/{API_VERSION}/workflows":
                        self._json(HTTPStatus.OK, {"items": [
                            {
                                "workflow_id": w.workflow_id,
                                "name": w.name,
                                "state": w.state.value,
                                "task_ids": list(w.task_ids),
                                "error": w.error,
                                "metadata": w.metadata,
                            }
                            for w in service.runtime.core.list_workflows()
                        ]})
                    else:
                        self._error(HTTPStatus.NOT_FOUND, "NOT_FOUND", "endpoint not found")
                except ConnectorNotFound as exc:
                    self._error(HTTPStatus.NOT_FOUND, "CONNECTOR_NOT_FOUND", str(exc))
                except ConnectorPermissionError as exc:
                    self._error(HTTPStatus.FORBIDDEN, "CONNECTOR_FORBIDDEN", str(exc))
                except ConnectorRateLimitError as exc:
                    self._error(HTTPStatus.TOO_MANY_REQUESTS, "CONNECTOR_RATE_LIMIT", str(exc))
                except (ProposalReviewRequired, ProposalRejected, ProposalIntegrityError, ProposalBridgeError) as exc:
                    self._error(HTTPStatus.CONFLICT, "PROPOSAL_STATE", str(exc))
                except (OAuthError, VaultError) as exc:
                    self._error(HTTPStatus.BAD_REQUEST, "PROVIDER_ERROR", str(exc))
                except (ValueError, KeyError) as exc:
                    self._error(HTTPStatus.BAD_REQUEST, "INVALID_REQUEST", str(exc))
                except Exception:
                    self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "request failed")

            def do_POST(self) -> None:
                parsed = urlparse(self.path)
                path = parsed.path.rstrip("/") or "/"
                if not self._authorized_mutation():
                    return
                try:
                    if path == f"/{API_VERSION}/setup/complete":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"model", "fallback_model", "auto_open_browser", "logging_level", "vault_master_key"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        model = body.get("model")
                        if not isinstance(model, str) or not model.strip():
                            raise ValueError("model is required")
                        fallback = body.get("fallback_model", "")
                        if not isinstance(fallback, str):
                            raise ValueError("fallback_model must be a string")
                        auto_open = body.get("auto_open_browser", True)
                        if not isinstance(auto_open, bool):
                            raise ValueError("auto_open_browser must be boolean")
                        level = body.get("logging_level", "INFO")
                        if not isinstance(level, str):
                            raise ValueError("logging_level must be a string")
                        master_key = body.get("vault_master_key")
                        if master_key is not None and not isinstance(master_key, str):
                            raise ValueError("vault_master_key must be a string")
                        item = service.runtime.complete_onboarding(
                            model=model.strip(),
                            fallback_model=fallback.strip(),
                            auto_open_browser=auto_open,
                            logging_level=level,
                            vault_master_key=master_key or None,
                        )
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/vault/unlock":
                        body = self._read_json_body()
                        if body is None:
                            return
                        if set(body) != {"master_key"} or not isinstance(body.get("master_key"), str):
                            raise ValueError("body must contain only master_key string")
                        self._json(HTTPStatus.OK, service.runtime.unlock_vault(body["master_key"]))
                    elif path == f"/{API_VERSION}/config":
                        body = self._read_json_body()
                        if body is None:
                            return
                        if set(body) != {"changes"} or not isinstance(body.get("changes"), dict):
                            raise ValueError("body must contain only a changes object")
                        updated = service.runtime.update_config(body["changes"])
                        self._json(HTTPStatus.OK, updated)
                    elif path == f"/{API_VERSION}/secrets/session":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"name", "value", "clear"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        name = body.get("name")
                        if not isinstance(name, str):
                            raise ValueError("name must be a string")
                        if body.get("clear") is True:
                            result = service.runtime.clear_session_secret(name)
                        else:
                            value = body.get("value")
                            if not isinstance(value, str):
                                raise ValueError("value must be a string")
                            result = service.runtime.set_session_secret(name, value)
                        self._json(HTTPStatus.OK, result)
                    elif path == f"/{API_VERSION}/chat":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"message", "conversation_id"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        message = body.get("message")
                        if not isinstance(message, str):
                            raise ValueError("message must be a string")
                        conversation_id = body.get("conversation_id")
                        if conversation_id is not None and not isinstance(conversation_id, str):
                            raise ValueError("conversation_id must be a string")
                        item = service.runtime.chat(message, conversation_id)
                        self._json(HTTPStatus.CREATED, item)
                    elif path == f"/{API_VERSION}/reason":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"request", "context"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        request = body.get("request")
                        if not isinstance(request, str):
                            raise ValueError("request must be a string")
                        context = body.get("context")
                        if context is not None and not isinstance(context, str):
                            raise ValueError("context must be a string")
                        item = service.runtime.reason(request, context)
                        self._json(HTTPStatus.CREATED, item)
                    elif path == f"/{API_VERSION}/reasoning/review":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"proposal_id", "decision", "actor", "reason"}
                        if set(body) != allowed:
                            raise ValueError("proposal_id, decision, actor and reason are required")
                        item = service.runtime.review_reasoning_proposal(
                            body["proposal_id"], decision=body["decision"], actor=body["actor"], reason=body["reason"]
                        )
                        self._json(HTTPStatus.CREATED, item)
                    elif path == f"/{API_VERSION}/reasoning/authorize":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"proposal_id", "actor", "reason"}
                        if set(body) != allowed:
                            raise ValueError("proposal_id, actor and reason are required")
                        item = service.runtime.authorize_reasoning_proposal(
                            body["proposal_id"], actor=body["actor"], reason=body["reason"]
                        )
                        self._json(HTTPStatus.CREATED, item)
                    elif path == f"/{API_VERSION}/reasoning/execute":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"proposal_id", "actor"}
                        if set(body) != allowed:
                            raise ValueError("proposal_id and actor are required")
                        item = service.runtime.execute_reasoning_proposal(body["proposal_id"], actor=body["actor"])
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/providers/google-gmail/setup":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"client_id", "client_secret", "persist"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        if "client_id" not in body:
                            raise ValueError("client_id is required")
                        item = service.runtime.configure_google_gmail_credentials(
                            client_id=body["client_id"],
                            client_secret=body.get("client_secret"),
                            persist=bool(body.get("persist", False)),
                        )
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/providers/google-gmail/oauth/start":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"redirect_uri"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        redirect_uri = body.get("redirect_uri") or f"http://{service.address.host}:{service.address.port}/oauth/callback"
                        item = service.runtime.oauth_google_gmail_start(redirect_uri=redirect_uri)
                        self._json(HTTPStatus.CREATED, item)
                    elif path == f"/{API_VERSION}/providers/google-gmail/oauth/exchange":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"flow_id", "state", "code"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        if set(body) != allowed:
                            raise ValueError("flow_id, state and code are required")
                        item = service.runtime.oauth_google_gmail_exchange(
                            flow_id=body["flow_id"], state=body["state"], code=body["code"]
                        )
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/providers/google-gmail/refresh":
                        body = self._read_json_body()
                        if body is None:
                            return
                        if body:
                            raise ValueError("request body must be an empty object")
                        item = service.runtime.refresh_google_gmail()
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/providers/google-gmail/test":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"actor"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        actor = body.get("actor", "local-user")
                        if not isinstance(actor, str) or not actor.strip():
                            raise ValueError("actor must be a non-empty string")
                        item = service.runtime.test_google_gmail_connection(actor=actor.strip())
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/connectors/control":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"connector_id", "enabled", "actor", "reason"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        if set(body) != allowed:
                            raise ValueError("connector_id, enabled, actor and reason are required")
                        item = service.runtime.set_connector_enabled(
                            body["connector_id"], body["enabled"], actor=body["actor"], reason=body["reason"]
                        )
                        self._json(HTTPStatus.OK, item)
                    elif path == f"/{API_VERSION}/connectors/approve":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"connector_id", "capability", "payload", "actor", "reason"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        if set(body) != allowed or not isinstance(body.get("payload"), dict):
                            raise ValueError("connector_id, capability, payload object, actor and reason are required")
                        item = service.runtime.approve_connector_action(
                            body["connector_id"], body["capability"], body["payload"],
                            actor=body["actor"], reason=body["reason"]
                        )
                        self._json(HTTPStatus.CREATED, item)
                    elif path == f"/{API_VERSION}/tasks":
                        body = self._read_json_body()
                        if body is None:
                            return
                        allowed = {"name", "priority", "dependencies", "max_attempts", "task_id"}
                        unknown = set(body) - allowed
                        if unknown:
                            raise ValueError(f"unknown fields: {', '.join(sorted(unknown))}")
                        name = body.get("name")
                        if not isinstance(name, str) or not name.strip():
                            raise ValueError("name must be a non-empty string")
                        if len(name) > 500:
                            raise ValueError("name is too long")
                        dependencies = body.get("dependencies")
                        if dependencies is not None and (
                            not isinstance(dependencies, list)
                            or not all(isinstance(x, str) and x for x in dependencies)
                        ):
                            raise ValueError("dependencies must be a list of non-empty strings")
                        item = service.runtime.add_task(
                            name.strip(),
                            priority=str(body.get("priority", "NORMAL")),
                            dependencies=dependencies,
                            max_attempts=int(body.get("max_attempts", 3)),
                            task_id=body.get("task_id"),
                        )
                        service.runtime._event("API_TASK_ADDED", {"task_id": item["task_id"]})
                        self._json(HTTPStatus.CREATED, item)
                    else:
                        self._error(HTTPStatus.NOT_FOUND, "NOT_FOUND", "endpoint not found")
                except ConnectorNotFound as exc:
                    self._error(HTTPStatus.NOT_FOUND, "CONNECTOR_NOT_FOUND", str(exc))
                except ConnectorPermissionError as exc:
                    self._error(HTTPStatus.FORBIDDEN, "CONNECTOR_FORBIDDEN", str(exc))
                except ConnectorRateLimitError as exc:
                    self._error(HTTPStatus.TOO_MANY_REQUESTS, "CONNECTOR_RATE_LIMIT", str(exc))
                except (ProposalReviewRequired, ProposalRejected, ProposalIntegrityError, ProposalBridgeError) as exc:
                    self._error(HTTPStatus.CONFLICT, "PROPOSAL_STATE", str(exc))
                except (OAuthError, VaultError) as exc:
                    self._error(HTTPStatus.BAD_REQUEST, "PROVIDER_ERROR", str(exc))
                except (ValueError, KeyError) as exc:
                    self._error(HTTPStatus.BAD_REQUEST, "INVALID_REQUEST", str(exc))
                except Exception:
                    self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "request failed")

            def do_PUT(self) -> None:
                self._error(HTTPStatus.METHOD_NOT_ALLOWED, "METHOD_NOT_ALLOWED", "method not allowed")

            def do_PATCH(self) -> None:
                self._error(HTTPStatus.METHOD_NOT_ALLOWED, "METHOD_NOT_ALLOWED", "method not allowed")

            def do_DELETE(self) -> None:
                self._error(HTTPStatus.METHOD_NOT_ALLOWED, "METHOD_NOT_ALLOWED", "method not allowed")

        return Handler

    def start(self, *, background: bool = True) -> ApiAddress:
        if self._server is not None:
            return self.address
        self._server = ThreadingHTTPServer((self.host, self.port), self._handler_class())
        self._server.daemon_threads = True
        addr = self.address
        self.runtime._event("LOCAL_API_STARTED", {"host": addr.host, "port": addr.port, "api_version": API_VERSION})
        if background:
            self._thread = threading.Thread(target=self._server.serve_forever, name="rabidanti-local-api", daemon=True)
            self._thread.start()
        else:
            try:
                self._server.serve_forever()
            finally:
                self.stop()
        return addr

    def stop(self) -> None:
        server = self._server
        if server is None:
            return
        addr = self.address
        server.shutdown()
        server.server_close()
        if self._thread is not None and self._thread.is_alive() and self._thread is not threading.current_thread():
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None
        self.runtime._event("LOCAL_API_STOPPED", {"host": addr.host, "port": addr.port})
