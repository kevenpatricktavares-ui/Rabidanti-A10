# Rabidanti v2.2 — Character Engine

The Character Engine creates consistent virtual characters that can later be
used by the audiovisual, content, marketing and sales layers.

The private Rabidanti Personality Core is separate from commercial characters.

Character safety rules:
- no unauthorized impersonation of real people;
- no fabricated credentials;
- no fabricated testimonials;
- synthetic/virtual identity should be disclosed where relevant;
- persuasion should rely on legitimate value, clarity and evidence.
