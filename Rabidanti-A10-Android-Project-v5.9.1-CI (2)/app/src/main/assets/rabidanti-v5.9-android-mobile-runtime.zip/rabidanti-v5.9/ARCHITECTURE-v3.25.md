# Rabidanti v3.25 — Workflow / DAG Engine

Adds a durable workflow orchestration foundation over the v3.24 dependency-aware queue.

- Validates workflow nodes and dependency references.
- Rejects cycles before registration.
- Registers a workflow into the durable queue.
- Produces a read-only workflow plan from durable queue state.
- Reuses queue dependency gating and durable worker claims.
- Does not execute arbitrary work, autoscale, or introduce paid infrastructure.
