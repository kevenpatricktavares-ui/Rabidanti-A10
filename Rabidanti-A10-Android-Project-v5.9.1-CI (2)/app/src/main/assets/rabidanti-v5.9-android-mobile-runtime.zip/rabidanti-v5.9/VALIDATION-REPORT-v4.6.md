# Rabidanti v4.6 — Relatório de Validação

## Baseline recebida

- Artefacto: `rabidanti-v4.5-oauth-vault-gmail-readonly.zip`
- SHA-256: `e07e7f90b94156cf2ebe02df4ecaf757d4101c010fd50bd5e06d2a8a82d69cc0`
- VERSION: `4.5.0`
- Baseline confirmada: **562/562 testes aprovados** em grupos determinísticos.

## Alterações v4.6

- novo `ProviderStateStore` persistente para metadados de providers;
- expiração conhecida de access token;
- refresh OAuth automático e manual;
- deteção de revogação (`invalid_grant`/`invalid_token`);
- callback OAuth loopback protegido por state;
- setup de credenciais em sessão ou vault;
- provider status integrado no runtime;
- teste de ligação Gmail através do connector permission gate;
- API local de provider management;
- nova área Providers na Sala;
- novos comandos CLI de provider.

## Testes novos

`test_v4_6_provider_management.py`: **17/17 aprovados**.

Incluem:

- persistência de metadados sem tokens;
- expiração e refresh;
- rotação de access token;
- invalid_grant como revogação;
- sessão vs vault;
- ausência de credenciais em ficheiros de estado;
- OAuth exchange e metadata;
- auto-refresh de token expirado;
- teste de ligação respeitando connector disabled;
- teste Gmail simulado bem sucedido;
- HTTP 401 marcado como revoked;
- API protegida por Bearer Token;
- callback OAuth local;
- state inválido sem token exchange;
- Sala sem browser persistence de credenciais.

## Regressão completa da árvore v4.6

Coleta: **579 testes**.

Grupos finais:

- grupo 1: 103 passed
- grupo 2: 102 passed
- grupo 3: 99 passed
- grupo 4: 87 passed
- grupo 5: 89 passed
- grupo 6: 99 passed

**Total: 579 passed / 0 failed.**

## Compilação e smoke test

- `python -m compileall -q .`: PASS
- `python rabidanti.py ... status`: PASS
- `python rabidanti.py ... provider list`: PASS
- provider Gmail registado: PASS
- connector Gmail desativado por defeito: PASS

## Limitações verificadas

- Nenhuma conta Google real foi autorizada nesta validação.
- OAuth/Gmail/refresh foram exercitados com respostas HTTP controladas/mocks.
- Docker/Podman não é necessário para esta funcionalidade e o isolamento por contentor continua uma validação separada.
- Ter credenciais não equivale a autorização geral de ações externas.
- Gmail continua read-only.

## Resultado

A v4.6 está tecnicamente validada como camada local de setup/gestão de provider, sujeita à futura validação live com uma conta Google explicitamente autorizada pelo criador.
