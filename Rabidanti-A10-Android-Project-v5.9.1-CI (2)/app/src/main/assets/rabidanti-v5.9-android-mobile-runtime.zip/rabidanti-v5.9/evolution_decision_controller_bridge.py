from dataclasses import dataclass
from enum import Enum
from typing import Any


class GateResult(str, Enum):
    BLOCKED = "blocked"
    ALLOWED = "allowed"


@dataclass(frozen=True)
class ControllerGateDecision:
    proposal_id: str
    decision: str
    score: float
    gate: GateResult
    reason: str


class EvolutionDecisionControllerBridge:
    """Connects evidence decisions to the Evolution Controller.

    This adapter is deliberately conservative: only an approval-required
    decision can request controller activation flow, and the controller's
    own approval/transition rules remain authoritative.
    """

    def __init__(self, controller, decision_engine):
        self.controller = controller
        self.decision_engine = decision_engine

    def assess(self, proposal_id: str, assessment) -> ControllerGateDecision:
        decision = self.decision_engine.evaluate(proposal_id, assessment)

        if decision.approval_required:
            return ControllerGateDecision(
                proposal_id, decision.decision.value, decision.score,
                GateResult.ALLOWED,
                "Eligible to enter the controller approval workflow."
            )

        return ControllerGateDecision(
            proposal_id, decision.decision.value, decision.score,
            GateResult.BLOCKED,
            "Decision does not authorize activation; follow investigation/experiment path."
        )

    def request_activation(self, proposal_id: str, assessment, approval: bool = False):
        gate = self.assess(proposal_id, assessment)
        if gate.gate is GateResult.BLOCKED:
            raise PermissionError("decision gate blocks activation")
        if not approval:
            raise PermissionError("explicit activation approval is required")
        # Delegate to the controller; never emulate or bypass its state machine.
        if not hasattr(self.controller, "request_activation"):
            raise AttributeError("controller does not expose request_activation")
        return self.controller.request_activation(proposal_id)

    def activate(self, proposal_id: str, approval: bool = False):
        if not approval:
            raise PermissionError("explicit activation approval is required")
        if not hasattr(self.controller, "activate"):
            raise AttributeError("controller does not expose activate")
        return self.controller.activate(proposal_id, approval=True)
