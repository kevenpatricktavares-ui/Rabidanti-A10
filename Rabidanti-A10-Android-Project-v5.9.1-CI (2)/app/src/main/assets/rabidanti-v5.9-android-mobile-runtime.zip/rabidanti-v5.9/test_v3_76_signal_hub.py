from evolution_signal_hub import EvolutionSignalHub, HubSignal, SignalDomain
from evolution_signal_runtime_bridge import EvolutionSignalRuntimeBridge
from evolution_runtime import EvolutionRuntime
from evolution_cycle_store import EvolutionCycleStore
from evolution_cycle_audit import EvolutionCycleAudit
from evolution_decision_controller_bridge import EvolutionDecisionControllerBridge
from evolution_evidence_decision import EvolutionEvidenceDecisionEngine, EvidenceAssessment


class Controller:
    def request_activation(self,pid): return "requested"


def assessment():
    return EvidenceAssessment(.9,.8,.2,.2,.9)


def hub():
    c=Controller()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    s=EvolutionCycleStore()
    r=EvolutionRuntime(b, EvolutionCycleAudit(s))
    return EvolutionSignalHub(EvolutionSignalRuntimeBridge(r)), s


def test_all_domains_accepted():
    h,s=hub()
    for i,d in enumerate(SignalDomain):
        h.submit(HubSignal(f"s{i}",d,f"p{i}",assessment(),f"e{i}"))
    assert all(v==1 for v in h.counts().values())
    assert h.domain_of("s0")==SignalDomain.HEALTH


def test_unknown_domain_rejected():
    h,_=hub()
    try:
        h.submit(HubSignal("s","invalid","p",assessment(),"e"))
        assert False
    except ValueError:
        assert True


def test_duplicate_rejected():
    h,_=hub()
    x=HubSignal("s1",SignalDomain.LEARNING,"p1",assessment(),"e1")
    h.submit(x)
    try:
        h.submit(x)
        assert False
    except ValueError:
        assert True


def test_result_reaches_audit():
    h,s=hub()
    h.submit(HubSignal("s2",SignalDomain.LABORATORY,"p2",assessment(),"e2"))
    assert s.latest("p2").event_id=="e2"


def test_counts_start_empty():
    h,_=hub()
    assert all(v==0 for v in h.counts().values())
