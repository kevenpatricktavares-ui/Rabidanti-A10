"""Rabidanti v3.61 — controlled adaptive prioritization proposals.

Learns cautiously from recorded priority outcomes. It proposes bounded weight
changes from observed associations; it never applies them automatically.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable

from priority_learning import PriorityLearningStore, PriorityOutcome


@dataclass(frozen=True)
class AdaptationProposal:
    factor: str
    current_weight: float
    proposed_weight: float
    delta: float
    evidence_count: int
    confidence: float
    direction: str
    rationale: str

    def to_dict(self) -> dict:
        return asdict(self)


class AdaptivePrioritizationEngine:
    """Generate bounded, explainable proposals from historical outcomes.

    Association is treated as evidence for review, never as proof of causation.
    Proposals are capped and require explicit approval before any strategy change.
    """

    MIN_GROUP = 3
    MAX_DELTA = 0.05

    def __init__(self, store: PriorityLearningStore, current_weights: dict[str, float] | None = None):
        self.store = store
        from intelligence_prioritization import IntelligencePrioritizer
        self.weights = dict(current_weights or IntelligencePrioritizer.WEIGHTS)
        self._validate_weights(self.weights)

    @staticmethod
    def _validate_weights(weights: dict[str, float]) -> None:
        if not weights:
            raise ValueError("weights are required")
        if any(not isinstance(k, str) or not k for k in weights):
            raise ValueError("weight names must be non-empty strings")
        if any(not -1.0 <= float(v) <= 1.0 for v in weights.values()):
            raise ValueError("weights must be between -1 and 1")

    def propose(self) -> tuple[AdaptationProposal, ...]:
        outcomes = [o for o in self.store.list() if o.outcome in {"COMPLETED", "FAILED"}]
        if len(outcomes) < self.MIN_GROUP * 2:
            return ()
        proposals: list[AdaptationProposal] = []
        for factor, weight in self.weights.items():
            observations = [o for o in outcomes if factor in getattr(o, "components", {})]
            high = [o for o in observations if float(o.components[factor]) >= 0.5]
            low = [o for o in observations if float(o.components[factor]) < 0.5]
            if len(high) < self.MIN_GROUP or len(low) < self.MIN_GROUP:
                continue
            high_rate = sum(o.outcome == "COMPLETED" for o in high) / len(high)
            low_rate = sum(o.outcome == "COMPLETED" for o in low) / len(low)
            diff = high_rate - low_rate
            if abs(diff) < 0.20:
                continue
            direction = "INCREASE" if diff > 0 else "DECREASE"
            delta = min(self.MAX_DELTA, max(-self.MAX_DELTA, diff * 0.05))
            proposed = round(float(weight) + delta, 4)
            confidence = round(min(1.0, abs(diff) * min(len(high), len(low)) / 10.0), 4)
            rationale = (
                f"High-vs-low {factor} completion difference is {diff:.2f}; "
                "this is an association, not proof of causation."
            )
            proposals.append(AdaptationProposal(
                factor, float(weight), proposed, round(delta, 4),
                len(high) + len(low), confidence, direction, rationale,
            ))
        return tuple(sorted(proposals, key=lambda p: (-p.confidence, p.factor)))

    def proposed_weights(self) -> dict[str, float]:
        result = dict(self.weights)
        for proposal in self.propose():
            result[proposal.factor] = proposal.proposed_weight
        return result
