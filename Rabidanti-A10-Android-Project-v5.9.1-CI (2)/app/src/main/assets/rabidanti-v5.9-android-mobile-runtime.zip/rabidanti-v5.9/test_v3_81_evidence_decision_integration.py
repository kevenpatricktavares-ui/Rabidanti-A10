from evidence_decision_integration import (
    EvidenceDecision, EvidenceDecisionInput, EvidenceToDecisionIntegration
)


def test_strong_evidence_reaches_approval_gate():
    e=EvidenceToDecisionIntegration()
    r=e.decide(EvidenceDecisionInput(.9,.9,.9,.1,.1))
    assert r.decision is EvidenceDecision.APPROVAL_REQUIRED
    assert r.approval_required


def test_low_independence_investigates():
    e=EvidenceToDecisionIntegration(min_independence=.5)
    r=e.decide(EvidenceDecisionInput(.95,.2,.9,.1,.1))
    assert r.decision is EvidenceDecision.INVESTIGATE
    assert not r.approval_required


def test_weak_fused_evidence_investigates():
    e=EvidenceToDecisionIntegration(min_evidence=.7)
    r=e.decide(EvidenceDecisionInput(.55,.9,.9,.1,.1))
    assert r.decision is EvidenceDecision.INVESTIGATE


def test_medium_case_experiment():
    e=EvidenceToDecisionIntegration()
    r=e.decide(EvidenceDecisionInput(.72,.8,.5,.5,.5))
    assert r.decision is EvidenceDecision.EXPERIMENT


def test_bad_case_rejected():
    e=EvidenceToDecisionIntegration()
    r=e.decide(EvidenceDecisionInput(.8,.8,.0,1.0,1.0))
    assert r.decision is EvidenceDecision.REJECT


def test_invalid_factors_blocked():
    e=EvidenceToDecisionIntegration()
    try:
        e.decide(EvidenceDecisionInput(1.1,.8,.8,.2,.2))
        assert False
    except ValueError:
        pass


def test_no_authority_to_activate_or_approve():
    e=EvidenceToDecisionIntegration()
    for method in (e.activate, e.approve):
        try:
            method()
            assert False
        except PermissionError:
            pass
