# Rabidanti v3.48 — World Awareness → Opportunity Intelligence

## Purpose
Convert world-awareness signals into traceable business opportunity hypotheses.

## Flow
World Source → World Signal → Opportunity Candidate → Research/Experiment → Validation

## Guarantees
- Candidate status starts as `HYPOTHESIS`.
- World source provenance is preserved.
- Confidence and freshness are inherited from the world signal.
- Unverified sources remain explicitly marked.
- No demand, willingness-to-pay, competition or commercial success is inferred from a world signal alone.
- Existing OpportunityEngine can consume the candidate through a compatibility bridge, while limitations remain explicit.

## Scope
This version does not fetch the web, publish products, spend money, or declare market opportunities validated.
