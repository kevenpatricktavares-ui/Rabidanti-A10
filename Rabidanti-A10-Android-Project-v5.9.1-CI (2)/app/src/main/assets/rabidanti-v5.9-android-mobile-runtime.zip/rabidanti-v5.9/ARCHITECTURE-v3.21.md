# Rabidanti v3.21 — Capacity Intelligence 2

Adds bounded capacity history, lightweight queue forecasting and non-destructive prioritization recommendations. Runner health can expose current capacity plus forecast when CapacityIntelligence is supplied. Forecasts are local heuristics, not guarantees, and do not autoscale or spend money.
