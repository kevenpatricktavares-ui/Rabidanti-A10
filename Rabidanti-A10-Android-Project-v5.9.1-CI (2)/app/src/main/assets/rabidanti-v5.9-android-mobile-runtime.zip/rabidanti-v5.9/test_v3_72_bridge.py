import pytest
from evolution_decision_controller_bridge import (
    EvolutionDecisionControllerBridge, GateResult
)
from evolution_evidence_decision import EvolutionEvidenceDecisionEngine, EvidenceAssessment


class StubController:
    def __init__(self): self.calls=[]
    def request_activation(self, pid): self.calls.append(("request",pid)); return "requested"
    def activate(self, pid, approval=False):
        self.calls.append(("activate",pid,approval)); return "activated"


def assess(**x):
    b=dict(evidence_confidence=.9, expected_impact=.8, risk=.2,
           estimated_cost=.2, reversibility=.9)
    b.update(x); return EvidenceAssessment(**b)


def test_strong_decision_enters_approval_gate():
    c=StubController()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    g=b.assess("p1", assess())
    assert g.gate is GateResult.ALLOWED


def test_weak_decision_blocked():
    c=StubController()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    g=b.assess("p1", assess(evidence_confidence=.4))
    assert g.gate is GateResult.BLOCKED


def test_activation_requires_explicit_approval():
    c=StubController()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    with pytest.raises(PermissionError):
        b.request_activation("p1", assess())


def test_approved_request_delegates_to_controller():
    c=StubController()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    assert b.request_activation("p1", assess(), approval=True)=="requested"
    assert c.calls==[("request","p1")]


def test_activate_never_bypasses_approval():
    c=StubController()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    with pytest.raises(PermissionError):
        b.activate("p1")


def test_approved_activation_delegates():
    c=StubController()
    b=EvolutionDecisionControllerBridge(c, EvolutionEvidenceDecisionEngine())
    assert b.activate("p1", approval=True)=="activated"
