from dataclasses import dataclass
from datetime import datetime, timezone
from evolution_evidence_fusion import EvidenceFusion
from evidence_decision_integration import EvidenceDecisionInput, EvidenceDecisionResult, EvidenceToDecisionIntegration


@dataclass(frozen=True)
class EvidenceRuntimeResult:
    event_id: str
    proposal_id: str
    fusion_id: str
    decision: str
    score: float
    approval_required: bool
    created_at: str


class EvolutionEvidenceRuntime:
    """Durable-facing orchestration for fused evidence -> decision.

    This layer validates and converts a completed EvidenceFusion into the
    existing v3.81 decision vocabulary, then persists the complete decision
    record through the supplied store. It has no activation or deployment
    authority.
    """

    def __init__(self, decision_engine=None, store=None):
        if decision_engine is None:
            decision_engine = EvidenceToDecisionIntegration()
        if store is None:
            raise ValueError("store is required")
        self.decision_engine = decision_engine
        self.store = store

    def evaluate(self, proposal_id, fusion: EvidenceFusion, *, reversibility, risk, cost, event_id):
        if not proposal_id or not proposal_id.strip():
            raise ValueError("proposal_id is required")
        if not event_id or not event_id.strip():
            raise ValueError("event_id is required")
        if not fusion.fusion_id:
            raise ValueError("fusion_id is required")
        assessment = EvidenceDecisionInput(
            fusion_score=float(fusion.fused_score),
            independence=float(fusion.independent_weight),
            reversibility=float(reversibility),
            risk=float(risk),
            cost=float(cost),
        )
        result = self.decision_engine.decide(assessment)
        created_at = datetime.now(timezone.utc).isoformat()
        self.store.record_evidence_decision(
            event_id=event_id,
            proposal_id=proposal_id,
            fusion_id=fusion.fusion_id,
            decision=result.decision.value,
            score=result.score,
            approval_required=result.approval_required,
            evidence_count=fusion.evidence_count,
            independence=fusion.independent_weight,
            fusion_score=fusion.fused_score,
            rationale=result.rationale,
            created_at=created_at,
        )
        return EvidenceRuntimeResult(
            event_id=event_id,
            proposal_id=proposal_id,
            fusion_id=fusion.fusion_id,
            decision=result.decision.value,
            score=result.score,
            approval_required=result.approval_required,
            created_at=created_at,
        )

    def activate(self, *args, **kwargs):
        raise PermissionError("activation belongs to Evolution Controller")

    def deploy(self, *args, **kwargs):
        raise PermissionError("deployment belongs to authorized execution workflows")
