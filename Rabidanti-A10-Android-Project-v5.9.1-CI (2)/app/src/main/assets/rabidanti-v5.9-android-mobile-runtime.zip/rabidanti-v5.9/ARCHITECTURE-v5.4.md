# Rabidanti v5.4 — Windows Build Validation & Installer Release Candidate

## Goal

Make the native Windows release pipeline auditable and deterministic without claiming that native artifacts exist before they are actually built and tested.

## Single version source

`VERSION` is the only authoritative product version. `rabidanti_release.py sync` derives:

- PyInstaller `FixedFileInfo` file/product versions;
- Windows FileVersion/ProductVersion strings;
- Inno Setup `MyAppVersion`;
- installer output filename.

Manual version duplication is treated as an error by `preflight`.

## Native build validation

`rabidanti_release.py postbuild` accepts only actual artifact files and validates a minimum Windows PE structure (`MZ`, PE pointer, `PE\\0\\0`) before calculating SHA-256. It then creates `release-manifest.json` from the exact bytes built.

The source distribution intentionally ships without `release-manifest.json`. Therefore a source ZIP cannot be mistaken for a natively validated Windows release.

## Build stages

1. `build_windows.bat`
   - prepares build venv/dependencies;
   - synchronizes release metadata;
   - runs release preflight;
   - runs full test suite and compileall;
   - builds `dist\\Rabidanti.exe` with PyInstaller;
   - smoke-tests the real EXE;
   - validates PE/hash and creates an EXE-only release manifest.

2. `build_release_windows.bat`
   - invokes `build_windows.bat`;
   - requires Inno Setup 6 (`ISCC.exe`);
   - creates `Rabidanti-Setup-<VERSION>.exe`;
   - validates both EXE and Setup PE/hash;
   - rewrites `release-manifest.json` with both native artifacts.

If Inno Setup is unavailable, installer validation fails explicitly with exit code 2.

## Security boundary

v5.4 changes packaging/release validation only. It does not expand connector permissions, model tool authority, external actions or automatic update authority.
