# Rabidanti v3.86 — Prototype & Acceptance Validation

Adds a persistent prototype registry with versioned descriptions/artifact references, acceptance tests, validation gates, integration proposals with risk and rollback fields, and explicit human approval before a prototype can be marked integrated.

This module records and governs prototype lifecycle. It does **not** execute arbitrary code, fetch research sources, deploy applications, or change the Core. Keep experimental work isolated and inspect artifacts before integration.

Run tests from the project root with `pytest -q`.
