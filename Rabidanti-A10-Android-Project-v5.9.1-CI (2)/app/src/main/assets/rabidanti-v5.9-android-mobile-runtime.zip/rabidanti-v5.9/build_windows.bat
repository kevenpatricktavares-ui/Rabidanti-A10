@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where py >nul 2>nul || (echo Python launcher not found.& exit /b 1)
if not exist ".build-venv\Scripts\python.exe" py -3 -m venv .build-venv || exit /b 1
call .build-venv\Scripts\activate.bat || exit /b 1
python -m pip install --upgrade pip || exit /b 1
python -m pip install -r requirements-dev.txt || exit /b 1

python rabidanti_release.py sync || exit /b 1
python rabidanti_release.py preflight || exit /b 1
python -m pytest -q test_v5_*.py test_v4_*.py || exit /b 1
python -m pytest -q test_v3_*.py || exit /b 1
set PYTHONPATH=.
python -m pytest -q tests || exit /b 1
python -m compileall -q . || exit /b 1

pyinstaller --noconfirm --clean Rabidanti.spec || exit /b 1
if not exist "dist\Rabidanti.exe" (echo Build failed: dist\Rabidanti.exe missing.& exit /b 1)
set "RABIDANTI_OUTPUT_FILE=%TEMP%\rabidanti-build-info.json"
"dist\Rabidanti.exe" product build-info || exit /b 1
if not exist "%RABIDANTI_OUTPUT_FILE%" (echo Build-info evidence missing.& exit /b 1)
set "RABIDANTI_OUTPUT_FILE="
python rabidanti_release.py postbuild --exe "dist\Rabidanti.exe" || exit /b 1

echo Built and validated: dist\Rabidanti.exe
endlocal
