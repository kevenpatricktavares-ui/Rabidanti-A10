# Rabidanti v4.1 — Local API & Service Layer

v4.1 extends the v4.0 local runtime with a standard-library HTTP API intended for local control and future UI integration.

## Start the API

```bash
python rabidanti.py --state-dir .rabidanti serve
```

Default address: `http://127.0.0.1:8765`.

The service refuses non-loopback bind addresses. Mutating requests require a bearer token. Supply one with `--api-token` or `RABIDANTI_API_TOKEN`; otherwise an ephemeral token is generated and printed once to stderr. The token is not persisted by Rabidanti.

## Read endpoints

- `GET /health`
- `GET /v1/status`
- `GET /v1/doctor`
- `GET /v1/tasks`
- `GET /v1/evidence`
- `GET /v1/events`
- `GET /v1/workflows`

## Mutation endpoint

`POST /v1/tasks` with `Authorization: Bearer <token>` and JSON body such as:

```json
{"name":"Research opportunity","priority":"HIGH"}
```

## Security boundary

The v4.1 API does not expose a shell, arbitrary command execution, Core integration authorization, external-account actions, spending, publication, or scientific-validation authority. Loopback-only binding is a deliberate boundary, not a claim of internet-facing hardening.
