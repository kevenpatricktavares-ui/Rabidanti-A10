# Rabidanti v5.7 — Product Self-Test & Operational Readiness

v5.7 adds an integrated, non-destructive product self-test. It runs in a temporary state directory and verifies runtime startup, SQLite/config health, safety boundaries, task persistence across restart, audit events, and that built-in connectors remain disabled by default.

Run:

```bash
python rabidanti.py --state-dir .rabidanti product self-test
```

The supplied `--state-dir` is **not initialized or modified** by the self-test. It is only used to choose a nearby temporary parent directory. The test does not call Gmail, Ollama, other providers, or execute reasoning proposals. Docker/Podman remains an optional environment check and does not make the self-test fail when unavailable.

A passing self-test means the local product foundation is operational in the current environment. It does **not** prove Windows native packaging, external provider connectivity, container isolation, or scientific validity.
