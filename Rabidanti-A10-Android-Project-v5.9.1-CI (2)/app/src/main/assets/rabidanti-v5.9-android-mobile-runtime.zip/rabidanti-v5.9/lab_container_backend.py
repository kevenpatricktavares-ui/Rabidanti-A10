"""Rabidanti v3.89: container backend readiness and safe execution planning.

This module never executes user-provided code. It probes a container runtime and
builds a constrained command plan for a caller-reviewed, prebuilt image/entrypoint.
Runtime presence alone is not proof of effective isolation.
"""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json, shutil, subprocess

@dataclass(frozen=True)
class RuntimeProbe:
    runtime: str | None
    version: str | None
    available: bool
    daemon_reachable: bool
    assessed_at: str
    digest: str

class LabContainerBackend:
    RUNTIMES = ("podman", "docker")
    @classmethod
    def probe(cls, timeout=3):
        if not isinstance(timeout, (int, float)) or timeout <= 0 or timeout > 10:
            raise ValueError("timeout must be in (0, 10]")
        runtime = next(((n, shutil.which(n)) for n in cls.RUNTIMES if shutil.which(n)), None)
        version = None; reachable = False
        if runtime:
            name, path = runtime
            try:
                # Fixed, read-only command; never interpolate user input.
                p = subprocess.run([path, "version", "--format", "{{.Client.Version}}"], capture_output=True, text=True, timeout=timeout, check=False, env={"PATH":"/usr/bin:/bin","LANG":"C"})
                version = (p.stdout or p.stderr).strip()[:200] or None
                reachable = p.returncode == 0
            except (OSError, subprocess.TimeoutExpired):
                pass
        payload = {"runtime": runtime[0] if runtime else None, "version": version, "available": bool(runtime), "daemon_reachable": reachable, "assessed_at": datetime.now(timezone.utc).isoformat()}
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return RuntimeProbe(payload["runtime"], version, bool(runtime), reachable, payload["assessed_at"], digest)

    @staticmethod
    def build_plan(image, entrypoint, workspace, *, memory="256m", cpus="1.0", pids=64, timeout=30, network=False):
        """Return a conservative plan, not an execution. Image must be pinned by digest."""
        for value, label in ((image,"image"),(entrypoint,"entrypoint"),(workspace,"workspace")):
            if not isinstance(value, str) or not value.strip() or value.startswith("-"):
                raise ValueError(f"invalid {label}")
        if "@sha256:" not in image:
            raise ValueError("image must be pinned by sha256 digest")
        if not memory.endswith(("m","g")) or not cpus.replace(".","",1).isdigit():
            raise ValueError("invalid resource limits")
        if not isinstance(pids,int) or not 1 <= pids <= 512 or not isinstance(timeout,int) or not 1 <= timeout <= 300:
            raise ValueError("pids/timeout outside allowed range")
        cmd = ["--rm", "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--user=65534:65534", f"--memory={memory}", f"--cpus={cpus}", f"--pids-limit={pids}", "--network=none" if not network else "--network=bridge", "--tmpfs=/tmp:rw,noexec,nosuid,size=16m", "--mount", f"type=bind,src={workspace},dst=/work,rw", image, entrypoint]
        return {"runtime_args":cmd,"timeout_seconds":timeout,"network_enabled":network,"execution_performed":False,"requires_operator_review":True}

    @staticmethod
    def report(probe):
        return json.dumps(asdict(probe), indent=2, ensure_ascii=False)
