# Rabidanti v3.36 — Content Review Integration

Business pipeline now executes Content -> Review through a deterministic quality gate.

Flow:
Research -> Opportunity -> Product -> Content -> Review

The Review Engine consumes the persisted Content artifact and produces a ReviewBrief with checks, score, blockers and recommendations. BLOCKED reviews prevent a later stage from treating content as approved. This is a local SQLite/in-process foundation; it does not claim legal certification, factual omniscience, or publication approval.
