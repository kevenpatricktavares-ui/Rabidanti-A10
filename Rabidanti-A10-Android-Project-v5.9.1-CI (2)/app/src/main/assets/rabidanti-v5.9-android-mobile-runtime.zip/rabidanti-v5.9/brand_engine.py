"""Rabidanti v3.38 — deterministic brand brief generation."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping

@dataclass(frozen=True)
class BrandBrief:
    project_id: str
    name: str
    positioning: str
    promise: str
    tone: str
    visual_direction: str
    primary_product: str
    source_stage: str = "product"
    render_reference: str = ""
    limitations: tuple[str, ...] = ()
    def to_dict(self) -> dict[str, Any]: return asdict(self)

class BrandEngine:
    def build(self, project_id: str, product: Mapping[str, Any], render: Mapping[str, Any]) -> BrandBrief:
        if not str(project_id).strip(): raise ValueError("project_id must not be empty")
        if not product: raise ValueError("product must not be empty")
        if not render: raise ValueError("render must not be empty")
        name = str(product.get("name") or product.get("title") or "Rabidanti Product").strip()
        audience = str(product.get("target_audience") or "the intended audience").strip()
        value = str(product.get("value_proposition") or "A practical solution to the stated problem.").strip()
        positioning = f"A practical {product.get('product_type','digital')} for {audience}."
        tone = "clear, practical, trustworthy, human and action-oriented"
        visual = "clean editorial system, strong hierarchy, readable typography, restrained accents"
        limitations = ("Brand direction is a working brief and requires final creative review.",)
        return BrandBrief(str(project_id), name, positioning, value, tone, visual, name, "product",
                          str(render.get("output_path") or ""), limitations)
