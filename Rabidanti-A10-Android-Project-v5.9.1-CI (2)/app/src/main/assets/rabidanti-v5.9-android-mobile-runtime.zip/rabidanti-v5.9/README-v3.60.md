# Rabidanti v3.60

Priority Outcome Feedback & Learning.

The system records what happened after an intelligence-priority decision and turns accumulated outcomes into bounded, auditable feedback. It deliberately separates observation from automatic adaptation.
