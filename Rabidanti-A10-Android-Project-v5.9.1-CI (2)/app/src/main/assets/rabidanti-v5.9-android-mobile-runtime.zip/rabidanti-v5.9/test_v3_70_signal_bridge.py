import pytest
from core_evolution_signal_bridge import (
    CoreEvolutionSignalBridge,
    EvolutionSignal,
    SignalType,
)


class DummyController:
    pass


def bridge():
    return CoreEvolutionSignalBridge(DummyController())


def test_signal_is_recorded():
    b = bridge()
    s = b.record_signal(EvolutionSignal(
        "s1", SignalType.HEALTH, "error_rate", 0.2, 0.1, 0.9, ("obs-1",)
    ))
    assert s.signal_id == "s1"
    assert b.get_signal("s1").delta == pytest.approx(0.1)


def test_low_confidence_blocks_proposal():
    b = bridge()
    b.record_signal(EvolutionSignal(
        "s1", SignalType.PERFORMANCE, "latency", 20, 10, 0.4
    ))
    with pytest.raises(ValueError, match="insufficient evidence"):
        b.propose("p1", "strategy.a", "test", ["s1"])


def test_proposal_requires_approval():
    b = bridge()
    b.record_signal(EvolutionSignal(
        "s1", SignalType.LEARNING, "score", 0.9, 0.7, 0.9
    ))
    p = b.propose("p1", "strategy.a", "validated improvement", ["s1"])
    assert p.requires_approval is True
    assert p.confidence == pytest.approx(0.9)


def test_duplicate_signal_rejected():
    b = bridge()
    s = EvolutionSignal("s1", SignalType.KNOWLEDGE, "gap", 0.3, 0.2, 0.8)
    b.record_signal(s)
    with pytest.raises(ValueError, match="duplicate"):
        b.record_signal(s)


def test_unknown_signal_rejected():
    b = bridge()
    with pytest.raises(KeyError, match="unknown signal"):
        b.propose("p1", "strategy.a", "missing evidence", ["nope"])
