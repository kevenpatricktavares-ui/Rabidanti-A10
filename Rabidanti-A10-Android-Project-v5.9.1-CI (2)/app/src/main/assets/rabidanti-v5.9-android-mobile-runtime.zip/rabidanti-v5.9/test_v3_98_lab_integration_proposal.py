import sqlite3
import pytest

from lab_evidence_memory import LabEvidenceMemory
from lab_experiment_manager import LabExperimentManager
from lab_human_review import LabHumanReviewWorkflow
from lab_integration_proposal import LabIntegrationProposalWorkflow


def make_approved(tmp_path, decision="APPROVED"):
    m = LabExperimentManager(tmp_path / "lab.sqlite3")
    m.create("e1", "p1", "proposal flow", "hypothesis", "method", ["criterion A"])
    m.transition("e1", "RUNNING", "start")
    m.transition("e1", "ANALYSIS", "analysis")
    m.transition("e1", "PASSED", "pass")
    for rid in ("r1", "r2"):
        m.add_entry("e1", f"{rid}:result", "RESULT", "completed", {
            "run_id": rid, "experiment_id": "e1", "executed": True, "status": "completed"
        })
        m.add_entry("e1", f"a-{rid}:analysis", "RECOMMENDATION", "review", {
            "analysis_id": f"a-{rid}", "experiment_id": "e1", "run_id": rid,
            "classification": "PASSED", "integration_authorized": False,
        })
    m.add_entry("e1", "rep-1:reproducibility", "RECOMMENDATION", "repro", {
        "reproducibility_id": "rep-1", "experiment_id": "e1", "run_ids": ["r1", "r2"],
        "classification": "CONSISTENT", "integration_authorized": False,
    })
    mem = LabEvidenceMemory(tmp_path / "evidence.sqlite3")
    reviews = LabHumanReviewWorkflow(m, mem, tmp_path / "reviews.sqlite3")
    review = reviews.open_review("e1", requested_by="creator")
    reviews.decide(review["review_id"], decision, decided_by="creator", rationale="reviewed evidence")
    proposals = LabIntegrationProposalWorkflow(reviews, mem, tmp_path / "proposals.sqlite3")
    return m, mem, reviews, proposals, reviews.get(review["review_id"])


def proposal_kwargs(**overrides):
    values = dict(
        title="Integrate laboratory capability",
        summary="Introduce the validated laboratory capability behind an explicit permission boundary.",
        target_component="Core/Laboratory bridge",
        affected_files=["core_orchestrator.py", "lab_bridge.py"],
        change_plan=["Add adapter", "Wire adapter behind approval gate"],
        test_plan=["Run unit tests", "Run full regression suite"],
        rollback_plan=["Restore previous files", "Re-run baseline tests"],
        risks=["Unexpected coupling with Core", "Regression in orchestration"],
        created_by="creator",
    )
    values.update(overrides)
    return values


def test_approved_review_creates_persistent_non_executable_proposal(tmp_path):
    _, mem, _, proposals, review = make_approved(tmp_path)
    p = proposals.create(review["review_id"], **proposal_kwargs())
    assert p["status"] == proposals.PROPOSED
    assert p["integration_authorized"] is False
    assert p["external_action_authorized"] is False
    assert p["scientifically_validated"] is False
    node = mem.get_node(p["proposal_id"])
    assert node["kind"] == "ARTIFACT"
    assert node["metadata"]["requires_separate_integration_approval"] is True


def test_non_approved_human_review_cannot_create_proposal(tmp_path):
    _, _, _, proposals, review = make_approved(tmp_path, decision="REJECTED")
    with pytest.raises(ValueError, match="APPROVED human review"):
        proposals.create(review["review_id"], **proposal_kwargs())


def test_proposal_requires_concrete_change_test_rollback_and_risk_plans(tmp_path):
    _, _, _, proposals, review = make_approved(tmp_path)
    for field in ("affected_files", "change_plan", "test_plan", "rollback_plan", "risks"):
        kwargs = proposal_kwargs(**{field: []})
        with pytest.raises(ValueError, match=field):
            proposals.create(review["review_id"], **kwargs)


def test_affected_files_reject_absolute_traversal_and_windows_paths(tmp_path):
    _, _, _, proposals, review = make_approved(tmp_path)
    for path in ("/etc/passwd", "../core.py", "core/../../secret", r"C:\\Windows\\system.ini"):
        with pytest.raises(ValueError, match="affected_files"):
            proposals.create(review["review_id"], **proposal_kwargs(affected_files=[path]))


def test_identical_proposal_is_idempotent(tmp_path):
    _, _, _, proposals, review = make_approved(tmp_path)
    a = proposals.create(review["review_id"], **proposal_kwargs())
    b = proposals.create(review["review_id"], **proposal_kwargs())
    assert a["proposal_id"] == b["proposal_id"]
    with sqlite3.connect(proposals.database) as c:
        assert c.execute("SELECT COUNT(*) FROM lab_integration_proposals").fetchone()[0] == 1
        assert c.execute("SELECT COUNT(*) FROM lab_integration_proposal_events").fetchone()[0] == 1


def test_materially_changed_proposal_creates_new_immutable_record(tmp_path):
    _, _, _, proposals, review = make_approved(tmp_path)
    a = proposals.create(review["review_id"], **proposal_kwargs())
    b = proposals.create(review["review_id"], **proposal_kwargs(summary="A materially revised integration approach."))
    assert a["proposal_id"] != b["proposal_id"]
    assert len(proposals.history("e1")["proposals"]) == 2


def test_proposal_is_bound_to_exact_approved_decision_evidence(tmp_path):
    _, mem, _, proposals, review = make_approved(tmp_path)
    decision_id = f"human-review-decision:{review['review_id']}"
    with mem._connect() as c:
        row = c.execute("SELECT metadata FROM lab_evidence_nodes WHERE node_id=?", (decision_id,)).fetchone()
        import json
        meta = json.loads(row["metadata"])
        meta["evidence_snapshot_digest"] = "tampered"
        c.execute("UPDATE lab_evidence_nodes SET metadata=? WHERE node_id=?", (json.dumps(meta), decision_id))
    with pytest.raises(ValueError, match="snapshot"):
        proposals.create(review["review_id"], **proposal_kwargs())


def test_proposal_links_decision_readiness_and_experiment(tmp_path):
    _, mem, _, proposals, review = make_approved(tmp_path)
    p = proposals.create(review["review_id"], **proposal_kwargs())
    trace = mem.trace(p["proposal_id"])
    relations = {(x["from_id"], x["relation"], x["to_id"]) for x in trace["links"]}
    assert (p["proposal_id"], "BASED_ON_READINESS", review["readiness_id"]) in relations
    assert (f"human-review-decision:{review['review_id']}", "HAS_INTEGRATION_PROPOSAL", p["proposal_id"]) in relations
    assert ("experiment:e1", "HAS_INTEGRATION_PROPOSAL", p["proposal_id"]) in relations


def test_proposal_survives_restart_and_history_is_auditable(tmp_path):
    _, mem, reviews, proposals, review = make_approved(tmp_path)
    p = proposals.create(review["review_id"], **proposal_kwargs())
    restarted = LabIntegrationProposalWorkflow(reviews, mem, tmp_path / "proposals.sqlite3")
    assert restarted.get(p["proposal_id"])["proposal_digest"] == p["proposal_digest"]
    history = restarted.history("e1")
    assert history["proposals"][0]["proposal_id"] == p["proposal_id"]
    assert history["integration_authorized"] is False


def test_v398_cannot_apply_or_self_authorize(tmp_path):
    _, _, _, proposals, review = make_approved(tmp_path)
    p = proposals.create(review["review_id"], **proposal_kwargs())
    with pytest.raises(PermissionError, match="cannot authorize"):
        proposals.authorize_integration(p["proposal_id"])
    with pytest.raises(PermissionError, match="non-executable"):
        proposals.apply(p["proposal_id"])
    with pytest.raises(PermissionError, match="external actions"):
        proposals.authorize_external_action(p["proposal_id"])
