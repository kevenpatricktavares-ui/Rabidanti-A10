# Rabidanti v3.65

Controlled Experiment Promotion Governance.

This release adds an explicit promotion boundary after v3.64 experiment-aware execution. A promising experiment can produce a promotion proposal, but no production weight changes automatically. Explicit approval is required, and applying the proposal returns a new weight mapping without mutating the controller's stored production configuration.
