import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class EvidenceDecisionEvent:
    event_id: str
    proposal_id: str
    fusion_id: str
    decision: str
    score: float
    approval_required: bool
    evidence_count: int
    independence: float
    fusion_score: float
    rationale: str
    created_at: str


class EvolutionEvidenceStore:
    """Durable store for evidence-to-decision outcomes."""

    def __init__(self, db_path=":memory:"):
        self.db = sqlite3.connect(db_path)
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_evidence_decisions (
                event_id TEXT PRIMARY KEY,
                proposal_id TEXT NOT NULL,
                fusion_id TEXT NOT NULL,
                decision TEXT NOT NULL,
                score REAL NOT NULL,
                approval_required INTEGER NOT NULL,
                evidence_count INTEGER NOT NULL,
                independence REAL NOT NULL,
                fusion_score REAL NOT NULL,
                rationale TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        self.db.commit()

    def record_evidence_decision(self, *, event_id, proposal_id, fusion_id,
                                 decision, score, approval_required,
                                 evidence_count, independence, fusion_score,
                                 rationale, created_at):
        if not event_id or not proposal_id or not fusion_id:
            raise ValueError("event_id, proposal_id and fusion_id are required")
        try:
            self.db.execute(
                """INSERT INTO evolution_evidence_decisions
                (event_id, proposal_id, fusion_id, decision, score,
                 approval_required, evidence_count, independence, fusion_score,
                 rationale, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (event_id, proposal_id, fusion_id, decision, float(score),
                 int(bool(approval_required)), int(evidence_count),
                 float(independence), float(fusion_score), rationale, created_at)
            )
            self.db.commit()
        except sqlite3.IntegrityError:
            raise ValueError("duplicate event_id")

    def list_events(self, proposal_id=None):
        q = """SELECT event_id, proposal_id, fusion_id, decision, score,
                       approval_required, evidence_count, independence,
                       fusion_score, rationale, created_at
                FROM evolution_evidence_decisions"""
        args = ()
        if proposal_id:
            q += " WHERE proposal_id = ?"
            args = (proposal_id,)
        q += " ORDER BY created_at, event_id"
        rows = self.db.execute(q, args).fetchall()
        return [EvidenceDecisionEvent(*r[:5], bool(r[5]), *r[6:]) for r in rows]

    def latest(self, proposal_id):
        events = self.list_events(proposal_id)
        return events[-1] if events else None

    def close(self):
        self.db.close()
