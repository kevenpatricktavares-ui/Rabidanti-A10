@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call build_windows.bat || exit /b 1
where ISCC.exe >nul 2>nul || (
  echo Inno Setup compiler ISCC.exe not found. Install Inno Setup 6 and rerun.
  exit /b 2
)
ISCC.exe installer_windows.iss || exit /b 1
echo Installer built under installer-dist\
endlocal
