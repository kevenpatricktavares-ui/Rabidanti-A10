"""Rabidanti v4.8 local model discovery and selection.

The manager only talks to the already loopback-restricted Ollama gateway. It can
inspect installed models and choose a configured primary/fallback model, but it
cannot download, delete, or execute model-management shell commands.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import httpx

from rabidanti_model_gateway import LocalOllamaGateway, ModelGatewayError


@dataclass(frozen=True)
class ModelSelection:
    selected: str
    requested: str
    fallback_used: bool
    installed: tuple[str, ...]


class ModelManager:
    def __init__(self, gateway: LocalOllamaGateway):
        self.gateway = gateway

    def installed_models(self) -> list[dict[str, Any]]:
        try:
            client = self.gateway._client or httpx.Client(timeout=min(self.gateway.timeout_seconds, 5.0))
            close = self.gateway._client is None
            try:
                response = client.get(self.gateway.base_url + "/api/tags")
                response.raise_for_status()
                data = response.json()
            finally:
                if close:
                    client.close()
        except Exception as exc:
            raise ModelGatewayError(f"model discovery failed: {type(exc).__name__}") from exc
        models = data.get("models", []) if isinstance(data, dict) else []
        if not isinstance(models, list):
            raise ModelGatewayError("model discovery returned invalid payload")
        out=[]
        for item in models:
            if not isinstance(item, dict):
                continue
            name=item.get("name") or item.get("model")
            if isinstance(name, str) and name.strip():
                out.append({
                    "name": name.strip(),
                    "size": item.get("size"),
                    "modified_at": item.get("modified_at"),
                    "digest": item.get("digest"),
                })
        return out

    def select(self, requested: str, fallback: str | None = None) -> ModelSelection:
        if not isinstance(requested, str) or not requested.strip():
            raise ValueError("requested model is required")
        requested=requested.strip()
        fallback=fallback.strip() if isinstance(fallback,str) and fallback.strip() else None
        installed=tuple(x["name"] for x in self.installed_models())
        if requested in installed:
            return ModelSelection(requested, requested, False, installed)
        if fallback and fallback in installed:
            return ModelSelection(fallback, requested, True, installed)
        raise ModelGatewayError("configured model is not installed and no installed fallback is available")

    def status(self, requested: str, fallback: str | None = None) -> dict[str, Any]:
        try:
            selection=self.select(requested, fallback)
            return {
                "reachable": True,
                "requested": selection.requested,
                "selected": selection.selected,
                "fallback_used": selection.fallback_used,
                "installed": list(selection.installed),
            }
        except ModelGatewayError as exc:
            health=self.gateway.health()
            return {
                "reachable": bool(health.get("reachable")),
                "requested": requested,
                "selected": None,
                "fallback_used": False,
                "installed": [],
                "error": str(exc),
            }
