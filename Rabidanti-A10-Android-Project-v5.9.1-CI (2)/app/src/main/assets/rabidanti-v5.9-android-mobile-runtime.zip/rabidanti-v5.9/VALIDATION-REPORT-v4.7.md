# Rabidanti v4.7 — Relatório de Validação

## Baseline
- versão anterior: 4.6.0
- baseline confirmada: 579/579 testes aprovados

## Alterações
- gateway local Ollama loopback-only;
- conversa persistente em SQLite;
- histórico reutilizável por conversation_id;
- integração runtime/API/Sala;
- configuração de modelo, base URL e timeout;
- resposta de modelo sem ferramentas/autorização.

## Testes novos
`test_v4_7_model_conversation.py`: 10/10 aprovados.

## Regressão completa
Coleta: 589 testes.
- grupo 1: 107 passed
- grupo 2: 108 passed
- grupo 3: 94 passed
- grupo 4: 100 passed
- grupo 5: 87 passed
- grupo 6: 93 passed

TOTAL: 589 passed / 0 failed.

## Compilação e smoke
- `python -m compileall -q .`: PASS
- runtime status com VERSION=4.7.0: PASS
- base URL default loopback: PASS

## Limitações
- nenhum servidor Ollama/modelo real foi validado neste ambiente;
- o gateway foi exercitado com HTTP mocks controlados;
- o modelo não tem tool execution nem autorização externa.
