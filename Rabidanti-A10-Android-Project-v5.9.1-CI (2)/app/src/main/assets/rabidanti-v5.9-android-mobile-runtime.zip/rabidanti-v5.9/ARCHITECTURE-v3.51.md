# Rabidanti v3.51 — Continuous Opportunity Runtime

Connects PersistentScheduler → DurableWorkerQueue → ContinuousWorkerRunner → OpportunityDiscoveryEngine.

The runtime schedules recurring scans over already-ingested World Awareness signals, persists discovered themes, and deduplicates repeated scans by topic + signal IDs.

It does not fetch the web itself, does not invent current-world data, and does not claim candidate themes are validated commercial opportunities.

Pipeline:
World Awareness → Scheduler → Durable Queue → Worker → Opportunity Discovery → Persistent Discovery Records → Opportunity Intelligence Loop.

Still a local/in-process foundation; cloud deployment, external broker, autoscaling and always-on remote hosting remain future infrastructure work.
