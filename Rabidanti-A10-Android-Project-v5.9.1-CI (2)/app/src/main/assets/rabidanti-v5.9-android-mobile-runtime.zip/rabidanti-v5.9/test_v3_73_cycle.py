from evolution_cycle_store import EvolutionCycleStore, EvolutionCycleEvent
from evolution_cycle_audit import EvolutionCycleAudit
from evolution_decision_controller_bridge import ControllerGateDecision, GateResult


def gate(pid="p1", decision="approval_required", score=.8):
    return ControllerGateDecision(pid, decision, score, GateResult.ALLOWED, "ok")


def test_persists_event():
    s=EvolutionCycleStore()
    a=EvolutionCycleAudit(s)
    e=a.record_assessment(gate(), "e1")
    assert s.latest("p1")==e


def test_reject_gate_is_persisted():
    s=EvolutionCycleStore()
    a=EvolutionCycleAudit(s)
    g=ControllerGateDecision("p2","reject",.2,GateResult.BLOCKED,"blocked")
    a.record_assessment(g,"e2")
    x=s.latest("p2")
    assert x.gate=="blocked"
    assert x.decision=="reject"


def test_duplicate_event_rejected():
    s=EvolutionCycleStore()
    e=EvolutionCycleEvent("e1","p1","X","approval_required",.8,"allowed","ok","2026-01-01")
    s.record(e)
    try:
        s.record(e)
        assert False
    except ValueError:
        assert True


def test_filter_by_proposal():
    s=EvolutionCycleStore()
    s.record(EvolutionCycleEvent("e1","p1","X","approval_required",.8,"allowed","a","2026-01-01"))
    s.record(EvolutionCycleEvent("e2","p2","X","reject",.2,"blocked","b","2026-01-02"))
    assert [x.proposal_id for x in s.list_events("p1")] == ["p1"]


def test_empty_latest_is_none():
    assert EvolutionCycleStore().latest("missing") is None
