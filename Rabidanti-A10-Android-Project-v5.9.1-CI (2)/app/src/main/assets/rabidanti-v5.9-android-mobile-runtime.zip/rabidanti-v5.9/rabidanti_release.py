#!/usr/bin/env python3
"""Release tooling for Rabidanti desktop builds.

Keeps Windows metadata derived from VERSION, validates source/build configuration,
and validates real PE/installer artifacts when they exist. It never fabricates a
successful native build.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

SEMVER_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


class ReleaseValidationError(RuntimeError):
    pass


def read_version(root: Path) -> str:
    value = (root / "VERSION").read_text(encoding="utf-8").strip()
    if not SEMVER_RE.fullmatch(value):
        raise ReleaseValidationError(f"VERSION is not strict SemVer x.y.z: {value!r}")
    return value


def version_quad(version: str) -> tuple[int, int, int, int]:
    match = SEMVER_RE.fullmatch(version)
    if not match:
        raise ReleaseValidationError(f"invalid version: {version!r}")
    return tuple(map(int, match.groups())) + (0,)


def render_version_info(version: str) -> str:
    quad = version_quad(version)
    return f'''# UTF-8\nVSVersionInfo(\n  ffi=FixedFileInfo(filevers={quad}, prodvers={quad}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0,0)),\n  kids=[\n    StringFileInfo([StringTable('040904B0', [\n      StringStruct('CompanyName', 'Rabidanti'),\n      StringStruct('FileDescription', 'Rabidanti Personal AI'),\n      StringStruct('FileVersion', '{version}'),\n      StringStruct('InternalName', 'Rabidanti'),\n      StringStruct('OriginalFilename', 'Rabidanti.exe'),\n      StringStruct('ProductName', 'Rabidanti'),\n      StringStruct('ProductVersion', '{version}')\n    ])]),\n    VarFileInfo([VarStruct('Translation', [1033, 1200])])\n  ]\n)\n'''


def render_installer(version: str) -> str:
    return f'''#define MyAppName "Rabidanti"\n#define MyAppVersion "{version}"\n#define MyAppExeName "Rabidanti.exe"\n\n[Setup]\nAppId={{{{7E0F0F39-35CA-4E0B-9E09-A9A4A0E12152}}\nAppName={{#MyAppName}}\nAppVersion={{#MyAppVersion}}\nDefaultDirName={{localappdata}}\\Programs\\Rabidanti\nDefaultGroupName=Rabidanti\nOutputDir=installer-dist\nOutputBaseFilename=Rabidanti-Setup-{version}\nCompression=lzma2\nSolidCompression=yes\nPrivilegesRequired=lowest\nArchitecturesInstallIn64BitMode=x64compatible\nSetupIconFile=assets\\rabidanti.ico\nUninstallDisplayIcon={{app}}\\{{#MyAppExeName}}\n\n[Files]\nSource: "dist\\Rabidanti.exe"; DestDir: "{{app}}"; Flags: ignoreversion\n\n[Icons]\nName: "{{group}}\\Rabidanti"; Filename: "{{app}}\\{{#MyAppExeName}}"\nName: "{{autodesktop}}\\Rabidanti"; Filename: "{{app}}\\{{#MyAppExeName}}"; Tasks: desktopicon\n\n[Tasks]\nName: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked\n\n[Run]\nFilename: "{{app}}\\{{#MyAppExeName}}"; Description: "Launch Rabidanti"; Flags: nowait postinstall skipifsilent\n'''


def sync_metadata(root: Path) -> dict[str, str]:
    version = read_version(root)
    (root / "rabidanti_version_info.txt").write_text(render_version_info(version), encoding="utf-8", newline="\n")
    (root / "installer_windows.iss").write_text(render_installer(version), encoding="utf-8", newline="\n")
    return {"version": version, "version_info": "rabidanti_version_info.txt", "installer": "installer_windows.iss"}


def _require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def validate_release_tree(root: Path) -> dict[str, Any]:
    version = read_version(root)
    quad = version_quad(version)
    errors: list[str] = []

    spec = (root / "Rabidanti.spec").read_text(encoding="utf-8")
    version_info = (root / "rabidanti_version_info.txt").read_text(encoding="utf-8")
    installer = (root / "installer_windows.iss").read_text(encoding="utf-8")
    build = (root / "build_windows.bat").read_text(encoding="utf-8")
    release_build = (root / "build_release_windows.bat").read_text(encoding="utf-8") if (root / "build_release_windows.bat").exists() else ""

    _require(f"filevers={quad}" in version_info, "FixedFileInfo filevers does not match VERSION", errors)
    _require(f"prodvers={quad}" in version_info, "FixedFileInfo prodvers does not match VERSION", errors)
    _require(f"StringStruct('FileVersion', '{version}')" in version_info, "FileVersion string mismatch", errors)
    _require(f"StringStruct('ProductVersion', '{version}')" in version_info, "ProductVersion string mismatch", errors)
    _require(f'#define MyAppVersion "{version}"' in installer, "installer version mismatch", errors)
    _require(f"OutputBaseFilename=Rabidanti-Setup-{version}" in installer, "installer output name mismatch", errors)
    _require("PrivilegesRequired=lowest" in installer, "installer must remain per-user", errors)
    _require('console=False' in spec, "PyInstaller spec must remain windowed", errors)
    _require('version="rabidanti_version_info.txt"' in spec, "PyInstaller spec missing version metadata", errors)
    _require('icon="assets/rabidanti.ico"' in spec, "PyInstaller spec missing icon", errors)
    _require('("VERSION", ".")' in spec, "PyInstaller spec must bundle VERSION", errors)
    _require("rabidanti_release.py sync" in build, "build_windows.bat must sync release metadata", errors)
    _require("rabidanti_release.py preflight" in build, "build_windows.bat must run release preflight", errors)
    _require("rabidanti_release.py postbuild" in build, "build_windows.bat must validate the real executable", errors)
    _require("iscc" in release_build.lower(), "release build must invoke Inno Setup (iscc)", errors)
    _require("release-manifest.json" in release_build, "release build must require release-manifest.json", errors)
    _require("verify_windows_release.ps1" in release_build, "release build must run Windows end-to-end verification", errors)
    _require("windows-release-validation.json" in release_build, "release build must require Windows validation evidence", errors)
    _require((root / "verify_windows_release.ps1").exists(), "Windows native verifier is missing", errors)
    _require((root / "native_release_check.py").exists(), "native release evidence checker is missing", errors)
    workflow = root / ".github" / "workflows" / "windows-native-release.yml"
    _require(workflow.exists(), "Windows native release workflow is missing", errors)
    _require((root / "windows-toolchain.json").exists(), "Windows toolchain contract is missing", errors)
    _require((root / "windows_handoff.py").exists(), "Windows handoff checker is missing", errors)
    _require((root / "prepare_windows_build.ps1").exists(), "Windows build preparation script is missing", errors)
    _require((root / "BUILD-WINDOWS-RELEASE.cmd").exists(), "one-command Windows release launcher is missing", errors)

    icon = root / "assets" / "rabidanti.ico"
    _require(icon.exists() and icon.stat().st_size > 1000, "desktop icon missing or suspiciously small", errors)
    if errors:
        raise ReleaseValidationError("; ".join(errors))
    return {"ok": True, "version": version, "checks": 25}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_pe(path: Path) -> dict[str, Any]:
    """Validate enough of a PE image to reject mislabeled/non-GUI artifacts.

    This is intentionally structural rather than a substitute for Windows execution.
    Native execution is validated separately by verify_windows_release.ps1.
    """
    if not path.exists() or not path.is_file():
        raise ReleaseValidationError(f"artifact missing: {path}")
    size = path.stat().st_size
    if size < 1024:
        raise ReleaseValidationError(f"artifact too small to be a Windows PE executable: {path}")
    with path.open("rb") as handle:
        if handle.read(2) != b"MZ":
            raise ReleaseValidationError(f"missing MZ header: {path}")
        handle.seek(0x3C)
        raw = handle.read(4)
        if len(raw) != 4:
            raise ReleaseValidationError(f"truncated DOS header: {path}")
        pe_offset = int.from_bytes(raw, "little")
        handle.seek(pe_offset)
        if handle.read(4) != b"PE\0\0":
            raise ReleaseValidationError(f"missing PE signature: {path}")
        coff = handle.read(20)
        if len(coff) != 20:
            raise ReleaseValidationError(f"truncated COFF header: {path}")
        machine = int.from_bytes(coff[0:2], "little")
        optional_size = int.from_bytes(coff[16:18], "little")
        optional = handle.read(optional_size)
        if len(optional) != optional_size or optional_size < 70:
            raise ReleaseValidationError(f"truncated PE optional header: {path}")
        magic = int.from_bytes(optional[0:2], "little")
        if magic not in {0x10B, 0x20B}:
            raise ReleaseValidationError(f"unsupported PE optional-header magic 0x{magic:04x}: {path}")
        subsystem = int.from_bytes(optional[68:70], "little")
    machine_names = {0x014C: "x86", 0x8664: "x64", 0xAA64: "arm64"}
    subsystem_names = {2: "windows_gui", 3: "windows_cui"}
    return {
        "path": str(path),
        "size": size,
        "sha256": sha256_file(path),
        "pe": True,
        "machine": machine_names.get(machine, f"0x{machine:04x}"),
        "pe_format": "PE32+" if magic == 0x20B else "PE32",
        "subsystem": subsystem_names.get(subsystem, str(subsystem)),
    }


def create_release_manifest(root: Path, exe: Path, installer: Path | None = None) -> dict[str, Any]:
    """Create a build-integrity manifest.

    `native_build_validated` means the supplied native artifacts are structurally valid
    PE files. End-to-end install/launch validation is represented separately by
    windows-release-validation.json and must be produced on Windows.
    """
    version = read_version(root)
    artifacts = {"executable": validate_pe(exe)}
    if artifacts["executable"]["subsystem"] != "windows_gui":
        raise ReleaseValidationError("Rabidanti.exe must use the Windows GUI subsystem")
    if installer is not None:
        artifacts["installer"] = validate_pe(installer)
    manifest = {
        "schema": 2,
        "product": "Rabidanti",
        "version": version,
        "native_build_validated": True,
        "end_to_end_windows_validated": False,
        "artifacts": artifacts,
    }
    (root / "release-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Rabidanti release validator")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("sync")
    sub.add_parser("preflight")
    post = sub.add_parser("postbuild")
    post.add_argument("--exe", required=True)
    post.add_argument("--installer")
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parent
    try:
        if args.command == "sync":
            result = sync_metadata(root)
        elif args.command == "preflight":
            result = validate_release_tree(root)
        else:
            validate_release_tree(root)
            installer = Path(args.installer).resolve() if args.installer else None
            result = create_release_manifest(root, Path(args.exe).resolve(), installer)
    except ReleaseValidationError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
