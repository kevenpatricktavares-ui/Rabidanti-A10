from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path

from rabidanti_selftest import ProductSelfTest


def test_version_is_at_least_5_7():
    version = tuple(map(int, Path("VERSION").read_text().strip().split(".")))
    assert version >= (5, 7, 0)


def test_selftest_is_isolated_and_healthy(tmp_path):
    result = ProductSelfTest(tmp_path).run()
    assert result["healthy"] is True
    assert result["isolated"] is True
    assert result["persistent_user_state_modified"] is False
    assert result["external_network_required"] is False
    assert result["external_action_authorized"] is False


def test_selftest_exercises_runtime_and_persistence(tmp_path):
    result = ProductSelfTest(tmp_path).run()
    checks = {x["name"]: x for x in result["checks"]}
    for name in ["runtime_start", "runtime_doctor", "task_write", "task_read", "audit_event", "restart_persistence"]:
        assert checks[name]["ok"] is True, checks[name]


def test_selftest_preserves_safety_boundaries(tmp_path):
    result = ProductSelfTest(tmp_path).run()
    checks = {x["name"]: x for x in result["checks"]}
    assert checks["safety_boundaries"]["ok"] is True
    assert checks["connectors_disabled_by_default"]["ok"] is True


def test_container_runtime_is_optional(tmp_path):
    result = ProductSelfTest(tmp_path).run()
    check = next(x for x in result["checks"] if x["name"] == "container_runtime")
    assert check["optional"] is True


def test_selftest_does_not_leave_state_tree(tmp_path):
    ProductSelfTest(tmp_path).run()
    assert list(tmp_path.iterdir()) == []


def test_cli_exposes_product_selftest(tmp_path):
    state = tmp_path / "real-user-state"
    cp = subprocess.run(
        [sys.executable, "rabidanti.py", "--state-dir", str(state), "product", "self-test"],
        text=True, capture_output=True, check=True,
    )
    payload = json.loads(cp.stdout)
    assert payload["healthy"] is True
    assert not state.exists(), "self-test must not initialize the requested user state"


def test_selftest_never_claims_scientific_validation(tmp_path):
    result = ProductSelfTest(tmp_path).run()
    assert result["scientific_validation_claimed"] is False


def test_release_metadata_tracks_5_7():
    version = Path("VERSION").read_text().strip()
    info = Path("rabidanti_version_info.txt").read_text()
    installer = Path("installer_windows.iss").read_text()
    assert f"FileVersion', '{version}'" in info
    assert f'#define MyAppVersion "{version}"' in installer


def test_readme_documents_selftest():
    text = Path("README.md").read_text(encoding="utf-8")
    assert "product self-test" in text
