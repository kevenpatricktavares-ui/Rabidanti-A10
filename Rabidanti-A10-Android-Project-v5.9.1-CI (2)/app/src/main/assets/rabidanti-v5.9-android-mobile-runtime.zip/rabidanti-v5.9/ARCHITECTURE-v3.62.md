# Rabidanti v3.62 — Controlled Adaptive Experimentation

v3.62 adds a shadow-evaluation layer for adaptive prioritization proposals.

Flow:
`outcomes → bounded proposal → historical shadow evaluation → recommendation → approval/forward test`

The evaluator compares the historical separation between completed and failed work under current versus proposed weights. It is deliberately retrospective and does not claim causality.

Guarantees:
- proposals remain bounded and are not applied automatically;
- insufficient evidence blocks evaluation;
- the current weight set is not mutated;
- no work is executed and no approvals are bypassed;
- a promising retrospective result still requires explicit approval and a forward test before production adoption;
- unknown factors are rejected deterministically.

This is an experimentation foundation, not autonomous self-modification.
