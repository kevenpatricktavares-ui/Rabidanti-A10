"""Rabidanti v3.19 — bounded automatic recovery controller."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

from recovery_engine import RecoveryEngine, RecoveryReport


@dataclass
class RecoveryControllerStats:
    cycles: int = 0
    applied_actions: int = 0
    skipped_actions: int = 0
    last_run: Optional[float] = None


class RecoveryController:
    """Run health-driven recovery on a bounded cadence.

    The controller does not invent recovery actions. It delegates to the
    conservative RecoveryEngine and rate-limits recovery cycles so a degraded
    system cannot continuously hammer its own recovery path.
    """

    def __init__(self, engine: RecoveryEngine, interval_seconds: float = 5.0):
        if interval_seconds < 0:
            raise ValueError("interval_seconds must be >= 0")
        self.engine = engine
        self.interval_seconds = float(interval_seconds)
        self.stats = RecoveryControllerStats()
        self.last_report: Optional[RecoveryReport] = None

    def due(self, now: Optional[float] = None) -> bool:
        now = time.time() if now is None else float(now)
        if self.stats.last_run is None:
            return True
        return now - self.stats.last_run >= self.interval_seconds

    def run_if_due(self, now: Optional[float] = None) -> Optional[RecoveryReport]:
        now = time.time() if now is None else float(now)
        if not self.due(now):
            return None
        report = self.engine.recover(now=now)
        self.last_report = report
        self.stats.cycles += 1
        self.stats.applied_actions += sum(a.status == "APPLIED" for a in report.actions)
        self.stats.skipped_actions += sum(a.status == "SKIPPED" for a in report.actions)
        self.stats.last_run = now
        return report
