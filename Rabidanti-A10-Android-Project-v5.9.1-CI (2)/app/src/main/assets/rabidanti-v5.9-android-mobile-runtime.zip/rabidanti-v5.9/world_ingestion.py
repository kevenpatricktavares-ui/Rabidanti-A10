"""Rabidanti v3.52 — controlled world-information ingestion.

Normalizes externally obtained records before they enter World Awareness.
This layer does not fetch the web and never upgrades verification on its own.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
import re, time
from typing import Optional, Iterable
from world_awareness import WorldAwareness, WorldSource

@dataclass(frozen=True)
class IngestionResult:
    source: WorldSource
    created: bool
    duplicate_of: Optional[str]
    normalized_hash: str

class WorldIntelligenceIngestion:
    def __init__(self, awareness: WorldAwareness):
        self.awareness = awareness

    @staticmethod
    def normalize_text(value: str) -> str:
        if value is None:
            return ""
        return re.sub(r"\s+", " ", str(value).strip())

    @classmethod
    def content_hash(cls, content: str) -> str:
        return sha256(cls.normalize_text(content).encode("utf-8")).hexdigest()

    def ingest(self, *, title: str, locator: str, publisher: str,
               content: str = "", kind: str = "web",
               published_at: Optional[float] = None,
               verified: bool = False, summary: str = "",
               fetched_at: Optional[float] = None) -> IngestionResult:
        title_n = self.normalize_text(title)
        locator_n = self.normalize_text(locator)
        publisher_n = self.normalize_text(publisher)
        kind_n = self.normalize_text(kind) or "web"
        summary_n = self.normalize_text(summary)
        content_n = self.normalize_text(content)
        if not title_n or not locator_n or not publisher_n:
            raise ValueError("title, locator and publisher are required")
        now = time.time() if fetched_at is None else float(fetched_at)
        if now > time.time() + 60:
            raise ValueError("fetched_at cannot be materially in the future")
        h = self.content_hash(content_n) if content_n else ""
        for existing in self.awareness.store.sources(1000):
            same_hash = bool(h) and bool(existing.content_hash) and existing.content_hash == h
            same_locator = existing.locator == locator_n
            if same_hash or same_locator:
                return IngestionResult(existing, False, existing.source_id, h or existing.content_hash)
        source = WorldSource(
            source_id="world-" + __import__("uuid").uuid4().hex,
            title=title_n, locator=locator_n, publisher=publisher_n,
            kind=kind_n, published_at=published_at, fetched_at=now,
            verified=bool(verified), content_hash=h, summary=summary_n,
        )
        self.awareness.store.save_source(source)
        return IngestionResult(source, True, None, h)

    def ingest_many(self, records: Iterable[dict]) -> list[IngestionResult]:
        return [self.ingest(**record) for record in records]
