# Rabidanti v3.12 — Continuous Worker Runner

v3.12 adds a continuous in-process runner over the v3.11 durable SQLite worker queue.

## Capabilities
- bounded concurrent workers;
- handler registry and dispatch;
- durable queue claims through worker leases;
- heartbeat renewal during execution;
- expired-work recovery;
- retry/failure handling delegated to the durable queue;
- graceful stop and completion of already claimed work;
- execution statistics.

## Deliberate limits
This release does **not** claim cloud deployment, external brokers, autoscaling,
leader election, multi-region failover, or production monitoring. Those remain later
infrastructure work. The runner is a local/in-process execution layer built on the
persistent v3.11 queue.
