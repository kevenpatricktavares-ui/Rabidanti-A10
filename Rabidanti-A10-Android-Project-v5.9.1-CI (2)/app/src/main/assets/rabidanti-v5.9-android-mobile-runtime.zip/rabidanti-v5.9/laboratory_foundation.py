"""Rabidanti v3.84 — persistent Laboratory workflow foundation."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional
from datetime import datetime, timezone
import json, sqlite3

class LabKind(str, Enum):
    SCIENCE="SCIENCE"; TECHNOLOGY="TECHNOLOGY"; AI="AI"; SOFTWARE="SOFTWARE"
    CYBER_DEFENSE="CYBER_DEFENSE"; DIGITAL_BUSINESS="DIGITAL_BUSINESS"
    PRODUCT="PRODUCT"; INTERNAL_IMPROVEMENT="INTERNAL_IMPROVEMENT"

class LabStage(str, Enum):
    PROJECT="PROJECT"; RESEARCH="RESEARCH"; HYPOTHESIS="HYPOTHESIS"
    EXPERIMENT="EXPERIMENT"; PROTOTYPE="PROTOTYPE"; VALIDATION="VALIDATION"
    DISCOVERY="DISCOVERY"; REJECTED="REJECTED"

@dataclass(frozen=True)
class LabRecord:
    record_id: str; title: str; kind: str; stage: str; summary: str
    evidence_refs: tuple[str,...]; confidence: float; result: str
    created_at: str; updated_at: str

class LaboratoryFoundation:
    _TRANSITIONS={
      LabStage.PROJECT:{LabStage.RESEARCH,LabStage.REJECTED},
      LabStage.RESEARCH:{LabStage.HYPOTHESIS,LabStage.REJECTED},
      LabStage.HYPOTHESIS:{LabStage.EXPERIMENT,LabStage.REJECTED},
      LabStage.EXPERIMENT:{LabStage.PROTOTYPE,LabStage.VALIDATION,LabStage.REJECTED},
      LabStage.PROTOTYPE:{LabStage.VALIDATION,LabStage.REJECTED},
      LabStage.VALIDATION:{LabStage.DISCOVERY,LabStage.RESEARCH,LabStage.REJECTED},
      LabStage.DISCOVERY:set(), LabStage.REJECTED:set()}
    def __init__(self,database="rabidanti_laboratory.sqlite3"):
        self.database=str(database); Path(self.database).parent.mkdir(parents=True,exist_ok=True); self._initialize()
    def _connect(self):
        c=sqlite3.connect(self.database); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c
    def _initialize(self):
        with self._connect() as c:
            c.execute("CREATE TABLE IF NOT EXISTS lab_records(record_id TEXT PRIMARY KEY,title TEXT NOT NULL,kind TEXT NOT NULL,stage TEXT NOT NULL,summary TEXT NOT NULL,evidence_refs TEXT NOT NULL DEFAULT '[]',confidence REAL NOT NULL DEFAULT 0,result TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS lab_events(event_id TEXT PRIMARY KEY,record_id TEXT NOT NULL,from_stage TEXT,to_stage TEXT NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(record_id) REFERENCES lab_records(record_id))")
    @staticmethod
    def _now(): return datetime.now(timezone.utc).isoformat()
    @staticmethod
    def _convert(r):
        return LabRecord(r['record_id'],r['title'],r['kind'],r['stage'],r['summary'],tuple(json.loads(r['evidence_refs'])),float(r['confidence']),r['result'],r['created_at'],r['updated_at'])
    def create_project(self,record_id,title,kind,summary):
        if not isinstance(record_id,str) or not record_id.strip(): raise ValueError('record_id is required')
        if not isinstance(title,str) or not title.strip(): raise ValueError('title is required')
        if not isinstance(kind,LabKind): raise ValueError('kind must be a LabKind')
        if not isinstance(summary,str) or not summary.strip(): raise ValueError('summary is required')
        now=self._now()
        with self._connect() as c:
            try:
                c.execute("INSERT INTO lab_records VALUES(?,?,?,?,?,'[]',0,'',?,?)",(record_id,title.strip(),kind.value,LabStage.PROJECT.value,summary.strip(),now,now))
                c.execute("INSERT INTO lab_events VALUES(?,?,?,?,?,?)",(f'{record_id}:created',record_id,None,LabStage.PROJECT.value,'Project created',now))
            except sqlite3.IntegrityError as e: raise ValueError('duplicate record_id') from e
        return self.get(record_id)
    def get(self,record_id):
        with self._connect() as c: r=c.execute('SELECT * FROM lab_records WHERE record_id=?',(record_id,)).fetchone()
        if r is None: raise KeyError(record_id)
        return self._convert(r)
    def transition(self,record_id,to_stage,*,event_id,note='',evidence_refs=None,confidence=None,result=None):
        if not isinstance(event_id,str) or not event_id.strip(): raise ValueError('event_id is required')
        if not isinstance(to_stage,LabStage): raise ValueError('to_stage must be a LabStage')
        if confidence is not None and (not isinstance(confidence,(int,float)) or not 0<=confidence<=1): raise ValueError('confidence must be between 0 and 1')
        refs=None
        if evidence_refs is not None:
            if any(not isinstance(x,str) or not x.strip() for x in evidence_refs): raise ValueError('evidence references must be non-empty strings')
            refs=json.dumps(list(dict.fromkeys(evidence_refs)))
        now=self._now()
        with self._connect() as c:
            r=c.execute('SELECT * FROM lab_records WHERE record_id=?',(record_id,)).fetchone()
            if r is None: raise KeyError(record_id)
            current=LabStage(r['stage'])
            if to_stage not in self._TRANSITIONS[current]: raise ValueError(f'invalid transition: {current.value} -> {to_stage.value}')
            try: c.execute('INSERT INTO lab_events VALUES(?,?,?,?,?,?)',(event_id,record_id,current.value,to_stage.value,note.strip(),now))
            except sqlite3.IntegrityError as e: raise ValueError('duplicate event_id') from e
            c.execute('UPDATE lab_records SET stage=?,evidence_refs=COALESCE(?,evidence_refs),confidence=COALESCE(?,confidence),result=COALESCE(?,result),updated_at=? WHERE record_id=?',(to_stage.value,refs,confidence,result,now,record_id))
        return self.get(record_id)
    def list_records(self,stage=None,kind=None):
        clauses=[]; args=[]
        if stage is not None: clauses.append('stage=?'); args.append(stage.value)
        if kind is not None: clauses.append('kind=?'); args.append(kind.value)
        sql='SELECT * FROM lab_records'+((' WHERE '+' AND '.join(clauses)) if clauses else '')+' ORDER BY created_at,record_id'
        with self._connect() as c: rows=c.execute(sql,args).fetchall()
        return [self._convert(r) for r in rows]
    def list_events(self,record_id):
        with self._connect() as c: rows=c.execute('SELECT event_id,record_id,from_stage,to_stage,note,created_at FROM lab_events WHERE record_id=? ORDER BY created_at,event_id',(record_id,)).fetchall()
        return [dict(r) for r in rows]
