# Rabidanti v3.96 — Validation Report

## Baseline
- Source: Rabidanti v3.95 Laboratory Evidence Flow Integration.
- Rechecked before modification: 456 tests passed, 0 failed.
- v3.95 source package preserved separately.

## Version
- New version: 3.96.0
- Feature: Laboratory Evidence Readiness Gate.

## Implemented
- `lab_evidence_readiness.py`.
- Synchronizes authoritative v3.85+ experiment records through the v3.95 Evidence Memory bridge before assessment.
- Builds a deterministic evidence snapshot digest.
- Requires a PASSED experiment, configurable minimum verified executed runs (default 2), PASSED reviewed analysis for counted runs, and CONSISTENT reproducibility covering the required executed runs.
- Persists readiness assessments as Evidence Memory `DECISION` nodes.
- Uses snapshot-derived IDs so repeated assessment of unchanged evidence is idempotent; changed evidence creates a new auditable decision record.
- Records supporting analysis/reproducibility links.
- Exposes only `READY_FOR_HUMAN_REVIEW`, `NOT_READY`, or `INSUFFICIENT_EVIDENCE`.
- Explicitly records `scientifically_validated=False` and `integration_authorized=False`.
- Provides no execution, deployment, Core mutation, or integration authority.

## Tests added
8 tests cover:
1. full positive readiness path;
2. insufficient run count;
3. failed analysis;
4. divergent reproducibility;
5. idempotent persistence;
6. new assessment after evidence changes;
7. refusal to authorize integration;
8. minimum-run input validation.

## Regression result
- Full suite: 464 passed, 0 failed.

## Known limitations
- Readiness evaluates internal recorded evidence and graph consistency only.
- It does not independently validate source truth or scientific validity.
- It does not prove external reproducibility.
- Real Docker/Podman isolation remains unverified in this environment unless a compatible runtime is separately demonstrated.
- Human approval remains mandatory for critical integration.
