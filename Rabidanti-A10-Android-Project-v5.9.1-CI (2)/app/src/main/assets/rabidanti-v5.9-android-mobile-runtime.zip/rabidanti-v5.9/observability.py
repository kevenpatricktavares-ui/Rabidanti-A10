"""Rabidanti v3.16 — Observability and telemetry foundation."""
from __future__ import annotations
import sqlite3, threading, time
from dataclasses import dataclass
from typing import Optional

@dataclass
class MetricSample:
    name: str
    value: float
    timestamp: float
    labels: str = ""

@dataclass
class EventRecord:
    event_id: int
    kind: str
    timestamp: float
    worker_id: str = ""
    item_id: str = ""
    detail: str = ""

class ObservabilityStore:
    def __init__(self, db_path: str):
        self.db_path=db_path; self._lock=threading.RLock()
        self._conn=sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory=sqlite3.Row
        if db_path != ':memory:':
            self._conn.execute('PRAGMA journal_mode=WAL'); self._conn.execute('PRAGMA synchronous=NORMAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS telemetry_metrics(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, value REAL NOT NULL,
            timestamp REAL NOT NULL, labels TEXT NOT NULL DEFAULT '')''')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS telemetry_events(
            event_id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, timestamp REAL NOT NULL,
            worker_id TEXT NOT NULL DEFAULT '', item_id TEXT NOT NULL DEFAULT '', detail TEXT NOT NULL DEFAULT '')''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_metrics_name_time ON telemetry_metrics(name,timestamp)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_events_time ON telemetry_events(timestamp)')
    def metric(self,name,value,labels=''):
        if not name: raise ValueError('name is required')
        now=time.time()
        with self._lock:
            self._conn.execute('INSERT INTO telemetry_metrics(name,value,timestamp,labels) VALUES(?,?,?,?)',(name,float(value),now,labels or ''))
        return MetricSample(name,float(value),now,labels or '')
    def event(self,kind,worker_id='',item_id='',detail=''):
        if not kind: raise ValueError('kind is required')
        now=time.time()
        with self._lock:
            cur=self._conn.execute('INSERT INTO telemetry_events(kind,timestamp,worker_id,item_id,detail) VALUES(?,?,?,?,?)',(kind,now,worker_id or '',item_id or '',detail or ''))
            return EventRecord(int(cur.lastrowid),kind,now,worker_id or '',item_id or '',detail or '')
    def recent_metrics(self,name:Optional[str]=None,limit=100):
        if limit<1: raise ValueError('limit must be >= 1')
        q='SELECT name,value,timestamp,labels FROM telemetry_metrics'; args=[]
        if name: q+=' WHERE name=?'; args.append(name)
        q+=' ORDER BY timestamp DESC LIMIT ?'; args.append(int(limit))
        with self._lock: rows=self._conn.execute(q,args).fetchall()
        return [MetricSample(r['name'],float(r['value']),float(r['timestamp']),r['labels']) for r in rows]
    def recent_events(self,limit=100):
        if limit<1: raise ValueError('limit must be >= 1')
        with self._lock: rows=self._conn.execute('SELECT * FROM telemetry_events ORDER BY timestamp DESC LIMIT ?',(int(limit),)).fetchall()
        return [EventRecord(int(r['event_id']),r['kind'],float(r['timestamp']),r['worker_id'],r['item_id'],r['detail']) for r in rows]
    def summary(self):
        with self._lock:
            metrics=int(self._conn.execute('SELECT COUNT(*) FROM telemetry_metrics').fetchone()[0])
            events=int(self._conn.execute('SELECT COUNT(*) FROM telemetry_events').fetchone()[0])
        return {'metrics':metrics,'events':events}
    def close(self): self._conn.close()
