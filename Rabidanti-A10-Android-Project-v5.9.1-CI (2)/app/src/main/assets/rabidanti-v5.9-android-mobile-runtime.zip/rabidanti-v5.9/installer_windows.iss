#define MyAppName "Rabidanti"
#define MyAppVersion "5.9.0"
#define MyAppExeName "Rabidanti.exe"

[Setup]
AppId={{7E0F0F39-35CA-4E0B-9E09-A9A4A0E12152}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={localappdata}\Programs\Rabidanti
DefaultGroupName=Rabidanti
OutputDir=installer-dist
OutputBaseFilename=Rabidanti-Setup-5.9.0
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
SetupIconFile=assets\rabidanti.ico
UninstallDisplayIcon={app}\{#MyAppExeName}

[Files]
Source: "dist\Rabidanti.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Rabidanti"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Rabidanti"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Rabidanti"; Flags: nowait postinstall skipifsilent
