# Rabidanti v4.9 — Proposal Review & Tool Execution Bridge

## Objetivo
Fechar de forma controlada o ciclo entre propostas produzidas pelo Reasoning Runtime e ações executáveis, sem permitir que o modelo autorize ou execute ferramentas diretamente.

## Fluxo
Reasoning proposal → human review → explicit execution authorization → Permission Gate → execution → audit/result ledger.

## Fronteiras
- O modelo apenas cria propostas persistentes.
- Revisão humana final: APPROVED ou REJECTED.
- Revisão e autorização de execução são passos distintos.
- Cada autorização de execução é one-shot e fica consumida na tentativa.
- Uma falha pode ser repetida apenas após nova autorização explícita.
- Uma execução bem-sucedida da mesma proposta não pode ser repetida.
- Conectores WRITE continuam a exigir a aprovação one-shot independente do ConnectorRegistry, ligada ao digest exato do payload.
- Propostas de tarefas internas criam tarefas apenas depois de revisão + autorização + execução explícita.
- Digests da proposta são revalidados entre revisão, autorização e execução.

## Persistência
`proposal_bridge.sqlite3` contém:
- `proposal_reviews`
- `proposal_authorizations`
- `proposal_executions`
- metadata de schema

Os resultados de execução são persistidos com digest SHA-256 e trilho de auditoria.

## Superfícies
CLI:
- `proposal-review`
- `proposal-authorize`
- `proposal-execute`
- `proposal-reviews`
- `proposal-executions`

API local:
- GET `/v1/reasoning/reviews`
- GET `/v1/reasoning/executions`
- POST `/v1/reasoning/review`
- POST `/v1/reasoning/authorize`
- POST `/v1/reasoning/execute`

Sala:
- revisão, autorização e execução separadas, todas protegidas pelo token local.

## Não significa
- autonomia irrestrita;
- execução direta pelo LLM;
- bypass de permissões de conectores;
- validação científica automática;
- autorização geral para ações externas.
