# Rabidanti v4.6

**Live Connector Setup & Provider Management**

A v4.6 acrescenta gestão operacional de providers ao runtime local.

## Iniciar a Sala

```bash
python rabidanti.py room
```

Na aba **Providers** é possível configurar o Google OAuth Client ID/Secret, iniciar a autorização, testar a ligação e forçar refresh.

## CLI

```bash
python rabidanti.py provider list
```

Configuração temporária:

```bash
python rabidanti.py provider gmail-setup --client-id "SEU_CLIENT_ID"
```

Configuração persistente no vault cifrado (requer `RABIDANTI_VAULT_MASTER_KEY`):

```bash
python rabidanti.py provider gmail-setup --client-id "SEU_CLIENT_ID" --persist --with-client-secret
```

Iniciar OAuth:

```bash
python rabidanti.py oauth gmail-start
```

Teste e refresh:

```bash
python rabidanti.py provider gmail-test
python rabidanti.py provider gmail-refresh
```

## Operação após reinício

Para refresh automático persistente, disponibilize no vault/ambiente:

- `GOOGLE_CLIENT_ID`
- `GMAIL_REFRESH_TOKEN`
- `GOOGLE_CLIENT_SECRET` quando exigido pelo cliente OAuth

A master key do vault não é persistida pelo Rabidanti.

## Segurança

- loopback-only;
- Gmail read-only;
- conector desativado por defeito;
- tokens fora de `providers.sqlite3`;
- callback OAuth protegido por `state`;
- Bearer Token para configuração/teste/refresh pela API;
- sem armazenamento de credenciais no browser;
- sem autoautorização ou autorização geral de ações externas.

## Estado de validação

- 579 testes na v4.6;
- comportamento OAuth, refresh, callback e Gmail testado com mocks/controlos locais;
- **nenhuma conta Google real foi ligada durante esta validação**.
