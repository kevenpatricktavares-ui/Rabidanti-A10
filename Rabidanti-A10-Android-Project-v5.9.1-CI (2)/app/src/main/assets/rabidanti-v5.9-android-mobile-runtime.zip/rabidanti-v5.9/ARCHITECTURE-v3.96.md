# Rabidanti v3.96 — Laboratory Evidence Readiness Gate

## Purpose
Convert the persistent laboratory provenance graph into a conservative,
auditable readiness assessment for human review.

## Flow
Experiment ledger -> v3.95 evidence synchronization -> evidence snapshot ->
readiness checks -> DECISION node -> human review.

## Readiness conditions
- experiment status is PASSED;
- at least the configured minimum (default 2) verified executed runs;
- every counted run has a PASSED reviewed analysis;
- at least one CONSISTENT reproducibility assessment covers at least the
  configured minimum executed runs.

## Boundaries
`READY_FOR_HUMAN_REVIEW` is not scientific validation. The gate cannot execute,
deploy, approve, mutate the Core, or authorize integration. It records a
recommendation boundary only.
