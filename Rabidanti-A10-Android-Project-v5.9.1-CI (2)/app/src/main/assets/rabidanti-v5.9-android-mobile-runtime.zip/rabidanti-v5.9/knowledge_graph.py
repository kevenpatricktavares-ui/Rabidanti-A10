"""Rabidanti v3.55 — provenance-aware World Knowledge Graph.

Stores entities and typed relationships while preserving provenance. The graph
is deliberately descriptive: adding a relationship does not make it true.
Verification assessments can be attached to edges, and traversal can expose
provenance so downstream Laboratory/Opportunity modules can inspect evidence.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
import sqlite3, threading, time, uuid
from typing import Optional

class RelationStatus(str, Enum):
    PROPOSED = "PROPOSED"
    SUPPORTED = "SUPPORTED"
    VERIFIED = "VERIFIED"
    CONTESTED = "CONTESTED"
    REJECTED = "REJECTED"

@dataclass(frozen=True)
class KnowledgeEntity:
    entity_id: str
    entity_type: str
    name: str
    description: str = ""
    created_at: float = 0.0

@dataclass(frozen=True)
class KnowledgeRelation:
    relation_id: str
    subject_id: str
    predicate: str
    object_id: str
    status: RelationStatus
    confidence: float
    source_id: Optional[str]
    claim_id: Optional[str]
    note: str
    created_at: float

class KnowledgeGraphStore:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        if db_path != ':memory:': self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS knowledge_entities (
            entity_id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, name TEXT NOT NULL,
            description TEXT NOT NULL, created_at REAL NOT NULL)''')
        self._conn.execute('''CREATE TABLE IF NOT EXISTS knowledge_relations (
            relation_id TEXT PRIMARY KEY, subject_id TEXT NOT NULL, predicate TEXT NOT NULL,
            object_id TEXT NOT NULL, status TEXT NOT NULL, confidence REAL NOT NULL,
            source_id TEXT, claim_id TEXT, note TEXT NOT NULL, created_at REAL NOT NULL)''')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_kg_entity_name ON knowledge_entities(name)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_kg_rel_subject ON knowledge_relations(subject_id)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_kg_rel_object ON knowledge_relations(object_id)')
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_kg_rel_predicate ON knowledge_relations(predicate)')

    def save_entity(self, entity: KnowledgeEntity) -> None:
        with self._lock:
            self._conn.execute('INSERT OR REPLACE INTO knowledge_entities VALUES(?,?,?,?,?)', tuple(asdict(entity).values()))

    def entity(self, entity_id: str) -> Optional[KnowledgeEntity]:
        with self._lock:
            row = self._conn.execute('SELECT * FROM knowledge_entities WHERE entity_id=?', (entity_id,)).fetchone()
        return None if not row else KnowledgeEntity(**dict(row))

    def entities(self, entity_type: Optional[str] = None, limit: int = 500) -> list[KnowledgeEntity]:
        with self._lock:
            if entity_type:
                rows = self._conn.execute('SELECT * FROM knowledge_entities WHERE entity_type=? ORDER BY created_at ASC LIMIT ?', (entity_type, int(limit))).fetchall()
            else:
                rows = self._conn.execute('SELECT * FROM knowledge_entities ORDER BY created_at ASC LIMIT ?', (int(limit),)).fetchall()
        return [KnowledgeEntity(**dict(r)) for r in rows]

    def save_relation(self, relation: KnowledgeRelation) -> None:
        with self._lock:
            self._conn.execute('INSERT OR REPLACE INTO knowledge_relations VALUES(?,?,?,?,?,?,?,?,?,?)',
                (relation.relation_id, relation.subject_id, relation.predicate, relation.object_id,
                 relation.status.value, relation.confidence, relation.source_id, relation.claim_id,
                 relation.note, relation.created_at))

    def relation(self, relation_id: str) -> Optional[KnowledgeRelation]:
        with self._lock:
            row = self._conn.execute('SELECT * FROM knowledge_relations WHERE relation_id=?', (relation_id,)).fetchone()
        if not row: return None
        d = dict(row); d['status'] = RelationStatus(d['status'])
        return KnowledgeRelation(**d)

    def relations(self, entity_id: Optional[str] = None, predicate: Optional[str] = None, limit: int = 500) -> list[KnowledgeRelation]:
        clauses, params = [], []
        if entity_id:
            clauses.append('(subject_id=? OR object_id=?)'); params.extend([entity_id, entity_id])
        if predicate:
            clauses.append('predicate=?'); params.append(predicate)
        sql = 'SELECT * FROM knowledge_relations'
        if clauses: sql += ' WHERE ' + ' AND '.join(clauses)
        sql += ' ORDER BY created_at ASC LIMIT ?'; params.append(int(limit))
        with self._lock: rows = self._conn.execute(sql, tuple(params)).fetchall()
        result=[]
        for r in rows:
            d=dict(r); d['status']=RelationStatus(d['status']); result.append(KnowledgeRelation(**d))
        return result

class WorldKnowledgeGraph:
    def __init__(self, store: KnowledgeGraphStore): self.store = store

    def add_entity(self, *, name: str, entity_type: str, description: str = '', entity_id: Optional[str] = None, created_at: Optional[float] = None) -> KnowledgeEntity:
        name, entity_type = str(name).strip(), str(entity_type).strip()
        if not name or not entity_type: raise ValueError('name and entity_type are required')
        ts = time.time() if created_at is None else float(created_at)
        if ts > time.time() + 60: raise ValueError('created_at cannot be materially in the future')
        e=KnowledgeEntity(entity_id or 'entity-'+uuid.uuid4().hex, entity_type, name, str(description).strip(), ts)
        self.store.save_entity(e); return e

    def add_relation(self, *, subject_id: str, predicate: str, object_id: str, status: RelationStatus = RelationStatus.PROPOSED, confidence: float = 0.0, source_id: Optional[str] = None, claim_id: Optional[str] = None, note: str = '', relation_id: Optional[str] = None, created_at: Optional[float] = None) -> KnowledgeRelation:
        if self.store.entity(subject_id) is None or self.store.entity(object_id) is None: raise KeyError('subject and object entities must exist')
        predicate=str(predicate).strip()
        if not predicate: raise ValueError('predicate is required')
        confidence=float(confidence)
        if not 0 <= confidence <= 1: raise ValueError('confidence must be between 0 and 1')
        ts=time.time() if created_at is None else float(created_at)
        if ts > time.time()+60: raise ValueError('created_at cannot be materially in the future')
        r=KnowledgeRelation(relation_id or 'relation-'+uuid.uuid4().hex, subject_id, predicate, object_id, RelationStatus(status), confidence, source_id, claim_id, str(note).strip(), ts)
        self.store.save_relation(r); return r

    def neighbors(self, entity_id: str, *, predicate: Optional[str] = None, limit: int = 100) -> list[dict]:
        if self.store.entity(entity_id) is None: raise KeyError('entity not found')
        out=[]
        for r in self.store.relations(entity_id, predicate, limit):
            other_id = r.object_id if r.subject_id == entity_id else r.subject_id
            other=self.store.entity(other_id)
            out.append({'relation': r.to_dict() if hasattr(r,'to_dict') else asdict(r) | {'status': r.status.value}, 'entity': other.to_dict() if hasattr(other,'to_dict') else asdict(other)})
        return out

    def snapshot(self, limit: int = 500) -> dict:
        return {'entities':[asdict(e) for e in self.store.entities(limit=limit)], 'relations':[asdict(r)|{'status':r.status.value} for r in self.store.relations(limit=limit)]}
