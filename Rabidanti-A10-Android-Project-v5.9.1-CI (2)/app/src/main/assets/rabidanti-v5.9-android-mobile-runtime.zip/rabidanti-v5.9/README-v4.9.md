# Rabidanti v4.9

A v4.9 adiciona a ponte controlada entre as propostas do Reasoning Runtime e a execução real.

## Exemplo de fluxo CLI

```bash
python rabidanti.py proposals
python rabidanti.py proposal-review PROPOSAL_ID APPROVED --actor Esequiel --reason "Aprovo esta proposta"
python rabidanti.py proposal-authorize PROPOSAL_ID --actor Esequiel --reason "Autorizo uma tentativa controlada"
python rabidanti.py proposal-execute PROPOSAL_ID --actor Esequiel
python rabidanti.py proposal-executions
```

Para conectores com capacidade WRITE, a autorização cria também uma aprovação one-shot no Connector Permission Gate para o payload exato.

Uma autorização é consumida na tentativa. Se a tentativa falhar, uma nova autorização explícita é necessária. Se tiver sucesso, a mesma proposta não pode ser executada novamente.

O LLM não chama estas operações sozinho e não recebe autoridade para executar ferramentas.
