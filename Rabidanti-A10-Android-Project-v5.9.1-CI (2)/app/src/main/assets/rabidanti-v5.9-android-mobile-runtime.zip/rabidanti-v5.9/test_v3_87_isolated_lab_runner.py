import sys, pytest
from isolated_lab_runner import IsolatedLabRunner

def test_runs_allowlisted_python_in_temp_workspace(tmp_path):
    runner=IsolatedLabRunner(tmp_path, timeout_seconds=10)
    r=runner.run("smoke",[sys.executable,"-c","print('ok')"] if False else ["python3","-c","print('ok')"])
    assert r.status=="PASSED" and r.stdout.strip()=="ok"
    assert r.digest and tmp_path.as_posix() in r.workspace

def test_artifact_written_only_to_workspace(tmp_path):
    runner=IsolatedLabRunner(tmp_path)
    r=runner.run("artifact",["python3","-c","print(open('input.txt').read())"],files={"input.txt":"lab"})
    assert r.status=="PASSED" and r.stdout.strip()=="lab"

def test_rejects_non_allowlisted_executable(tmp_path):
    with pytest.raises(PermissionError): IsolatedLabRunner(tmp_path).run("no",["sh","-c","echo unsafe"])

def test_rejects_path_traversal(tmp_path):
    with pytest.raises(ValueError): IsolatedLabRunner(tmp_path).run("bad",["python3","-c","pass"],files={"../oops":"x"})

def test_timeout_is_reported(tmp_path):
    r=IsolatedLabRunner(tmp_path,timeout_seconds=1).run("slow",["python3","-c","import time; time.sleep(3)"],timeout_seconds=1)
    assert r.status=="TIMED_OUT"

def test_timeout_bounds_are_enforced(tmp_path):
    with pytest.raises(ValueError): IsolatedLabRunner(tmp_path,timeout_seconds=99)
