import os
import pytest
from lab_container_backend import LabContainerBackend
from lab_container_executor import LabContainerExecutor

IMAGE = "python@sha256:" + "a" * 64

def valid_plan(tmp_path):
    return LabContainerBackend.build_plan(IMAGE, "/usr/bin/python", str(tmp_path))

def test_requires_explicit_per_run_approval(tmp_path):
    with pytest.raises(PermissionError):
        LabContainerExecutor.execute(valid_plan(tmp_path), {"available": True, "daemon_reachable": True, "runtime": "docker"})

def test_fails_closed_when_runtime_unavailable(tmp_path):
    result = LabContainerExecutor.execute(valid_plan(tmp_path), {"available": False, "daemon_reachable": False, "runtime": None}, approved=True)
    assert result.status == "blocked_runtime_unavailable"
    assert not result.executed and result.audit_digest

def test_rejects_network_enabled_plan(tmp_path):
    plan = LabContainerBackend.build_plan(IMAGE, "/usr/bin/python", str(tmp_path), network=True)
    with pytest.raises(PermissionError):
        LabContainerExecutor.execute(plan, {"available": True, "daemon_reachable": True, "runtime": "docker"}, approved=True)

def test_rejects_missing_required_isolation_flag(tmp_path):
    plan = valid_plan(tmp_path)
    plan["runtime_args"].remove("--cap-drop=ALL")
    with pytest.raises(PermissionError):
        LabContainerExecutor.execute(plan, {"available": True, "daemon_reachable": True, "runtime": "docker"}, approved=True)

def test_timeout_bounds(tmp_path):
    with pytest.raises(ValueError):
        LabContainerExecutor.execute(valid_plan(tmp_path), {"available": True, "daemon_reachable": True, "runtime": "docker"}, approved=True, timeout=999)

def test_probe_result_contains_audit_digest():
    result = LabContainerExecutor._result("blocked", False, None, "", "", None, None)
    assert len(result.audit_digest) == 64
