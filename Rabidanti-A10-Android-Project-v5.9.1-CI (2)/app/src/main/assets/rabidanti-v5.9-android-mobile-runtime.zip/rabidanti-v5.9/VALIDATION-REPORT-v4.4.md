# Rabidanti v4.4 — Validation Report

## Input baseline

- Source package: `rabidanti-v4.3-configuration-secrets.zip`
- Input SHA-256: `c0afa10d390a51492c21ef71c251b7ca490ccba7fb77a498bcf03dbc63e60ac0`
- Input VERSION: `4.3.0`
- Baseline collected tests: 536
- Baseline result: 536 passed (executed in deterministic file groups because a single long tool call exceeded the host execution window)

## v4.4 implementation

Added:

- `rabidanti_connectors.py`
- persistent connector registry/state ledger;
- declared READ/WRITE capabilities;
- mandatory human approval for WRITE capabilities;
- exact-request SHA-256 binding;
- one-time approval consumption;
- required-secret checks through v4.3 non-persistent secret boundary;
- local rate limiting;
- audit-safe invocation history without raw payloads;
- runtime integration and connector status;
- connector database integrity diagnostic;
- local API discovery/control/approval endpoints;
- Sala connector visibility/control;
- CLI connector inspection and activation/deactivation.

No third-party connector or account is enabled by default.

## Security validation

Validated that:

- connector registration does not enable the connector;
- enabling requires explicit actor and reason;
- missing required secrets block invocation;
- WRITE capabilities cannot opt out of action approval;
- approval is bound to connector, capability and exact payload digest;
- changed payloads are rejected;
- approvals cannot be reused;
- local rate limits are enforced;
- secret values are not persisted in the connector database;
- raw invocation payloads are not persisted;
- executable handlers are process-local and must be reloaded after restart;
- API mutation endpoints require bearer authentication;
- no generic HTTP connector invocation endpoint exists in v4.4.

## Tests

- New v4.4 tests: 11 passed
- Focused v4.0–v4.4 tests: 53 passed
- Full collected suite: 547 tests
- Full regression result: 547 passed, 0 failed
- `python -m compileall -q .`: PASS

## Known limitations

- Real provider adapters are not included yet.
- No provider OAuth flow or OS credential vault is implemented yet.
- Local connector rate limits do not replace provider-side limits.
- Docker/Podman availability remains environment-dependent and is not implied by this release.
- Connector framework controls authorization boundaries but cannot make unreviewed connector code trustworthy.

## Package-final verification

The distribution ZIP was extracted into a clean directory and revalidated from the extracted copy:

- root/versioned tests: 210 passed;
- `tests/` groups: 78 + 73 + 85 + 101 passed;
- total collected tests: 547;
- total result: 547 passed, 0 failed;
- `compileall`: PASS;
- `rabidanti.py status`: PASS;
- `rabidanti.py connector list`: PASS and returns an empty list by default, confirming no bundled connector activation.
