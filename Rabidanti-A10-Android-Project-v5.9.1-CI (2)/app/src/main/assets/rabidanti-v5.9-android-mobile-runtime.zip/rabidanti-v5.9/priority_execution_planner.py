"""Rabidanti v3.59 — intelligence-priority aware execution planning."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Mapping

from execution_planner import ExecutionPlanner, ExecutionPlan, PlannedItem
from intelligence_prioritization import PriorityDecision


@dataclass(frozen=True)
class PriorityPlannedItem(PlannedItem):
    """Execution item optionally enriched with an intelligence decision."""
    intelligence_score: float | None = None
    intelligence_band: int | None = None


class PriorityAwareExecutionPlanner(ExecutionPlanner):
    """Use validated intelligence decisions to orient eligible work selection.

    Intelligence priority is advisory: readiness, dependencies, capacity and the
    durable queue claim remain authoritative execution gates.
    """

    def plan_with_decisions(
        self,
        items: Iterable[PlannedItem],
        available_slots: int,
        decisions: Mapping[str, PriorityDecision] | Iterable[PriorityDecision],
        now: float | None = None,
    ) -> ExecutionPlan:
        if isinstance(decisions, Mapping):
            by_id = dict(decisions)
        else:
            by_id = {d.candidate_id: d for d in decisions}
        enriched: list[PriorityPlannedItem] = []
        for item in items:
            decision = by_id.get(item.item_id)
            if decision is None:
                enriched.append(PriorityPlannedItem(item.item_id, item.priority, item.ready, item.dependencies_satisfied))
            else:
                enriched.append(PriorityPlannedItem(
                    item.item_id,
                    item.priority,
                    item.ready,
                    item.dependencies_satisfied,
                    decision.score,
                    int(decision.band),
                ))
        return self._plan_priority(enriched, available_slots, now=now)

    def _plan_priority(
        self, items: list[PriorityPlannedItem], available_slots: int, now: float | None = None
    ) -> ExecutionPlan:
        # Keep the base planner's validation/capacity/reason semantics, while
        # replacing only the eligible ordering with intelligence score first.
        if available_slots < 0:
            raise ValueError("available_slots must be >= 0")
        import time
        now = time.time() if now is None else float(now)
        eligible = [x for x in items if x.ready and x.dependencies_satisfied]
        eligible.sort(key=lambda x: (
            -(x.intelligence_score if x.intelligence_score is not None else -1.0),
            -(x.intelligence_band if x.intelligence_band is not None else 0),
            -x.priority,
            x.item_id,
        ))
        selected = tuple(x.item_id for x in eligible[:available_slots])
        selected_set = set(selected)
        deferred = tuple(x.item_id for x in items if x.item_id not in selected_set)
        forecast_recommendation = None
        try:
            forecast_recommendation = self.capacity.forecast(now=now).recommendation
        except RuntimeError:
            pass
        if available_slots == 0:
            reason = "NO_CAPACITY"
        elif not eligible:
            reason = "NO_ELIGIBLE_WORK"
        elif len(selected) < len(eligible):
            reason = "CAPACITY_BOUND"
        else:
            reason = "INTELLIGENCE_PRIORITY_ORDER"
        return ExecutionPlan(now, available_slots, selected, deferred, reason, forecast_recommendation)
