# Rabidanti v3.97 — Laboratory Human Review & Decision Workflow

## Purpose
v3.97 formalizes the human governance step after the v3.96 evidence-readiness gate.

## Flow
Experiment → Runs → Analyses → Reproducibility → Evidence Memory → Readiness Gate → **Human Review**

Only a `READY_FOR_HUMAN_REVIEW` readiness assessment can open a review.

## Decisions
A human reviewer may record exactly one immutable final decision for a readiness snapshot:

- `APPROVED`
- `REJECTED`
- `MORE_EVIDENCE_REQUIRED`

Each review stores the asserted reviewer identity, rationale, timestamp, readiness identifier and evidence snapshot digest. The decision is also persisted as a `DECISION` node in Evidence Memory and linked to the readiness assessment and experiment.

## Safety boundary
Human review in this module is a governance record only. It never sets scientific validation, Core integration authorization or external-action authorization to true. Reviewer identity is recorded but is not cryptographically authenticated by this module.

A new evidence snapshot produces a new readiness assessment and therefore can enter a new review while preserving prior decisions.
