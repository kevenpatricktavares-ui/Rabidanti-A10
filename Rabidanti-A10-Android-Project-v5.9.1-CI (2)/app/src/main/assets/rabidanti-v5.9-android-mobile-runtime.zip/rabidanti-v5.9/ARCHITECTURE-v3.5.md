# Rabidanti v3.5 — Scheduler & Continuous Execution

v3.5 adds a deterministic scheduler foundation for one-shot and recurring
tasks. SchedulerLoop converts due tasks into queue submissions while preserving
the existing job/worker execution layers.

This is not yet a distributed scheduler or cloud deployment. Persistent
scheduler storage, leader election, distributed locks, autoscaling and
production monitoring remain future infrastructure work.
