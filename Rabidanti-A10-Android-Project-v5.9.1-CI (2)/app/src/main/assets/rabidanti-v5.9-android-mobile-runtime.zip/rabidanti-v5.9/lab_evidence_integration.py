"""Rabidanti v3.95 — Laboratory Evidence Memory integration.

Bridges the experiment ledger (v3.85+), execution pipeline (v3.91), result
analysis (v3.92), reproducibility assessment (v3.93), and evidence memory
(v3.94). The bridge records provenance only. It does not establish scientific
truth and never authorizes execution or integration into the Core.
"""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
import json


class LabEvidenceIntegration:
    """Synchronize laboratory records into :class:`LabEvidenceMemory`.

    Node identifiers are deterministic and derived from the authoritative
    laboratory identifiers. This makes repeated synchronization idempotent and
    preserves provenance without creating duplicate evidence nodes or links.
    """

    def __init__(self, experiment_manager, evidence_memory):
        if experiment_manager is None or evidence_memory is None:
            raise ValueError("experiment_manager and evidence_memory are required")
        self.manager = experiment_manager
        self.memory = evidence_memory

    @staticmethod
    def _canonical(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)

    @staticmethod
    def _experiment_node_id(experiment_id):
        return f"experiment:{experiment_id}"

    @staticmethod
    def _run_node_id(run_id):
        return f"run:{run_id}"

    @staticmethod
    def _analysis_node_id(analysis_id):
        return f"analysis:{analysis_id}"

    @staticmethod
    def _repro_node_id(reproducibility_id):
        return f"reproducibility:{reproducibility_id}"

    def _ensure_node(self, kind, node_id, title, description, payload):
        try:
            existing = self.memory.get_node(node_id)
        except KeyError:
            return self.memory.add_node(
                kind,
                title,
                description,
                node_id=node_id,
                content=self._canonical(payload),
                metadata=payload,
            )
        if existing["kind"] != kind:
            raise ValueError(f"evidence node {node_id} exists with incompatible kind")
        return existing

    def _ensure_link(self, from_id, relation, to_id, *, note=""):
        trace = self.memory.trace(from_id)
        for link in trace["links"]:
            if (
                link["from_id"] == from_id
                and link["relation"] == relation
                and link["to_id"] == to_id
            ):
                return link
        return self.memory.link(from_id, relation, to_id, note=note)

    def ensure_experiment(self, experiment_id):
        exp = self.manager.get(experiment_id)
        payload = asdict(exp) if is_dataclass(exp) else dict(exp)
        node_id = self._experiment_node_id(experiment_id)
        return self._ensure_node(
            "EXPERIMENT",
            node_id,
            payload.get("title") or experiment_id,
            payload.get("hypothesis", ""),
            {"record_type": "experiment", **payload},
        )

    def record_run(self, experiment_id, run):
        if not isinstance(run, dict):
            raise ValueError("run must be a dictionary")
        run_id = run.get("run_id")
        if not isinstance(run_id, str) or not run_id.strip():
            raise ValueError("run_id is required")
        exp_node = self.ensure_experiment(experiment_id)
        payload = {"record_type": "run", **run}
        node = self._ensure_node(
            "RUN", self._run_node_id(run_id), f"Run {run_id}",
            f"Laboratory execution status: {run.get('status', 'unknown')}", payload,
        )
        self._ensure_link(exp_node["node_id"], "EXECUTED_AS", node["node_id"], note="Experiment execution record")
        return node

    def record_analysis(self, experiment_id, report):
        if not isinstance(report, dict):
            raise ValueError("report must be a dictionary")
        analysis_id = report.get("analysis_id")
        run_id = report.get("run_id")
        if not isinstance(analysis_id, str) or not analysis_id.strip():
            raise ValueError("analysis_id is required")
        if not isinstance(run_id, str) or not run_id.strip():
            raise ValueError("analysis run_id is required")
        exp_node = self.ensure_experiment(experiment_id)
        # Ensure the authoritative run exists in evidence, recovering it from
        # the experiment ledger during synchronization when necessary.
        run_node_id = self._run_node_id(run_id)
        try:
            self.memory.get_node(run_node_id)
        except KeyError:
            entries = [e for e in self.manager.list_entries(experiment_id, "RESULT") if e["metadata"].get("run_id") == run_id]
            if not entries:
                raise ValueError(f"no recorded execution result exists for run {run_id}")
            self.record_run(experiment_id, entries[-1]["metadata"])
        payload = {"record_type": "analysis", **report}
        node = self._ensure_node(
            "ANALYSIS", self._analysis_node_id(analysis_id), f"Analysis {analysis_id}",
            f"Result classification: {report.get('classification', 'unknown')}", payload,
        )
        self._ensure_link(exp_node["node_id"], "HAS_ANALYSIS", node["node_id"], note="Human-reviewed result analysis")
        self._ensure_link(run_node_id, "ANALYZED_BY", node["node_id"], note="Analysis of recorded run")
        return node

    def record_reproducibility(self, experiment_id, report):
        if not isinstance(report, dict):
            raise ValueError("report must be a dictionary")
        repro_id = report.get("reproducibility_id")
        run_ids = report.get("run_ids")
        if not isinstance(repro_id, str) or not repro_id.strip():
            raise ValueError("reproducibility_id is required")
        if not isinstance(run_ids, list) or not run_ids or any(not isinstance(x, str) or not x.strip() for x in run_ids):
            raise ValueError("reproducibility run_ids are required")
        exp_node = self.ensure_experiment(experiment_id)
        for run_id in run_ids:
            run_node_id = self._run_node_id(run_id)
            try:
                self.memory.get_node(run_node_id)
            except KeyError:
                entries = [e for e in self.manager.list_entries(experiment_id, "RESULT") if e["metadata"].get("run_id") == run_id]
                if not entries:
                    raise ValueError(f"no recorded execution result exists for run {run_id}")
                self.record_run(experiment_id, entries[-1]["metadata"])
        payload = {"record_type": "reproducibility", **report}
        node = self._ensure_node(
            "ANALYSIS", self._repro_node_id(repro_id), f"Reproducibility {repro_id}",
            f"Reproducibility classification: {report.get('classification', 'unknown')}", payload,
        )
        self._ensure_link(exp_node["node_id"], "HAS_REPRODUCIBILITY", node["node_id"], note="Repeat-run consistency assessment")
        for run_id in run_ids:
            self._ensure_link(node["node_id"], "COMPARES_RUN", self._run_node_id(run_id), note="Run included in reproducibility assessment")
        return node

    def sync_experiment(self, experiment_id):
        """Idempotently synchronize existing lab records for one experiment."""
        self.ensure_experiment(experiment_id)
        entries = self.manager.list_entries(experiment_id)
        counts = {"experiment": 1, "runs": 0, "analyses": 0, "reproducibility": 0}
        for entry in entries:
            metadata = entry.get("metadata") or {}
            if entry.get("entry_type") == "RESULT" and metadata.get("run_id"):
                self.record_run(experiment_id, metadata)
                counts["runs"] += 1
        for entry in entries:
            metadata = entry.get("metadata") or {}
            if entry.get("entry_type") != "RECOMMENDATION":
                continue
            if metadata.get("analysis_id"):
                self.record_analysis(experiment_id, metadata)
                counts["analyses"] += 1
            elif metadata.get("reproducibility_id"):
                self.record_reproducibility(experiment_id, metadata)
                counts["reproducibility"] += 1
        return counts

    def history(self, experiment_id):
        """Return the evidence records directly attached to an experiment."""
        node_id = self._experiment_node_id(experiment_id)
        trace = self.memory.trace(node_id)
        records = []
        for link in trace["links"]:
            if link["from_id"] != node_id:
                continue
            records.append({
                "relation": link["relation"],
                "node_id": link["to_id"],
                "kind": link["other_kind"],
                "title": link["other_title"],
                "metadata": link["other_metadata"],
                "created_at": link["created_at"],
            })
        records.sort(key=lambda x: (x["created_at"], x["node_id"]))
        return {
            "experiment_id": experiment_id,
            "experiment_node_id": node_id,
            "records": records,
            "trace_digest": trace["trace_digest"],
            "integration_authorized": False,
            "limitation": "Evidence history preserves provenance; it does not independently validate scientific truth.",
        }
